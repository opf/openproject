--
-- PostgreSQL database dump
--

-- Dumped from database version 13.11 (Debian 13.11-1.pgdg110+1)
-- Dumped by pg_dump version 13.11 (Debian 13.11-1.pgdg110+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: delayed_job_status; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.delayed_job_status AS ENUM (
    'in_queue',
    'error',
    'in_process',
    'success',
    'failure',
    'cancelled'
);


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: announcements; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.announcements (
    id bigint NOT NULL,
    text text,
    show_until date,
    active boolean DEFAULT false,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


--
-- Name: announcements_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.announcements_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: announcements_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.announcements_id_seq OWNED BY public.announcements.id;


--
-- Name: ar_internal_metadata; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ar_internal_metadata (
    key character varying NOT NULL,
    value character varying,
    created_at timestamp(6) with time zone NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL
);


--
-- Name: attachable_journals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.attachable_journals (
    id bigint NOT NULL,
    journal_id bigint NOT NULL,
    attachment_id bigint NOT NULL,
    filename character varying NOT NULL
);


--
-- Name: attachable_journals_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.attachable_journals_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: attachable_journals_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.attachable_journals_id_seq OWNED BY public.attachable_journals.id;


--
-- Name: attachment_journals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.attachment_journals (
    id bigint NOT NULL,
    container_id bigint,
    container_type character varying(30),
    filename character varying NOT NULL,
    disk_filename character varying NOT NULL,
    filesize bigint NOT NULL,
    content_type character varying,
    digest character varying(40) NOT NULL,
    downloads integer NOT NULL,
    author_id bigint NOT NULL,
    description text
);


--
-- Name: attachment_journals_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.attachment_journals_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: attachment_journals_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.attachment_journals_id_seq OWNED BY public.attachment_journals.id;


--
-- Name: attachments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.attachments (
    id bigint NOT NULL,
    container_id bigint,
    container_type character varying(30),
    filename character varying DEFAULT ''::character varying NOT NULL,
    disk_filename character varying DEFAULT ''::character varying NOT NULL,
    filesize bigint DEFAULT 0 NOT NULL,
    content_type character varying DEFAULT ''::character varying,
    digest character varying(40) DEFAULT ''::character varying NOT NULL,
    downloads integer DEFAULT 0 NOT NULL,
    author_id bigint NOT NULL,
    created_at timestamp with time zone,
    description character varying,
    file character varying,
    fulltext text,
    fulltext_tsv tsvector,
    file_tsv tsvector,
    updated_at timestamp with time zone
);


--
-- Name: attachments_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.attachments_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: attachments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.attachments_id_seq OWNED BY public.attachments.id;


--
-- Name: attribute_help_texts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.attribute_help_texts (
    id bigint NOT NULL,
    help_text text NOT NULL,
    type character varying NOT NULL,
    attribute_name character varying NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- Name: attribute_help_texts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.attribute_help_texts_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: attribute_help_texts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.attribute_help_texts_id_seq OWNED BY public.attribute_help_texts.id;


--
-- Name: auth_sources; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.auth_sources (
    id bigint NOT NULL,
    type character varying(30) DEFAULT ''::character varying NOT NULL,
    name character varying(60) DEFAULT ''::character varying NOT NULL,
    host character varying(60),
    port integer,
    account character varying,
    account_password character varying DEFAULT ''::character varying,
    base_dn character varying,
    attr_login character varying(30),
    attr_firstname character varying(30),
    attr_lastname character varying(30),
    attr_mail character varying(30),
    onthefly_register boolean DEFAULT false NOT NULL,
    attr_admin character varying,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    tls_mode integer DEFAULT 0 NOT NULL,
    filter_string text,
    verify_peer boolean DEFAULT true NOT NULL,
    tls_certificate_string text
);


--
-- Name: auth_sources_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.auth_sources_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: auth_sources_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.auth_sources_id_seq OWNED BY public.auth_sources.id;


--
-- Name: bcf_comments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.bcf_comments (
    id bigint NOT NULL,
    uuid text,
    journal_id bigint,
    issue_id bigint,
    viewpoint_id bigint,
    reply_to bigint
);


--
-- Name: bcf_comments_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.bcf_comments_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bcf_comments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.bcf_comments_id_seq OWNED BY public.bcf_comments.id;


--
-- Name: bcf_issues; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.bcf_issues (
    id bigint NOT NULL,
    uuid text,
    markup xml,
    work_package_id bigint,
    stage character varying,
    index integer,
    labels text[] DEFAULT '{}'::text[],
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: bcf_issues_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.bcf_issues_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bcf_issues_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.bcf_issues_id_seq OWNED BY public.bcf_issues.id;


--
-- Name: bcf_viewpoints; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.bcf_viewpoints (
    id bigint NOT NULL,
    uuid text,
    viewpoint_name text,
    issue_id bigint,
    json_viewpoint jsonb,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: bcf_viewpoints_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.bcf_viewpoints_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bcf_viewpoints_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.bcf_viewpoints_id_seq OWNED BY public.bcf_viewpoints.id;


--
-- Name: budget_journals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.budget_journals (
    id bigint NOT NULL,
    project_id bigint NOT NULL,
    author_id bigint NOT NULL,
    subject character varying NOT NULL,
    description text,
    fixed_date date NOT NULL
);


--
-- Name: budget_journals_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.budget_journals_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: budget_journals_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.budget_journals_id_seq OWNED BY public.budget_journals.id;


--
-- Name: budgets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.budgets (
    id bigint NOT NULL,
    project_id bigint NOT NULL,
    author_id bigint NOT NULL,
    subject character varying NOT NULL,
    description text NOT NULL,
    fixed_date date NOT NULL,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


--
-- Name: budgets_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.budgets_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: budgets_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.budgets_id_seq OWNED BY public.budgets.id;


--
-- Name: categories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.categories (
    id bigint NOT NULL,
    project_id bigint NOT NULL,
    name character varying(256) DEFAULT ''::character varying NOT NULL,
    assigned_to_id bigint,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- Name: categories_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.categories_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.categories_id_seq OWNED BY public.categories.id;


--
-- Name: changes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.changes (
    id bigint NOT NULL,
    changeset_id bigint NOT NULL,
    action character varying(1) DEFAULT ''::character varying NOT NULL,
    path text NOT NULL,
    from_path text,
    from_revision character varying,
    revision character varying,
    branch character varying
);


--
-- Name: changes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.changes_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: changes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.changes_id_seq OWNED BY public.changes.id;


--
-- Name: changeset_journals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.changeset_journals (
    id bigint NOT NULL,
    repository_id bigint NOT NULL,
    revision character varying NOT NULL,
    committer character varying,
    committed_on timestamp with time zone NOT NULL,
    comments text,
    commit_date date,
    scmid character varying,
    user_id bigint
);


--
-- Name: changeset_journals_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.changeset_journals_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: changeset_journals_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.changeset_journals_id_seq OWNED BY public.changeset_journals.id;


--
-- Name: changesets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.changesets (
    id bigint NOT NULL,
    repository_id bigint NOT NULL,
    revision character varying NOT NULL,
    committer character varying,
    committed_on timestamp with time zone NOT NULL,
    comments text,
    commit_date date,
    scmid character varying,
    user_id bigint
);


--
-- Name: changesets_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.changesets_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: changesets_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.changesets_id_seq OWNED BY public.changesets.id;


--
-- Name: changesets_work_packages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.changesets_work_packages (
    changeset_id bigint NOT NULL,
    work_package_id bigint NOT NULL
);


--
-- Name: colors; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.colors (
    id bigint NOT NULL,
    name character varying NOT NULL,
    hexcode character varying NOT NULL,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


--
-- Name: colors_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.colors_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: colors_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.colors_id_seq OWNED BY public.colors.id;


--
-- Name: comments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.comments (
    id bigint NOT NULL,
    commented_type character varying(30) DEFAULT ''::character varying NOT NULL,
    commented_id bigint NOT NULL,
    author_id bigint NOT NULL,
    comments text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: comments_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.comments_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: comments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.comments_id_seq OWNED BY public.comments.id;


--
-- Name: cost_entries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cost_entries (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    project_id bigint NOT NULL,
    work_package_id bigint NOT NULL,
    cost_type_id bigint NOT NULL,
    units double precision NOT NULL,
    spent_on date NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    comments character varying NOT NULL,
    blocked boolean DEFAULT false NOT NULL,
    overridden_costs numeric(15,4),
    costs numeric(15,4),
    rate_id bigint,
    tyear integer NOT NULL,
    tmonth integer NOT NULL,
    tweek integer NOT NULL,
    logged_by_id bigint
);


--
-- Name: cost_entries_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.cost_entries_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: cost_entries_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.cost_entries_id_seq OWNED BY public.cost_entries.id;


--
-- Name: cost_queries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cost_queries (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    project_id bigint,
    name character varying NOT NULL,
    is_public boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    serialized character varying(2000) NOT NULL
);


--
-- Name: cost_queries_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.cost_queries_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: cost_queries_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.cost_queries_id_seq OWNED BY public.cost_queries.id;


--
-- Name: cost_types; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cost_types (
    id bigint NOT NULL,
    name character varying NOT NULL,
    unit character varying NOT NULL,
    unit_plural character varying NOT NULL,
    "default" boolean DEFAULT false NOT NULL,
    deleted_at timestamp with time zone
);


--
-- Name: cost_types_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.cost_types_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: cost_types_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.cost_types_id_seq OWNED BY public.cost_types.id;


--
-- Name: custom_actions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.custom_actions (
    id bigint NOT NULL,
    name character varying,
    actions text,
    description text,
    "position" integer
);


--
-- Name: custom_actions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.custom_actions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: custom_actions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.custom_actions_id_seq OWNED BY public.custom_actions.id;


--
-- Name: custom_actions_projects; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.custom_actions_projects (
    id bigint NOT NULL,
    project_id bigint,
    custom_action_id bigint
);


--
-- Name: custom_actions_projects_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.custom_actions_projects_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: custom_actions_projects_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.custom_actions_projects_id_seq OWNED BY public.custom_actions_projects.id;


--
-- Name: custom_actions_roles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.custom_actions_roles (
    id bigint NOT NULL,
    role_id bigint,
    custom_action_id bigint
);


--
-- Name: custom_actions_roles_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.custom_actions_roles_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: custom_actions_roles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.custom_actions_roles_id_seq OWNED BY public.custom_actions_roles.id;


--
-- Name: custom_actions_statuses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.custom_actions_statuses (
    id bigint NOT NULL,
    status_id bigint,
    custom_action_id bigint
);


--
-- Name: custom_actions_statuses_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.custom_actions_statuses_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: custom_actions_statuses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.custom_actions_statuses_id_seq OWNED BY public.custom_actions_statuses.id;


--
-- Name: custom_actions_types; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.custom_actions_types (
    id bigint NOT NULL,
    type_id bigint,
    custom_action_id bigint
);


--
-- Name: custom_actions_types_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.custom_actions_types_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: custom_actions_types_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.custom_actions_types_id_seq OWNED BY public.custom_actions_types.id;


--
-- Name: custom_fields; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.custom_fields (
    id bigint NOT NULL,
    type character varying(30) DEFAULT ''::character varying NOT NULL,
    field_format character varying(30) DEFAULT ''::character varying NOT NULL,
    regexp character varying DEFAULT ''::character varying,
    min_length integer DEFAULT 0 NOT NULL,
    max_length integer DEFAULT 0 NOT NULL,
    is_required boolean DEFAULT false NOT NULL,
    is_for_all boolean DEFAULT false NOT NULL,
    is_filter boolean DEFAULT false NOT NULL,
    "position" integer DEFAULT 1,
    searchable boolean DEFAULT false,
    editable boolean DEFAULT true,
    visible boolean DEFAULT true NOT NULL,
    multi_value boolean DEFAULT false,
    default_value text,
    name character varying DEFAULT NULL::character varying,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    content_right_to_left boolean DEFAULT false
);


--
-- Name: custom_fields_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.custom_fields_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: custom_fields_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.custom_fields_id_seq OWNED BY public.custom_fields.id;


--
-- Name: custom_fields_projects; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.custom_fields_projects (
    custom_field_id bigint NOT NULL,
    project_id bigint NOT NULL
);


--
-- Name: custom_fields_types; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.custom_fields_types (
    custom_field_id bigint NOT NULL,
    type_id bigint NOT NULL
);


--
-- Name: custom_options; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.custom_options (
    id bigint NOT NULL,
    custom_field_id bigint,
    "position" integer,
    default_value boolean,
    value text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


--
-- Name: custom_options_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.custom_options_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: custom_options_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.custom_options_id_seq OWNED BY public.custom_options.id;


--
-- Name: custom_styles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.custom_styles (
    id bigint NOT NULL,
    logo character varying,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    favicon character varying,
    touch_icon character varying,
    theme character varying DEFAULT 'OpenProject'::character varying,
    theme_logo character varying
);


--
-- Name: custom_styles_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.custom_styles_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: custom_styles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.custom_styles_id_seq OWNED BY public.custom_styles.id;


--
-- Name: custom_values; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.custom_values (
    id bigint NOT NULL,
    customized_type character varying(30) DEFAULT ''::character varying NOT NULL,
    customized_id bigint NOT NULL,
    custom_field_id bigint NOT NULL,
    value text
);


--
-- Name: custom_values_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.custom_values_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: custom_values_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.custom_values_id_seq OWNED BY public.custom_values.id;


--
-- Name: customizable_journals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.customizable_journals (
    id bigint NOT NULL,
    journal_id bigint NOT NULL,
    custom_field_id bigint NOT NULL,
    value text
);


--
-- Name: customizable_journals_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.customizable_journals_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: customizable_journals_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.customizable_journals_id_seq OWNED BY public.customizable_journals.id;


--
-- Name: delayed_job_statuses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.delayed_job_statuses (
    id bigint NOT NULL,
    reference_type character varying,
    reference_id bigint,
    message character varying,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    status public.delayed_job_status DEFAULT 'in_queue'::public.delayed_job_status,
    user_id bigint,
    job_id character varying,
    payload jsonb
);


--
-- Name: delayed_job_statuses_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.delayed_job_statuses_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: delayed_job_statuses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.delayed_job_statuses_id_seq OWNED BY public.delayed_job_statuses.id;


--
-- Name: delayed_jobs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.delayed_jobs (
    id bigint NOT NULL,
    priority integer DEFAULT 0,
    attempts integer DEFAULT 0,
    handler text,
    last_error text,
    run_at timestamp with time zone,
    locked_at timestamp with time zone,
    failed_at timestamp with time zone,
    locked_by character varying,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    queue character varying,
    cron character varying
);


--
-- Name: delayed_jobs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.delayed_jobs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: delayed_jobs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.delayed_jobs_id_seq OWNED BY public.delayed_jobs.id;


--
-- Name: design_colors; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.design_colors (
    id bigint NOT NULL,
    variable character varying,
    hexcode character varying,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- Name: design_colors_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.design_colors_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: design_colors_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.design_colors_id_seq OWNED BY public.design_colors.id;


--
-- Name: document_journals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.document_journals (
    id bigint NOT NULL,
    project_id bigint NOT NULL,
    category_id bigint NOT NULL,
    title character varying(60) NOT NULL,
    description text
);


--
-- Name: document_journals_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.document_journals_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: document_journals_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.document_journals_id_seq OWNED BY public.document_journals.id;


--
-- Name: documents; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.documents (
    id bigint NOT NULL,
    project_id bigint NOT NULL,
    category_id bigint NOT NULL,
    title character varying(60) DEFAULT ''::character varying NOT NULL,
    description text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


--
-- Name: documents_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.documents_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: documents_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.documents_id_seq OWNED BY public.documents.id;


--
-- Name: done_statuses_for_project; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.done_statuses_for_project (
    project_id bigint,
    status_id bigint
);


--
-- Name: enabled_modules; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.enabled_modules (
    id bigint NOT NULL,
    project_id bigint,
    name character varying NOT NULL
);


--
-- Name: enabled_modules_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.enabled_modules_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: enabled_modules_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.enabled_modules_id_seq OWNED BY public.enabled_modules.id;


--
-- Name: enterprise_tokens; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.enterprise_tokens (
    id bigint NOT NULL,
    encoded_token text,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- Name: enterprise_tokens_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.enterprise_tokens_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: enterprise_tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.enterprise_tokens_id_seq OWNED BY public.enterprise_tokens.id;


--
-- Name: enumerations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.enumerations (
    id bigint NOT NULL,
    name character varying(30) DEFAULT ''::character varying NOT NULL,
    "position" integer DEFAULT 1,
    is_default boolean DEFAULT false NOT NULL,
    type character varying,
    active boolean DEFAULT true NOT NULL,
    project_id bigint,
    parent_id bigint,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    color_id bigint
);


--
-- Name: enumerations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.enumerations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: enumerations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.enumerations_id_seq OWNED BY public.enumerations.id;


--
-- Name: export_card_configurations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.export_card_configurations (
    id bigint NOT NULL,
    name character varying,
    per_page integer,
    page_size character varying,
    orientation character varying,
    rows text,
    active boolean DEFAULT true,
    description text
);


--
-- Name: export_card_configurations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.export_card_configurations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: export_card_configurations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.export_card_configurations_id_seq OWNED BY public.export_card_configurations.id;


--
-- Name: exports; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.exports (
    id bigint NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    type character varying
);


--
-- Name: exports_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.exports_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: exports_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.exports_id_seq OWNED BY public.exports.id;


--
-- Name: file_links; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.file_links (
    id bigint NOT NULL,
    storage_id bigint,
    creator_id bigint NOT NULL,
    container_id bigint,
    container_type character varying,
    origin_id character varying,
    origin_name character varying,
    origin_created_by_name character varying,
    origin_last_modified_by_name character varying,
    origin_mime_type character varying,
    origin_created_at timestamp with time zone,
    origin_updated_at timestamp with time zone,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- Name: file_links_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.file_links_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: file_links_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.file_links_id_seq OWNED BY public.file_links.id;


--
-- Name: forums; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.forums (
    id bigint NOT NULL,
    project_id bigint NOT NULL,
    name character varying DEFAULT ''::character varying NOT NULL,
    description character varying,
    "position" integer DEFAULT 1,
    topics_count integer DEFAULT 0 NOT NULL,
    messages_count integer DEFAULT 0 NOT NULL,
    last_message_id bigint
);


--
-- Name: forums_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.forums_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: forums_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.forums_id_seq OWNED BY public.forums.id;


--
-- Name: github_check_runs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.github_check_runs (
    id bigint NOT NULL,
    github_pull_request_id bigint NOT NULL,
    github_id bigint NOT NULL,
    github_html_url character varying NOT NULL,
    app_id bigint NOT NULL,
    github_app_owner_avatar_url character varying NOT NULL,
    status character varying NOT NULL,
    name character varying NOT NULL,
    conclusion character varying,
    output_title character varying,
    output_summary character varying,
    details_url character varying,
    started_at timestamp with time zone,
    completed_at timestamp with time zone,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- Name: github_check_runs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.github_check_runs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: github_check_runs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.github_check_runs_id_seq OWNED BY public.github_check_runs.id;


--
-- Name: github_pull_requests; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.github_pull_requests (
    id bigint NOT NULL,
    github_user_id bigint,
    merged_by_id bigint,
    github_id bigint,
    number integer NOT NULL,
    github_html_url character varying NOT NULL,
    state character varying NOT NULL,
    repository character varying NOT NULL,
    github_updated_at timestamp with time zone,
    title character varying,
    body text,
    draft boolean,
    merged boolean,
    merged_at timestamp with time zone,
    comments_count integer,
    review_comments_count integer,
    additions_count integer,
    deletions_count integer,
    changed_files_count integer,
    labels json,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- Name: github_pull_requests_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.github_pull_requests_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: github_pull_requests_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.github_pull_requests_id_seq OWNED BY public.github_pull_requests.id;


--
-- Name: github_pull_requests_work_packages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.github_pull_requests_work_packages (
    github_pull_request_id bigint NOT NULL,
    work_package_id bigint NOT NULL
);


--
-- Name: github_users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.github_users (
    id bigint NOT NULL,
    github_id bigint NOT NULL,
    github_login character varying NOT NULL,
    github_html_url character varying NOT NULL,
    github_avatar_url character varying NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- Name: github_users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.github_users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: github_users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.github_users_id_seq OWNED BY public.github_users.id;


--
-- Name: grid_widgets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.grid_widgets (
    id bigint NOT NULL,
    start_row integer NOT NULL,
    end_row integer NOT NULL,
    start_column integer NOT NULL,
    end_column integer NOT NULL,
    identifier character varying,
    options text,
    grid_id bigint
);


--
-- Name: grid_widgets_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.grid_widgets_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: grid_widgets_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.grid_widgets_id_seq OWNED BY public.grid_widgets.id;


--
-- Name: grids; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.grids (
    id bigint NOT NULL,
    row_count integer NOT NULL,
    column_count integer NOT NULL,
    type character varying,
    user_id bigint,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    project_id bigint,
    name text,
    options text
);


--
-- Name: grids_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.grids_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: grids_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.grids_id_seq OWNED BY public.grids.id;


--
-- Name: group_users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.group_users (
    group_id bigint NOT NULL,
    user_id bigint NOT NULL,
    id bigint NOT NULL
);


--
-- Name: group_users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.group_users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: group_users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.group_users_id_seq OWNED BY public.group_users.id;


--
-- Name: ifc_models; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ifc_models (
    id bigint NOT NULL,
    title character varying,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    project_id bigint,
    uploader_id bigint,
    is_default boolean DEFAULT false NOT NULL,
    conversion_status integer DEFAULT 0,
    conversion_error_message text
);


--
-- Name: ifc_models_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ifc_models_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ifc_models_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.ifc_models_id_seq OWNED BY public.ifc_models.id;


--
-- Name: journals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.journals (
    id bigint NOT NULL,
    journable_type character varying,
    journable_id bigint,
    user_id bigint NOT NULL,
    notes text,
    created_at timestamp with time zone NOT NULL,
    version integer DEFAULT 0 NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    data_type character varying NOT NULL,
    data_id bigint NOT NULL
);


--
-- Name: journals_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.journals_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: journals_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.journals_id_seq OWNED BY public.journals.id;


--
-- Name: labor_budget_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.labor_budget_items (
    id bigint NOT NULL,
    budget_id bigint NOT NULL,
    hours double precision NOT NULL,
    user_id bigint,
    comments character varying DEFAULT ''::character varying NOT NULL,
    amount numeric(15,4)
);


--
-- Name: labor_budget_items_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.labor_budget_items_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: labor_budget_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.labor_budget_items_id_seq OWNED BY public.labor_budget_items.id;


--
-- Name: ldap_groups_memberships; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ldap_groups_memberships (
    id bigint NOT NULL,
    user_id bigint,
    group_id bigint,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: ldap_groups_memberships_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ldap_groups_memberships_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ldap_groups_memberships_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.ldap_groups_memberships_id_seq OWNED BY public.ldap_groups_memberships.id;


--
-- Name: ldap_groups_synchronized_filters; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ldap_groups_synchronized_filters (
    id bigint NOT NULL,
    name character varying,
    group_name_attribute character varying,
    filter_string character varying,
    auth_source_id bigint,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    base_dn text,
    sync_users boolean DEFAULT false NOT NULL
);


--
-- Name: ldap_groups_synchronized_filters_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ldap_groups_synchronized_filters_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ldap_groups_synchronized_filters_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.ldap_groups_synchronized_filters_id_seq OWNED BY public.ldap_groups_synchronized_filters.id;


--
-- Name: ldap_groups_synchronized_groups; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ldap_groups_synchronized_groups (
    id bigint NOT NULL,
    group_id bigint,
    auth_source_id bigint,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    dn text,
    users_count integer DEFAULT 0 NOT NULL,
    filter_id bigint,
    sync_users boolean DEFAULT false NOT NULL
);


--
-- Name: ldap_groups_synchronized_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ldap_groups_synchronized_groups_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ldap_groups_synchronized_groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.ldap_groups_synchronized_groups_id_seq OWNED BY public.ldap_groups_synchronized_groups.id;


--
-- Name: material_budget_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.material_budget_items (
    id bigint NOT NULL,
    budget_id bigint NOT NULL,
    units double precision NOT NULL,
    cost_type_id bigint,
    comments character varying DEFAULT ''::character varying NOT NULL,
    amount numeric(15,4)
);


--
-- Name: material_budget_items_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.material_budget_items_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: material_budget_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.material_budget_items_id_seq OWNED BY public.material_budget_items.id;


--
-- Name: meeting_content_journals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.meeting_content_journals (
    id bigint NOT NULL,
    meeting_id bigint,
    author_id bigint,
    text text,
    locked boolean
);


--
-- Name: meeting_content_journals_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.meeting_content_journals_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: meeting_content_journals_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.meeting_content_journals_id_seq OWNED BY public.meeting_content_journals.id;


--
-- Name: meeting_contents; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.meeting_contents (
    id bigint NOT NULL,
    type character varying,
    meeting_id bigint,
    author_id bigint,
    text text,
    lock_version integer,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    locked boolean DEFAULT false
);


--
-- Name: meeting_contents_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.meeting_contents_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: meeting_contents_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.meeting_contents_id_seq OWNED BY public.meeting_contents.id;


--
-- Name: meeting_journals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.meeting_journals (
    id bigint NOT NULL,
    title character varying,
    author_id bigint,
    project_id bigint,
    location character varying,
    start_time timestamp with time zone,
    duration double precision
);


--
-- Name: meeting_journals_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.meeting_journals_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: meeting_journals_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.meeting_journals_id_seq OWNED BY public.meeting_journals.id;


--
-- Name: meeting_participants; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.meeting_participants (
    id bigint NOT NULL,
    user_id bigint,
    meeting_id bigint,
    email character varying,
    name character varying,
    invited boolean,
    attended boolean,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- Name: meeting_participants_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.meeting_participants_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: meeting_participants_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.meeting_participants_id_seq OWNED BY public.meeting_participants.id;


--
-- Name: meetings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.meetings (
    id bigint NOT NULL,
    title character varying,
    author_id bigint,
    project_id bigint,
    location character varying,
    start_time timestamp with time zone,
    duration double precision,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- Name: meetings_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.meetings_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: meetings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.meetings_id_seq OWNED BY public.meetings.id;


--
-- Name: member_roles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.member_roles (
    id bigint NOT NULL,
    member_id bigint NOT NULL,
    role_id bigint NOT NULL,
    inherited_from bigint
);


--
-- Name: member_roles_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.member_roles_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: member_roles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.member_roles_id_seq OWNED BY public.member_roles.id;


--
-- Name: members; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.members (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    project_id bigint,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: members_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.members_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: members_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.members_id_seq OWNED BY public.members.id;


--
-- Name: menu_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.menu_items (
    id bigint NOT NULL,
    name character varying,
    title character varying,
    parent_id bigint,
    options text,
    navigatable_id bigint,
    type character varying
);


--
-- Name: menu_items_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.menu_items_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: menu_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.menu_items_id_seq OWNED BY public.menu_items.id;


--
-- Name: message_journals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.message_journals (
    id bigint NOT NULL,
    forum_id bigint NOT NULL,
    parent_id bigint,
    subject character varying NOT NULL,
    content text,
    author_id bigint,
    locked boolean,
    sticky integer
);


--
-- Name: message_journals_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.message_journals_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: message_journals_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.message_journals_id_seq OWNED BY public.message_journals.id;


--
-- Name: messages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.messages (
    id bigint NOT NULL,
    forum_id bigint NOT NULL,
    parent_id bigint,
    subject character varying DEFAULT ''::character varying NOT NULL,
    content text,
    author_id bigint,
    replies_count integer DEFAULT 0 NOT NULL,
    last_reply_id bigint,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    locked boolean DEFAULT false,
    sticky integer DEFAULT 0,
    sticked_on timestamp with time zone
);


--
-- Name: messages_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.messages_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: messages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.messages_id_seq OWNED BY public.messages.id;


--
-- Name: news; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.news (
    id bigint NOT NULL,
    project_id bigint,
    title character varying(60) DEFAULT ''::character varying NOT NULL,
    summary character varying DEFAULT ''::character varying,
    description text,
    author_id bigint NOT NULL,
    created_at timestamp with time zone,
    comments_count integer DEFAULT 0 NOT NULL,
    updated_at timestamp with time zone
);


--
-- Name: news_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.news_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: news_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.news_id_seq OWNED BY public.news.id;


--
-- Name: news_journals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.news_journals (
    id bigint NOT NULL,
    project_id bigint,
    title character varying(60) NOT NULL,
    summary character varying,
    description text,
    author_id bigint NOT NULL,
    comments_count integer NOT NULL
);


--
-- Name: news_journals_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.news_journals_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: news_journals_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.news_journals_id_seq OWNED BY public.news_journals.id;


--
-- Name: non_working_days; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.non_working_days (
    id bigint NOT NULL,
    name character varying NOT NULL,
    date date NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- Name: non_working_days_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.non_working_days_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: non_working_days_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.non_working_days_id_seq OWNED BY public.non_working_days.id;


--
-- Name: notification_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notification_settings (
    id bigint NOT NULL,
    project_id bigint,
    user_id bigint NOT NULL,
    watched boolean DEFAULT true,
    mentioned boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    work_package_commented boolean DEFAULT false,
    work_package_created boolean DEFAULT false,
    work_package_processed boolean DEFAULT false,
    work_package_prioritized boolean DEFAULT false,
    work_package_scheduled boolean DEFAULT false,
    news_added boolean DEFAULT false,
    news_commented boolean DEFAULT false,
    document_added boolean DEFAULT false,
    forum_messages boolean DEFAULT false,
    wiki_page_added boolean DEFAULT false,
    wiki_page_updated boolean DEFAULT false,
    membership_added boolean DEFAULT false,
    membership_updated boolean DEFAULT false,
    start_date integer DEFAULT 1,
    due_date integer DEFAULT 1,
    overdue integer,
    assignee boolean DEFAULT true NOT NULL,
    responsible boolean DEFAULT true NOT NULL
);


--
-- Name: notification_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.notification_settings_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: notification_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.notification_settings_id_seq OWNED BY public.notification_settings.id;


--
-- Name: notifications; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notifications (
    id bigint NOT NULL,
    subject text,
    read_ian boolean DEFAULT false,
    reason smallint,
    recipient_id bigint NOT NULL,
    actor_id bigint,
    resource_type character varying NOT NULL,
    resource_id bigint NOT NULL,
    project_id bigint,
    journal_id bigint,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    mail_reminder_sent boolean DEFAULT false,
    mail_alert_sent boolean
);


--
-- Name: notifications_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.notifications_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: notifications_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.notifications_id_seq OWNED BY public.notifications.id;


--
-- Name: oauth_access_grants; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.oauth_access_grants (
    id bigint NOT NULL,
    resource_owner_id bigint NOT NULL,
    application_id bigint NOT NULL,
    token character varying NOT NULL,
    expires_in integer NOT NULL,
    redirect_uri text NOT NULL,
    created_at timestamp with time zone NOT NULL,
    revoked_at timestamp with time zone,
    scopes character varying,
    code_challenge character varying,
    code_challenge_method character varying
);


--
-- Name: oauth_access_grants_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.oauth_access_grants_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: oauth_access_grants_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.oauth_access_grants_id_seq OWNED BY public.oauth_access_grants.id;


--
-- Name: oauth_access_tokens; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.oauth_access_tokens (
    id bigint NOT NULL,
    resource_owner_id bigint,
    application_id bigint,
    token character varying NOT NULL,
    refresh_token character varying,
    expires_in integer,
    revoked_at timestamp with time zone,
    created_at timestamp with time zone NOT NULL,
    scopes character varying,
    previous_refresh_token character varying DEFAULT ''::character varying NOT NULL
);


--
-- Name: oauth_access_tokens_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.oauth_access_tokens_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: oauth_access_tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.oauth_access_tokens_id_seq OWNED BY public.oauth_access_tokens.id;


--
-- Name: oauth_applications; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.oauth_applications (
    id bigint NOT NULL,
    name character varying NOT NULL,
    uid character varying NOT NULL,
    secret character varying NOT NULL,
    owner_type character varying,
    owner_id bigint,
    client_credentials_user_id bigint,
    redirect_uri text NOT NULL,
    scopes character varying DEFAULT ''::character varying NOT NULL,
    confidential boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    integration_type character varying,
    integration_id bigint
);


--
-- Name: oauth_applications_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.oauth_applications_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: oauth_applications_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.oauth_applications_id_seq OWNED BY public.oauth_applications.id;


--
-- Name: oauth_client_tokens; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.oauth_client_tokens (
    id bigint NOT NULL,
    oauth_client_id bigint NOT NULL,
    user_id bigint NOT NULL,
    access_token character varying,
    refresh_token character varying,
    token_type character varying,
    expires_in integer,
    scope character varying,
    origin_user_id character varying,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- Name: oauth_client_tokens_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.oauth_client_tokens_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: oauth_client_tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.oauth_client_tokens_id_seq OWNED BY public.oauth_client_tokens.id;


--
-- Name: oauth_clients; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.oauth_clients (
    id bigint NOT NULL,
    client_id character varying NOT NULL,
    client_secret character varying NOT NULL,
    integration_type character varying NOT NULL,
    integration_id bigint NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- Name: oauth_clients_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.oauth_clients_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: oauth_clients_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.oauth_clients_id_seq OWNED BY public.oauth_clients.id;


--
-- Name: oidc_user_session_links; Type: TABLE; Schema: public; Owner: -
--

CREATE UNLOGGED TABLE public.oidc_user_session_links (
    id bigint NOT NULL,
    oidc_session character varying NOT NULL,
    session_id bigint,
    created_at timestamp(6) with time zone NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL
);


--
-- Name: oidc_user_session_links_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.oidc_user_session_links_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: oidc_user_session_links_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.oidc_user_session_links_id_seq OWNED BY public.oidc_user_session_links.id;


--
-- Name: ordered_work_packages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ordered_work_packages (
    id bigint NOT NULL,
    "position" integer NOT NULL,
    query_id bigint,
    work_package_id bigint
);


--
-- Name: ordered_work_packages_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ordered_work_packages_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ordered_work_packages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.ordered_work_packages_id_seq OWNED BY public.ordered_work_packages.id;


--
-- Name: paper_trail_audits; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.paper_trail_audits (
    id bigint NOT NULL,
    item_type character varying NOT NULL,
    item_id bigint NOT NULL,
    event character varying NOT NULL,
    whodunnit character varying,
    stack text,
    object jsonb,
    object_changes jsonb,
    created_at timestamp(6) with time zone
);


--
-- Name: paper_trail_audits_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.paper_trail_audits_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: paper_trail_audits_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.paper_trail_audits_id_seq OWNED BY public.paper_trail_audits.id;


--
-- Name: project_journals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.project_journals (
    id bigint NOT NULL,
    name character varying NOT NULL,
    description text,
    public boolean NOT NULL,
    parent_id bigint,
    identifier character varying NOT NULL,
    active boolean NOT NULL,
    templated boolean NOT NULL
);


--
-- Name: project_journals_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.project_journals_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: project_journals_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.project_journals_id_seq OWNED BY public.project_journals.id;


--
-- Name: project_statuses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.project_statuses (
    id bigint NOT NULL,
    project_id bigint NOT NULL,
    explanation text,
    code integer,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- Name: project_statuses_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.project_statuses_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: project_statuses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.project_statuses_id_seq OWNED BY public.project_statuses.id;


--
-- Name: projects; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.projects (
    id bigint NOT NULL,
    name character varying DEFAULT ''::character varying NOT NULL,
    description text,
    public boolean DEFAULT true NOT NULL,
    parent_id bigint,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    identifier character varying NOT NULL,
    lft integer,
    rgt integer,
    active boolean DEFAULT true NOT NULL,
    templated boolean DEFAULT false NOT NULL
);


--
-- Name: projects_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.projects_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: projects_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.projects_id_seq OWNED BY public.projects.id;


--
-- Name: projects_storages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.projects_storages (
    id bigint NOT NULL,
    project_id bigint NOT NULL,
    storage_id bigint NOT NULL,
    creator_id bigint NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- Name: projects_storages_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.projects_storages_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: projects_storages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.projects_storages_id_seq OWNED BY public.projects_storages.id;


--
-- Name: projects_types; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.projects_types (
    project_id bigint NOT NULL,
    type_id bigint NOT NULL
);


--
-- Name: queries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.queries (
    id bigint NOT NULL,
    project_id bigint,
    name character varying DEFAULT ''::character varying NOT NULL,
    filters text,
    user_id bigint NOT NULL,
    public boolean DEFAULT false NOT NULL,
    column_names text,
    sort_criteria text,
    group_by character varying,
    display_sums boolean DEFAULT false NOT NULL,
    timeline_visible boolean DEFAULT false,
    show_hierarchies boolean DEFAULT false,
    timeline_zoom_level integer DEFAULT 5,
    timeline_labels text,
    highlighting_mode text,
    highlighted_attributes text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    display_representation text,
    starred boolean DEFAULT false,
    include_subprojects boolean NOT NULL,
    timestamps character varying
);


--
-- Name: queries_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.queries_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: queries_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.queries_id_seq OWNED BY public.queries.id;


--
-- Name: rates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.rates (
    id bigint NOT NULL,
    valid_from date NOT NULL,
    rate numeric(15,4) NOT NULL,
    type character varying NOT NULL,
    project_id bigint,
    user_id bigint,
    cost_type_id bigint
);


--
-- Name: rates_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.rates_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: rates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.rates_id_seq OWNED BY public.rates.id;


--
-- Name: recaptcha_entries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.recaptcha_entries (
    id integer NOT NULL,
    user_id bigint,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    version integer NOT NULL
);


--
-- Name: recaptcha_entries_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.recaptcha_entries_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: recaptcha_entries_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.recaptcha_entries_id_seq OWNED BY public.recaptcha_entries.id;


--
-- Name: relations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.relations (
    id bigint NOT NULL,
    from_id integer NOT NULL,
    to_id integer NOT NULL,
    delay integer,
    description text,
    relation_type character varying
);


--
-- Name: relations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.relations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: relations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.relations_id_seq OWNED BY public.relations.id;


--
-- Name: repositories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.repositories (
    id bigint NOT NULL,
    project_id bigint NOT NULL,
    url character varying DEFAULT ''::character varying NOT NULL,
    login character varying(60) DEFAULT ''::character varying,
    password character varying DEFAULT ''::character varying,
    root_url character varying DEFAULT ''::character varying,
    type character varying,
    path_encoding character varying(64),
    log_encoding character varying(64),
    scm_type character varying NOT NULL,
    required_storage_bytes bigint DEFAULT 0 NOT NULL,
    storage_updated_at timestamp with time zone
);


--
-- Name: repositories_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.repositories_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: repositories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.repositories_id_seq OWNED BY public.repositories.id;


--
-- Name: role_permissions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.role_permissions (
    id bigint NOT NULL,
    permission character varying,
    role_id bigint,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- Name: role_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.role_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: role_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.role_permissions_id_seq OWNED BY public.role_permissions.id;


--
-- Name: roles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.roles (
    id bigint NOT NULL,
    name character varying(30) DEFAULT ''::character varying NOT NULL,
    "position" integer DEFAULT 1,
    builtin integer DEFAULT 0 NOT NULL,
    type character varying(30) DEFAULT 'Role'::character varying,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: roles_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.roles_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: roles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.roles_id_seq OWNED BY public.roles.id;


--
-- Name: schema_migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.schema_migrations (
    version character varying NOT NULL
);


--
-- Name: sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE UNLOGGED TABLE public.sessions (
    id bigint NOT NULL,
    session_id character varying NOT NULL,
    data text,
    updated_at timestamp with time zone,
    user_id bigint
);


--
-- Name: sessions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.sessions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: sessions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.sessions_id_seq OWNED BY public.sessions.id;


--
-- Name: settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.settings (
    id bigint NOT NULL,
    name character varying DEFAULT ''::character varying NOT NULL,
    value text,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: settings_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.settings_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.settings_id_seq OWNED BY public.settings.id;


--
-- Name: statuses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.statuses (
    id bigint NOT NULL,
    name character varying(30) DEFAULT ''::character varying NOT NULL,
    is_closed boolean DEFAULT false NOT NULL,
    is_default boolean DEFAULT false NOT NULL,
    "position" integer DEFAULT 1,
    default_done_ratio integer,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    color_id bigint,
    is_readonly boolean DEFAULT false
);


--
-- Name: statuses_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.statuses_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: statuses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.statuses_id_seq OWNED BY public.statuses.id;


--
-- Name: storages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.storages (
    id bigint NOT NULL,
    provider_type character varying NOT NULL,
    name character varying NOT NULL,
    host character varying NOT NULL,
    creator_id bigint NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- Name: storages_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.storages_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: storages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.storages_id_seq OWNED BY public.storages.id;


--
-- Name: time_entries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.time_entries (
    id bigint NOT NULL,
    project_id bigint NOT NULL,
    user_id bigint NOT NULL,
    work_package_id bigint,
    hours double precision NOT NULL,
    comments character varying,
    activity_id bigint NOT NULL,
    spent_on date NOT NULL,
    tyear integer NOT NULL,
    tmonth integer NOT NULL,
    tweek integer NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    overridden_costs numeric(15,4),
    costs numeric(15,4),
    rate_id bigint,
    logged_by_id bigint NOT NULL
);


--
-- Name: time_entries_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.time_entries_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: time_entries_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.time_entries_id_seq OWNED BY public.time_entries.id;


--
-- Name: time_entry_activities_projects; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.time_entry_activities_projects (
    id bigint NOT NULL,
    activity_id bigint NOT NULL,
    project_id bigint NOT NULL,
    active boolean DEFAULT true
);


--
-- Name: time_entry_activities_projects_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.time_entry_activities_projects_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: time_entry_activities_projects_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.time_entry_activities_projects_id_seq OWNED BY public.time_entry_activities_projects.id;


--
-- Name: time_entry_journals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.time_entry_journals (
    id bigint NOT NULL,
    project_id bigint NOT NULL,
    user_id bigint NOT NULL,
    work_package_id bigint,
    hours double precision NOT NULL,
    comments character varying,
    activity_id bigint NOT NULL,
    spent_on date NOT NULL,
    tyear integer NOT NULL,
    tmonth integer NOT NULL,
    tweek integer NOT NULL,
    overridden_costs numeric(15,2),
    costs numeric(15,2),
    rate_id bigint,
    logged_by_id bigint NOT NULL
);


--
-- Name: time_entry_journals_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.time_entry_journals_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: time_entry_journals_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.time_entry_journals_id_seq OWNED BY public.time_entry_journals.id;


--
-- Name: tokens; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tokens (
    id bigint NOT NULL,
    user_id bigint,
    type character varying,
    value character varying(128) DEFAULT ''::character varying NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    expires_on timestamp with time zone
);


--
-- Name: tokens_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.tokens_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.tokens_id_seq OWNED BY public.tokens.id;


--
-- Name: two_factor_authentication_devices; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.two_factor_authentication_devices (
    id bigint NOT NULL,
    type character varying,
    "default" boolean DEFAULT false NOT NULL,
    active boolean DEFAULT false NOT NULL,
    channel character varying NOT NULL,
    phone_number character varying,
    identifier character varying NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    last_used_at integer,
    otp_secret text,
    user_id bigint
);


--
-- Name: two_factor_authentication_devices_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.two_factor_authentication_devices_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: two_factor_authentication_devices_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.two_factor_authentication_devices_id_seq OWNED BY public.two_factor_authentication_devices.id;


--
-- Name: types; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.types (
    id bigint NOT NULL,
    name character varying DEFAULT ''::character varying NOT NULL,
    "position" integer DEFAULT 1,
    is_in_roadmap boolean DEFAULT true NOT NULL,
    is_milestone boolean DEFAULT false NOT NULL,
    is_default boolean DEFAULT false NOT NULL,
    color_id bigint,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    is_standard boolean DEFAULT false NOT NULL,
    attribute_groups text,
    description text
);


--
-- Name: types_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.types_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: types_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.types_id_seq OWNED BY public.types.id;


--
-- Name: user_passwords; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_passwords (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    hashed_password character varying(128) NOT NULL,
    salt character varying(64),
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    type character varying NOT NULL
);


--
-- Name: user_passwords_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.user_passwords_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: user_passwords_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.user_passwords_id_seq OWNED BY public.user_passwords.id;


--
-- Name: user_preferences; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_preferences (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    settings jsonb DEFAULT '{}'::jsonb
);


--
-- Name: user_preferences_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.user_preferences_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: user_preferences_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.user_preferences_id_seq OWNED BY public.user_preferences.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id bigint NOT NULL,
    login character varying(256) DEFAULT ''::character varying NOT NULL,
    firstname character varying DEFAULT ''::character varying NOT NULL,
    lastname character varying DEFAULT ''::character varying NOT NULL,
    mail character varying DEFAULT ''::character varying NOT NULL,
    admin boolean DEFAULT false NOT NULL,
    status integer DEFAULT 1 NOT NULL,
    last_login_on timestamp with time zone,
    language character varying(5) DEFAULT ''::character varying,
    auth_source_id bigint,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    type character varying,
    identity_url character varying,
    first_login boolean DEFAULT true NOT NULL,
    force_password_change boolean DEFAULT false,
    failed_login_count integer DEFAULT 0,
    last_failed_login_on timestamp with time zone,
    consented_at timestamp with time zone
);


--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: version_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.version_settings (
    id bigint NOT NULL,
    project_id bigint,
    version_id bigint,
    display integer,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- Name: version_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.version_settings_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: version_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.version_settings_id_seq OWNED BY public.version_settings.id;


--
-- Name: versions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.versions (
    id bigint NOT NULL,
    project_id bigint NOT NULL,
    name character varying DEFAULT ''::character varying NOT NULL,
    description character varying DEFAULT ''::character varying,
    effective_date date,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    wiki_page_title character varying,
    status character varying DEFAULT 'open'::character varying,
    sharing character varying DEFAULT 'none'::character varying NOT NULL,
    start_date date
);


--
-- Name: versions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.versions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: versions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.versions_id_seq OWNED BY public.versions.id;


--
-- Name: views; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.views (
    id bigint NOT NULL,
    query_id bigint NOT NULL,
    options jsonb DEFAULT '{}'::jsonb NOT NULL,
    type character varying NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- Name: views_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.views_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: views_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.views_id_seq OWNED BY public.views.id;


--
-- Name: watchers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.watchers (
    id bigint NOT NULL,
    watchable_type character varying DEFAULT ''::character varying NOT NULL,
    watchable_id bigint NOT NULL,
    user_id bigint
);


--
-- Name: watchers_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.watchers_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: watchers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.watchers_id_seq OWNED BY public.watchers.id;


--
-- Name: webhooks_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.webhooks_events (
    id bigint NOT NULL,
    name character varying,
    webhooks_webhook_id bigint
);


--
-- Name: webhooks_events_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.webhooks_events_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: webhooks_events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.webhooks_events_id_seq OWNED BY public.webhooks_events.id;


--
-- Name: webhooks_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.webhooks_logs (
    id bigint NOT NULL,
    webhooks_webhook_id bigint,
    event_name character varying,
    url character varying,
    request_headers text,
    request_body text,
    response_code integer,
    response_headers text,
    response_body text,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- Name: webhooks_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.webhooks_logs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: webhooks_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.webhooks_logs_id_seq OWNED BY public.webhooks_logs.id;


--
-- Name: webhooks_projects; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.webhooks_projects (
    id bigint NOT NULL,
    project_id bigint,
    webhooks_webhook_id bigint
);


--
-- Name: webhooks_projects_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.webhooks_projects_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: webhooks_projects_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.webhooks_projects_id_seq OWNED BY public.webhooks_projects.id;


--
-- Name: webhooks_webhooks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.webhooks_webhooks (
    id bigint NOT NULL,
    name character varying,
    url text,
    description text NOT NULL,
    secret character varying,
    enabled boolean NOT NULL,
    all_projects boolean NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- Name: webhooks_webhooks_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.webhooks_webhooks_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: webhooks_webhooks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.webhooks_webhooks_id_seq OWNED BY public.webhooks_webhooks.id;


--
-- Name: wiki_content_journals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.wiki_content_journals (
    id bigint NOT NULL,
    page_id bigint NOT NULL,
    author_id bigint,
    text text
);


--
-- Name: wiki_content_journals_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.wiki_content_journals_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: wiki_content_journals_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.wiki_content_journals_id_seq OWNED BY public.wiki_content_journals.id;


--
-- Name: wiki_contents; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.wiki_contents (
    id bigint NOT NULL,
    page_id bigint NOT NULL,
    author_id bigint,
    text text,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    lock_version integer NOT NULL
);


--
-- Name: wiki_contents_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.wiki_contents_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: wiki_contents_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.wiki_contents_id_seq OWNED BY public.wiki_contents.id;


--
-- Name: wiki_pages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.wiki_pages (
    id bigint NOT NULL,
    wiki_id bigint NOT NULL,
    title character varying NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    protected boolean DEFAULT false NOT NULL,
    parent_id bigint,
    slug character varying NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- Name: wiki_pages_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.wiki_pages_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: wiki_pages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.wiki_pages_id_seq OWNED BY public.wiki_pages.id;


--
-- Name: wiki_redirects; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.wiki_redirects (
    id bigint NOT NULL,
    wiki_id bigint NOT NULL,
    title character varying,
    redirects_to character varying,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: wiki_redirects_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.wiki_redirects_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: wiki_redirects_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.wiki_redirects_id_seq OWNED BY public.wiki_redirects.id;


--
-- Name: wikis; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.wikis (
    id bigint NOT NULL,
    project_id bigint NOT NULL,
    start_page character varying NOT NULL,
    status integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- Name: wikis_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.wikis_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: wikis_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.wikis_id_seq OWNED BY public.wikis.id;


--
-- Name: work_package_hierarchies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.work_package_hierarchies (
    ancestor_id integer NOT NULL,
    descendant_id integer NOT NULL,
    generations integer NOT NULL
);


--
-- Name: work_package_journals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.work_package_journals (
    id bigint NOT NULL,
    type_id bigint NOT NULL,
    project_id bigint NOT NULL,
    subject character varying NOT NULL,
    description text,
    due_date date,
    category_id bigint,
    status_id bigint NOT NULL,
    assigned_to_id bigint,
    priority_id bigint NOT NULL,
    version_id bigint,
    author_id bigint NOT NULL,
    done_ratio integer NOT NULL,
    estimated_hours double precision,
    start_date date,
    parent_id bigint,
    responsible_id bigint,
    budget_id bigint,
    story_points integer,
    remaining_hours double precision,
    derived_estimated_hours double precision,
    schedule_manually boolean,
    duration integer,
    ignore_non_working_days boolean NOT NULL
);


--
-- Name: work_package_journals_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.work_package_journals_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: work_package_journals_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.work_package_journals_id_seq OWNED BY public.work_package_journals.id;


--
-- Name: work_packages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.work_packages (
    id bigint NOT NULL,
    type_id bigint NOT NULL,
    project_id bigint NOT NULL,
    subject character varying DEFAULT ''::character varying NOT NULL,
    description text,
    due_date date,
    category_id bigint,
    status_id bigint NOT NULL,
    assigned_to_id bigint,
    priority_id bigint,
    version_id bigint,
    author_id bigint NOT NULL,
    lock_version integer DEFAULT 0 NOT NULL,
    done_ratio integer DEFAULT 0 NOT NULL,
    estimated_hours double precision,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    start_date date,
    responsible_id bigint,
    budget_id bigint,
    "position" integer,
    story_points integer,
    remaining_hours double precision,
    derived_estimated_hours double precision,
    schedule_manually boolean DEFAULT false,
    parent_id bigint,
    duration integer,
    ignore_non_working_days boolean DEFAULT false NOT NULL,
    CONSTRAINT work_packages_due_larger_start_date CHECK ((due_date >= start_date))
);


--
-- Name: work_packages_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.work_packages_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: work_packages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.work_packages_id_seq OWNED BY public.work_packages.id;


--
-- Name: workflows; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.workflows (
    id bigint NOT NULL,
    type_id bigint NOT NULL,
    old_status_id bigint NOT NULL,
    new_status_id bigint NOT NULL,
    role_id bigint NOT NULL,
    assignee boolean DEFAULT false NOT NULL,
    author boolean DEFAULT false NOT NULL
);


--
-- Name: workflows_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.workflows_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: workflows_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.workflows_id_seq OWNED BY public.workflows.id;


--
-- Name: announcements id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.announcements ALTER COLUMN id SET DEFAULT nextval('public.announcements_id_seq'::regclass);


--
-- Name: attachable_journals id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attachable_journals ALTER COLUMN id SET DEFAULT nextval('public.attachable_journals_id_seq'::regclass);


--
-- Name: attachment_journals id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attachment_journals ALTER COLUMN id SET DEFAULT nextval('public.attachment_journals_id_seq'::regclass);


--
-- Name: attachments id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attachments ALTER COLUMN id SET DEFAULT nextval('public.attachments_id_seq'::regclass);


--
-- Name: attribute_help_texts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attribute_help_texts ALTER COLUMN id SET DEFAULT nextval('public.attribute_help_texts_id_seq'::regclass);


--
-- Name: auth_sources id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_sources ALTER COLUMN id SET DEFAULT nextval('public.auth_sources_id_seq'::regclass);


--
-- Name: bcf_comments id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bcf_comments ALTER COLUMN id SET DEFAULT nextval('public.bcf_comments_id_seq'::regclass);


--
-- Name: bcf_issues id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bcf_issues ALTER COLUMN id SET DEFAULT nextval('public.bcf_issues_id_seq'::regclass);


--
-- Name: bcf_viewpoints id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bcf_viewpoints ALTER COLUMN id SET DEFAULT nextval('public.bcf_viewpoints_id_seq'::regclass);


--
-- Name: budget_journals id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.budget_journals ALTER COLUMN id SET DEFAULT nextval('public.budget_journals_id_seq'::regclass);


--
-- Name: budgets id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.budgets ALTER COLUMN id SET DEFAULT nextval('public.budgets_id_seq'::regclass);


--
-- Name: categories id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categories ALTER COLUMN id SET DEFAULT nextval('public.categories_id_seq'::regclass);


--
-- Name: changes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.changes ALTER COLUMN id SET DEFAULT nextval('public.changes_id_seq'::regclass);


--
-- Name: changeset_journals id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.changeset_journals ALTER COLUMN id SET DEFAULT nextval('public.changeset_journals_id_seq'::regclass);


--
-- Name: changesets id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.changesets ALTER COLUMN id SET DEFAULT nextval('public.changesets_id_seq'::regclass);


--
-- Name: colors id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.colors ALTER COLUMN id SET DEFAULT nextval('public.colors_id_seq'::regclass);


--
-- Name: comments id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.comments ALTER COLUMN id SET DEFAULT nextval('public.comments_id_seq'::regclass);


--
-- Name: cost_entries id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cost_entries ALTER COLUMN id SET DEFAULT nextval('public.cost_entries_id_seq'::regclass);


--
-- Name: cost_queries id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cost_queries ALTER COLUMN id SET DEFAULT nextval('public.cost_queries_id_seq'::regclass);


--
-- Name: cost_types id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cost_types ALTER COLUMN id SET DEFAULT nextval('public.cost_types_id_seq'::regclass);


--
-- Name: custom_actions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.custom_actions ALTER COLUMN id SET DEFAULT nextval('public.custom_actions_id_seq'::regclass);


--
-- Name: custom_actions_projects id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.custom_actions_projects ALTER COLUMN id SET DEFAULT nextval('public.custom_actions_projects_id_seq'::regclass);


--
-- Name: custom_actions_roles id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.custom_actions_roles ALTER COLUMN id SET DEFAULT nextval('public.custom_actions_roles_id_seq'::regclass);


--
-- Name: custom_actions_statuses id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.custom_actions_statuses ALTER COLUMN id SET DEFAULT nextval('public.custom_actions_statuses_id_seq'::regclass);


--
-- Name: custom_actions_types id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.custom_actions_types ALTER COLUMN id SET DEFAULT nextval('public.custom_actions_types_id_seq'::regclass);


--
-- Name: custom_fields id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.custom_fields ALTER COLUMN id SET DEFAULT nextval('public.custom_fields_id_seq'::regclass);


--
-- Name: custom_options id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.custom_options ALTER COLUMN id SET DEFAULT nextval('public.custom_options_id_seq'::regclass);


--
-- Name: custom_styles id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.custom_styles ALTER COLUMN id SET DEFAULT nextval('public.custom_styles_id_seq'::regclass);


--
-- Name: custom_values id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.custom_values ALTER COLUMN id SET DEFAULT nextval('public.custom_values_id_seq'::regclass);


--
-- Name: customizable_journals id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customizable_journals ALTER COLUMN id SET DEFAULT nextval('public.customizable_journals_id_seq'::regclass);


--
-- Name: delayed_job_statuses id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.delayed_job_statuses ALTER COLUMN id SET DEFAULT nextval('public.delayed_job_statuses_id_seq'::regclass);


--
-- Name: delayed_jobs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.delayed_jobs ALTER COLUMN id SET DEFAULT nextval('public.delayed_jobs_id_seq'::regclass);


--
-- Name: design_colors id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.design_colors ALTER COLUMN id SET DEFAULT nextval('public.design_colors_id_seq'::regclass);


--
-- Name: document_journals id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_journals ALTER COLUMN id SET DEFAULT nextval('public.document_journals_id_seq'::regclass);


--
-- Name: documents id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documents ALTER COLUMN id SET DEFAULT nextval('public.documents_id_seq'::regclass);


--
-- Name: enabled_modules id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.enabled_modules ALTER COLUMN id SET DEFAULT nextval('public.enabled_modules_id_seq'::regclass);


--
-- Name: enterprise_tokens id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.enterprise_tokens ALTER COLUMN id SET DEFAULT nextval('public.enterprise_tokens_id_seq'::regclass);


--
-- Name: enumerations id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.enumerations ALTER COLUMN id SET DEFAULT nextval('public.enumerations_id_seq'::regclass);


--
-- Name: export_card_configurations id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.export_card_configurations ALTER COLUMN id SET DEFAULT nextval('public.export_card_configurations_id_seq'::regclass);


--
-- Name: exports id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.exports ALTER COLUMN id SET DEFAULT nextval('public.exports_id_seq'::regclass);


--
-- Name: file_links id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.file_links ALTER COLUMN id SET DEFAULT nextval('public.file_links_id_seq'::regclass);


--
-- Name: forums id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.forums ALTER COLUMN id SET DEFAULT nextval('public.forums_id_seq'::regclass);


--
-- Name: github_check_runs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.github_check_runs ALTER COLUMN id SET DEFAULT nextval('public.github_check_runs_id_seq'::regclass);


--
-- Name: github_pull_requests id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.github_pull_requests ALTER COLUMN id SET DEFAULT nextval('public.github_pull_requests_id_seq'::regclass);


--
-- Name: github_users id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.github_users ALTER COLUMN id SET DEFAULT nextval('public.github_users_id_seq'::regclass);


--
-- Name: grid_widgets id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.grid_widgets ALTER COLUMN id SET DEFAULT nextval('public.grid_widgets_id_seq'::regclass);


--
-- Name: grids id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.grids ALTER COLUMN id SET DEFAULT nextval('public.grids_id_seq'::regclass);


--
-- Name: group_users id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.group_users ALTER COLUMN id SET DEFAULT nextval('public.group_users_id_seq'::regclass);


--
-- Name: ifc_models id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ifc_models ALTER COLUMN id SET DEFAULT nextval('public.ifc_models_id_seq'::regclass);


--
-- Name: journals id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.journals ALTER COLUMN id SET DEFAULT nextval('public.journals_id_seq'::regclass);


--
-- Name: labor_budget_items id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.labor_budget_items ALTER COLUMN id SET DEFAULT nextval('public.labor_budget_items_id_seq'::regclass);


--
-- Name: ldap_groups_memberships id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ldap_groups_memberships ALTER COLUMN id SET DEFAULT nextval('public.ldap_groups_memberships_id_seq'::regclass);


--
-- Name: ldap_groups_synchronized_filters id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ldap_groups_synchronized_filters ALTER COLUMN id SET DEFAULT nextval('public.ldap_groups_synchronized_filters_id_seq'::regclass);


--
-- Name: ldap_groups_synchronized_groups id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ldap_groups_synchronized_groups ALTER COLUMN id SET DEFAULT nextval('public.ldap_groups_synchronized_groups_id_seq'::regclass);


--
-- Name: material_budget_items id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.material_budget_items ALTER COLUMN id SET DEFAULT nextval('public.material_budget_items_id_seq'::regclass);


--
-- Name: meeting_content_journals id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.meeting_content_journals ALTER COLUMN id SET DEFAULT nextval('public.meeting_content_journals_id_seq'::regclass);


--
-- Name: meeting_contents id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.meeting_contents ALTER COLUMN id SET DEFAULT nextval('public.meeting_contents_id_seq'::regclass);


--
-- Name: meeting_journals id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.meeting_journals ALTER COLUMN id SET DEFAULT nextval('public.meeting_journals_id_seq'::regclass);


--
-- Name: meeting_participants id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.meeting_participants ALTER COLUMN id SET DEFAULT nextval('public.meeting_participants_id_seq'::regclass);


--
-- Name: meetings id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.meetings ALTER COLUMN id SET DEFAULT nextval('public.meetings_id_seq'::regclass);


--
-- Name: member_roles id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_roles ALTER COLUMN id SET DEFAULT nextval('public.member_roles_id_seq'::regclass);


--
-- Name: members id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.members ALTER COLUMN id SET DEFAULT nextval('public.members_id_seq'::regclass);


--
-- Name: menu_items id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.menu_items ALTER COLUMN id SET DEFAULT nextval('public.menu_items_id_seq'::regclass);


--
-- Name: message_journals id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.message_journals ALTER COLUMN id SET DEFAULT nextval('public.message_journals_id_seq'::regclass);


--
-- Name: messages id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.messages ALTER COLUMN id SET DEFAULT nextval('public.messages_id_seq'::regclass);


--
-- Name: news id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.news ALTER COLUMN id SET DEFAULT nextval('public.news_id_seq'::regclass);


--
-- Name: news_journals id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.news_journals ALTER COLUMN id SET DEFAULT nextval('public.news_journals_id_seq'::regclass);


--
-- Name: non_working_days id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.non_working_days ALTER COLUMN id SET DEFAULT nextval('public.non_working_days_id_seq'::regclass);


--
-- Name: notification_settings id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_settings ALTER COLUMN id SET DEFAULT nextval('public.notification_settings_id_seq'::regclass);


--
-- Name: notifications id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications ALTER COLUMN id SET DEFAULT nextval('public.notifications_id_seq'::regclass);


--
-- Name: oauth_access_grants id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth_access_grants ALTER COLUMN id SET DEFAULT nextval('public.oauth_access_grants_id_seq'::regclass);


--
-- Name: oauth_access_tokens id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth_access_tokens ALTER COLUMN id SET DEFAULT nextval('public.oauth_access_tokens_id_seq'::regclass);


--
-- Name: oauth_applications id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth_applications ALTER COLUMN id SET DEFAULT nextval('public.oauth_applications_id_seq'::regclass);


--
-- Name: oauth_client_tokens id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth_client_tokens ALTER COLUMN id SET DEFAULT nextval('public.oauth_client_tokens_id_seq'::regclass);


--
-- Name: oauth_clients id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth_clients ALTER COLUMN id SET DEFAULT nextval('public.oauth_clients_id_seq'::regclass);


--
-- Name: oidc_user_session_links id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oidc_user_session_links ALTER COLUMN id SET DEFAULT nextval('public.oidc_user_session_links_id_seq'::regclass);


--
-- Name: ordered_work_packages id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ordered_work_packages ALTER COLUMN id SET DEFAULT nextval('public.ordered_work_packages_id_seq'::regclass);


--
-- Name: paper_trail_audits id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.paper_trail_audits ALTER COLUMN id SET DEFAULT nextval('public.paper_trail_audits_id_seq'::regclass);


--
-- Name: project_journals id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_journals ALTER COLUMN id SET DEFAULT nextval('public.project_journals_id_seq'::regclass);


--
-- Name: project_statuses id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_statuses ALTER COLUMN id SET DEFAULT nextval('public.project_statuses_id_seq'::regclass);


--
-- Name: projects id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.projects ALTER COLUMN id SET DEFAULT nextval('public.projects_id_seq'::regclass);


--
-- Name: projects_storages id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.projects_storages ALTER COLUMN id SET DEFAULT nextval('public.projects_storages_id_seq'::regclass);


--
-- Name: queries id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.queries ALTER COLUMN id SET DEFAULT nextval('public.queries_id_seq'::regclass);


--
-- Name: rates id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rates ALTER COLUMN id SET DEFAULT nextval('public.rates_id_seq'::regclass);


--
-- Name: recaptcha_entries id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recaptcha_entries ALTER COLUMN id SET DEFAULT nextval('public.recaptcha_entries_id_seq'::regclass);


--
-- Name: relations id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.relations ALTER COLUMN id SET DEFAULT nextval('public.relations_id_seq'::regclass);


--
-- Name: repositories id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.repositories ALTER COLUMN id SET DEFAULT nextval('public.repositories_id_seq'::regclass);


--
-- Name: role_permissions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role_permissions ALTER COLUMN id SET DEFAULT nextval('public.role_permissions_id_seq'::regclass);


--
-- Name: roles id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.roles ALTER COLUMN id SET DEFAULT nextval('public.roles_id_seq'::regclass);


--
-- Name: sessions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sessions ALTER COLUMN id SET DEFAULT nextval('public.sessions_id_seq'::regclass);


--
-- Name: settings id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.settings ALTER COLUMN id SET DEFAULT nextval('public.settings_id_seq'::regclass);


--
-- Name: statuses id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.statuses ALTER COLUMN id SET DEFAULT nextval('public.statuses_id_seq'::regclass);


--
-- Name: storages id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.storages ALTER COLUMN id SET DEFAULT nextval('public.storages_id_seq'::regclass);


--
-- Name: time_entries id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.time_entries ALTER COLUMN id SET DEFAULT nextval('public.time_entries_id_seq'::regclass);


--
-- Name: time_entry_activities_projects id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.time_entry_activities_projects ALTER COLUMN id SET DEFAULT nextval('public.time_entry_activities_projects_id_seq'::regclass);


--
-- Name: time_entry_journals id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.time_entry_journals ALTER COLUMN id SET DEFAULT nextval('public.time_entry_journals_id_seq'::regclass);


--
-- Name: tokens id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tokens ALTER COLUMN id SET DEFAULT nextval('public.tokens_id_seq'::regclass);


--
-- Name: two_factor_authentication_devices id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.two_factor_authentication_devices ALTER COLUMN id SET DEFAULT nextval('public.two_factor_authentication_devices_id_seq'::regclass);


--
-- Name: types id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.types ALTER COLUMN id SET DEFAULT nextval('public.types_id_seq'::regclass);


--
-- Name: user_passwords id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_passwords ALTER COLUMN id SET DEFAULT nextval('public.user_passwords_id_seq'::regclass);


--
-- Name: user_preferences id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_preferences ALTER COLUMN id SET DEFAULT nextval('public.user_preferences_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Name: version_settings id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.version_settings ALTER COLUMN id SET DEFAULT nextval('public.version_settings_id_seq'::regclass);


--
-- Name: versions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.versions ALTER COLUMN id SET DEFAULT nextval('public.versions_id_seq'::regclass);


--
-- Name: views id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.views ALTER COLUMN id SET DEFAULT nextval('public.views_id_seq'::regclass);


--
-- Name: watchers id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.watchers ALTER COLUMN id SET DEFAULT nextval('public.watchers_id_seq'::regclass);


--
-- Name: webhooks_events id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.webhooks_events ALTER COLUMN id SET DEFAULT nextval('public.webhooks_events_id_seq'::regclass);


--
-- Name: webhooks_logs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.webhooks_logs ALTER COLUMN id SET DEFAULT nextval('public.webhooks_logs_id_seq'::regclass);


--
-- Name: webhooks_projects id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.webhooks_projects ALTER COLUMN id SET DEFAULT nextval('public.webhooks_projects_id_seq'::regclass);


--
-- Name: webhooks_webhooks id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.webhooks_webhooks ALTER COLUMN id SET DEFAULT nextval('public.webhooks_webhooks_id_seq'::regclass);


--
-- Name: wiki_content_journals id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wiki_content_journals ALTER COLUMN id SET DEFAULT nextval('public.wiki_content_journals_id_seq'::regclass);


--
-- Name: wiki_contents id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wiki_contents ALTER COLUMN id SET DEFAULT nextval('public.wiki_contents_id_seq'::regclass);


--
-- Name: wiki_pages id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wiki_pages ALTER COLUMN id SET DEFAULT nextval('public.wiki_pages_id_seq'::regclass);


--
-- Name: wiki_redirects id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wiki_redirects ALTER COLUMN id SET DEFAULT nextval('public.wiki_redirects_id_seq'::regclass);


--
-- Name: wikis id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wikis ALTER COLUMN id SET DEFAULT nextval('public.wikis_id_seq'::regclass);


--
-- Name: work_package_journals id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_package_journals ALTER COLUMN id SET DEFAULT nextval('public.work_package_journals_id_seq'::regclass);


--
-- Name: work_packages id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_packages ALTER COLUMN id SET DEFAULT nextval('public.work_packages_id_seq'::regclass);


--
-- Name: workflows id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workflows ALTER COLUMN id SET DEFAULT nextval('public.workflows_id_seq'::regclass);


--
-- Data for Name: announcements; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.announcements (id, text, show_until, active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: ar_internal_metadata; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ar_internal_metadata (key, value, created_at, updated_at) FROM stdin;
environment	production	2023-08-03 10:37:21.866293+00	2023-08-03 10:37:21.866293+00
\.


--
-- Data for Name: attachable_journals; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.attachable_journals (id, journal_id, attachment_id, filename) FROM stdin;
\.


--
-- Data for Name: attachment_journals; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.attachment_journals (id, container_id, container_type, filename, disk_filename, filesize, content_type, digest, downloads, author_id, description) FROM stdin;
1	6	Grids::Grid			455768	image/png	2a53ddc815206499a480d08e38272b8a	0	1	\N
2	7	Grids::Grid			442579	image/png	7b7d591a8dfdaf2900ceecdb9755f39f	0	1	\N
\.


--
-- Data for Name: attachments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.attachments (id, container_id, container_type, filename, disk_filename, filesize, content_type, digest, downloads, author_id, created_at, description, file, fulltext, fulltext_tsv, file_tsv, updated_at) FROM stdin;
1	6	Grids::Grid			455768	image/png	2a53ddc815206499a480d08e38272b8a	0	1	2023-08-03 10:37:31.609828+00	\N	demo_project_teaser.png	\N	\N	\N	2023-08-03 10:37:31.609828+00
2	7	Grids::Grid			442579	image/png	7b7d591a8dfdaf2900ceecdb9755f39f	0	1	2023-08-03 10:37:31.631621+00	\N	scrum_project_teaser.png	\N	\N	\N	2023-08-03 10:37:31.631621+00
\.


--
-- Data for Name: attribute_help_texts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.attribute_help_texts (id, help_text, type, attribute_name, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: auth_sources; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.auth_sources (id, type, name, host, port, account, account_password, base_dn, attr_login, attr_firstname, attr_lastname, attr_mail, onthefly_register, attr_admin, created_at, updated_at, tls_mode, filter_string, verify_peer, tls_certificate_string) FROM stdin;
\.


--
-- Data for Name: bcf_comments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.bcf_comments (id, uuid, journal_id, issue_id, viewpoint_id, reply_to) FROM stdin;
\.


--
-- Data for Name: bcf_issues; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.bcf_issues (id, uuid, markup, work_package_id, stage, index, labels, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: bcf_viewpoints; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.bcf_viewpoints (id, uuid, viewpoint_name, issue_id, json_viewpoint, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: budget_journals; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.budget_journals (id, project_id, author_id, subject, description, fixed_date) FROM stdin;
\.


--
-- Data for Name: budgets; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.budgets (id, project_id, author_id, subject, description, fixed_date, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: categories; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.categories (id, project_id, name, assigned_to_id, created_at, updated_at) FROM stdin;
1	1	Category 1 (to be changed in Project settings)	\N	2023-08-03 10:37:30.299419+00	2023-08-03 10:37:30.299419+00
2	2	Category 1 (to be changed in Project settings)	\N	2023-08-03 10:37:30.880096+00	2023-08-03 10:37:30.880096+00
\.


--
-- Data for Name: changes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.changes (id, changeset_id, action, path, from_path, from_revision, revision, branch) FROM stdin;
\.


--
-- Data for Name: changeset_journals; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.changeset_journals (id, repository_id, revision, committer, committed_on, comments, commit_date, scmid, user_id) FROM stdin;
\.


--
-- Data for Name: changesets; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.changesets (id, repository_id, revision, committer, committed_on, comments, commit_date, scmid, user_id) FROM stdin;
\.


--
-- Data for Name: changesets_work_packages; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.changesets_work_packages (changeset_id, work_package_id) FROM stdin;
\.


--
-- Data for Name: colors; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.colors (id, name, hexcode, created_at, updated_at) FROM stdin;
1	Blue (dark)	#175A8E	2023-08-03 10:37:26.956715+00	2023-08-03 10:37:26.956715+00
2	Blue	#1A67A3	2023-08-03 10:37:26.957213+00	2023-08-03 10:37:26.957213+00
3	Blue (light)	#00B0F0	2023-08-03 10:37:26.95754+00	2023-08-03 10:37:26.95754+00
4	Green (light)	#35C53F	2023-08-03 10:37:26.957822+00	2023-08-03 10:37:26.957822+00
5	Green (dark)	#339933	2023-08-03 10:37:26.958092+00	2023-08-03 10:37:26.958092+00
6	Yellow	#FFFF00	2023-08-03 10:37:26.958364+00	2023-08-03 10:37:26.958364+00
7	Orange	#FFCC00	2023-08-03 10:37:26.958816+00	2023-08-03 10:37:26.958816+00
8	Red	#FF3300	2023-08-03 10:37:26.95944+00	2023-08-03 10:37:26.95944+00
9	Magenta	#E20074	2023-08-03 10:37:26.959811+00	2023-08-03 10:37:26.959811+00
10	White	#FFFFFF	2023-08-03 10:37:26.960159+00	2023-08-03 10:37:26.960159+00
11	Grey (light)	#F8F8F8	2023-08-03 10:37:26.960457+00	2023-08-03 10:37:26.960457+00
12	Grey	#EAEAEA	2023-08-03 10:37:26.960734+00	2023-08-03 10:37:26.960734+00
13	Grey (dark)	#878787	2023-08-03 10:37:26.960997+00	2023-08-03 10:37:26.960997+00
14	Black	#000000	2023-08-03 10:37:26.968622+00	2023-08-03 10:37:26.968622+00
15	gray-0	#F8F9FA	2023-08-03 10:37:26.969456+00	2023-08-03 10:37:26.969456+00
16	gray-1	#F1F3F5	2023-08-03 10:37:26.969782+00	2023-08-03 10:37:26.969782+00
17	gray-2	#E9ECEF	2023-08-03 10:37:26.970074+00	2023-08-03 10:37:26.970074+00
18	gray-3	#DEE2E6	2023-08-03 10:37:26.970363+00	2023-08-03 10:37:26.970363+00
19	gray-4	#CED4DA	2023-08-03 10:37:26.970646+00	2023-08-03 10:37:26.970646+00
20	gray-5	#ADB5BD	2023-08-03 10:37:26.970925+00	2023-08-03 10:37:26.970925+00
21	gray-6	#868E96	2023-08-03 10:37:26.971686+00	2023-08-03 10:37:26.971686+00
22	gray-7	#495057	2023-08-03 10:37:26.97208+00	2023-08-03 10:37:26.97208+00
23	gray-8	#343A40	2023-08-03 10:37:26.972368+00	2023-08-03 10:37:26.972368+00
24	gray-9	#212529	2023-08-03 10:37:26.972642+00	2023-08-03 10:37:26.972642+00
25	red-0	#FFF5F5	2023-08-03 10:37:26.972925+00	2023-08-03 10:37:26.972925+00
26	red-1	#FFE3E3	2023-08-03 10:37:26.973214+00	2023-08-03 10:37:26.973214+00
27	red-2	#FFC9C9	2023-08-03 10:37:26.973492+00	2023-08-03 10:37:26.973492+00
28	red-3	#FFA8A8	2023-08-03 10:37:26.973762+00	2023-08-03 10:37:26.973762+00
29	red-4	#FF8787	2023-08-03 10:37:26.974128+00	2023-08-03 10:37:26.974128+00
30	red-5	#FF6B6B	2023-08-03 10:37:26.974456+00	2023-08-03 10:37:26.974456+00
31	red-6	#FA5252	2023-08-03 10:37:26.974865+00	2023-08-03 10:37:26.974865+00
32	red-7	#F03E3E	2023-08-03 10:37:26.975199+00	2023-08-03 10:37:26.975199+00
33	red-8	#E03131	2023-08-03 10:37:26.975453+00	2023-08-03 10:37:26.975453+00
34	red-9	#C92A2A	2023-08-03 10:37:26.975708+00	2023-08-03 10:37:26.975708+00
35	pink-0	#FFF0F6	2023-08-03 10:37:26.975979+00	2023-08-03 10:37:26.975979+00
36	pink-1	#FFDEEB	2023-08-03 10:37:26.976246+00	2023-08-03 10:37:26.976246+00
37	pink-2	#FCC2D7	2023-08-03 10:37:26.976507+00	2023-08-03 10:37:26.976507+00
38	pink-3	#FAA2C1	2023-08-03 10:37:26.976765+00	2023-08-03 10:37:26.976765+00
39	pink-4	#F783AC	2023-08-03 10:37:26.977031+00	2023-08-03 10:37:26.977031+00
40	pink-5	#F06595	2023-08-03 10:37:26.977302+00	2023-08-03 10:37:26.977302+00
41	pink-6	#E64980	2023-08-03 10:37:26.977767+00	2023-08-03 10:37:26.977767+00
42	pink-7	#D6336C	2023-08-03 10:37:26.978181+00	2023-08-03 10:37:26.978181+00
43	pink-8	#C2255C	2023-08-03 10:37:26.978569+00	2023-08-03 10:37:26.978569+00
44	pink-9	#A61E4D	2023-08-03 10:37:26.978848+00	2023-08-03 10:37:26.978848+00
45	grape-0	#F8F0FC	2023-08-03 10:37:26.979162+00	2023-08-03 10:37:26.979162+00
46	grape-1	#F3D9FA	2023-08-03 10:37:26.979452+00	2023-08-03 10:37:26.979452+00
47	grape-2	#EEBEFA	2023-08-03 10:37:26.979725+00	2023-08-03 10:37:26.979725+00
48	grape-3	#E599F7	2023-08-03 10:37:26.979993+00	2023-08-03 10:37:26.979993+00
49	grape-4	#DA77F2	2023-08-03 10:37:26.980262+00	2023-08-03 10:37:26.980262+00
50	grape-5	#CC5DE8	2023-08-03 10:37:26.98052+00	2023-08-03 10:37:26.98052+00
51	grape-6	#BE4BDB	2023-08-03 10:37:26.981068+00	2023-08-03 10:37:26.981068+00
52	grape-7	#AE3EC9	2023-08-03 10:37:26.981401+00	2023-08-03 10:37:26.981401+00
53	grape-8	#9C36B5	2023-08-03 10:37:26.981658+00	2023-08-03 10:37:26.981658+00
54	grape-9	#862E9C	2023-08-03 10:37:26.981902+00	2023-08-03 10:37:26.981902+00
55	violet-0	#F3F0FF	2023-08-03 10:37:26.982164+00	2023-08-03 10:37:26.982164+00
56	violet-1	#E5DBFF	2023-08-03 10:37:26.982483+00	2023-08-03 10:37:26.982483+00
57	violet-2	#D0BFFF	2023-08-03 10:37:26.982827+00	2023-08-03 10:37:26.982827+00
58	violet-3	#B197FC	2023-08-03 10:37:26.983125+00	2023-08-03 10:37:26.983125+00
59	violet-4	#9775FA	2023-08-03 10:37:26.983404+00	2023-08-03 10:37:26.983404+00
60	violet-5	#845EF7	2023-08-03 10:37:26.983669+00	2023-08-03 10:37:26.983669+00
61	violet-6	#7950F2	2023-08-03 10:37:26.983986+00	2023-08-03 10:37:26.983986+00
62	violet-7	#7048E8	2023-08-03 10:37:26.984548+00	2023-08-03 10:37:26.984548+00
63	violet-8	#6741D9	2023-08-03 10:37:26.98488+00	2023-08-03 10:37:26.98488+00
64	violet-9	#5F3DC4	2023-08-03 10:37:26.985146+00	2023-08-03 10:37:26.985146+00
65	indigo-0	#EDF2FF	2023-08-03 10:37:26.985402+00	2023-08-03 10:37:26.985402+00
66	indigo-1	#DBE4FF	2023-08-03 10:37:26.985671+00	2023-08-03 10:37:26.985671+00
67	indigo-2	#BAC8FF	2023-08-03 10:37:26.985932+00	2023-08-03 10:37:26.985932+00
68	indigo-3	#91A7FF	2023-08-03 10:37:26.986201+00	2023-08-03 10:37:26.986201+00
69	indigo-4	#748FFC	2023-08-03 10:37:26.986457+00	2023-08-03 10:37:26.986457+00
70	indigo-5	#5C7CFA	2023-08-03 10:37:26.98671+00	2023-08-03 10:37:26.98671+00
71	indigo-6	#4C6EF5	2023-08-03 10:37:26.986969+00	2023-08-03 10:37:26.986969+00
72	indigo-7	#4263EB	2023-08-03 10:37:26.987359+00	2023-08-03 10:37:26.987359+00
73	indigo-8	#3B5BDB	2023-08-03 10:37:26.987668+00	2023-08-03 10:37:26.987668+00
74	indigo-9	#364FC7	2023-08-03 10:37:26.987907+00	2023-08-03 10:37:26.987907+00
75	blue-0	#E7F5FF	2023-08-03 10:37:26.988153+00	2023-08-03 10:37:26.988153+00
76	blue-1	#D0EBFF	2023-08-03 10:37:26.98846+00	2023-08-03 10:37:26.98846+00
77	blue-2	#A5D8FF	2023-08-03 10:37:26.988755+00	2023-08-03 10:37:26.988755+00
78	blue-3	#74C0FC	2023-08-03 10:37:26.98903+00	2023-08-03 10:37:26.98903+00
79	blue-4	#4DABF7	2023-08-03 10:37:26.989297+00	2023-08-03 10:37:26.989297+00
80	blue-5	#339AF0	2023-08-03 10:37:26.989734+00	2023-08-03 10:37:26.989734+00
81	blue-6	#228BE6	2023-08-03 10:37:26.990118+00	2023-08-03 10:37:26.990118+00
82	blue-7	#1C7ED6	2023-08-03 10:37:26.990623+00	2023-08-03 10:37:26.990623+00
83	blue-8	#1971C2	2023-08-03 10:37:26.990959+00	2023-08-03 10:37:26.990959+00
84	blue-9	#1864AB	2023-08-03 10:37:26.991228+00	2023-08-03 10:37:26.991228+00
85	cyan-0	#E3FAFC	2023-08-03 10:37:26.991495+00	2023-08-03 10:37:26.991495+00
86	cyan-1	#C5F6FA	2023-08-03 10:37:26.991779+00	2023-08-03 10:37:26.991779+00
87	cyan-2	#99E9F2	2023-08-03 10:37:26.992064+00	2023-08-03 10:37:26.992064+00
88	cyan-3	#66D9E8	2023-08-03 10:37:26.992329+00	2023-08-03 10:37:26.992329+00
89	cyan-4	#3BC9DB	2023-08-03 10:37:26.992602+00	2023-08-03 10:37:26.992602+00
90	cyan-5	#22B8CF	2023-08-03 10:37:26.992875+00	2023-08-03 10:37:26.992875+00
91	cyan-6	#15AABF	2023-08-03 10:37:26.993146+00	2023-08-03 10:37:26.993146+00
92	cyan-7	#1098AD	2023-08-03 10:37:26.99343+00	2023-08-03 10:37:26.99343+00
93	cyan-8	#0C8599	2023-08-03 10:37:26.993833+00	2023-08-03 10:37:26.993833+00
94	cyan-9	#0B7285	2023-08-03 10:37:26.994173+00	2023-08-03 10:37:26.994173+00
95	teal-0	#E6FCF5	2023-08-03 10:37:26.99443+00	2023-08-03 10:37:26.99443+00
96	teal-1	#C3FAE8	2023-08-03 10:37:26.994751+00	2023-08-03 10:37:26.994751+00
97	teal-2	#96F2D7	2023-08-03 10:37:26.995021+00	2023-08-03 10:37:26.995021+00
98	teal-3	#63E6BE	2023-08-03 10:37:26.995287+00	2023-08-03 10:37:26.995287+00
99	teal-4	#38D9A9	2023-08-03 10:37:26.995555+00	2023-08-03 10:37:26.995555+00
100	teal-5	#20C997	2023-08-03 10:37:26.995817+00	2023-08-03 10:37:26.995817+00
101	teal-6	#12B886	2023-08-03 10:37:26.996075+00	2023-08-03 10:37:26.996075+00
102	teal-7	#0CA678	2023-08-03 10:37:26.996331+00	2023-08-03 10:37:26.996331+00
103	teal-8	#099268	2023-08-03 10:37:26.9968+00	2023-08-03 10:37:26.9968+00
104	teal-9	#087F5B	2023-08-03 10:37:26.997075+00	2023-08-03 10:37:26.997075+00
105	green-0	#EBFBEE	2023-08-03 10:37:26.997316+00	2023-08-03 10:37:26.997316+00
106	green-1	#D3F9D8	2023-08-03 10:37:26.997586+00	2023-08-03 10:37:26.997586+00
107	green-2	#B2F2BB	2023-08-03 10:37:26.99787+00	2023-08-03 10:37:26.99787+00
108	green-3	#8CE99A	2023-08-03 10:37:26.99814+00	2023-08-03 10:37:26.99814+00
109	green-4	#69DB7C	2023-08-03 10:37:26.9984+00	2023-08-03 10:37:26.9984+00
110	green-5	#51CF66	2023-08-03 10:37:26.99867+00	2023-08-03 10:37:26.99867+00
111	green-6	#40C057	2023-08-03 10:37:26.998933+00	2023-08-03 10:37:26.998933+00
112	green-7	#37B24D	2023-08-03 10:37:26.999189+00	2023-08-03 10:37:26.999189+00
113	green-8	#2F9E44	2023-08-03 10:37:26.999458+00	2023-08-03 10:37:26.999458+00
114	green-9	#2B8A3E	2023-08-03 10:37:26.999932+00	2023-08-03 10:37:26.999932+00
115	lime-0	#F4FCE3	2023-08-03 10:37:27.000231+00	2023-08-03 10:37:27.000231+00
116	lime-1	#E9FAC8	2023-08-03 10:37:27.000492+00	2023-08-03 10:37:27.000492+00
117	lime-2	#D8F5A2	2023-08-03 10:37:27.00076+00	2023-08-03 10:37:27.00076+00
118	lime-3	#C0EB75	2023-08-03 10:37:27.001037+00	2023-08-03 10:37:27.001037+00
119	lime-4	#A9E34B	2023-08-03 10:37:27.001394+00	2023-08-03 10:37:27.001394+00
120	lime-5	#94D82D	2023-08-03 10:37:27.001676+00	2023-08-03 10:37:27.001676+00
121	lime-6	#82C91E	2023-08-03 10:37:27.001946+00	2023-08-03 10:37:27.001946+00
122	lime-7	#74B816	2023-08-03 10:37:27.00221+00	2023-08-03 10:37:27.00221+00
123	lime-8	#66A80F	2023-08-03 10:37:27.002476+00	2023-08-03 10:37:27.002476+00
124	lime-9	#5C940D	2023-08-03 10:37:27.002744+00	2023-08-03 10:37:27.002744+00
125	yellow-0	#FFF9DB	2023-08-03 10:37:27.003002+00	2023-08-03 10:37:27.003002+00
126	yellow-1	#FFF3BF	2023-08-03 10:37:27.003267+00	2023-08-03 10:37:27.003267+00
127	yellow-2	#FFEC99	2023-08-03 10:37:27.003643+00	2023-08-03 10:37:27.003643+00
128	yellow-3	#FFE066	2023-08-03 10:37:27.003944+00	2023-08-03 10:37:27.003944+00
129	yellow-4	#FFD43B	2023-08-03 10:37:27.004185+00	2023-08-03 10:37:27.004185+00
130	yellow-5	#FCC419	2023-08-03 10:37:27.004453+00	2023-08-03 10:37:27.004453+00
131	yellow-6	#FAB005	2023-08-03 10:37:27.004723+00	2023-08-03 10:37:27.004723+00
132	yellow-7	#F59F00	2023-08-03 10:37:27.004978+00	2023-08-03 10:37:27.004978+00
133	yellow-8	#F08C00	2023-08-03 10:37:27.005231+00	2023-08-03 10:37:27.005231+00
134	yellow-9	#E67700	2023-08-03 10:37:27.005727+00	2023-08-03 10:37:27.005727+00
135	orange-0	#FFF4E6	2023-08-03 10:37:27.006251+00	2023-08-03 10:37:27.006251+00
136	orange-1	#FFE8CC	2023-08-03 10:37:27.006899+00	2023-08-03 10:37:27.006899+00
137	orange-2	#FFD8A8	2023-08-03 10:37:27.008082+00	2023-08-03 10:37:27.008082+00
138	orange-3	#FFC078	2023-08-03 10:37:27.009005+00	2023-08-03 10:37:27.009005+00
139	orange-4	#FFA94D	2023-08-03 10:37:27.009442+00	2023-08-03 10:37:27.009442+00
140	orange-5	#FF922B	2023-08-03 10:37:27.009845+00	2023-08-03 10:37:27.009845+00
141	orange-6	#FD7E14	2023-08-03 10:37:27.010237+00	2023-08-03 10:37:27.010237+00
142	orange-7	#F76707	2023-08-03 10:37:27.010585+00	2023-08-03 10:37:27.010585+00
143	orange-8	#E8590C	2023-08-03 10:37:27.010949+00	2023-08-03 10:37:27.010949+00
144	orange-9	#D9480F	2023-08-03 10:37:27.011446+00	2023-08-03 10:37:27.011446+00
\.


--
-- Data for Name: comments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.comments (id, commented_type, commented_id, author_id, comments, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: cost_entries; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cost_entries (id, user_id, project_id, work_package_id, cost_type_id, units, spent_on, created_at, updated_at, comments, blocked, overridden_costs, costs, rate_id, tyear, tmonth, tweek, logged_by_id) FROM stdin;
\.


--
-- Data for Name: cost_queries; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cost_queries (id, user_id, project_id, name, is_public, created_at, updated_at, serialized) FROM stdin;
\.


--
-- Data for Name: cost_types; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cost_types (id, name, unit, unit_plural, "default", deleted_at) FROM stdin;
\.


--
-- Data for Name: custom_actions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.custom_actions (id, name, actions, description, "position") FROM stdin;
\.


--
-- Data for Name: custom_actions_projects; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.custom_actions_projects (id, project_id, custom_action_id) FROM stdin;
\.


--
-- Data for Name: custom_actions_roles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.custom_actions_roles (id, role_id, custom_action_id) FROM stdin;
\.


--
-- Data for Name: custom_actions_statuses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.custom_actions_statuses (id, status_id, custom_action_id) FROM stdin;
\.


--
-- Data for Name: custom_actions_types; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.custom_actions_types (id, type_id, custom_action_id) FROM stdin;
\.


--
-- Data for Name: custom_fields; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.custom_fields (id, type, field_format, regexp, min_length, max_length, is_required, is_for_all, is_filter, "position", searchable, editable, visible, multi_value, default_value, name, created_at, updated_at, content_right_to_left) FROM stdin;
\.


--
-- Data for Name: custom_fields_projects; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.custom_fields_projects (custom_field_id, project_id) FROM stdin;
\.


--
-- Data for Name: custom_fields_types; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.custom_fields_types (custom_field_id, type_id) FROM stdin;
\.


--
-- Data for Name: custom_options; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.custom_options (id, custom_field_id, "position", default_value, value, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: custom_styles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.custom_styles (id, logo, created_at, updated_at, favicon, touch_icon, theme, theme_logo) FROM stdin;
\.


--
-- Data for Name: custom_values; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.custom_values (id, customized_type, customized_id, custom_field_id, value) FROM stdin;
\.


--
-- Data for Name: customizable_journals; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.customizable_journals (id, journal_id, custom_field_id, value) FROM stdin;
\.


--
-- Data for Name: delayed_job_statuses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.delayed_job_statuses (id, reference_type, reference_id, message, created_at, updated_at, status, user_id, job_id, payload) FROM stdin;
1	Export	1	\N	2023-08-03 10:42:24.082462+00	2023-08-03 10:42:27.373491+00	in_process	3	1e8ba5ac-48f8-4861-a52c-fedc522e1804	\N
\.


--
-- Data for Name: delayed_jobs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.delayed_jobs (id, priority, attempts, handler, last_error, run_at, locked_at, failed_at, locked_by, created_at, updated_at, queue, cron) FROM stdin;
2	10	0	--- !ruby/object:ActiveJob::QueueAdapters::DelayedJobAdapter::JobWrapper\njob_data:\n  job_class: CleanupWebhookLogsJob\n  job_id: 9783e388-040d-4975-ae39-d220d6a3a4a2\n  provider_job_id: \n  queue_name: default\n  priority: \n  arguments: []\n  executions: 0\n  exception_executions: {}\n  locale: en\n  timezone: UTC\n  enqueued_at: '2023-08-03T10:37:41Z'\n	\N	2023-08-06 05:28:00+00	\N	\N	\N	2023-08-03 10:37:41.189487+00	2023-08-03 10:37:41.189487+00	default	28 5 * * 7
3	10	0	--- !ruby/object:ActiveJob::QueueAdapters::DelayedJobAdapter::JobWrapper\njob_data:\n  job_class: Cron::ClearOldPullRequestsJob\n  job_id: 9defde42-e7bd-41a6-b654-ef7a4dffccb8\n  provider_job_id: \n  queue_name: default\n  priority: \n  arguments: []\n  executions: 0\n  exception_executions: {}\n  locale: en\n  timezone: UTC\n  enqueued_at: '2023-08-03T10:37:41Z'\n	\N	2023-08-04 01:25:00+00	\N	\N	\N	2023-08-03 10:37:41.205185+00	2023-08-03 10:37:41.205185+00	default	25 1 * * *
4	10	0	--- !ruby/object:ActiveJob::QueueAdapters::DelayedJobAdapter::JobWrapper\njob_data:\n  job_class: LdapGroups::SynchronizationJob\n  job_id: ea2307b9-a1fd-44ea-9eb7-602c3e10fb39\n  provider_job_id: \n  queue_name: default\n  priority: \n  arguments: []\n  executions: 0\n  exception_executions: {}\n  locale: en\n  timezone: UTC\n  enqueued_at: '2023-08-03T10:37:41Z'\n	\N	2023-08-03 11:00:00+00	\N	\N	\N	2023-08-03 10:37:41.210393+00	2023-08-03 10:37:41.210393+00	default	*/30 * * * *
5	10	0	--- !ruby/object:ActiveJob::QueueAdapters::DelayedJobAdapter::JobWrapper\njob_data:\n  job_class: JobStatus::Cron::ClearOldJobStatusJob\n  job_id: 2b31339b-b323-4df9-86d7-e27d7c4a6a74\n  provider_job_id: \n  queue_name: default\n  priority: \n  arguments: []\n  executions: 0\n  exception_executions: {}\n  locale: en\n  timezone: UTC\n  enqueued_at: '2023-08-03T10:37:41Z'\n	\N	2023-08-04 04:15:00+00	\N	\N	\N	2023-08-03 10:37:41.215345+00	2023-08-03 10:37:41.215345+00	default	15 4 * * *
6	20	0	--- !ruby/object:ActiveJob::QueueAdapters::DelayedJobAdapter::JobWrapper\njob_data:\n  job_class: CleanupUncontaineredFileLinksJob\n  job_id: e3084a8f-f7ee-4991-9ec5-65987c0c3ef9\n  provider_job_id: \n  queue_name: default\n  priority: 20\n  arguments: []\n  executions: 0\n  exception_executions: {}\n  locale: en\n  timezone: UTC\n  enqueued_at: '2023-08-03T10:37:41Z'\n	\N	2023-08-03 22:06:00+00	\N	\N	\N	2023-08-03 10:37:41.220325+00	2023-08-03 10:37:41.220325+00	default	06 22 * * *
7	10	0	--- !ruby/object:ActiveJob::QueueAdapters::DelayedJobAdapter::JobWrapper\njob_data:\n  job_class: Cron::ClearOldSessionsJob\n  job_id: 239d79f8-c8dc-47b7-ad72-2506e66eeaad\n  provider_job_id: \n  queue_name: default\n  priority: \n  arguments: []\n  executions: 0\n  exception_executions: {}\n  locale: en\n  timezone: UTC\n  enqueued_at: '2023-08-03T10:37:41Z'\n	\N	2023-08-04 01:15:00+00	\N	\N	\N	2023-08-03 10:37:41.225073+00	2023-08-03 10:37:41.225073+00	default	15 1 * * *
8	10	0	--- !ruby/object:ActiveJob::QueueAdapters::DelayedJobAdapter::JobWrapper\njob_data:\n  job_class: Cron::ClearTmpCacheJob\n  job_id: 00267066-6642-48da-af3d-88bb78dfff8f\n  provider_job_id: \n  queue_name: default\n  priority: \n  arguments: []\n  executions: 0\n  exception_executions: {}\n  locale: en\n  timezone: UTC\n  enqueued_at: '2023-08-03T10:37:41Z'\n	\N	2023-08-06 02:45:00+00	\N	\N	\N	2023-08-03 10:37:41.229815+00	2023-08-03 10:37:41.229815+00	default	45 2 * * 7
9	10	0	--- !ruby/object:ActiveJob::QueueAdapters::DelayedJobAdapter::JobWrapper\njob_data:\n  job_class: Cron::ClearUploadedFilesJob\n  job_id: 2be216dd-5537-45bb-94ac-f601c3bca232\n  provider_job_id: \n  queue_name: default\n  priority: \n  arguments: []\n  executions: 0\n  exception_executions: {}\n  locale: en\n  timezone: UTC\n  enqueued_at: '2023-08-03T10:37:41Z'\n	\N	2023-08-04 23:00:00+00	\N	\N	\N	2023-08-03 10:37:41.235955+00	2023-08-03 10:37:41.235955+00	default	0 23 * * 5
10	20	0	--- !ruby/object:ActiveJob::QueueAdapters::DelayedJobAdapter::JobWrapper\njob_data:\n  job_class: OAuth::CleanupJob\n  job_id: f38143ea-c4d3-4c30-9aaf-979e9083ab83\n  provider_job_id: \n  queue_name: default\n  priority: 20\n  arguments: []\n  executions: 0\n  exception_executions: {}\n  locale: en\n  timezone: UTC\n  enqueued_at: '2023-08-03T10:37:41Z'\n	\N	2023-08-04 01:52:00+00	\N	\N	\N	2023-08-03 10:37:41.241292+00	2023-08-03 10:37:41.241292+00	default	52 1 * * *
11	10	0	--- !ruby/object:ActiveJob::QueueAdapters::DelayedJobAdapter::JobWrapper\njob_data:\n  job_class: PaperTrailAudits::CleanupJob\n  job_id: 441c03b9-41f9-4740-984d-f3c92e9b4fc2\n  provider_job_id: \n  queue_name: default\n  priority: \n  arguments: []\n  executions: 0\n  exception_executions: {}\n  locale: en\n  timezone: UTC\n  enqueued_at: '2023-08-03T10:37:41Z'\n	\N	2023-08-05 04:03:00+00	\N	\N	\N	2023-08-03 10:37:41.245802+00	2023-08-03 10:37:41.245802+00	default	3 4 * * 6
12	20	0	--- !ruby/object:ActiveJob::QueueAdapters::DelayedJobAdapter::JobWrapper\njob_data:\n  job_class: Attachments::CleanupUncontaineredJob\n  job_id: bb7e1192-209a-46d4-9959-954fe3e6ddde\n  provider_job_id: \n  queue_name: default\n  priority: 20\n  arguments: []\n  executions: 0\n  exception_executions: {}\n  locale: en\n  timezone: UTC\n  enqueued_at: '2023-08-03T10:37:41Z'\n	\N	2023-08-03 22:03:00+00	\N	\N	\N	2023-08-03 10:37:41.250618+00	2023-08-03 10:37:41.250618+00	default	03 22 * * *
13	10	0	--- !ruby/object:ActiveJob::QueueAdapters::DelayedJobAdapter::JobWrapper\njob_data:\n  job_class: Notifications::ScheduleDateAlertsNotificationsJob\n  job_id: 30e45b82-6ab0-4693-a898-7dd4ff560811\n  provider_job_id: \n  queue_name: default\n  priority: \n  arguments: []\n  executions: 0\n  exception_executions: {}\n  locale: en\n  timezone: UTC\n  enqueued_at: '2023-08-03T10:37:41Z'\n	\N	2023-08-03 10:45:00+00	\N	\N	\N	2023-08-03 10:37:41.255204+00	2023-08-03 10:37:41.255204+00	default	*/15 * * * *
14	10	0	--- !ruby/object:ActiveJob::QueueAdapters::DelayedJobAdapter::JobWrapper\njob_data:\n  job_class: Notifications::ScheduleReminderMailsJob\n  job_id: fd5f9bb6-5fac-40cc-b9d4-be295fc06fa4\n  provider_job_id: \n  queue_name: default\n  priority: \n  arguments: []\n  executions: 0\n  exception_executions: {}\n  locale: en\n  timezone: UTC\n  enqueued_at: '2023-08-03T10:37:41Z'\n	\N	2023-08-03 10:45:00+00	\N	\N	\N	2023-08-03 10:37:41.259824+00	2023-08-03 10:37:41.259824+00	default	*/15 * * * *
15	10	0	--- !ruby/object:ActiveJob::QueueAdapters::DelayedJobAdapter::JobWrapper\njob_data:\n  job_class: Ldap::SynchronizationJob\n  job_id: e0140baa-2473-405e-9467-719c1aa23755\n  provider_job_id: \n  queue_name: default\n  priority: \n  arguments: []\n  executions: 0\n  exception_executions: {}\n  locale: en\n  timezone: UTC\n  enqueued_at: '2023-08-03T10:37:41Z'\n	\N	2023-08-03 23:30:00+00	\N	\N	\N	2023-08-03 10:37:41.264135+00	2023-08-03 10:37:41.264135+00	default	30 23 * * *
17	5	0	--- !ruby/object:ActiveJob::QueueAdapters::DelayedJobAdapter::JobWrapper\njob_data:\n  job_class: Notifications::WorkflowJob\n  job_id: cf3a136c-bfec-4edb-9d48-fa3623fcc715\n  provider_job_id: \n  queue_name: default\n  priority: 5\n  arguments:\n  - _aj_serialized: ActiveJob::Serializers::SymbolSerializer\n    value: send_mails\n  executions: 0\n  exception_executions: {}\n  locale: de\n  timezone: UTC\n  enqueued_at: '2023-08-03T10:40:16Z'\n	\N	2023-08-03 10:45:16.590636+00	\N	\N	\N	2023-08-03 10:40:16.596372+00	2023-08-03 10:40:16.596372+00	default	\N
19	5	0	--- !ruby/object:ActiveJob::QueueAdapters::DelayedJobAdapter::JobWrapper\njob_data:\n  job_class: Journals::CompletedJob\n  job_id: 5032ee5d-94e4-46d0-b7f3-f9f7410f58ac\n  provider_job_id: \n  queue_name: default\n  priority: 5\n  arguments:\n  - 46\n  - _aj_serialized: ActiveJob::Serializers::TimeWithZoneSerializer\n    value: '2023-08-03T10:40:31.599371000Z'\n  - true\n  executions: 0\n  exception_executions: {}\n  locale: de\n  timezone: UTC\n  enqueued_at: '2023-08-03T10:40:31Z'\n	\N	2023-08-03 10:45:31.65199+00	\N	\N	\N	2023-08-03 10:40:31.65878+00	2023-08-03 10:40:31.65878+00	default	\N
21	5	0	--- !ruby/object:ActiveJob::QueueAdapters::DelayedJobAdapter::JobWrapper\njob_data:\n  job_class: Journals::CompletedJob\n  job_id: 5b820b00-d217-426b-99b5-7c5706946c5b\n  provider_job_id: \n  queue_name: default\n  priority: 5\n  arguments:\n  - 46\n  - _aj_serialized: ActiveJob::Serializers::TimeWithZoneSerializer\n    value: '2023-08-03T10:40:31.681193000Z'\n  - true\n  executions: 0\n  exception_executions: {}\n  locale: de\n  timezone: UTC\n  enqueued_at: '2023-08-03T10:40:31Z'\n	\N	2023-08-03 10:45:31.684304+00	\N	\N	\N	2023-08-03 10:40:31.68517+00	2023-08-03 10:40:31.68517+00	default	\N
22	5	0	--- !ruby/object:ActiveJob::QueueAdapters::DelayedJobAdapter::JobWrapper\njob_data:\n  job_class: Notifications::WorkflowJob\n  job_id: 0b0cb2bf-2deb-4fd6-ac63-ea8d2e11bf4f\n  provider_job_id: \n  queue_name: default\n  priority: 5\n  arguments:\n  - _aj_serialized: ActiveJob::Serializers::SymbolSerializer\n    value: send_mails\n  executions: 0\n  exception_executions: {}\n  locale: de\n  timezone: UTC\n  enqueued_at: '2023-08-03T10:40:36Z'\n	\N	2023-08-03 10:45:36.732143+00	\N	\N	\N	2023-08-03 10:40:36.733123+00	2023-08-03 10:40:36.733123+00	default	\N
28	5	0	--- !ruby/object:ActiveJob::QueueAdapters::DelayedJobAdapter::JobWrapper\njob_data:\n  job_class: Journals::CompletedJob\n  job_id: 62ff3e73-3ff2-489b-8457-3fa4f0afa5d7\n  provider_job_id: \n  queue_name: default\n  priority: 5\n  arguments:\n  - 46\n  - _aj_serialized: ActiveJob::Serializers::TimeWithZoneSerializer\n    value: '2023-08-03T10:41:23.916315000Z'\n  - true\n  executions: 0\n  exception_executions: {}\n  locale: de\n  timezone: UTC\n  enqueued_at: '2023-08-03T10:41:23Z'\n	\N	2023-08-03 10:46:23.930585+00	\N	\N	\N	2023-08-03 10:41:23.931786+00	2023-08-03 10:41:23.931786+00	default	\N
23	5	0	--- !ruby/object:ActiveJob::QueueAdapters::DelayedJobAdapter::JobWrapper\njob_data:\n  job_class: Notifications::WorkflowJob\n  job_id: 15e5b5be-8822-4dd4-852f-d12b36f65bc0\n  provider_job_id: \n  queue_name: default\n  priority: 5\n  arguments:\n  - _aj_serialized: ActiveJob::Serializers::SymbolSerializer\n    value: send_mails\n  executions: 0\n  exception_executions: {}\n  locale: de\n  timezone: UTC\n  enqueued_at: '2023-08-03T10:40:36Z'\n	\N	2023-08-03 10:45:36.788553+00	\N	\N	\N	2023-08-03 10:40:36.789701+00	2023-08-03 10:40:36.789701+00	default	\N
25	5	0	--- !ruby/object:ActiveJob::QueueAdapters::DelayedJobAdapter::JobWrapper\njob_data:\n  job_class: Journals::CompletedJob\n  job_id: afc1cc17-cb4f-4a31-822a-884ca1c2ed3e\n  provider_job_id: \n  queue_name: default\n  priority: 5\n  arguments:\n  - 46\n  - _aj_serialized: ActiveJob::Serializers::TimeWithZoneSerializer\n    value: '2023-08-03T10:40:52.960973000Z'\n  - true\n  executions: 0\n  exception_executions: {}\n  locale: de\n  timezone: UTC\n  enqueued_at: '2023-08-03T10:40:52Z'\n	\N	2023-08-03 10:45:52.963373+00	\N	\N	\N	2023-08-03 10:40:52.964032+00	2023-08-03 10:40:52.964032+00	default	\N
26	5	0	--- !ruby/object:ActiveJob::QueueAdapters::DelayedJobAdapter::JobWrapper\njob_data:\n  job_class: Notifications::WorkflowJob\n  job_id: 568f9081-bf67-406f-bf10-e4e7496582c9\n  provider_job_id: \n  queue_name: default\n  priority: 5\n  arguments:\n  - _aj_serialized: ActiveJob::Serializers::SymbolSerializer\n    value: send_mails\n  executions: 0\n  exception_executions: {}\n  locale: de\n  timezone: UTC\n  enqueued_at: '2023-08-03T10:40:56Z'\n	\N	2023-08-03 10:45:56.912028+00	\N	\N	\N	2023-08-03 10:40:56.912704+00	2023-08-03 10:40:56.912704+00	default	\N
29	5	0	--- !ruby/object:ActiveJob::QueueAdapters::DelayedJobAdapter::JobWrapper\njob_data:\n  job_class: Notifications::WorkflowJob\n  job_id: 1de74116-a0ed-424c-b87b-dff2e8a1282e\n  provider_job_id: \n  queue_name: default\n  priority: 5\n  arguments:\n  - _aj_serialized: ActiveJob::Serializers::SymbolSerializer\n    value: send_mails\n  executions: 0\n  exception_executions: {}\n  locale: de\n  timezone: UTC\n  enqueued_at: '2023-08-03T10:41:27Z'\n	\N	2023-08-03 10:46:27.043575+00	\N	\N	\N	2023-08-03 10:41:27.045111+00	2023-08-03 10:41:27.045111+00	default	\N
31	7	0	--- !ruby/object:ActiveJob::QueueAdapters::DelayedJobAdapter::JobWrapper\njob_data:\n  job_class: BackupJob\n  job_id: 1e8ba5ac-48f8-4861-a52c-fedc522e1804\n  provider_job_id: \n  queue_name: default\n  priority: 7\n  arguments:\n  - backup:\n      _aj_globalid: gid://open-project/Backup/1\n    user:\n      _aj_globalid: gid://open-project/User/3\n    include_attachments: true\n    _aj_ruby2_keywords:\n    - backup\n    - user\n    - include_attachments\n  executions: 0\n  exception_executions: {}\n  locale: de\n  timezone: UTC\n  enqueued_at: '2023-08-03T10:42:24Z'\n	\N	2023-08-03 10:42:24.077305+00	2023-08-03 10:42:27.329108+00	\N	host:4d971a9c73ac pid:138	2023-08-03 10:42:24.077392+00	2023-08-03 10:42:24.077392+00	default	\N
\.


--
-- Data for Name: design_colors; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.design_colors (id, variable, hexcode, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: document_journals; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.document_journals (id, project_id, category_id, title, description) FROM stdin;
\.


--
-- Data for Name: documents; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.documents (id, project_id, category_id, title, description, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: done_statuses_for_project; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.done_statuses_for_project (project_id, status_id) FROM stdin;
\.


--
-- Data for Name: enabled_modules; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.enabled_modules (id, project_id, name) FROM stdin;
1	1	work_package_tracking
2	1	news
3	1	wiki
4	1	board_view
5	1	team_planner_view
6	2	backlogs
7	2	news
8	2	wiki
9	2	work_package_tracking
10	2	board_view
\.


--
-- Data for Name: enterprise_tokens; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.enterprise_tokens (id, encoded_token, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: enumerations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.enumerations (id, name, "position", is_default, type, active, project_id, parent_id, created_at, updated_at, color_id) FROM stdin;
1	Management	1	t	TimeEntryActivity	t	\N	\N	2023-08-03 10:37:26.941341+00	2023-08-03 10:37:26.941341+00	\N
2	Specification	2	f	TimeEntryActivity	t	\N	\N	2023-08-03 10:37:26.942639+00	2023-08-03 10:37:26.942639+00	\N
3	Development	3	f	TimeEntryActivity	t	\N	\N	2023-08-03 10:37:26.944933+00	2023-08-03 10:37:26.944933+00	\N
4	Testing	4	f	TimeEntryActivity	t	\N	\N	2023-08-03 10:37:26.947001+00	2023-08-03 10:37:26.947001+00	\N
5	Support	5	f	TimeEntryActivity	t	\N	\N	2023-08-03 10:37:26.949018+00	2023-08-03 10:37:26.949018+00	\N
6	Other	6	f	TimeEntryActivity	t	\N	\N	2023-08-03 10:37:26.951081+00	2023-08-03 10:37:26.951081+00	\N
7	Low	1	f	IssuePriority	t	\N	\N	2023-08-03 10:37:29.776173+00	2023-08-03 10:37:29.776173+00	86
8	Normal	2	t	IssuePriority	t	\N	\N	2023-08-03 10:37:29.777787+00	2023-08-03 10:37:29.777787+00	78
9	High	3	f	IssuePriority	t	\N	\N	2023-08-03 10:37:29.780247+00	2023-08-03 10:37:29.780247+00	132
10	Immediate	4	f	IssuePriority	t	\N	\N	2023-08-03 10:37:29.782352+00	2023-08-03 10:37:29.782352+00	50
11	Documentation	1	f	DocumentCategory	t	\N	\N	2023-08-03 10:37:29.96626+00	2023-08-03 10:37:29.96626+00	\N
12	Specification	2	f	DocumentCategory	t	\N	\N	2023-08-03 10:37:29.967481+00	2023-08-03 10:37:29.967481+00	\N
13	Other	3	f	DocumentCategory	t	\N	\N	2023-08-03 10:37:29.968574+00	2023-08-03 10:37:29.968574+00	\N
\.


--
-- Data for Name: export_card_configurations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.export_card_configurations (id, name, per_page, page_size, orientation, rows, active, description) FROM stdin;
\.


--
-- Data for Name: exports; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.exports (id, created_at, updated_at, type) FROM stdin;
1	2023-08-03 10:42:24.073918+00	2023-08-03 10:42:24.073918+00	Backup
\.


--
-- Data for Name: file_links; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.file_links (id, storage_id, creator_id, container_id, container_type, origin_id, origin_name, origin_created_by_name, origin_last_modified_by_name, origin_mime_type, origin_created_at, origin_updated_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: forums; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.forums (id, project_id, name, description, "position", topics_count, messages_count, last_message_id) FROM stdin;
\.


--
-- Data for Name: github_check_runs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.github_check_runs (id, github_pull_request_id, github_id, github_html_url, app_id, github_app_owner_avatar_url, status, name, conclusion, output_title, output_summary, details_url, started_at, completed_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: github_pull_requests; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.github_pull_requests (id, github_user_id, merged_by_id, github_id, number, github_html_url, state, repository, github_updated_at, title, body, draft, merged, merged_at, comments_count, review_comments_count, additions_count, deletions_count, changed_files_count, labels, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: github_pull_requests_work_packages; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.github_pull_requests_work_packages (github_pull_request_id, work_package_id) FROM stdin;
\.


--
-- Data for Name: github_users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.github_users (id, github_id, github_login, github_html_url, github_avatar_url, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: grid_widgets; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.grid_widgets (id, start_row, end_row, start_column, end_column, identifier, options, grid_id) FROM stdin;
1	1	2	1	2	work_package_query	---\n:query_id: 5\n:filters:\n- :status:\n    :operator: "="\n    :values:\n    - '1'\n	1
2	1	2	2	3	work_package_query	---\n:query_id: 6\n:filters:\n- :status:\n    :operator: "="\n    :values:\n    - '7'\n	1
3	1	2	3	4	work_package_query	---\n:query_id: 7\n:filters:\n- :status:\n    :operator: "="\n    :values:\n    - '12'\n	1
4	1	2	4	5	work_package_query	---\n:query_id: 8\n:filters:\n- :status:\n    :operator: "="\n    :values:\n    - '14'\n	1
5	1	2	1	2	work_package_query	---\n:query_id: 9\n:filters:\n- :manualSort:\n    :operator: ow\n    :values: []\n	2
6	1	2	2	3	work_package_query	---\n:query_id: 10\n:filters:\n- :manualSort:\n    :operator: ow\n    :values: []\n	2
7	1	2	3	4	work_package_query	---\n:query_id: 11\n:filters:\n- :manualSort:\n    :operator: ow\n    :values: []\n	2
8	1	2	4	5	work_package_query	---\n:query_id: 12\n:filters:\n- :manualSort:\n    :operator: ow\n    :values: []\n	2
9	1	2	1	2	work_package_query	---\n:query_id: 13\n:filters:\n- :parent:\n    :operator: "="\n    :values:\n    - '2'\n	3
10	1	2	2	3	work_package_query	---\n:query_id: 14\n:filters:\n- :parent:\n    :operator: "="\n    :values:\n    - '10'\n	3
11	1	2	1	2	work_package_query	---\n:query_id: 19\n:filters:\n- :status:\n    :operator: "="\n    :values:\n    - '1'\n	4
12	1	2	2	3	work_package_query	---\n:query_id: 20\n:filters:\n- :status:\n    :operator: "="\n    :values:\n    - '7'\n	4
13	1	2	3	4	work_package_query	---\n:query_id: 21\n:filters:\n- :status:\n    :operator: "="\n    :values:\n    - '12'\n	4
14	1	2	4	5	work_package_query	---\n:query_id: 22\n:filters:\n- :status:\n    :operator: "="\n    :values:\n    - '14'\n	4
15	1	2	1	2	work_package_query	---\n:query_id: 23\n:filters:\n- :manualSort:\n    :operator: ow\n    :values: []\n	5
16	1	2	2	3	work_package_query	---\n:query_id: 24\n:filters:\n- :manualSort:\n    :operator: ow\n    :values: []\n	5
17	1	2	3	4	work_package_query	---\n:query_id: 25\n:filters:\n- :manualSort:\n    :operator: ow\n    :values: []\n	5
18	1	2	4	5	work_package_query	---\n:query_id: 26\n:filters:\n- :manualSort:\n    :operator: ow\n    :values: []\n	5
19	1	2	1	3	custom_text	---\n:name: Welcome\n:text: "![Teaser](/api/v3/attachments/1/content)"\n	6
20	2	5	1	2	custom_text	---\n:name: Getting started\n:text: |\n  We are glad you joined! We suggest to try a few things to get started in OpenProject.\n\n  Discover the most important features with our [Guided Tour]({{opSetting:base_url}}/projects/demo-project/work_packages/?start_onboarding_tour=true).\n\n  _Try the following steps:_\n\n  1. *Invite new members to your project*: &rightarrow; Go to [Members]({{opSetting:base_url}}/projects/demo-project/members) in the project navigation.\n  2. *View the work in your project*: &rightarrow; Go to [Work packages]({{opSetting:base_url}}/projects/demo-project/work_packages) in the project navigation.\n  3. *Create a new work package*: &rightarrow; Go to [Work packages &rightarrow; Create]({{opSetting:base_url}}/projects/demo-project/work_packages/new).\n  4. *Create and update a project plan*: &rightarrow; Go to [Project plan]({{opSetting:base_url}}/projects/demo-project/work_packages?query_id=1) in the project navigation.\n  5. *Activate further modules*: &rightarrow; Go to [Project settings &rightarrow; Modules]({{opSetting:base_url}}/projects/demo-project/settings/modules).\n  6. *Complete your tasks in the project*: &rightarrow; Go to [Work packages &rightarrow; Tasks]({{opSetting:base_url}}/projects/demo-project/work_packages/details/3/overview?query_id=3).\n\n  Here you will find our [User Guides](https://www.openproject.org/docs/user-guide/).\n  Please let us know if you have any questions or need support. Contact us: [support[at]openproject.com](mailto:support@openproject.com).\n	6
21	2	3	2	3	project_status	\N	6
22	3	4	2	3	project_description	\N	6
23	4	5	2	3	members	---\n:name: Members\n	6
24	5	6	1	3	work_packages_overview	---\n:name: Work packages\n	6
25	6	7	1	3	work_packages_table	---\n:name: Milestones\n:queryId: '2'\n	6
26	1	2	1	3	custom_text	---\n:name: Welcome\n:text: "![Teaser](/api/v3/attachments/2/content)"\n	7
27	2	5	1	2	custom_text	---\n:name: Getting started\n:text: |\n  We are glad you joined! We suggest to try a few things to get started in OpenProject.\n\n  Discover the most important features with our [Guided Tour]({{opSetting:base_url}}/projects/your-scrum-project/backlogs?start_scrum_onboarding_tour=true).\n\n  _Try the following steps:_\n\n  1. *Invite new members to your project*: &rightarrow; Go to [Members]({{opSetting:base_url}}/projects/your-scrum-project/members) in the project navigation.\n  2. *View your Product backlog and Sprint backlogs*: &rightarrow; Go to [Backlogs]({{opSetting:base_url}}/projects/your-scrum-project/backlogs) in the project navigation.\n  3. *View your Task board*: &rightarrow; Go to [Backlogs]({{opSetting:base_url}}/projects/your-scrum-project/backlogs) &rightarrow; Click on right arrow on Sprint &rightarrow; Select [Task Board](/projects/your-scrum-project/sprints/3/taskboard).\n  4. *Create a new work package*: &rightarrow; Go to [Work packages &rightarrow; Create]({{opSetting:base_url}}/projects/your-scrum-project/work_packages/new).\n  5. *Create and update a project plan*: &rightarrow; Go to [Project plan](/projects/your-scrum-project/work_packages?query_id=15) in the project navigation.\n  6. *Create a Sprint wiki*: &rightarrow; Go to [Backlogs]({{opSetting:base_url}}/projects/your-scrum-project/backlogs) and open the sprint wiki from the right drop down menu in a sprint. You can edit the [wiki template]({{opSetting:base_url}}/projects/your-scrum-project/wiki/) based on your needs.\n  7. *Activate further modules*: &rightarrow; Go to [Project settings &rightarrow; Modules]({{opSetting:base_url}}/projects/your-scrum-project/settings/modules).\n\n  Here you will find our [User Guides](https://www.openproject.org/docs/user-guide/).\n  Please let us know if you have any questions or need support. Contact us: [support[at]openproject.com](mailto:support@openproject.com).\n	7
28	2	3	2	3	project_status	\N	7
29	3	4	2	3	project_description	\N	7
30	4	5	2	3	members	---\n:name: Members\n	7
31	5	6	1	3	work_packages_overview	---\n:name: Work packages\n	7
32	6	7	1	3	work_packages_table	---\n:name: Project plan\n:queryId: '15'\n	7
\.


--
-- Data for Name: grids; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.grids (id, row_count, column_count, type, user_id, created_at, updated_at, project_id, name, options) FROM stdin;
1	1	0	Boards::Grid	\N	2023-08-03 10:37:30.761791+00	2023-08-03 10:37:30.761791+00	1	Kanban board	---\ntype: action\nattribute: status\nhighlightingMode: priority\n:filters:\n- :type:\n    :operator: "="\n    :values:\n    - '1'\n
2	1	0	Boards::Grid	\N	2023-08-03 10:37:30.78246+00	2023-08-03 10:37:30.78246+00	1	Basic board	---\nhighlightingMode: priority\n
3	1	0	Boards::Grid	\N	2023-08-03 10:37:30.795517+00	2023-08-03 10:37:30.795517+00	1	Work breakdown structure	---\ntype: action\nattribute: subtasks\n
4	1	0	Boards::Grid	\N	2023-08-03 10:37:31.564599+00	2023-08-03 10:37:31.564599+00	2	Kanban board	---\ntype: action\nattribute: status\nhighlightingMode: priority\n
5	1	0	Boards::Grid	\N	2023-08-03 10:37:31.583077+00	2023-08-03 10:37:31.583077+00	2	Task board	---\nhighlightingMode: priority\n
6	6	2	Grids::Overview	\N	2023-08-03 10:37:31.595739+00	2023-08-03 10:37:31.595739+00	1	\N	\N
7	6	2	Grids::Overview	\N	2023-08-03 10:37:31.627019+00	2023-08-03 10:37:31.627019+00	2	\N	\N
\.


--
-- Data for Name: group_users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.group_users (group_id, user_id, id) FROM stdin;
\.


--
-- Data for Name: ifc_models; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ifc_models (id, title, created_at, updated_at, project_id, uploader_id, is_default, conversion_status, conversion_error_message) FROM stdin;
\.


--
-- Data for Name: journals; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.journals (id, journable_type, journable_id, user_id, notes, created_at, version, updated_at, data_type, data_id) FROM stdin;
1	Project	1	4		2023-08-03 10:37:30.189551+00	1	2023-08-03 10:37:30.189551+00	Journal::ProjectJournal	1
2	News	1	4		2023-08-03 10:37:30.26514+00	1	2023-08-03 10:37:30.26514+00	Journal::NewsJournal	1
3	WorkPackage	1	4		2023-08-03 10:37:30.362073+00	1	2023-08-03 10:37:30.362073+00	Journal::WorkPackageJournal	1
6	WorkPackage	4	4		2023-08-03 10:37:30.434508+00	1	2023-08-03 10:37:30.456272+00	Journal::WorkPackageJournal	5
7	WorkPackage	5	4		2023-08-03 10:37:30.46595+00	1	2023-08-03 10:37:30.48515+00	Journal::WorkPackageJournal	7
8	WorkPackage	6	4		2023-08-03 10:37:30.494267+00	1	2023-08-03 10:37:30.516435+00	Journal::WorkPackageJournal	9
5	WorkPackage	3	4		2023-08-03 10:37:30.42146+00	1	2023-08-03 10:37:30.53959+00	Journal::WorkPackageJournal	11
9	WorkPackage	7	4		2023-08-03 10:37:30.548793+00	1	2023-08-03 10:37:30.571013+00	Journal::WorkPackageJournal	13
10	WorkPackage	8	4		2023-08-03 10:37:30.582649+00	1	2023-08-03 10:37:30.602088+00	Journal::WorkPackageJournal	15
4	WorkPackage	2	4		2023-08-03 10:37:30.404951+00	1	2023-08-03 10:37:30.610209+00	Journal::WorkPackageJournal	16
11	WorkPackage	9	4		2023-08-03 10:37:30.620252+00	1	2023-08-03 10:37:30.620252+00	Journal::WorkPackageJournal	17
13	WorkPackage	11	4		2023-08-03 10:37:30.650405+00	1	2023-08-03 10:37:30.669464+00	Journal::WorkPackageJournal	20
14	WorkPackage	12	4		2023-08-03 10:37:30.678678+00	1	2023-08-03 10:37:30.698903+00	Journal::WorkPackageJournal	22
12	WorkPackage	10	4		2023-08-03 10:37:30.637001+00	1	2023-08-03 10:37:30.706851+00	Journal::WorkPackageJournal	23
15	WorkPackage	13	4		2023-08-03 10:37:30.715227+00	1	2023-08-03 10:37:30.715227+00	Journal::WorkPackageJournal	24
16	Project	2	4		2023-08-03 10:37:30.805922+00	1	2023-08-03 10:37:30.805922+00	Journal::ProjectJournal	2
17	News	2	4		2023-08-03 10:37:30.84738+00	1	2023-08-03 10:37:30.84738+00	Journal::NewsJournal	2
18	WikiContent	1	4		2023-08-03 10:37:30.910964+00	1	2023-08-03 10:37:30.910964+00	Journal::WikiContentJournal	1
19	WikiContent	2	4		2023-08-03 10:37:30.969775+00	1	2023-08-03 10:37:30.969775+00	Journal::WikiContentJournal	2
20	WorkPackage	14	4		2023-08-03 10:37:30.982383+00	1	2023-08-03 10:37:30.982383+00	Journal::WorkPackageJournal	25
21	WorkPackage	15	4		2023-08-03 10:37:31.00254+00	1	2023-08-03 10:37:31.00254+00	Journal::WorkPackageJournal	26
23	WorkPackage	17	4		2023-08-03 10:37:31.037148+00	1	2023-08-03 10:37:31.06331+00	Journal::WorkPackageJournal	29
24	WorkPackage	18	4		2023-08-03 10:37:31.073946+00	1	2023-08-03 10:37:31.096161+00	Journal::WorkPackageJournal	31
26	WorkPackage	20	4		2023-08-03 10:37:31.122433+00	1	2023-08-03 10:37:31.142681+00	Journal::WorkPackageJournal	34
25	WorkPackage	19	4		2023-08-03 10:37:31.106108+00	1	2023-08-03 10:37:31.16686+00	Journal::WorkPackageJournal	36
22	WorkPackage	16	4		2023-08-03 10:37:31.0229+00	1	2023-08-03 10:37:31.176081+00	Journal::WorkPackageJournal	37
27	WorkPackage	21	4		2023-08-03 10:37:31.186657+00	1	2023-08-03 10:37:31.186657+00	Journal::WorkPackageJournal	38
29	WorkPackage	23	4		2023-08-03 10:37:31.226873+00	1	2023-08-03 10:37:31.24722+00	Journal::WorkPackageJournal	41
28	WorkPackage	22	4		2023-08-03 10:37:31.207606+00	1	2023-08-03 10:37:31.256421+00	Journal::WorkPackageJournal	42
30	WorkPackage	24	4		2023-08-03 10:37:31.26635+00	1	2023-08-03 10:37:31.26635+00	Journal::WorkPackageJournal	43
31	WorkPackage	25	4		2023-08-03 10:37:31.290566+00	1	2023-08-03 10:37:31.290566+00	Journal::WorkPackageJournal	44
32	WorkPackage	26	4		2023-08-03 10:37:31.309943+00	1	2023-08-03 10:37:31.309943+00	Journal::WorkPackageJournal	45
33	WorkPackage	27	4		2023-08-03 10:37:31.329724+00	1	2023-08-03 10:37:31.329724+00	Journal::WorkPackageJournal	46
35	WorkPackage	29	4		2023-08-03 10:37:31.366729+00	1	2023-08-03 10:37:31.391202+00	Journal::WorkPackageJournal	49
34	WorkPackage	28	4		2023-08-03 10:37:31.349654+00	1	2023-08-03 10:37:31.406644+00	Journal::WorkPackageJournal	50
36	WorkPackage	30	4		2023-08-03 10:37:31.415173+00	1	2023-08-03 10:37:31.415173+00	Journal::WorkPackageJournal	51
37	WorkPackage	31	4		2023-08-03 10:37:31.433693+00	1	2023-08-03 10:37:31.433693+00	Journal::WorkPackageJournal	52
38	WorkPackage	32	4		2023-08-03 10:37:31.450448+00	1	2023-08-03 10:37:31.450448+00	Journal::WorkPackageJournal	53
39	WorkPackage	33	4		2023-08-03 10:37:31.467039+00	1	2023-08-03 10:37:31.467039+00	Journal::WorkPackageJournal	54
40	WorkPackage	34	4		2023-08-03 10:37:31.486185+00	1	2023-08-03 10:37:31.486185+00	Journal::WorkPackageJournal	55
41	WorkPackage	35	4		2023-08-03 10:37:31.506514+00	1	2023-08-03 10:37:31.506514+00	Journal::WorkPackageJournal	56
42	WorkPackage	36	4		2023-08-03 10:37:31.533606+00	1	2023-08-03 10:37:31.533606+00	Journal::WorkPackageJournal	57
43	Attachment	1	4		2023-08-03 10:37:31.609828+00	1	2023-08-03 10:37:31.609828+00	Journal::AttachmentJournal	1
44	Attachment	2	4		2023-08-03 10:37:31.631621+00	1	2023-08-03 10:37:31.631621+00	Journal::AttachmentJournal	2
45	Project	1	3		2023-08-03 10:40:15.789882+00	2	2023-08-03 10:40:15.789882+00	Journal::ProjectJournal	3
46	WorkPackage	37	3	Rischtisch öde deß ganße.	2023-08-03 10:40:31.599371+00	1	2023-08-03 10:41:23.916315+00	Journal::WorkPackageJournal	61
\.


--
-- Data for Name: labor_budget_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.labor_budget_items (id, budget_id, hours, user_id, comments, amount) FROM stdin;
\.


--
-- Data for Name: ldap_groups_memberships; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ldap_groups_memberships (id, user_id, group_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: ldap_groups_synchronized_filters; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ldap_groups_synchronized_filters (id, name, group_name_attribute, filter_string, auth_source_id, created_at, updated_at, base_dn, sync_users) FROM stdin;
\.


--
-- Data for Name: ldap_groups_synchronized_groups; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ldap_groups_synchronized_groups (id, group_id, auth_source_id, created_at, updated_at, dn, users_count, filter_id, sync_users) FROM stdin;
\.


--
-- Data for Name: material_budget_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.material_budget_items (id, budget_id, units, cost_type_id, comments, amount) FROM stdin;
\.


--
-- Data for Name: meeting_content_journals; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.meeting_content_journals (id, meeting_id, author_id, text, locked) FROM stdin;
\.


--
-- Data for Name: meeting_contents; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.meeting_contents (id, type, meeting_id, author_id, text, lock_version, created_at, updated_at, locked) FROM stdin;
\.


--
-- Data for Name: meeting_journals; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.meeting_journals (id, title, author_id, project_id, location, start_time, duration) FROM stdin;
\.


--
-- Data for Name: meeting_participants; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.meeting_participants (id, user_id, meeting_id, email, name, invited, attended, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: meetings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.meetings (id, title, author_id, project_id, location, start_time, duration, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: member_roles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.member_roles (id, member_id, role_id, inherited_from) FROM stdin;
1	1	3	\N
2	2	3	\N
\.


--
-- Data for Name: members; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.members (id, user_id, project_id, created_at, updated_at) FROM stdin;
1	3	1	2023-08-03 10:37:30.25882+00	2023-08-03 10:37:30.260042+00
2	3	2	2023-08-03 10:37:30.845316+00	2023-08-03 10:37:30.846309+00
\.


--
-- Data for Name: menu_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.menu_items (id, name, title, parent_id, options, navigatable_id, type) FROM stdin;
1	wiki	Wiki	\N	---\n:new_wiki_page: true\n:index_page: true\n	1	MenuItems::WikiMenuItem
2	wiki	Wiki	\N	---\n:new_wiki_page: true\n:index_page: true\n	2	MenuItems::WikiMenuItem
\.


--
-- Data for Name: message_journals; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.message_journals (id, forum_id, parent_id, subject, content, author_id, locked, sticky) FROM stdin;
\.


--
-- Data for Name: messages; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.messages (id, forum_id, parent_id, subject, content, author_id, replies_count, last_reply_id, created_at, updated_at, locked, sticky, sticked_on) FROM stdin;
\.


--
-- Data for Name: news; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.news (id, project_id, title, summary, description, author_id, created_at, comments_count, updated_at) FROM stdin;
1	1	Welcome to your demo project	We are glad you joined. In this module you can communicate project news to your team members.\n	The actual news	1	2023-08-03 10:37:30.26514+00	0	2023-08-03 10:37:30.26514+00
2	2	Welcome to your Scrum demo project	We are glad you joined. In this module you can communicate project news to your team members.\n	This is the news content.	1	2023-08-03 10:37:30.84738+00	0	2023-08-03 10:37:30.84738+00
\.


--
-- Data for Name: news_journals; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.news_journals (id, project_id, title, summary, description, author_id, comments_count) FROM stdin;
1	1	Welcome to your demo project	We are glad you joined. In this module you can communicate project news to your team members.\n	The actual news	1	0
2	2	Welcome to your Scrum demo project	We are glad you joined. In this module you can communicate project news to your team members.\n	This is the news content.	1	0
\.


--
-- Data for Name: non_working_days; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.non_working_days (id, name, date, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: notification_settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.notification_settings (id, project_id, user_id, watched, mentioned, created_at, updated_at, work_package_commented, work_package_created, work_package_processed, work_package_prioritized, work_package_scheduled, news_added, news_commented, document_added, forum_messages, wiki_page_added, wiki_page_updated, membership_added, membership_updated, start_date, due_date, overdue, assignee, responsible) FROM stdin;
1	\N	3	t	t	2023-08-03 10:37:29.993217+00	2023-08-03 10:37:29.993217+00	f	f	f	f	f	f	f	f	f	f	f	f	f	1	1	\N	t	t
\.


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.notifications (id, subject, read_ian, reason, recipient_id, actor_id, resource_type, resource_id, project_id, journal_id, created_at, updated_at, mail_reminder_sent, mail_alert_sent) FROM stdin;
\.


--
-- Data for Name: oauth_access_grants; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.oauth_access_grants (id, resource_owner_id, application_id, token, expires_in, redirect_uri, created_at, revoked_at, scopes, code_challenge, code_challenge_method) FROM stdin;
\.


--
-- Data for Name: oauth_access_tokens; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.oauth_access_tokens (id, resource_owner_id, application_id, token, refresh_token, expires_in, revoked_at, created_at, scopes, previous_refresh_token) FROM stdin;
\.


--
-- Data for Name: oauth_applications; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.oauth_applications (id, name, uid, secret, owner_type, owner_id, client_credentials_user_id, redirect_uri, scopes, confidential, created_at, updated_at, integration_type, integration_id) FROM stdin;
\.


--
-- Data for Name: oauth_client_tokens; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.oauth_client_tokens (id, oauth_client_id, user_id, access_token, refresh_token, token_type, expires_in, scope, origin_user_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: oauth_clients; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.oauth_clients (id, client_id, client_secret, integration_type, integration_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: oidc_user_session_links; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.oidc_user_session_links (id, oidc_session, session_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: ordered_work_packages; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ordered_work_packages (id, "position", query_id, work_package_id) FROM stdin;
1	0	9	8
2	1	9	11
3	0	10	7
4	0	11	3
5	0	23	16
6	1	23	25
7	2	23	27
8	0	24	14
9	0	25	26
10	0	26	24
\.


--
-- Data for Name: paper_trail_audits; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.paper_trail_audits (id, item_type, item_id, event, whodunnit, stack, object, object_changes, created_at) FROM stdin;
\.


--
-- Data for Name: project_journals; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.project_journals (id, name, description, public, parent_id, identifier, active, templated) FROM stdin;
1	Demo project	This is a short summary of the goals of this demo project.	t	\N	demo-project	t	f
2	Scrum project	This is a short summary of the goals of this demo Scrum project.	t	\N	your-scrum-project	t	f
3	Dämöpröjäkt	This is a short summary of the goals of this demo project.	t	\N	demo-project	t	f
\.


--
-- Data for Name: project_statuses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.project_statuses (id, project_id, explanation, code, created_at, updated_at) FROM stdin;
1	1	All tasks are on schedule. The people involved know their tasks. The system is completely set up.	0	2023-08-03 10:37:30.247428+00	2023-08-03 10:37:30.247428+00
2	2	All tasks are on schedule. The people involved know their tasks. The system is completely set up.	0	2023-08-03 10:37:30.839619+00	2023-08-03 10:37:30.839619+00
\.


--
-- Data for Name: projects; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.projects (id, name, description, public, parent_id, created_at, updated_at, identifier, lft, rgt, active, templated) FROM stdin;
2	Scrum project	This is a short summary of the goals of this demo Scrum project.	t	\N	2023-08-03 10:37:30.805922+00	2023-08-03 10:37:30.805922+00	your-scrum-project	3	4	t	f
1	Dämöpröjäkt	This is a short summary of the goals of this demo project.	t	\N	2023-08-03 10:37:30.189551+00	2023-08-03 10:40:15.789882+00	demo-project	1	2	t	f
\.


--
-- Data for Name: projects_storages; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.projects_storages (id, project_id, storage_id, creator_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: projects_types; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.projects_types (project_id, type_id) FROM stdin;
1	1
1	2
1	3
2	1
2	2
2	3
2	5
2	6
2	7
\.


--
-- Data for Name: queries; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.queries (id, project_id, name, filters, user_id, public, column_names, sort_criteria, group_by, display_sums, timeline_visible, show_hierarchies, timeline_zoom_level, timeline_labels, highlighting_mode, highlighted_attributes, created_at, updated_at, display_representation, starred, include_subprojects, timestamps) FROM stdin;
1	1	Project plan	---\nstatus_id:\n  :operator: o\n  :values: []\n	3	t	---\n- :id\n- :type\n- :subject\n- :status\n- :start_date\n- :due_date\n- :duration\n- :assigned_to\n	---\n- - id\n  - asc\n	\N	f	t	t	5	\N	\N	\N	2023-08-03 10:37:30.317743+00	2023-08-03 10:37:30.317743+00	\N	t	t	\N
2	1	Milestones	---\ntype_id:\n  :operator: "="\n  :values:\n  - '2'\n	3	t	---\n- :id\n- :type\n- :subject\n- :status\n- :start_date\n- :due_date\n	---\n- - id\n  - asc\n	\N	f	t	f	5	\N	\N	\N	2023-08-03 10:37:30.330146+00	2023-08-03 10:37:30.330146+00	\N	f	t	\N
3	1	Tasks	---\nstatus_id:\n  :operator: o\n  :values: []\ntype_id:\n  :operator: "="\n  :values:\n  - '1'\n	3	t	---\n- :id\n- :subject\n- :priority\n- :status\n- :assigned_to\n	---\n- - id\n  - asc\n	\N	f	f	t	5	\N	\N	\N	2023-08-03 10:37:30.336277+00	2023-08-03 10:37:30.336277+00	\N	f	t	\N
4	1	Team planner	---\nassigned_to_id:\n  :operator: "="\n  :values:\n  - '3'\n	3	t	\N	\N	\N	f	f	f	5	\N	\N	\N	2023-08-03 10:37:30.342505+00	2023-08-03 10:37:30.342505+00	\N	f	t	\N
5	1	New	---\nstatus_id:\n  :operator: "="\n  :values:\n  - '1'\n	1	t	\N	---\n- - manual_sorting\n  - asc\n	\N	f	f	t	5	\N	\N	\N	2023-08-03 10:37:30.752005+00	2023-08-03 10:37:30.752005+00	\N	f	t	\N
6	1	In progress	---\nstatus_id:\n  :operator: "="\n  :values:\n  - '7'\n	1	t	\N	---\n- - manual_sorting\n  - asc\n	\N	f	f	t	5	\N	\N	\N	2023-08-03 10:37:30.75391+00	2023-08-03 10:37:30.75391+00	\N	f	t	\N
7	1	Closed	---\nstatus_id:\n  :operator: "="\n  :values:\n  - '12'\n	1	t	\N	---\n- - manual_sorting\n  - asc\n	\N	f	f	t	5	\N	\N	\N	2023-08-03 10:37:30.755564+00	2023-08-03 10:37:30.755564+00	\N	f	t	\N
8	1	Rejected	---\nstatus_id:\n  :operator: "="\n  :values:\n  - '14'\n	1	t	\N	---\n- - manual_sorting\n  - asc\n	\N	f	f	t	5	\N	\N	\N	2023-08-03 10:37:30.757169+00	2023-08-03 10:37:30.757169+00	\N	f	t	\N
9	1	Wish list	---\nmanual_sort:\n  :operator: ow\n  :values: []\n	1	t	\N	---\n- - manual_sorting\n  - asc\n	\N	f	f	f	5	\N	\N	\N	2023-08-03 10:37:30.773196+00	2023-08-03 10:37:30.773196+00	\N	f	t	\N
10	1	Short list	---\nmanual_sort:\n  :operator: ow\n  :values: []\n	1	t	\N	---\n- - manual_sorting\n  - asc\n	\N	f	f	f	5	\N	\N	\N	2023-08-03 10:37:30.776281+00	2023-08-03 10:37:30.776281+00	\N	f	t	\N
11	1	Prio list for today	---\nmanual_sort:\n  :operator: ow\n  :values: []\n	1	t	\N	---\n- - manual_sorting\n  - asc\n	\N	f	f	f	5	\N	\N	\N	2023-08-03 10:37:30.779083+00	2023-08-03 10:37:30.779083+00	\N	f	t	\N
12	1	Never	---\nmanual_sort:\n  :operator: ow\n  :values: []\n	1	t	\N	---\n- - manual_sorting\n  - asc\n	\N	f	f	f	5	\N	\N	\N	2023-08-03 10:37:30.781515+00	2023-08-03 10:37:30.781515+00	\N	f	t	\N
13	1	Organize open source conference	---\nstatus_id:\n  :operator: o\n  :values:\n  - ''\nparent:\n  :operator: "="\n  :values:\n  - '2'\n	1	t	\N	---\n- - manual_sorting\n  - asc\n	\N	f	f	t	5	\N	\N	\N	2023-08-03 10:37:30.790635+00	2023-08-03 10:37:30.790635+00	\N	f	t	\N
14	1	Follow-up tasks	---\nstatus_id:\n  :operator: o\n  :values:\n  - ''\nparent:\n  :operator: "="\n  :values:\n  - '10'\n	1	t	\N	---\n- - manual_sorting\n  - asc\n	\N	f	f	t	5	\N	\N	\N	2023-08-03 10:37:30.794221+00	2023-08-03 10:37:30.794221+00	\N	f	t	\N
15	2	Project plan	---\nstatus_id:\n  :operator: o\n  :values: []\ntype_id:\n  :operator: "="\n  :values:\n  - '2'\n  - '3'\n	3	t	\N	---\n- - id\n  - asc\n	\N	f	t	f	5	\N	\N	\N	2023-08-03 10:37:30.943276+00	2023-08-03 10:37:30.943276+00	\N	f	t	\N
16	2	Product backlog	---\nstatus_id:\n  :operator: o\n  :values: []\nversion_id:\n  :operator: "="\n  :values:\n  - '2'\n	3	t	---\n- :id\n- :type\n- :subject\n- :priority\n- :status\n- :assigned_to\n- :story_points\n	---\n- - status\n  - asc\n	status	f	f	f	5	\N	\N	\N	2023-08-03 10:37:30.951458+00	2023-08-03 10:37:30.951458+00	\N	f	t	\N
17	2	Sprint 1	---\nstatus_id:\n  :operator: o\n  :values: []\nversion_id:\n  :operator: "="\n  :values:\n  - '3'\n	3	t	---\n- :id\n- :type\n- :subject\n- :priority\n- :status\n- :assigned_to\n- :done_ratio\n- :story_points\n	\N	\N	f	f	t	5	\N	\N	\N	2023-08-03 10:37:30.958302+00	2023-08-03 10:37:30.958302+00	\N	f	t	\N
18	2	Tasks	---\nstatus_id:\n  :operator: o\n  :values: []\ntype_id:\n  :operator: "="\n  :values:\n  - '1'\n	3	t	\N	\N	\N	f	f	t	5	\N	\N	\N	2023-08-03 10:37:30.964747+00	2023-08-03 10:37:30.964747+00	\N	f	t	\N
19	2	New	---\nstatus_id:\n  :operator: "="\n  :values:\n  - '1'\n	1	t	\N	---\n- - manual_sorting\n  - asc\n	\N	f	f	t	5	\N	\N	\N	2023-08-03 10:37:31.55723+00	2023-08-03 10:37:31.55723+00	\N	f	t	\N
20	2	In progress	---\nstatus_id:\n  :operator: "="\n  :values:\n  - '7'\n	1	t	\N	---\n- - manual_sorting\n  - asc\n	\N	f	f	t	5	\N	\N	\N	2023-08-03 10:37:31.559022+00	2023-08-03 10:37:31.559022+00	\N	f	t	\N
21	2	Closed	---\nstatus_id:\n  :operator: "="\n  :values:\n  - '12'\n	1	t	\N	---\n- - manual_sorting\n  - asc\n	\N	f	f	t	5	\N	\N	\N	2023-08-03 10:37:31.561314+00	2023-08-03 10:37:31.561314+00	\N	f	t	\N
22	2	Rejected	---\nstatus_id:\n  :operator: "="\n  :values:\n  - '14'\n	1	t	\N	---\n- - manual_sorting\n  - asc\n	\N	f	f	t	5	\N	\N	\N	2023-08-03 10:37:31.563314+00	2023-08-03 10:37:31.563314+00	\N	f	t	\N
23	2	Wish list	---\nmanual_sort:\n  :operator: ow\n  :values: []\n	1	t	\N	---\n- - manual_sorting\n  - asc\n	\N	f	f	f	5	\N	\N	\N	2023-08-03 10:37:31.573228+00	2023-08-03 10:37:31.573228+00	\N	f	t	\N
24	2	Short list	---\nmanual_sort:\n  :operator: ow\n  :values: []\n	1	t	\N	---\n- - manual_sorting\n  - asc\n	\N	f	f	f	5	\N	\N	\N	2023-08-03 10:37:31.576565+00	2023-08-03 10:37:31.576565+00	\N	f	t	\N
25	2	Prio list for today	---\nmanual_sort:\n  :operator: ow\n  :values: []\n	1	t	\N	---\n- - manual_sorting\n  - asc\n	\N	f	f	f	5	\N	\N	\N	2023-08-03 10:37:31.579432+00	2023-08-03 10:37:31.579432+00	\N	f	t	\N
26	2	Never	---\nmanual_sort:\n  :operator: ow\n  :values: []\n	1	t	\N	---\n- - manual_sorting\n  - asc\n	\N	f	f	f	5	\N	\N	\N	2023-08-03 10:37:31.581917+00	2023-08-03 10:37:31.581917+00	\N	f	t	\N
\.


--
-- Data for Name: rates; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.rates (id, valid_from, rate, type, project_id, user_id, cost_type_id) FROM stdin;
\.


--
-- Data for Name: recaptcha_entries; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.recaptcha_entries (id, user_id, created_at, updated_at, version) FROM stdin;
\.


--
-- Data for Name: relations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.relations (id, from_id, to_id, delay, description, relation_type) FROM stdin;
1	7	3	\N	\N	follows
2	8	3	\N	\N	follows
3	9	2	\N	\N	follows
4	13	10	\N	\N	follows
5	32	31	\N	\N	follows
6	34	33	\N	\N	follows
7	36	35	\N	\N	follows
\.


--
-- Data for Name: repositories; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.repositories (id, project_id, url, login, password, root_url, type, path_encoding, log_encoding, scm_type, required_storage_bytes, storage_updated_at) FROM stdin;
\.


--
-- Data for Name: role_permissions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.role_permissions (id, permission, role_id, created_at, updated_at) FROM stdin;
1	archive_project	3	2023-08-03 10:37:26.833816+00	2023-08-03 10:37:26.833816+00
2	edit_project	3	2023-08-03 10:37:26.834379+00	2023-08-03 10:37:26.834379+00
3	select_project_modules	3	2023-08-03 10:37:26.83476+00	2023-08-03 10:37:26.83476+00
4	manage_members	3	2023-08-03 10:37:26.835109+00	2023-08-03 10:37:26.835109+00
5	view_members	3	2023-08-03 10:37:26.835452+00	2023-08-03 10:37:26.835452+00
6	manage_versions	3	2023-08-03 10:37:26.835803+00	2023-08-03 10:37:26.835803+00
7	manage_types	3	2023-08-03 10:37:26.836144+00	2023-08-03 10:37:26.836144+00
8	select_custom_fields	3	2023-08-03 10:37:26.836471+00	2023-08-03 10:37:26.836471+00
9	add_subprojects	3	2023-08-03 10:37:26.836818+00	2023-08-03 10:37:26.836818+00
10	copy_projects	3	2023-08-03 10:37:26.837156+00	2023-08-03 10:37:26.837156+00
11	view_work_packages	3	2023-08-03 10:37:26.837481+00	2023-08-03 10:37:26.837481+00
12	add_work_packages	3	2023-08-03 10:37:26.837861+00	2023-08-03 10:37:26.837861+00
13	edit_work_packages	3	2023-08-03 10:37:26.838186+00	2023-08-03 10:37:26.838186+00
14	move_work_packages	3	2023-08-03 10:37:26.838514+00	2023-08-03 10:37:26.838514+00
15	add_work_package_notes	3	2023-08-03 10:37:26.838846+00	2023-08-03 10:37:26.838846+00
16	edit_work_package_notes	3	2023-08-03 10:37:26.839166+00	2023-08-03 10:37:26.839166+00
17	edit_own_work_package_notes	3	2023-08-03 10:37:26.839528+00	2023-08-03 10:37:26.839528+00
18	manage_categories	3	2023-08-03 10:37:26.839841+00	2023-08-03 10:37:26.839841+00
19	export_work_packages	3	2023-08-03 10:37:26.840085+00	2023-08-03 10:37:26.840085+00
20	delete_work_packages	3	2023-08-03 10:37:26.840329+00	2023-08-03 10:37:26.840329+00
21	manage_work_package_relations	3	2023-08-03 10:37:26.84056+00	2023-08-03 10:37:26.84056+00
22	manage_subtasks	3	2023-08-03 10:37:26.840788+00	2023-08-03 10:37:26.840788+00
23	manage_public_queries	3	2023-08-03 10:37:26.841017+00	2023-08-03 10:37:26.841017+00
24	save_queries	3	2023-08-03 10:37:26.841243+00	2023-08-03 10:37:26.841243+00
25	view_work_package_watchers	3	2023-08-03 10:37:26.841469+00	2023-08-03 10:37:26.841469+00
26	add_work_package_watchers	3	2023-08-03 10:37:26.841694+00	2023-08-03 10:37:26.841694+00
27	delete_work_package_watchers	3	2023-08-03 10:37:26.841933+00	2023-08-03 10:37:26.841933+00
28	assign_versions	3	2023-08-03 10:37:26.84217+00	2023-08-03 10:37:26.84217+00
29	work_package_assigned	3	2023-08-03 10:37:26.842405+00	2023-08-03 10:37:26.842405+00
30	manage_news	3	2023-08-03 10:37:26.842634+00	2023-08-03 10:37:26.842634+00
31	comment_news	3	2023-08-03 10:37:26.842858+00	2023-08-03 10:37:26.842858+00
32	view_wiki_pages	3	2023-08-03 10:37:26.843084+00	2023-08-03 10:37:26.843084+00
33	list_attachments	3	2023-08-03 10:37:26.843312+00	2023-08-03 10:37:26.843312+00
34	manage_wiki	3	2023-08-03 10:37:26.843536+00	2023-08-03 10:37:26.843536+00
35	manage_wiki_menu	3	2023-08-03 10:37:26.843764+00	2023-08-03 10:37:26.843764+00
36	rename_wiki_pages	3	2023-08-03 10:37:26.84399+00	2023-08-03 10:37:26.84399+00
37	change_wiki_parent_page	3	2023-08-03 10:37:26.844214+00	2023-08-03 10:37:26.844214+00
38	delete_wiki_pages	3	2023-08-03 10:37:26.844438+00	2023-08-03 10:37:26.844438+00
39	export_wiki_pages	3	2023-08-03 10:37:26.844943+00	2023-08-03 10:37:26.844943+00
40	view_wiki_edits	3	2023-08-03 10:37:26.845458+00	2023-08-03 10:37:26.845458+00
41	edit_wiki_pages	3	2023-08-03 10:37:26.845922+00	2023-08-03 10:37:26.845922+00
42	delete_wiki_pages_attachments	3	2023-08-03 10:37:26.846314+00	2023-08-03 10:37:26.846314+00
43	protect_wiki_pages	3	2023-08-03 10:37:26.846598+00	2023-08-03 10:37:26.846598+00
44	browse_repository	3	2023-08-03 10:37:26.846857+00	2023-08-03 10:37:26.846857+00
45	commit_access	3	2023-08-03 10:37:26.847115+00	2023-08-03 10:37:26.847115+00
46	manage_repository	3	2023-08-03 10:37:26.847359+00	2023-08-03 10:37:26.847359+00
47	view_changesets	3	2023-08-03 10:37:26.847585+00	2023-08-03 10:37:26.847585+00
48	view_commit_author_statistics	3	2023-08-03 10:37:26.84782+00	2023-08-03 10:37:26.84782+00
49	manage_forums	3	2023-08-03 10:37:26.848042+00	2023-08-03 10:37:26.848042+00
50	add_messages	3	2023-08-03 10:37:26.848262+00	2023-08-03 10:37:26.848262+00
51	edit_messages	3	2023-08-03 10:37:26.848481+00	2023-08-03 10:37:26.848481+00
52	edit_own_messages	3	2023-08-03 10:37:26.84882+00	2023-08-03 10:37:26.84882+00
53	delete_messages	3	2023-08-03 10:37:26.849154+00	2023-08-03 10:37:26.849154+00
54	delete_own_messages	3	2023-08-03 10:37:26.849522+00	2023-08-03 10:37:26.849522+00
55	view_documents	3	2023-08-03 10:37:26.849811+00	2023-08-03 10:37:26.849811+00
56	manage_documents	3	2023-08-03 10:37:26.850065+00	2023-08-03 10:37:26.850065+00
57	view_time_entries	3	2023-08-03 10:37:26.850301+00	2023-08-03 10:37:26.850301+00
58	view_own_time_entries	3	2023-08-03 10:37:26.850529+00	2023-08-03 10:37:26.850529+00
59	log_own_time	3	2023-08-03 10:37:26.850919+00	2023-08-03 10:37:26.850919+00
60	log_time	3	2023-08-03 10:37:26.851194+00	2023-08-03 10:37:26.851194+00
61	edit_own_time_entries	3	2023-08-03 10:37:26.851425+00	2023-08-03 10:37:26.851425+00
62	edit_time_entries	3	2023-08-03 10:37:26.851653+00	2023-08-03 10:37:26.851653+00
63	manage_project_activities	3	2023-08-03 10:37:26.851888+00	2023-08-03 10:37:26.851888+00
64	view_own_hourly_rate	3	2023-08-03 10:37:26.852122+00	2023-08-03 10:37:26.852122+00
65	view_hourly_rates	3	2023-08-03 10:37:26.852522+00	2023-08-03 10:37:26.852522+00
66	edit_own_hourly_rate	3	2023-08-03 10:37:26.852767+00	2023-08-03 10:37:26.852767+00
67	edit_hourly_rates	3	2023-08-03 10:37:26.85301+00	2023-08-03 10:37:26.85301+00
68	view_cost_rates	3	2023-08-03 10:37:26.853254+00	2023-08-03 10:37:26.853254+00
69	log_own_costs	3	2023-08-03 10:37:26.853494+00	2023-08-03 10:37:26.853494+00
70	log_costs	3	2023-08-03 10:37:26.853742+00	2023-08-03 10:37:26.853742+00
71	edit_own_cost_entries	3	2023-08-03 10:37:26.853997+00	2023-08-03 10:37:26.853997+00
72	edit_cost_entries	3	2023-08-03 10:37:26.854252+00	2023-08-03 10:37:26.854252+00
73	view_cost_entries	3	2023-08-03 10:37:26.854505+00	2023-08-03 10:37:26.854505+00
74	view_own_cost_entries	3	2023-08-03 10:37:26.854769+00	2023-08-03 10:37:26.854769+00
77	view_meetings	3	2023-08-03 10:37:26.855586+00	2023-08-03 10:37:26.855586+00
78	create_meetings	3	2023-08-03 10:37:26.855862+00	2023-08-03 10:37:26.855862+00
79	edit_meetings	3	2023-08-03 10:37:26.856296+00	2023-08-03 10:37:26.856296+00
80	delete_meetings	3	2023-08-03 10:37:26.856836+00	2023-08-03 10:37:26.856836+00
81	meetings_send_invite	3	2023-08-03 10:37:26.857227+00	2023-08-03 10:37:26.857227+00
82	create_meeting_agendas	3	2023-08-03 10:37:26.857519+00	2023-08-03 10:37:26.857519+00
83	close_meeting_agendas	3	2023-08-03 10:37:26.857806+00	2023-08-03 10:37:26.857806+00
84	send_meeting_agendas_notification	3	2023-08-03 10:37:26.858087+00	2023-08-03 10:37:26.858087+00
85	send_meeting_agendas_icalendar	3	2023-08-03 10:37:26.85836+00	2023-08-03 10:37:26.85836+00
86	create_meeting_minutes	3	2023-08-03 10:37:26.85864+00	2023-08-03 10:37:26.85864+00
87	send_meeting_minutes_notification	3	2023-08-03 10:37:26.85892+00	2023-08-03 10:37:26.85892+00
88	view_master_backlog	3	2023-08-03 10:37:26.859205+00	2023-08-03 10:37:26.859205+00
89	view_taskboards	3	2023-08-03 10:37:26.859547+00	2023-08-03 10:37:26.859547+00
90	select_done_statuses	3	2023-08-03 10:37:26.859848+00	2023-08-03 10:37:26.859848+00
91	update_sprints	3	2023-08-03 10:37:26.860151+00	2023-08-03 10:37:26.860151+00
92	show_github_content	3	2023-08-03 10:37:26.860544+00	2023-08-03 10:37:26.860544+00
93	show_board_views	3	2023-08-03 10:37:26.86093+00	2023-08-03 10:37:26.86093+00
94	manage_board_views	3	2023-08-03 10:37:26.861276+00	2023-08-03 10:37:26.861276+00
95	manage_overview	3	2023-08-03 10:37:26.861645+00	2023-08-03 10:37:26.861645+00
96	view_budgets	3	2023-08-03 10:37:26.862019+00	2023-08-03 10:37:26.862019+00
97	edit_budgets	3	2023-08-03 10:37:26.862505+00	2023-08-03 10:37:26.862505+00
98	view_team_planner	3	2023-08-03 10:37:26.863038+00	2023-08-03 10:37:26.863038+00
99	manage_team_planner	3	2023-08-03 10:37:26.863442+00	2023-08-03 10:37:26.863442+00
100	view_calendar	3	2023-08-03 10:37:26.863814+00	2023-08-03 10:37:26.863814+00
101	manage_calendars	3	2023-08-03 10:37:26.864226+00	2023-08-03 10:37:26.864226+00
102	view_file_links	3	2023-08-03 10:37:26.864598+00	2023-08-03 10:37:26.864598+00
103	manage_file_links	3	2023-08-03 10:37:26.864949+00	2023-08-03 10:37:26.864949+00
104	manage_storages_in_project	3	2023-08-03 10:37:26.865481+00	2023-08-03 10:37:26.865481+00
105	view_ifc_models	3	2023-08-03 10:37:26.865946+00	2023-08-03 10:37:26.865946+00
106	manage_ifc_models	3	2023-08-03 10:37:26.866371+00	2023-08-03 10:37:26.866371+00
107	view_linked_issues	3	2023-08-03 10:37:26.866728+00	2023-08-03 10:37:26.866728+00
108	manage_bcf	3	2023-08-03 10:37:26.867102+00	2023-08-03 10:37:26.867102+00
109	delete_bcf	3	2023-08-03 10:37:26.867448+00	2023-08-03 10:37:26.867448+00
110	save_bcf_queries	3	2023-08-03 10:37:26.867856+00	2023-08-03 10:37:26.867856+00
111	manage_public_bcf_queries	3	2023-08-03 10:37:26.86815+00	2023-08-03 10:37:26.86815+00
112	view_work_packages	4	2023-08-03 10:37:26.874549+00	2023-08-03 10:37:26.874549+00
113	export_work_packages	4	2023-08-03 10:37:26.874866+00	2023-08-03 10:37:26.874866+00
114	add_work_packages	4	2023-08-03 10:37:26.875221+00	2023-08-03 10:37:26.875221+00
115	move_work_packages	4	2023-08-03 10:37:26.875519+00	2023-08-03 10:37:26.875519+00
116	edit_work_packages	4	2023-08-03 10:37:26.875775+00	2023-08-03 10:37:26.875775+00
117	assign_versions	4	2023-08-03 10:37:26.876074+00	2023-08-03 10:37:26.876074+00
118	work_package_assigned	4	2023-08-03 10:37:26.876343+00	2023-08-03 10:37:26.876343+00
119	add_work_package_notes	4	2023-08-03 10:37:26.876616+00	2023-08-03 10:37:26.876616+00
120	edit_own_work_package_notes	4	2023-08-03 10:37:26.876861+00	2023-08-03 10:37:26.876861+00
121	manage_work_package_relations	4	2023-08-03 10:37:26.877162+00	2023-08-03 10:37:26.877162+00
122	manage_subtasks	4	2023-08-03 10:37:26.877507+00	2023-08-03 10:37:26.877507+00
123	manage_public_queries	4	2023-08-03 10:37:26.877882+00	2023-08-03 10:37:26.877882+00
124	save_queries	4	2023-08-03 10:37:26.878254+00	2023-08-03 10:37:26.878254+00
125	view_work_package_watchers	4	2023-08-03 10:37:26.878727+00	2023-08-03 10:37:26.878727+00
126	add_work_package_watchers	4	2023-08-03 10:37:26.879091+00	2023-08-03 10:37:26.879091+00
127	delete_work_package_watchers	4	2023-08-03 10:37:26.879385+00	2023-08-03 10:37:26.879385+00
128	view_calendar	4	2023-08-03 10:37:26.879687+00	2023-08-03 10:37:26.879687+00
129	comment_news	4	2023-08-03 10:37:26.880357+00	2023-08-03 10:37:26.880357+00
130	manage_news	4	2023-08-03 10:37:26.880756+00	2023-08-03 10:37:26.880756+00
131	log_time	4	2023-08-03 10:37:26.881032+00	2023-08-03 10:37:26.881032+00
132	view_time_entries	4	2023-08-03 10:37:26.881282+00	2023-08-03 10:37:26.881282+00
133	view_own_time_entries	4	2023-08-03 10:37:26.881519+00	2023-08-03 10:37:26.881519+00
134	edit_own_time_entries	4	2023-08-03 10:37:26.881753+00	2023-08-03 10:37:26.881753+00
135	view_timelines	4	2023-08-03 10:37:26.881986+00	2023-08-03 10:37:26.881986+00
136	edit_timelines	4	2023-08-03 10:37:26.882214+00	2023-08-03 10:37:26.882214+00
137	delete_timelines	4	2023-08-03 10:37:26.882441+00	2023-08-03 10:37:26.882441+00
138	view_reportings	4	2023-08-03 10:37:26.882672+00	2023-08-03 10:37:26.882672+00
139	edit_reportings	4	2023-08-03 10:37:26.8829+00	2023-08-03 10:37:26.8829+00
140	delete_reportings	4	2023-08-03 10:37:26.883212+00	2023-08-03 10:37:26.883212+00
141	manage_wiki	4	2023-08-03 10:37:26.883532+00	2023-08-03 10:37:26.883532+00
142	manage_wiki_menu	4	2023-08-03 10:37:26.883791+00	2023-08-03 10:37:26.883791+00
143	rename_wiki_pages	4	2023-08-03 10:37:26.884035+00	2023-08-03 10:37:26.884035+00
144	change_wiki_parent_page	4	2023-08-03 10:37:26.884273+00	2023-08-03 10:37:26.884273+00
145	delete_wiki_pages	4	2023-08-03 10:37:26.884509+00	2023-08-03 10:37:26.884509+00
146	view_wiki_pages	4	2023-08-03 10:37:26.88474+00	2023-08-03 10:37:26.88474+00
147	export_wiki_pages	4	2023-08-03 10:37:26.885033+00	2023-08-03 10:37:26.885033+00
148	view_wiki_edits	4	2023-08-03 10:37:26.885307+00	2023-08-03 10:37:26.885307+00
149	edit_wiki_pages	4	2023-08-03 10:37:26.885564+00	2023-08-03 10:37:26.885564+00
150	delete_wiki_pages_attachments	4	2023-08-03 10:37:26.885905+00	2023-08-03 10:37:26.885905+00
151	protect_wiki_pages	4	2023-08-03 10:37:26.886275+00	2023-08-03 10:37:26.886275+00
152	list_attachments	4	2023-08-03 10:37:26.886682+00	2023-08-03 10:37:26.886682+00
153	add_messages	4	2023-08-03 10:37:26.887032+00	2023-08-03 10:37:26.887032+00
154	edit_own_messages	4	2023-08-03 10:37:26.887323+00	2023-08-03 10:37:26.887323+00
155	delete_own_messages	4	2023-08-03 10:37:26.887576+00	2023-08-03 10:37:26.887576+00
156	browse_repository	4	2023-08-03 10:37:26.887821+00	2023-08-03 10:37:26.887821+00
157	view_changesets	4	2023-08-03 10:37:26.888055+00	2023-08-03 10:37:26.888055+00
158	commit_access	4	2023-08-03 10:37:26.888283+00	2023-08-03 10:37:26.888283+00
159	view_commit_author_statistics	4	2023-08-03 10:37:26.888508+00	2023-08-03 10:37:26.888508+00
160	view_members	4	2023-08-03 10:37:26.888844+00	2023-08-03 10:37:26.888844+00
161	manage_board_views	4	2023-08-03 10:37:26.88921+00	2023-08-03 10:37:26.88921+00
162	show_board_views	4	2023-08-03 10:37:26.889532+00	2023-08-03 10:37:26.889532+00
163	view_team_planner	4	2023-08-03 10:37:26.889796+00	2023-08-03 10:37:26.889796+00
164	view_file_links	4	2023-08-03 10:37:26.890047+00	2023-08-03 10:37:26.890047+00
165	manage_file_links	4	2023-08-03 10:37:26.89029+00	2023-08-03 10:37:26.89029+00
166	view_documents	4	2023-08-03 10:37:26.890531+00	2023-08-03 10:37:26.890531+00
167	manage_documents	4	2023-08-03 10:37:26.890776+00	2023-08-03 10:37:26.890776+00
168	view_master_backlog	4	2023-08-03 10:37:26.891017+00	2023-08-03 10:37:26.891017+00
169	view_taskboards	4	2023-08-03 10:37:26.891251+00	2023-08-03 10:37:26.891251+00
170	show_board_views	4	2023-08-03 10:37:26.891504+00	2023-08-03 10:37:26.891504+00
171	manage_board_views	4	2023-08-03 10:37:26.891749+00	2023-08-03 10:37:26.891749+00
172	view_work_packages	5	2023-08-03 10:37:26.895352+00	2023-08-03 10:37:26.895352+00
173	add_work_package_notes	5	2023-08-03 10:37:26.895943+00	2023-08-03 10:37:26.895943+00
174	edit_own_work_package_notes	5	2023-08-03 10:37:26.896416+00	2023-08-03 10:37:26.896416+00
175	save_queries	5	2023-08-03 10:37:26.896687+00	2023-08-03 10:37:26.896687+00
176	view_calendar	5	2023-08-03 10:37:26.896992+00	2023-08-03 10:37:26.896992+00
177	comment_news	5	2023-08-03 10:37:26.897343+00	2023-08-03 10:37:26.897343+00
178	view_timelines	5	2023-08-03 10:37:26.897691+00	2023-08-03 10:37:26.897691+00
179	view_reportings	5	2023-08-03 10:37:26.898148+00	2023-08-03 10:37:26.898148+00
180	view_wiki_pages	5	2023-08-03 10:37:26.898431+00	2023-08-03 10:37:26.898431+00
181	export_wiki_pages	5	2023-08-03 10:37:26.898774+00	2023-08-03 10:37:26.898774+00
182	list_attachments	5	2023-08-03 10:37:26.899142+00	2023-08-03 10:37:26.899142+00
183	add_messages	5	2023-08-03 10:37:26.899502+00	2023-08-03 10:37:26.899502+00
184	edit_own_messages	5	2023-08-03 10:37:26.900357+00	2023-08-03 10:37:26.900357+00
185	delete_own_messages	5	2023-08-03 10:37:26.900659+00	2023-08-03 10:37:26.900659+00
186	browse_repository	5	2023-08-03 10:37:26.90092+00	2023-08-03 10:37:26.90092+00
187	view_changesets	5	2023-08-03 10:37:26.901177+00	2023-08-03 10:37:26.901177+00
188	show_board_views	5	2023-08-03 10:37:26.90142+00	2023-08-03 10:37:26.90142+00
189	view_team_planner	5	2023-08-03 10:37:26.901759+00	2023-08-03 10:37:26.901759+00
190	view_file_links	5	2023-08-03 10:37:26.902038+00	2023-08-03 10:37:26.902038+00
191	view_documents	5	2023-08-03 10:37:26.902294+00	2023-08-03 10:37:26.902294+00
192	view_master_backlog	5	2023-08-03 10:37:26.90254+00	2023-08-03 10:37:26.90254+00
193	view_taskboards	5	2023-08-03 10:37:26.902797+00	2023-08-03 10:37:26.902797+00
194	show_board_views	5	2023-08-03 10:37:26.90303+00	2023-08-03 10:37:26.90303+00
195	add_project	6	2023-08-03 10:37:26.906271+00	2023-08-03 10:37:26.906271+00
196	manage_user	6	2023-08-03 10:37:26.906545+00	2023-08-03 10:37:26.906545+00
197	manage_placeholder_user	6	2023-08-03 10:37:26.906794+00	2023-08-03 10:37:26.906794+00
198	view_work_packages	1	2023-08-03 10:37:26.908023+00	2023-08-03 10:37:26.908023+00
199	view_calendar	1	2023-08-03 10:37:26.908418+00	2023-08-03 10:37:26.908418+00
200	comment_news	1	2023-08-03 10:37:26.908803+00	2023-08-03 10:37:26.908803+00
201	browse_repository	1	2023-08-03 10:37:26.909193+00	2023-08-03 10:37:26.909193+00
202	view_changesets	1	2023-08-03 10:37:26.909633+00	2023-08-03 10:37:26.909633+00
203	view_wiki_pages	1	2023-08-03 10:37:26.910131+00	2023-08-03 10:37:26.910131+00
204	show_board_views	1	2023-08-03 10:37:26.910529+00	2023-08-03 10:37:26.910529+00
205	view_file_links	1	2023-08-03 10:37:26.911286+00	2023-08-03 10:37:26.911286+00
206	view_work_packages	2	2023-08-03 10:37:26.913166+00	2023-08-03 10:37:26.913166+00
207	browse_repository	2	2023-08-03 10:37:26.913685+00	2023-08-03 10:37:26.913685+00
208	view_changesets	2	2023-08-03 10:37:26.914097+00	2023-08-03 10:37:26.914097+00
209	view_wiki_pages	2	2023-08-03 10:37:26.914573+00	2023-08-03 10:37:26.914573+00
210	view_file_links	2	2023-08-03 10:37:26.915021+00	2023-08-03 10:37:26.915021+00
211	view_own_hourly_rate	4	2023-08-03 10:37:26.917359+00	2023-08-03 10:37:26.917359+00
212	view_cost_rates	4	2023-08-03 10:37:26.91779+00	2023-08-03 10:37:26.91779+00
213	log_own_costs	4	2023-08-03 10:37:26.918175+00	2023-08-03 10:37:26.918175+00
214	edit_own_cost_entries	4	2023-08-03 10:37:26.918506+00	2023-08-03 10:37:26.918506+00
215	view_budgets	4	2023-08-03 10:37:26.919029+00	2023-08-03 10:37:26.919029+00
216	view_own_cost_entries	4	2023-08-03 10:37:26.919495+00	2023-08-03 10:37:26.919495+00
217	create_meetings	4	2023-08-03 10:37:26.926207+00	2023-08-03 10:37:26.926207+00
218	edit_meetings	4	2023-08-03 10:37:26.926612+00	2023-08-03 10:37:26.926612+00
219	delete_meetings	4	2023-08-03 10:37:26.927352+00	2023-08-03 10:37:26.927352+00
220	view_meetings	4	2023-08-03 10:37:26.92802+00	2023-08-03 10:37:26.92802+00
221	create_meeting_agendas	4	2023-08-03 10:37:26.92839+00	2023-08-03 10:37:26.92839+00
222	close_meeting_agendas	4	2023-08-03 10:37:26.928758+00	2023-08-03 10:37:26.928758+00
223	send_meeting_agendas_notification	4	2023-08-03 10:37:26.929165+00	2023-08-03 10:37:26.929165+00
224	send_meeting_agendas_icalendar	4	2023-08-03 10:37:26.929594+00	2023-08-03 10:37:26.929594+00
225	create_meeting_minutes	4	2023-08-03 10:37:26.929951+00	2023-08-03 10:37:26.929951+00
226	send_meeting_minutes_notification	4	2023-08-03 10:37:26.930318+00	2023-08-03 10:37:26.930318+00
227	view_meetings	5	2023-08-03 10:37:26.931661+00	2023-08-03 10:37:26.931661+00
228	manage_overview	3	2023-08-03 10:37:31.645508+00	2023-08-03 10:37:31.645508+00
\.


--
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.roles (id, name, "position", builtin, type, created_at, updated_at) FROM stdin;
1	Non member	1	1	Role	2023-08-03 10:37:26.803602+00	2023-08-03 10:37:26.803602+00
2	Anonymous	2	2	Role	2023-08-03 10:37:26.806575+00	2023-08-03 10:37:26.806575+00
4	Member	3	0	Role	2023-08-03 10:37:26.872903+00	2023-08-03 10:37:26.872903+00
5	Reader	4	0	Role	2023-08-03 10:37:26.893934+00	2023-08-03 10:37:26.893934+00
3	Project admin	8	0	Role	2023-08-03 10:37:26.831469+00	2023-08-03 10:37:26.905728+00
6	Staff and projects manager	6	0	GlobalRole	2023-08-03 10:37:26.905057+00	2023-08-03 10:37:26.905057+00
\.


--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.schema_migrations (version) FROM stdin;
10000000000000
20100528100562
20120214103300
20130214130336
20140113132617
20140129103924
20140207134248
20160331190036
20170703075208
20170705134348
20170818063404
20170829095701
20171023190036
20171106074835
20171129145631
20171218205557
20171219145752
20180105130053
20180108132929
20180116065518
20180117065255
20180122135443
20180123092002
20180125082205
20180213155320
20180221151038
20180305130811
20180323130704
20180323133404
20180323135408
20180323140208
20180323151208
20180419061910
20180504144320
20180510184732
20180518130559
20180524084654
20180524113516
20180706150714
20180717102331
20180801072018
20180830120550
20180903110212
20180924141838
20181101132712
20181112125034
20181118193730
20181121174153
20181214103300
20190124081710
20190129083842
20190205090102
20190207155607
20190220080647
20190227163226
20190301122554
20190312083304
20190411122815
20190502102512
20190507132517
20190509071101
20190527095959
20190603060951
20190618115620
20190619143049
20190710132957
20190716071941
20190719123448
20190722082648
20190724093332
20190823090211
20190826083604
20190905130336
20190920102446
20190923111902
20190923123858
20191029155327
20191106132533
20191112111040
20191114090353
20191115141154
20191119144123
20191121140202
20191216135213
20200114091135
20200115090742
20200123163818
20200206101135
20200217061622
20200217090016
20200217155632
20200220171133
20200302100431
20200310092237
20200325101528
20200326102408
20200327074416
20200403105252
20200415131633
20200420122713
20200420133116
20200422105623
20200427082928
20200427121606
20200428105404
20200504085933
20200522131255
20200522140244
20200527130633
20200610083854
20200610124259
20200625133727
20200708065116
20200803081038
20200807083950
20200807083952
20200810152654
20200820140526
20200903064009
20200907090753
20200914092212
20200924085508
20200925084550
20201001184404
20201005120137
20201005184411
20201105154216
20201125121949
20210126112238
20210127134438
20210214205545
20210219092709
20210221230446
20210310101840
20210331085058
20210407110000
20210427065703
20210510193438
20210512121322
20210519141244
20210521080035
20210615150558
20210616145324
20210616191052
20210618125430
20210618132206
20210628185054
20210701073944
20210701082511
20210713081724
20210726065912
20210726070813
20210802114054
20210825183540
20210902201126
20210910092414
20210914065555
20210915154656
20210917190141
20210922123908
20210928133538
20211005080304
20211005135637
20211011204301
20211022143726
20211026061420
20211101152840
20211102161932
20211103120946
20211104151329
20211105142202
20211117195121
20211118203332
20211130161501
20211209092519
20220106145037
20220113144323
20220113144759
20220121090847
20220202140507
20220223095355
20220302123642
20220319211253
20220323083000
20220408080838
20220414085531
20220426132637
20220428071221
20220503093844
20220511124930
20220517113828
20220518154147
20220525154549
20220608213712
20220614132200
20220615213015
20220620132922
20220622151721
20220629061540
20220629073727
20220707192304
20220712132505
20220712165928
20220714145356
20220804112533
20220811061024
20220815072420
20220817154403
20220818074150
20220818074159
20220830074821
20220830092057
20220831073113
20220831081937
20220909153412
20220911182835
20220918165443
20220922200908
20220926124435
20220929114423
20220930133418
20221017073431
20221017184204
20221018160449
20221026132134
20221027151959
20221028070534
20221029194419
20221115082403
20221122072857
20221129074635
20221130150352
20221201140825
20221202130039
20221213092910
20230105073117
20230105134940
20230123092649
20230130134630
20230306083203
20230309104056
20230314093106
\.


--
-- Data for Name: sessions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sessions (id, session_id, data, updated_at, user_id) FROM stdin;
2	2::8c3d9a62a6397413b6842b83dd0f0e64db3e5a5b98c41a99a3dafb57bc414d39	BAh7CEkiDHVzZXJfaWQGOgZFRmkISSIPdXBkYXRlZF9hdAY7AEZJdToJVGlt\nZQ1q3B6AW2I2qQo6DW5hbm9fbnVtaQKXAToNbmFub19kZW5pBjoNc3VibWlj\ncm8iB0BwOgtvZmZzZXRpADoJem9uZUkiCFVUQwY7AEZJIhBfY3NyZl90b2tl\nbgY7AEZJIjFqeFpkcUhxcjZvMXNOeEZDWDM3aVVCOWd6eWcwT01qK0NBWTB2\nRktmTk5RPQY7AEY=\n	2023-08-03 10:42:26.15037+00	3
\.


--
-- Data for Name: settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.settings (id, name, value, updated_at) FROM stdin;
1	working_days	---\n- 1\n- 2\n- 3\n- 4\n- 5\n	2023-08-03 10:37:13.850206+00
2	fog	{}	2023-08-03 10:37:29.789097+00
3	plugin_openproject_auth_saml	---\nproviders: \n	2023-08-03 10:37:29.790928+00
4	plugin_costs	---\ncosts_currency: EUR\ncosts_currency_format: "%n %u"\n	2023-08-03 10:37:29.792452+00
5	cost_reporting_cache_filter_classes	true	2023-08-03 10:37:29.793906+00
7	plugin_openproject_avatars	---\nenable_gravatars: true\nenable_local_avatars: true\n	2023-08-03 10:37:29.79743+00
8	plugin_openproject_two_factor_authentication	---\nactive_strategies:\n- :totp\nenforced: false\nallow_remember_for_days: 0\n	2023-08-03 10:37:29.799105+00
9	plugin_openproject_ldap_groups	{}	2023-08-03 10:37:29.800798+00
10	plugin_openproject_recaptcha	---\nrecaptcha_type: disabled\n	2023-08-03 10:37:29.802051+00
11	recaptcha_via_hcaptcha	f	2023-08-03 10:37:29.803469+00
12	feature_storage_file_picking_select_all_active	f	2023-08-03 10:37:29.804628+00
13	feature_legacy_upload_preparation_active	f	2023-08-03 10:37:29.805777+00
14	plugin_openproject_bim	{}	2023-08-03 10:37:29.807328+00
15	available_languages	---\n- en\n- de\n- fr\n- es\n- pt\n- pt-BR\n- it\n- zh-CN\n- ko\n- ru\n	2023-08-03 10:37:29.808612+00
16	activity_days_default	30	2023-08-03 10:37:29.809906+00
17	apiv3_cors_enabled	f	2023-08-03 10:37:29.811097+00
18	apiv3_cors_origins	[]	2023-08-03 10:37:29.812455+00
19	apiv3_docs_enabled	true	2023-08-03 10:37:29.813869+00
20	apiv3_max_page_size	1000	2023-08-03 10:37:29.815102+00
21	app_title	OpenProject	2023-08-03 10:37:29.816503+00
22	attachment_max_size	5120	2023-08-03 10:37:29.817791+00
23	attachment_whitelist	[]	2023-08-03 10:37:29.82071+00
24	autofetch_changesets	true	2023-08-03 10:37:29.821973+00
25	autologin	0	2023-08-03 10:37:29.823199+00
26	bcc_recipients	true	2023-08-03 10:37:29.824423+00
28	brute_force_block_minutes	30	2023-08-03 10:37:29.826898+00
29	brute_force_block_after_failed_logins	20	2023-08-03 10:37:29.828146+00
31	commit_fix_done_ratio	100	2023-08-03 10:37:29.830945+00
32	commit_fix_keywords	fixes,closes	2023-08-03 10:37:29.832165+00
33	commit_logs_encoding	UTF-8	2023-08-03 10:37:29.83341+00
34	commit_logtime_enabled	f	2023-08-03 10:37:29.834639+00
35	commit_ref_keywords	refs,references,IssueID	2023-08-03 10:37:29.835909+00
36	consent_info	---\nen: |-\n  ## Consent\n\n  You need to agree to the [privacy and security policy](https://www.openproject.org/data-privacy-and-security/) of this OpenProject instance.\n	2023-08-03 10:37:29.837203+00
37	consent_required	f	2023-08-03 10:37:29.838591+00
38	cross_project_work_package_relations	true	2023-08-03 10:37:29.839848+00
39	default_auto_hide_popups	true	2023-08-03 10:37:29.841118+00
40	default_language	en	2023-08-03 10:37:29.842374+00
41	default_projects_modules	---\n- calendar\n- board_view\n- work_package_tracking\n- news\n- costs\n- wiki\n- reporting_module\n- meetings\n- backlogs\n	2023-08-03 10:37:29.843693+00
42	default_projects_public	f	2023-08-03 10:37:29.845588+00
46	diff_max_lines_displayed	1500	2023-08-03 10:37:29.85334+00
47	display_subprojects_work_packages	true	2023-08-03 10:37:29.855143+00
48	emails_footer	---\nen: ''\n	2023-08-03 10:37:29.856953+00
49	emails_header	---\nen: ''\n	2023-08-03 10:37:29.858705+00
50	email_login	f	2023-08-03 10:37:29.861014+00
51	enabled_projects_columns	---\n- project_status\n- public\n- created_at\n- latest_activity_at\n- required_disk_space\n	2023-08-03 10:37:29.862943+00
52	enabled_scm	---\n- subversion\n- git\n	2023-08-03 10:37:29.864885+00
54	feeds_limit	15	2023-08-03 10:37:29.868778+00
55	file_max_size_displayed	512	2023-08-03 10:37:29.870803+00
56	forced_single_page_size	250	2023-08-03 10:37:29.872233+00
57	host_name	localhost:3000	2023-08-03 10:37:29.87368+00
58	invitation_expiration_days	7	2023-08-03 10:37:29.875297+00
59	journal_aggregation_time_minutes	5	2023-08-03 10:37:29.876908+00
60	ldap_tls_options	{}	2023-08-03 10:37:29.878295+00
61	log_requesting_user	f	2023-08-03 10:37:29.879744+00
62	login_required	f	2023-08-03 10:37:29.881115+00
63	lost_password	true	2023-08-03 10:37:29.882478+00
64	mail_from	openproject@example.net	2023-08-03 10:37:29.884436+00
65	mail_handler_body_delimiters		2023-08-03 10:37:29.886036+00
66	mail_handler_body_delimiter_regex		2023-08-03 10:37:29.887408+00
67	mail_handler_ignore_filenames	signature.asc	2023-08-03 10:37:29.888806+00
68	mail_suffix_separators	+	2023-08-03 10:37:29.890364+00
69	oauth_allow_remapping_of_existing_users	true	2023-08-03 10:37:29.892335+00
70	password_active_rules	---\n- lowercase\n- uppercase\n- numeric\n- special\n	2023-08-03 10:37:29.893837+00
71	password_count_former_banned	0	2023-08-03 10:37:29.895435+00
72	password_days_valid	0	2023-08-03 10:37:29.896908+00
73	password_min_length	10	2023-08-03 10:37:29.8983+00
74	password_min_adhered_rules	0	2023-08-03 10:37:29.89982+00
75	per_page_options	20, 100	2023-08-03 10:37:29.90125+00
76	plain_text_mail	f	2023-08-03 10:37:29.902639+00
77	report_incoming_email_errors	true	2023-08-03 10:37:29.904066+00
78	repository_authentication_caching_enabled	true	2023-08-03 10:37:29.905537+00
79	repository_checkout_data	---\ngit:\n  enabled: 0\nsubversion:\n  enabled: 0\n	2023-08-03 10:37:29.907167+00
80	repository_log_display_limit	100	2023-08-03 10:37:29.908937+00
81	repository_storage_cache_minutes	720	2023-08-03 10:37:29.91042+00
82	repository_truncate_at	500	2023-08-03 10:37:29.912072+00
83	rest_api_enabled	true	2023-08-03 10:37:29.913754+00
85	self_registration	2	2023-08-03 10:37:29.916693+00
86	sendmail_location	/usr/sbin/sendmail	2023-08-03 10:37:29.918145+00
87	session_ttl_enabled	f	2023-08-03 10:37:29.91989+00
88	session_ttl	120	2023-08-03 10:37:29.921381+00
89	smtp_authentication	plain	2023-08-03 10:37:29.922949+00
90	smtp_enable_starttls_auto	f	2023-08-03 10:37:29.924387+00
91	smtp_ssl	f	2023-08-03 10:37:29.925827+00
92	smtp_address		2023-08-03 10:37:29.927466+00
93	smtp_domain	your.domain.com	2023-08-03 10:37:29.929151+00
94	smtp_user_name		2023-08-03 10:37:29.930769+00
95	smtp_port	587	2023-08-03 10:37:29.932547+00
96	smtp_password		2023-08-03 10:37:29.934119+00
97	software_name	OpenProject	2023-08-03 10:37:29.935921+00
27	boards_demo_data_available	true	2023-08-03 10:37:30.766091+00
30	cache_formatted_text	1	2023-08-03 10:42:12.467972+00
53	feeds_enabled	1	2023-08-03 10:42:12.48302+00
84	security_badge_displayed	1	2023-08-03 10:42:12.510347+00
98	software_url	https://www.openproject.org/	2023-08-03 10:37:29.937533+00
99	sys_api_enabled	f	2023-08-03 10:37:29.939401+00
100	users_deletable_by_admins	f	2023-08-03 10:37:29.941003+00
101	users_deletable_by_self	f	2023-08-03 10:37:29.942454+00
102	user_format	firstname_lastname	2023-08-03 10:37:29.943977+00
104	work_package_done_ratio	field	2023-08-03 10:37:29.94712+00
105	work_packages_projects_export_limit	500	2023-08-03 10:37:29.948693+00
106	work_packages_bulk_request_limit	10	2023-08-03 10:37:29.950204+00
107	work_package_list_default_highlighted_attributes	[]	2023-08-03 10:37:29.951805+00
108	work_package_list_default_columns	---\n- id\n- subject\n- type\n- status\n- assigned_to\n- priority\n	2023-08-03 10:37:29.953672+00
109	work_package_startdate_is_adddate	f	2023-08-03 10:37:29.956299+00
110	new_project_user_role_id	3	2023-08-03 10:37:29.958128+00
111	commit_fix_status_id	12	2023-08-03 10:37:29.960271+00
6	plugin_openproject_backlogs	---\nstory_types:\n- 4\n- 5\n- 6\n- 7\ntask_type: 1\npoints_burn_direction: up\nwiki_template: ''\n	2023-08-03 10:37:29.963295+00
112	welcome_title	Welcome to OpenProject!	2023-08-03 10:37:30.150272+00
103	welcome_on_homescreen	1	2023-08-03 10:37:30.154207+00
44	demo_view_of_type_work_packages_table_seeded	true	2023-08-03 10:37:30.32349+00
45	demo_view_of_type_team_planner_seeded	true	2023-08-03 10:37:30.344066+00
43	demo_projects_available	true	2023-08-03 10:37:30.799863+00
114	installation_uuid	9bb40a1f-e957-4404-bdf1-55e26ac5e8ea	2023-08-03 10:39:35.633213+00
113	welcome_text	**Backup token:** `ba02a6780c21867884e08fd9b7f2575bc0818667b13a8a984b85baa3d48a15da`	2023-08-03 10:42:12.516998+00
\.


--
-- Data for Name: statuses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.statuses (id, name, is_closed, is_default, "position", default_done_ratio, created_at, updated_at, color_id, is_readonly) FROM stdin;
1	New	f	t	1	\N	2023-08-03 10:37:27.047173+00	2023-08-03 10:37:27.047173+00	92	f
2	In specification	f	f	2	\N	2023-08-03 10:37:27.04887+00	2023-08-03 10:37:27.04887+00	77	f
3	Specified	f	f	3	\N	2023-08-03 10:37:27.050972+00	2023-08-03 10:37:27.050972+00	77	f
4	Confirmed	f	f	4	\N	2023-08-03 10:37:27.053071+00	2023-08-03 10:37:27.053071+00	57	f
5	To be scheduled	f	f	5	\N	2023-08-03 10:37:27.05502+00	2023-08-03 10:37:27.05502+00	127	f
6	Scheduled	f	f	6	\N	2023-08-03 10:37:27.0569+00	2023-08-03 10:37:27.0569+00	117	f
7	In progress	f	f	7	\N	2023-08-03 10:37:27.058891+00	2023-08-03 10:37:27.058891+00	50	f
8	Developed	f	f	9	\N	2023-08-03 10:37:27.0608+00	2023-08-03 10:37:27.0608+00	108	f
9	In testing	f	f	10	\N	2023-08-03 10:37:27.062698+00	2023-08-03 10:37:27.062698+00	90	f
10	Tested	f	f	11	\N	2023-08-03 10:37:27.064861+00	2023-08-03 10:37:27.064861+00	101	f
11	Test failed	f	f	12	\N	2023-08-03 10:37:27.066895+00	2023-08-03 10:37:27.066895+00	30	f
12	Closed	t	f	13	\N	2023-08-03 10:37:27.069255+00	2023-08-03 10:37:27.069255+00	18	f
13	On hold	f	f	14	\N	2023-08-03 10:37:27.071335+00	2023-08-03 10:37:27.071335+00	138	f
14	Rejected	t	f	15	\N	2023-08-03 10:37:27.073376+00	2023-08-03 10:37:27.073376+00	28	f
\.


--
-- Data for Name: storages; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.storages (id, provider_type, name, host, creator_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: time_entries; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.time_entries (id, project_id, user_id, work_package_id, hours, comments, activity_id, spent_on, tyear, tmonth, tweek, created_at, updated_at, overridden_costs, costs, rate_id, logged_by_id) FROM stdin;
\.


--
-- Data for Name: time_entry_activities_projects; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.time_entry_activities_projects (id, activity_id, project_id, active) FROM stdin;
\.


--
-- Data for Name: time_entry_journals; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.time_entry_journals (id, project_id, user_id, work_package_id, hours, comments, activity_id, spent_on, tyear, tmonth, tweek, overridden_costs, costs, rate_id, logged_by_id) FROM stdin;
\.


--
-- Data for Name: tokens; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tokens (id, user_id, type, value, created_at, expires_on) FROM stdin;
2	3	Token::RSS	e4100d767b499eb79279b64fb5e08c048e16ec6262ba905091afaa5f27e0e7ef	2023-08-03 10:40:19.002133+00	\N
3	3	Token::Backup	636379d7954db01edff6039fe20e93ce6f5d3c7a7dd92d8fa4cfc17568e5060c	1787-01-12 10:41:48.856288+00	\N
\.


--
-- Data for Name: two_factor_authentication_devices; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.two_factor_authentication_devices (id, type, "default", active, channel, phone_number, identifier, created_at, updated_at, last_used_at, otp_secret, user_id) FROM stdin;
\.


--
-- Data for Name: types; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.types (id, name, "position", is_in_roadmap, is_milestone, is_default, color_id, created_at, updated_at, is_standard, attribute_groups, description) FROM stdin;
1	Task	1	t	f	t	2	2023-08-03 10:37:27.029543+00	2023-08-03 10:37:27.029543+00	f	\N	
2	Milestone	2	f	t	t	4	2023-08-03 10:37:27.031139+00	2023-08-03 10:37:27.031139+00	f	\N	
3	Phase	3	f	f	t	140	2023-08-03 10:37:27.033034+00	2023-08-03 10:37:27.033034+00	f	\N	
4	Feature	4	t	f	f	70	2023-08-03 10:37:27.034888+00	2023-08-03 10:37:27.034888+00	f	\N	
5	Epic	5	t	f	f	60	2023-08-03 10:37:27.036511+00	2023-08-03 10:37:27.036511+00	f	\N	
6	User story	6	t	f	f	3	2023-08-03 10:37:27.03832+00	2023-08-03 10:37:27.03832+00	f	\N	
7	Bug	7	t	f	f	32	2023-08-03 10:37:27.04003+00	2023-08-03 10:37:27.04003+00	f	\N	
\.


--
-- Data for Name: user_passwords; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_passwords (id, user_id, hashed_password, salt, created_at, updated_at, type) FROM stdin;
2	3	$2a$12$uN3gWdyjltmQmsvCqqB.OeaNd2fttYaO.8gPaZT.VVz04FakzTxCy	\N	2023-08-03 10:39:35.045955+00	2023-08-03 10:39:35.045955+00	UserPassword::Bcrypt
\.


--
-- Data for Name: user_preferences; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_preferences (id, user_id, settings) FROM stdin;
1	3	\N
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, login, firstname, lastname, mail, admin, status, last_login_on, language, auth_source_id, created_at, updated_at, type, identity_url, first_login, force_password_change, failed_login_count, last_failed_login_on, consented_at) FROM stdin;
2					f	3	\N		\N	2023-08-03 10:37:08.415074+00	2023-08-03 10:37:08.415074+00	DeletedUser	\N	t	f	0	\N	\N
1			System		t	1	\N		\N	2023-08-03 10:37:07.55359+00	2023-08-03 10:37:07.55359+00	SystemUser	\N	f	f	0	\N	\N
4			Anonymous		f	1	\N		\N	2023-08-03 10:37:30.214129+00	2023-08-03 10:37:30.214129+00	AnonymousUser	\N	t	f	0	\N	\N
3	admin	OpenProject	Admin	admin@example.net	t	1	2023-08-03 10:39:35.586719+00	de	\N	2023-08-03 10:37:29.992503+00	2023-08-03 10:39:38.767453+00	User	\N	f	f	0	2023-08-03 10:39:26.427779+00	\N
\.


--
-- Data for Name: version_settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.version_settings (id, project_id, version_id, display, created_at, updated_at) FROM stdin;
1	2	1	3	2023-08-03 10:37:30.932511+00	2023-08-03 10:37:30.932511+00
2	2	2	3	2023-08-03 10:37:30.933657+00	2023-08-03 10:37:30.933657+00
3	2	3	2	2023-08-03 10:37:30.934412+00	2023-08-03 10:37:30.934412+00
4	2	4	2	2023-08-03 10:37:30.935179+00	2023-08-03 10:37:30.935179+00
\.


--
-- Data for Name: versions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.versions (id, project_id, name, description, effective_date, created_at, updated_at, wiki_page_title, status, sharing, start_date) FROM stdin;
1	2	Bug Backlog		\N	2023-08-03 10:37:30.888851+00	2023-08-03 10:37:30.888851+00	\N	open	none	\N
2	2	Product Backlog		\N	2023-08-03 10:37:30.891838+00	2023-08-03 10:37:30.891838+00	\N	open	none	\N
3	2	Sprint 1		\N	2023-08-03 10:37:30.893329+00	2023-08-03 10:37:30.923975+00	Sprint 1	open	none	\N
4	2	Sprint 2		\N	2023-08-03 10:37:30.925476+00	2023-08-03 10:37:30.925476+00	\N	open	none	\N
\.


--
-- Data for Name: views; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.views (id, query_id, options, type, created_at, updated_at) FROM stdin;
1	1	{}	work_packages_table	2023-08-03 10:37:30.321735+00	2023-08-03 10:37:30.321735+00
2	2	{}	work_packages_table	2023-08-03 10:37:30.330879+00	2023-08-03 10:37:30.330879+00
3	3	{}	work_packages_table	2023-08-03 10:37:30.337072+00	2023-08-03 10:37:30.337072+00
4	4	{}	team_planner	2023-08-03 10:37:30.343156+00	2023-08-03 10:37:30.343156+00
5	15	{}	work_packages_table	2023-08-03 10:37:30.944143+00	2023-08-03 10:37:30.944143+00
6	16	{}	work_packages_table	2023-08-03 10:37:30.95223+00	2023-08-03 10:37:30.95223+00
7	17	{}	work_packages_table	2023-08-03 10:37:30.958999+00	2023-08-03 10:37:30.958999+00
8	18	{}	work_packages_table	2023-08-03 10:37:30.965402+00	2023-08-03 10:37:30.965402+00
\.


--
-- Data for Name: watchers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.watchers (id, watchable_type, watchable_id, user_id) FROM stdin;
1	News	1	1
2	News	2	1
3	WorkPackage	37	3
\.


--
-- Data for Name: webhooks_events; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.webhooks_events (id, name, webhooks_webhook_id) FROM stdin;
\.


--
-- Data for Name: webhooks_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.webhooks_logs (id, webhooks_webhook_id, event_name, url, request_headers, request_body, response_code, response_headers, response_body, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: webhooks_projects; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.webhooks_projects (id, project_id, webhooks_webhook_id) FROM stdin;
\.


--
-- Data for Name: webhooks_webhooks; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.webhooks_webhooks (id, name, url, description, secret, enabled, all_projects, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: wiki_content_journals; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.wiki_content_journals (id, page_id, author_id, text) FROM stdin;
1	1	1	### Sprint planning meeting\n\n_Please document here topics to the Sprint planning meeting_\n\n* Time boxed (8 h)\n* Input: Product Backlog\n* Output: Sprint Backlog\n\n* Divided into two additional time boxes of 4 h:\n\n    * The Product Owner presents the team the [Product Backlog]({{opSetting:base_url}}/projects/your-scrum-project/backlogs) and the priorities and explanes the Sprint Goal, to which the team must agree. Together, they prioritize the topics from the Product Backlog which the team will take care of in the next sprint. The team committs to the discussed delivery.\n    * The team plans autonomously (without the Product Owner) in detail and breaks down the tasks from the discussed requirements to consolidate a [Sprint Backlog]({{opSetting:base_url}}/projects/your-scrum-project/backlogs).\n\n\n### Daily Scrum meeting\n\n_Please document here topics to the Daily Scrum meeting_\n\n* Short, daily status meeting of the team.\n* Time boxed (max. 15 min).\n* Stand-up meeting to discuss the following topics from the [Task board](/projects/your-scrum-project/sprints/3/taskboard).\n    * What do I plan to do until the next Daily Scrum?\n    * What has blocked my work (Impediments)?\n* Scrum Master moderates and notes down [Sprint Impediments](/projects/your-scrum-project/sprints/3/taskboard).\n* Product Owner may participate may participate in order to stay informed.\n\n### Sprint Review meeting\n\n_Please document here topcis to the Sprint Review meeting_\n\n* Time boxed (4 h).\n* A maximum of one hour of preparation time per person.\n* The team shows the product owner and other interested persons what has been achieved in this sprint.\n* Important: no dummies and no PowerPoint! Just finished product functionality (Increments) should be demonstrated.\n* Feedback from Product Owner, stakeholders and others is desired and will be included in further work.\n* Based on the demonstrated functionalities, the Product Owner decides to go live with this increment or to develop it further. This possibility allows an early ROI.\n\n\n### Sprint Retrospective\n\n_Please document here topcis to the Sprint Retrospective meeting_\n\n* Time boxed (3 h).\n* After Sprint Review, will be moderated by Scrum Master.\n* The team discusses the sprint: what went well, what needs to be improved to be more productive for the next sprint or even have more fun.\n
2	2	1	### Sprint planning meeting\n\n_Please document here topics to the Sprint planning meeting_\n\n* Time boxed (8 h)\n* Input: Product Backlog\n* Output: Sprint Backlog\n\n* Divided into two additional time boxes of 4 h:\n\n    * The Product Owner presents the team the [Product Backlog]({{opSetting:base_url}}/projects/your-scrum-project/backlogs) and the priorities and explanes the Sprint Goal, to which the team must agree. Together, they prioritize the topics from the Product Backlog which the team will take care of in the next sprint. The team committs to the discussed delivery.\n    * The team plans autonomously (without the Product Owner) in detail and breaks down the tasks from the discussed requirements to consolidate a [Sprint Backlog]({{opSetting:base_url}}/projects/your-scrum-project/backlogs).\n\n\n### Daily Scrum meeting\n\n_Please document here topics to the Daily Scrum meeting_\n\n* Short, daily status meeting of the team.\n* Time boxed (max. 15 min).\n* Stand-up meeting to discuss the following topics from the Task board.\n    * What do I plan to do until the next Daily Scrum?\n    * What has blocked my work (Impediments)?\n* Scrum Master moderates and notes down Sprint Impediments.\n* Product Owner may participate may participate in order to stay informed.\n\n### Sprint Review meeting\n\n_Please document here topcis to the Sprint Review meeting_\n\n* Time boxed (4 h).\n* A maximum of one hour of preparation time per person.\n* The team shows the product owner and other interested persons what has been achieved in this sprint.\n* Important: no dummies and no PowerPoint! Just finished product functionality (Increments) should be demonstrated.\n* Feedback from Product Owner, stakeholders and others is desired and will be included in further work.\n* Based on the demonstrated functionalities, the Product Owner decides to go live with this increment or to develop it further. This possibility allows an early ROI.\n\n\n### Sprint Retrospective\n\n_Please document here topcis to the Sprint Retrospective meeting_\n\n* Time boxed (3 h).\n* After Sprint Review, will be moderated by Scrum Master.\n* The team discusses the sprint: what went well, what needs to be improved to be more productive for the next sprint or even have more fun.\n
\.


--
-- Data for Name: wiki_contents; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.wiki_contents (id, page_id, author_id, text, updated_at, lock_version) FROM stdin;
1	1	1	### Sprint planning meeting\n\n_Please document here topics to the Sprint planning meeting_\n\n* Time boxed (8 h)\n* Input: Product Backlog\n* Output: Sprint Backlog\n\n* Divided into two additional time boxes of 4 h:\n\n    * The Product Owner presents the team the [Product Backlog]({{opSetting:base_url}}/projects/your-scrum-project/backlogs) and the priorities and explanes the Sprint Goal, to which the team must agree. Together, they prioritize the topics from the Product Backlog which the team will take care of in the next sprint. The team committs to the discussed delivery.\n    * The team plans autonomously (without the Product Owner) in detail and breaks down the tasks from the discussed requirements to consolidate a [Sprint Backlog]({{opSetting:base_url}}/projects/your-scrum-project/backlogs).\n\n\n### Daily Scrum meeting\n\n_Please document here topics to the Daily Scrum meeting_\n\n* Short, daily status meeting of the team.\n* Time boxed (max. 15 min).\n* Stand-up meeting to discuss the following topics from the [Task board](/projects/your-scrum-project/sprints/3/taskboard).\n    * What do I plan to do until the next Daily Scrum?\n    * What has blocked my work (Impediments)?\n* Scrum Master moderates and notes down [Sprint Impediments](/projects/your-scrum-project/sprints/3/taskboard).\n* Product Owner may participate may participate in order to stay informed.\n\n### Sprint Review meeting\n\n_Please document here topcis to the Sprint Review meeting_\n\n* Time boxed (4 h).\n* A maximum of one hour of preparation time per person.\n* The team shows the product owner and other interested persons what has been achieved in this sprint.\n* Important: no dummies and no PowerPoint! Just finished product functionality (Increments) should be demonstrated.\n* Feedback from Product Owner, stakeholders and others is desired and will be included in further work.\n* Based on the demonstrated functionalities, the Product Owner decides to go live with this increment or to develop it further. This possibility allows an early ROI.\n\n\n### Sprint Retrospective\n\n_Please document here topcis to the Sprint Retrospective meeting_\n\n* Time boxed (3 h).\n* After Sprint Review, will be moderated by Scrum Master.\n* The team discusses the sprint: what went well, what needs to be improved to be more productive for the next sprint or even have more fun.\n	2023-08-03 10:37:30.910964+00	0
2	2	1	### Sprint planning meeting\n\n_Please document here topics to the Sprint planning meeting_\n\n* Time boxed (8 h)\n* Input: Product Backlog\n* Output: Sprint Backlog\n\n* Divided into two additional time boxes of 4 h:\n\n    * The Product Owner presents the team the [Product Backlog]({{opSetting:base_url}}/projects/your-scrum-project/backlogs) and the priorities and explanes the Sprint Goal, to which the team must agree. Together, they prioritize the topics from the Product Backlog which the team will take care of in the next sprint. The team committs to the discussed delivery.\n    * The team plans autonomously (without the Product Owner) in detail and breaks down the tasks from the discussed requirements to consolidate a [Sprint Backlog]({{opSetting:base_url}}/projects/your-scrum-project/backlogs).\n\n\n### Daily Scrum meeting\n\n_Please document here topics to the Daily Scrum meeting_\n\n* Short, daily status meeting of the team.\n* Time boxed (max. 15 min).\n* Stand-up meeting to discuss the following topics from the Task board.\n    * What do I plan to do until the next Daily Scrum?\n    * What has blocked my work (Impediments)?\n* Scrum Master moderates and notes down Sprint Impediments.\n* Product Owner may participate may participate in order to stay informed.\n\n### Sprint Review meeting\n\n_Please document here topcis to the Sprint Review meeting_\n\n* Time boxed (4 h).\n* A maximum of one hour of preparation time per person.\n* The team shows the product owner and other interested persons what has been achieved in this sprint.\n* Important: no dummies and no PowerPoint! Just finished product functionality (Increments) should be demonstrated.\n* Feedback from Product Owner, stakeholders and others is desired and will be included in further work.\n* Based on the demonstrated functionalities, the Product Owner decides to go live with this increment or to develop it further. This possibility allows an early ROI.\n\n\n### Sprint Retrospective\n\n_Please document here topcis to the Sprint Retrospective meeting_\n\n* Time boxed (3 h).\n* After Sprint Review, will be moderated by Scrum Master.\n* The team discusses the sprint: what went well, what needs to be improved to be more productive for the next sprint or even have more fun.\n	2023-08-03 10:37:30.969775+00	0
\.


--
-- Data for Name: wiki_pages; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.wiki_pages (id, wiki_id, title, created_at, protected, parent_id, slug, updated_at) FROM stdin;
1	2	Sprint 1	2023-08-03 10:37:30.903577+00	f	\N	sprint-1	2023-08-03 10:37:30.903577+00
2	2	Wiki	2023-08-03 10:37:30.969024+00	f	\N	wiki	2023-08-03 10:37:30.969024+00
\.


--
-- Data for Name: wiki_redirects; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.wiki_redirects (id, wiki_id, title, redirects_to, created_at) FROM stdin;
\.


--
-- Data for Name: wikis; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.wikis (id, project_id, start_page, status, created_at, updated_at) FROM stdin;
1	1	Wiki	1	2023-08-03 10:37:30.196011+00	2023-08-03 10:37:30.196011+00
2	2	Wiki	1	2023-08-03 10:37:30.808431+00	2023-08-03 10:37:30.969456+00
\.


--
-- Data for Name: work_package_hierarchies; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.work_package_hierarchies (ancestor_id, descendant_id, generations) FROM stdin;
1	1	0
2	2	0
3	3	0
2	3	1
4	4	0
3	4	1
2	4	2
5	5	0
3	5	1
2	5	2
6	6	0
3	6	1
2	6	2
7	7	0
2	7	1
8	8	0
2	8	1
9	9	0
10	10	0
11	11	0
10	11	1
12	12	0
10	12	1
13	13	0
14	14	0
15	15	0
16	16	0
17	17	0
16	17	1
18	18	0
16	18	1
19	19	0
16	19	1
20	20	0
19	20	1
16	20	2
21	21	0
22	22	0
23	23	0
22	23	1
24	24	0
25	25	0
26	26	0
27	27	0
28	28	0
29	29	0
28	29	1
30	30	0
31	31	0
32	32	0
33	33	0
34	34	0
35	35	0
36	36	0
37	37	0
\.


--
-- Data for Name: work_package_journals; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.work_package_journals (id, type_id, project_id, subject, description, due_date, category_id, status_id, assigned_to_id, priority_id, version_id, author_id, done_ratio, estimated_hours, start_date, parent_id, responsible_id, budget_id, story_points, remaining_hours, derived_estimated_hours, schedule_manually, duration, ignore_non_working_days) FROM stdin;
1	2	1	Start of project		2023-07-30	\N	12	3	8	\N	3	0	\N	2023-07-30	\N	\N	\N	\N	\N	\N	f	1	t
5	1	1	Send invitation to speakers		2023-07-31	\N	7	3	8	\N	3	0	\N	2023-07-31	3	\N	\N	\N	\N	\N	f	1	f
7	1	1	Contact sponsoring partners		2023-08-01	\N	1	3	8	\N	3	0	\N	2023-07-31	3	\N	\N	\N	\N	\N	f	2	f
9	1	1	Create sponsorship brochure and hand-outs		2023-08-03	\N	1	3	8	\N	3	0	\N	2023-07-31	3	\N	\N	\N	\N	\N	f	4	f
11	1	1	Set date and location of conference		2023-08-03	\N	7	3	8	\N	3	0	\N	2023-07-31	2	\N	\N	\N	\N	\N	f	4	f
13	1	1	Invite attendees to conference		2023-08-04	\N	1	3	8	\N	3	0	\N	2023-08-04	2	\N	\N	\N	\N	\N	f	1	f
15	1	1	Setup conference website		2023-08-14	\N	1	3	8	\N	3	0	\N	2023-08-04	2	\N	\N	\N	\N	\N	f	7	f
16	3	1	Organize open source conference		2023-08-14	\N	7	3	8	\N	3	0	\N	2023-07-31	\N	\N	\N	\N	\N	\N	f	11	f
17	2	1	Conference		2023-08-15	\N	6	3	8	\N	3	0	\N	2023-08-15	\N	\N	\N	\N	\N	\N	f	1	f
20	1	1	Upload presentations to website		2023-08-30	\N	1	3	8	\N	3	0	\N	2023-08-21	10	\N	\N	\N	\N	\N	f	8	f
22	1	1	Party for conference supporters :-)	*   [ ] Beer\n*   [ ] Snacks\n*   [ ] Music\n*   [ ] Even more beer	2023-08-31	\N	1	3	8	\N	3	0	\N	2023-08-31	10	\N	\N	\N	\N	\N	f	1	f
23	3	1	Follow-up tasks		2023-08-31	\N	5	3	8	\N	3	0	\N	2023-08-21	\N	\N	\N	\N	\N	\N	f	9	f
24	2	1	End of project		2023-09-01	\N	1	3	8	\N	3	0	\N	2023-09-01	\N	\N	\N	\N	\N	\N	f	1	f
25	6	2	New login screen		\N	\N	2	3	8	2	3	0	\N	2023-07-31	\N	\N	\N	\N	\N	\N	f	\N	f
26	7	2	Password reset does not send email		\N	\N	4	3	8	1	3	0	\N	2023-07-31	\N	\N	\N	\N	\N	\N	f	\N	f
29	6	2	Newsletter registration form		\N	\N	7	3	8	2	3	0	\N	2023-07-31	16	\N	\N	\N	\N	\N	f	\N	f
31	6	2	Implement product tour		\N	\N	2	3	8	2	3	0	\N	2023-07-31	16	\N	\N	\N	\N	\N	f	\N	f
34	1	2	Create wireframes for new landing page		2023-08-28	\N	7	3	8	3	3	0	\N	2023-08-28	19	\N	\N	\N	\N	\N	f	1	f
36	6	2	New landing page		2023-08-28	\N	3	3	8	3	3	0	\N	2023-08-28	16	\N	\N	3	\N	\N	f	1	f
37	5	2	New website		2023-08-28	\N	3	3	8	\N	3	0	\N	2023-07-31	\N	\N	\N	\N	\N	\N	f	21	f
38	6	2	Contact form		2023-08-21	\N	3	3	8	3	3	0	\N	2023-08-21	\N	\N	\N	1	\N	\N	f	1	f
41	1	2	Make screenshots for feature tour		\N	\N	12	3	8	3	3	0	\N	2023-07-31	22	\N	\N	\N	\N	\N	f	\N	f
42	6	2	Feature carousel		\N	\N	3	3	8	3	3	0	\N	2023-07-31	\N	\N	\N	5	\N	\N	f	\N	f
43	7	2	Wrong hover color		2023-08-21	\N	14	3	8	3	3	0	\N	2023-08-21	\N	\N	\N	1	\N	\N	f	1	f
44	6	2	SSL certificate		2023-08-22	\N	3	3	8	2	3	0	\N	2023-08-22	\N	\N	\N	\N	\N	\N	f	1	f
45	6	2	Set-up Staging environment		2023-08-23	\N	2	3	8	2	3	0	\N	2023-08-23	\N	\N	\N	\N	\N	\N	f	1	f
46	6	2	Choose a content management system		2023-08-24	\N	3	3	8	2	3	0	\N	2023-08-24	\N	\N	\N	\N	\N	\N	f	1	f
49	1	2	Set up navigation concept for website.		2023-08-25	\N	2	3	8	3	3	0	\N	2023-08-25	28	\N	\N	\N	\N	\N	f	1	f
50	6	2	Website navigation structure		2023-08-25	\N	3	3	8	3	3	0	\N	2023-08-25	\N	\N	\N	3	\N	\N	f	1	f
51	6	2	Internal link structure		2023-08-25	\N	12	3	8	2	3	0	\N	2023-08-25	\N	\N	\N	\N	\N	\N	f	1	f
52	3	2	Develop v1.0		2023-08-16	\N	7	3	8	\N	3	0	\N	2023-08-14	\N	\N	\N	\N	\N	\N	f	3	f
53	2	2	Release v1.0		2023-08-18	\N	1	3	8	\N	3	0	\N	2023-08-18	\N	\N	\N	\N	\N	\N	f	1	f
54	3	2	Develop v1.1		2023-08-23	\N	1	3	8	\N	3	0	\N	2023-08-21	\N	\N	\N	\N	\N	\N	f	3	f
55	2	2	Release v1.1		2023-08-25	\N	1	3	8	\N	3	0	\N	2023-08-25	\N	\N	\N	\N	\N	\N	f	1	f
56	3	2	Develop v2.0		2023-08-30	\N	1	3	8	\N	3	0	\N	2023-08-28	\N	\N	\N	\N	\N	\N	f	3	f
57	2	2	Release v2.0		2023-09-01	\N	1	3	8	\N	3	0	\N	2023-09-01	\N	\N	\N	\N	\N	\N	f	1	f
61	1	1	Ein übliges Arbeitspaket mit Umlauten	Umhier hiä, Umlaute überall!	\N	\N	1	\N	8	\N	3	0	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f
\.


--
-- Data for Name: work_packages; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.work_packages (id, type_id, project_id, subject, description, due_date, category_id, status_id, assigned_to_id, priority_id, version_id, author_id, lock_version, done_ratio, estimated_hours, created_at, updated_at, start_date, responsible_id, budget_id, "position", story_points, remaining_hours, derived_estimated_hours, schedule_manually, parent_id, duration, ignore_non_working_days) FROM stdin;
1	2	1	Start of project	\N	2023-07-30	\N	12	3	8	\N	3	0	0	\N	2023-08-03 10:37:30.362073+00	2023-08-03 10:37:30.362073+00	2023-07-30	\N	\N	1	\N	\N	\N	f	\N	1	t
2	3	1	Organize open source conference	\N	2023-08-14	\N	7	3	8	\N	3	0	0	\N	2023-08-03 10:37:30.404951+00	2023-08-03 10:37:30.404951+00	2023-07-31	\N	\N	1	\N	\N	\N	f	\N	11	f
4	1	1	Send invitation to speakers	\N	2023-07-31	\N	7	3	8	\N	3	1	0	\N	2023-08-03 10:37:30.434508+00	2023-08-03 10:37:30.450307+00	2023-07-31	\N	\N	1	\N	\N	\N	f	3	1	f
5	1	1	Contact sponsoring partners	\N	2023-08-01	\N	1	3	8	\N	3	1	0	\N	2023-08-03 10:37:30.46595+00	2023-08-03 10:37:30.479957+00	2023-07-31	\N	\N	1	\N	\N	\N	f	3	2	f
6	1	1	Create sponsorship brochure and hand-outs	\N	2023-08-03	\N	1	3	8	\N	3	1	0	\N	2023-08-03 10:37:30.494267+00	2023-08-03 10:37:30.510266+00	2023-07-31	\N	\N	1	\N	\N	\N	f	3	4	f
3	1	1	Set date and location of conference	\N	2023-08-03	\N	7	3	8	\N	3	1	0	\N	2023-08-03 10:37:30.42146+00	2023-08-03 10:37:30.531408+00	2023-07-31	\N	\N	1	\N	\N	\N	f	2	4	f
7	1	1	Invite attendees to conference	\N	2023-08-04	\N	1	3	8	\N	3	1	0	\N	2023-08-03 10:37:30.548793+00	2023-08-03 10:37:30.565857+00	2023-08-04	\N	\N	1	\N	\N	\N	f	2	1	f
8	1	1	Setup conference website	\N	2023-08-14	\N	1	3	8	\N	3	1	0	\N	2023-08-03 10:37:30.582649+00	2023-08-03 10:37:30.59717+00	2023-08-04	\N	\N	1	\N	\N	\N	f	2	7	f
9	2	1	Conference	\N	2023-08-15	\N	6	3	8	\N	3	0	0	\N	2023-08-03 10:37:30.620252+00	2023-08-03 10:37:30.620252+00	2023-08-15	\N	\N	1	\N	\N	\N	f	\N	1	f
10	3	1	Follow-up tasks	\N	2023-08-31	\N	5	3	8	\N	3	0	0	\N	2023-08-03 10:37:30.637001+00	2023-08-03 10:37:30.637001+00	2023-08-21	\N	\N	1	\N	\N	\N	f	\N	9	f
11	1	1	Upload presentations to website	\N	2023-08-30	\N	1	3	8	\N	3	1	0	\N	2023-08-03 10:37:30.650405+00	2023-08-03 10:37:30.664589+00	2023-08-21	\N	\N	1	\N	\N	\N	f	10	8	f
12	1	1	Party for conference supporters :-)	*   [ ] Beer\n*   [ ] Snacks\n*   [ ] Music\n*   [ ] Even more beer	2023-08-31	\N	1	3	8	\N	3	1	0	\N	2023-08-03 10:37:30.678678+00	2023-08-03 10:37:30.693431+00	2023-08-31	\N	\N	1	\N	\N	\N	f	10	1	f
13	2	1	End of project	\N	2023-09-01	\N	1	3	8	\N	3	0	0	\N	2023-08-03 10:37:30.715227+00	2023-08-03 10:37:30.715227+00	2023-09-01	\N	\N	1	\N	\N	\N	f	\N	1	f
15	7	2	Password reset does not send email	\N	\N	\N	4	3	8	1	3	0	0	\N	2023-08-03 10:37:31.00254+00	2023-08-03 10:37:31.00254+00	2023-07-31	\N	\N	1	\N	\N	\N	f	\N	\N	f
16	5	2	New website	\N	2023-08-28	\N	3	3	8	\N	3	0	0	\N	2023-08-03 10:37:31.0229+00	2023-08-03 10:37:31.0229+00	2023-07-31	\N	\N	1	\N	\N	\N	f	\N	21	f
20	1	2	Create wireframes for new landing page	\N	2023-08-28	\N	7	3	8	3	3	1	0	\N	2023-08-03 10:37:31.122433+00	2023-08-03 10:37:31.137565+00	2023-08-28	\N	\N	1	\N	\N	\N	f	19	1	f
19	6	2	New landing page	\N	2023-08-28	\N	3	3	8	3	3	1	0	\N	2023-08-03 10:37:31.106108+00	2023-08-03 10:37:31.156336+00	2023-08-28	\N	\N	2	3	\N	\N	f	16	1	f
22	6	2	Feature carousel	\N	\N	\N	3	3	8	3	3	0	0	\N	2023-08-03 10:37:31.207606+00	2023-08-03 10:37:31.207606+00	2023-07-31	\N	\N	3	5	\N	\N	f	\N	\N	f
23	1	2	Make screenshots for feature tour	\N	\N	\N	12	3	8	3	3	1	0	\N	2023-08-03 10:37:31.226873+00	2023-08-03 10:37:31.241997+00	2023-07-31	\N	\N	1	\N	\N	\N	f	22	\N	f
24	7	2	Wrong hover color	\N	2023-08-21	\N	14	3	8	3	3	0	0	\N	2023-08-03 10:37:31.26635+00	2023-08-03 10:37:31.26635+00	2023-08-21	\N	\N	4	1	\N	\N	f	\N	1	f
25	6	2	SSL certificate	\N	2023-08-22	\N	3	3	8	2	3	0	0	\N	2023-08-03 10:37:31.290566+00	2023-08-03 10:37:31.290566+00	2023-08-22	\N	\N	1	\N	\N	\N	f	\N	1	f
26	6	2	Set-up Staging environment	\N	2023-08-23	\N	2	3	8	2	3	0	0	\N	2023-08-03 10:37:31.309943+00	2023-08-03 10:37:31.309943+00	2023-08-23	\N	\N	2	\N	\N	\N	f	\N	1	f
21	6	2	Contact form	\N	2023-08-21	\N	3	3	8	3	3	0	0	\N	2023-08-03 10:37:31.186657+00	2023-08-03 10:37:31.186657+00	2023-08-21	\N	\N	8	1	\N	\N	f	\N	1	f
28	6	2	Website navigation structure	\N	2023-08-25	\N	3	3	8	3	3	0	0	\N	2023-08-03 10:37:31.349654+00	2023-08-03 10:37:31.349654+00	2023-08-25	\N	\N	7	3	\N	\N	f	\N	1	f
29	1	2	Set up navigation concept for website.	\N	2023-08-25	\N	2	3	8	3	3	1	0	\N	2023-08-03 10:37:31.366729+00	2023-08-03 10:37:31.38514+00	2023-08-25	\N	\N	1	\N	\N	\N	f	28	1	f
14	6	2	New login screen	\N	\N	\N	2	3	8	2	3	0	0	\N	2023-08-03 10:37:30.982383+00	2023-08-03 10:37:30.982383+00	2023-07-31	\N	\N	6	\N	\N	\N	f	\N	\N	f
17	6	2	Newsletter registration form	\N	\N	\N	7	3	8	2	3	1	0	\N	2023-08-03 10:37:31.037148+00	2023-08-03 10:37:31.057254+00	2023-07-31	\N	\N	11	\N	\N	\N	f	16	\N	f
18	6	2	Implement product tour	\N	\N	\N	2	3	8	2	3	1	0	\N	2023-08-03 10:37:31.073946+00	2023-08-03 10:37:31.090758+00	2023-07-31	\N	\N	7	\N	\N	\N	f	16	\N	f
27	6	2	Choose a content management system	\N	2023-08-24	\N	3	3	8	2	3	0	0	\N	2023-08-03 10:37:31.329724+00	2023-08-03 10:37:31.329724+00	2023-08-24	\N	\N	8	\N	\N	\N	f	\N	1	f
30	6	2	Internal link structure	\N	2023-08-25	\N	12	3	8	2	3	0	0	\N	2023-08-03 10:37:31.415173+00	2023-08-03 10:37:31.415173+00	2023-08-25	\N	\N	5	\N	\N	\N	f	\N	1	f
31	3	2	Develop v1.0	\N	2023-08-16	\N	7	3	8	\N	3	0	0	\N	2023-08-03 10:37:31.433693+00	2023-08-03 10:37:31.433693+00	2023-08-14	\N	\N	1	\N	\N	\N	f	\N	3	f
32	2	2	Release v1.0	\N	2023-08-18	\N	1	3	8	\N	3	0	0	\N	2023-08-03 10:37:31.450448+00	2023-08-03 10:37:31.450448+00	2023-08-18	\N	\N	1	\N	\N	\N	f	\N	1	f
33	3	2	Develop v1.1	\N	2023-08-23	\N	1	3	8	\N	3	0	0	\N	2023-08-03 10:37:31.467039+00	2023-08-03 10:37:31.467039+00	2023-08-21	\N	\N	1	\N	\N	\N	f	\N	3	f
34	2	2	Release v1.1	\N	2023-08-25	\N	1	3	8	\N	3	0	0	\N	2023-08-03 10:37:31.486185+00	2023-08-03 10:37:31.486185+00	2023-08-25	\N	\N	1	\N	\N	\N	f	\N	1	f
35	3	2	Develop v2.0	\N	2023-08-30	\N	1	3	8	\N	3	0	0	\N	2023-08-03 10:37:31.506514+00	2023-08-03 10:37:31.506514+00	2023-08-28	\N	\N	1	\N	\N	\N	f	\N	3	f
36	2	2	Release v2.0	\N	2023-09-01	\N	1	3	8	\N	3	0	0	\N	2023-08-03 10:37:31.533606+00	2023-08-03 10:37:31.533606+00	2023-09-01	\N	\N	1	\N	\N	\N	f	\N	1	f
37	1	1	Ein übliges Arbeitspaket mit Umlauten	Umhier hiä, Umlaute überall!	\N	\N	1	\N	8	\N	3	1	0	\N	2023-08-03 10:40:31.599371+00	2023-08-03 10:41:23.916315+00	\N	\N	\N	1	\N	\N	\N	f	\N	\N	f
\.


--
-- Data for Name: workflows; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.workflows (id, type_id, old_status_id, new_status_id, role_id, assignee, author) FROM stdin;
1	1	1	1	3	f	f
2	1	1	1	4	f	f
3	1	1	7	3	f	f
4	1	1	7	4	f	f
5	1	1	13	3	f	f
6	1	1	13	4	f	f
7	1	1	14	3	f	f
8	1	1	14	4	f	f
9	1	1	12	3	f	f
10	1	1	12	4	f	f
11	1	7	1	3	f	f
12	1	7	1	4	f	f
13	1	7	7	3	f	f
14	1	7	7	4	f	f
15	1	7	13	3	f	f
16	1	7	13	4	f	f
17	1	7	14	3	f	f
18	1	7	14	4	f	f
19	1	7	12	3	f	f
20	1	7	12	4	f	f
21	1	13	1	3	f	f
22	1	13	1	4	f	f
23	1	13	7	3	f	f
24	1	13	7	4	f	f
25	1	13	13	3	f	f
26	1	13	13	4	f	f
27	1	13	14	3	f	f
28	1	13	14	4	f	f
29	1	13	12	3	f	f
30	1	13	12	4	f	f
31	1	14	1	3	f	f
32	1	14	1	4	f	f
33	1	14	7	3	f	f
34	1	14	7	4	f	f
35	1	14	13	3	f	f
36	1	14	13	4	f	f
37	1	14	14	3	f	f
38	1	14	14	4	f	f
39	1	14	12	3	f	f
40	1	14	12	4	f	f
41	1	12	1	3	f	f
42	1	12	1	4	f	f
43	1	12	7	3	f	f
44	1	12	7	4	f	f
45	1	12	13	3	f	f
46	1	12	13	4	f	f
47	1	12	14	3	f	f
48	1	12	14	4	f	f
49	1	12	12	3	f	f
50	1	12	12	4	f	f
51	2	1	1	3	f	f
52	2	1	1	4	f	f
53	2	1	5	3	f	f
54	2	1	5	4	f	f
55	2	1	6	3	f	f
56	2	1	6	4	f	f
57	2	1	7	3	f	f
58	2	1	7	4	f	f
59	2	1	13	3	f	f
60	2	1	13	4	f	f
61	2	1	14	3	f	f
62	2	1	14	4	f	f
63	2	1	12	3	f	f
64	2	1	12	4	f	f
65	2	5	1	3	f	f
66	2	5	1	4	f	f
67	2	5	5	3	f	f
68	2	5	5	4	f	f
69	2	5	6	3	f	f
70	2	5	6	4	f	f
71	2	5	7	3	f	f
72	2	5	7	4	f	f
73	2	5	13	3	f	f
74	2	5	13	4	f	f
75	2	5	14	3	f	f
76	2	5	14	4	f	f
77	2	5	12	3	f	f
78	2	5	12	4	f	f
79	2	6	1	3	f	f
80	2	6	1	4	f	f
81	2	6	5	3	f	f
82	2	6	5	4	f	f
83	2	6	6	3	f	f
84	2	6	6	4	f	f
85	2	6	7	3	f	f
86	2	6	7	4	f	f
87	2	6	13	3	f	f
88	2	6	13	4	f	f
89	2	6	14	3	f	f
90	2	6	14	4	f	f
91	2	6	12	3	f	f
92	2	6	12	4	f	f
93	2	7	1	3	f	f
94	2	7	1	4	f	f
95	2	7	5	3	f	f
96	2	7	5	4	f	f
97	2	7	6	3	f	f
98	2	7	6	4	f	f
99	2	7	7	3	f	f
100	2	7	7	4	f	f
101	2	7	13	3	f	f
102	2	7	13	4	f	f
103	2	7	14	3	f	f
104	2	7	14	4	f	f
105	2	7	12	3	f	f
106	2	7	12	4	f	f
107	2	13	1	3	f	f
108	2	13	1	4	f	f
109	2	13	5	3	f	f
110	2	13	5	4	f	f
111	2	13	6	3	f	f
112	2	13	6	4	f	f
113	2	13	7	3	f	f
114	2	13	7	4	f	f
115	2	13	13	3	f	f
116	2	13	13	4	f	f
117	2	13	14	3	f	f
118	2	13	14	4	f	f
119	2	13	12	3	f	f
120	2	13	12	4	f	f
121	2	14	1	3	f	f
122	2	14	1	4	f	f
123	2	14	5	3	f	f
124	2	14	5	4	f	f
125	2	14	6	3	f	f
126	2	14	6	4	f	f
127	2	14	7	3	f	f
128	2	14	7	4	f	f
129	2	14	13	3	f	f
130	2	14	13	4	f	f
131	2	14	14	3	f	f
132	2	14	14	4	f	f
133	2	14	12	3	f	f
134	2	14	12	4	f	f
135	2	12	1	3	f	f
136	2	12	1	4	f	f
137	2	12	5	3	f	f
138	2	12	5	4	f	f
139	2	12	6	3	f	f
140	2	12	6	4	f	f
141	2	12	7	3	f	f
142	2	12	7	4	f	f
143	2	12	13	3	f	f
144	2	12	13	4	f	f
145	2	12	14	3	f	f
146	2	12	14	4	f	f
147	2	12	12	3	f	f
148	2	12	12	4	f	f
149	3	1	1	3	f	f
150	3	1	1	4	f	f
151	3	1	5	3	f	f
152	3	1	5	4	f	f
153	3	1	6	3	f	f
154	3	1	6	4	f	f
155	3	1	7	3	f	f
156	3	1	7	4	f	f
157	3	1	13	3	f	f
158	3	1	13	4	f	f
159	3	1	14	3	f	f
160	3	1	14	4	f	f
161	3	1	12	3	f	f
162	3	1	12	4	f	f
163	3	5	1	3	f	f
164	3	5	1	4	f	f
165	3	5	5	3	f	f
166	3	5	5	4	f	f
167	3	5	6	3	f	f
168	3	5	6	4	f	f
169	3	5	7	3	f	f
170	3	5	7	4	f	f
171	3	5	13	3	f	f
172	3	5	13	4	f	f
173	3	5	14	3	f	f
174	3	5	14	4	f	f
175	3	5	12	3	f	f
176	3	5	12	4	f	f
177	3	6	1	3	f	f
178	3	6	1	4	f	f
179	3	6	5	3	f	f
180	3	6	5	4	f	f
181	3	6	6	3	f	f
182	3	6	6	4	f	f
183	3	6	7	3	f	f
184	3	6	7	4	f	f
185	3	6	13	3	f	f
186	3	6	13	4	f	f
187	3	6	14	3	f	f
188	3	6	14	4	f	f
189	3	6	12	3	f	f
190	3	6	12	4	f	f
191	3	7	1	3	f	f
192	3	7	1	4	f	f
193	3	7	5	3	f	f
194	3	7	5	4	f	f
195	3	7	6	3	f	f
196	3	7	6	4	f	f
197	3	7	7	3	f	f
198	3	7	7	4	f	f
199	3	7	13	3	f	f
200	3	7	13	4	f	f
201	3	7	14	3	f	f
202	3	7	14	4	f	f
203	3	7	12	3	f	f
204	3	7	12	4	f	f
205	3	13	1	3	f	f
206	3	13	1	4	f	f
207	3	13	5	3	f	f
208	3	13	5	4	f	f
209	3	13	6	3	f	f
210	3	13	6	4	f	f
211	3	13	7	3	f	f
212	3	13	7	4	f	f
213	3	13	13	3	f	f
214	3	13	13	4	f	f
215	3	13	14	3	f	f
216	3	13	14	4	f	f
217	3	13	12	3	f	f
218	3	13	12	4	f	f
219	3	14	1	3	f	f
220	3	14	1	4	f	f
221	3	14	5	3	f	f
222	3	14	5	4	f	f
223	3	14	6	3	f	f
224	3	14	6	4	f	f
225	3	14	7	3	f	f
226	3	14	7	4	f	f
227	3	14	13	3	f	f
228	3	14	13	4	f	f
229	3	14	14	3	f	f
230	3	14	14	4	f	f
231	3	14	12	3	f	f
232	3	14	12	4	f	f
233	3	12	1	3	f	f
234	3	12	1	4	f	f
235	3	12	5	3	f	f
236	3	12	5	4	f	f
237	3	12	6	3	f	f
238	3	12	6	4	f	f
239	3	12	7	3	f	f
240	3	12	7	4	f	f
241	3	12	13	3	f	f
242	3	12	13	4	f	f
243	3	12	14	3	f	f
244	3	12	14	4	f	f
245	3	12	12	3	f	f
246	3	12	12	4	f	f
247	4	1	1	3	f	f
248	4	1	1	4	f	f
249	4	1	2	3	f	f
250	4	1	2	4	f	f
251	4	1	3	3	f	f
252	4	1	3	4	f	f
253	4	1	7	3	f	f
254	4	1	7	4	f	f
255	4	1	8	3	f	f
256	4	1	8	4	f	f
257	4	1	9	3	f	f
258	4	1	9	4	f	f
259	4	1	10	3	f	f
260	4	1	10	4	f	f
261	4	1	11	3	f	f
262	4	1	11	4	f	f
263	4	1	13	3	f	f
264	4	1	13	4	f	f
265	4	1	14	3	f	f
266	4	1	14	4	f	f
267	4	1	12	3	f	f
268	4	1	12	4	f	f
269	4	2	1	3	f	f
270	4	2	1	4	f	f
271	4	2	2	3	f	f
272	4	2	2	4	f	f
273	4	2	3	3	f	f
274	4	2	3	4	f	f
275	4	2	7	3	f	f
276	4	2	7	4	f	f
277	4	2	8	3	f	f
278	4	2	8	4	f	f
279	4	2	9	3	f	f
280	4	2	9	4	f	f
281	4	2	10	3	f	f
282	4	2	10	4	f	f
283	4	2	11	3	f	f
284	4	2	11	4	f	f
285	4	2	13	3	f	f
286	4	2	13	4	f	f
287	4	2	14	3	f	f
288	4	2	14	4	f	f
289	4	2	12	3	f	f
290	4	2	12	4	f	f
291	4	3	1	3	f	f
292	4	3	1	4	f	f
293	4	3	2	3	f	f
294	4	3	2	4	f	f
295	4	3	3	3	f	f
296	4	3	3	4	f	f
297	4	3	7	3	f	f
298	4	3	7	4	f	f
299	4	3	8	3	f	f
300	4	3	8	4	f	f
301	4	3	9	3	f	f
302	4	3	9	4	f	f
303	4	3	10	3	f	f
304	4	3	10	4	f	f
305	4	3	11	3	f	f
306	4	3	11	4	f	f
307	4	3	13	3	f	f
308	4	3	13	4	f	f
309	4	3	14	3	f	f
310	4	3	14	4	f	f
311	4	3	12	3	f	f
312	4	3	12	4	f	f
313	4	7	1	3	f	f
314	4	7	1	4	f	f
315	4	7	2	3	f	f
316	4	7	2	4	f	f
317	4	7	3	3	f	f
318	4	7	3	4	f	f
319	4	7	7	3	f	f
320	4	7	7	4	f	f
321	4	7	8	3	f	f
322	4	7	8	4	f	f
323	4	7	9	3	f	f
324	4	7	9	4	f	f
325	4	7	10	3	f	f
326	4	7	10	4	f	f
327	4	7	11	3	f	f
328	4	7	11	4	f	f
329	4	7	13	3	f	f
330	4	7	13	4	f	f
331	4	7	14	3	f	f
332	4	7	14	4	f	f
333	4	7	12	3	f	f
334	4	7	12	4	f	f
335	4	8	1	3	f	f
336	4	8	1	4	f	f
337	4	8	2	3	f	f
338	4	8	2	4	f	f
339	4	8	3	3	f	f
340	4	8	3	4	f	f
341	4	8	7	3	f	f
342	4	8	7	4	f	f
343	4	8	8	3	f	f
344	4	8	8	4	f	f
345	4	8	9	3	f	f
346	4	8	9	4	f	f
347	4	8	10	3	f	f
348	4	8	10	4	f	f
349	4	8	11	3	f	f
350	4	8	11	4	f	f
351	4	8	13	3	f	f
352	4	8	13	4	f	f
353	4	8	14	3	f	f
354	4	8	14	4	f	f
355	4	8	12	3	f	f
356	4	8	12	4	f	f
357	4	9	1	3	f	f
358	4	9	1	4	f	f
359	4	9	2	3	f	f
360	4	9	2	4	f	f
361	4	9	3	3	f	f
362	4	9	3	4	f	f
363	4	9	7	3	f	f
364	4	9	7	4	f	f
365	4	9	8	3	f	f
366	4	9	8	4	f	f
367	4	9	9	3	f	f
368	4	9	9	4	f	f
369	4	9	10	3	f	f
370	4	9	10	4	f	f
371	4	9	11	3	f	f
372	4	9	11	4	f	f
373	4	9	13	3	f	f
374	4	9	13	4	f	f
375	4	9	14	3	f	f
376	4	9	14	4	f	f
377	4	9	12	3	f	f
378	4	9	12	4	f	f
379	4	10	1	3	f	f
380	4	10	1	4	f	f
381	4	10	2	3	f	f
382	4	10	2	4	f	f
383	4	10	3	3	f	f
384	4	10	3	4	f	f
385	4	10	7	3	f	f
386	4	10	7	4	f	f
387	4	10	8	3	f	f
388	4	10	8	4	f	f
389	4	10	9	3	f	f
390	4	10	9	4	f	f
391	4	10	10	3	f	f
392	4	10	10	4	f	f
393	4	10	11	3	f	f
394	4	10	11	4	f	f
395	4	10	13	3	f	f
396	4	10	13	4	f	f
397	4	10	14	3	f	f
398	4	10	14	4	f	f
399	4	10	12	3	f	f
400	4	10	12	4	f	f
401	4	11	1	3	f	f
402	4	11	1	4	f	f
403	4	11	2	3	f	f
404	4	11	2	4	f	f
405	4	11	3	3	f	f
406	4	11	3	4	f	f
407	4	11	7	3	f	f
408	4	11	7	4	f	f
409	4	11	8	3	f	f
410	4	11	8	4	f	f
411	4	11	9	3	f	f
412	4	11	9	4	f	f
413	4	11	10	3	f	f
414	4	11	10	4	f	f
415	4	11	11	3	f	f
416	4	11	11	4	f	f
417	4	11	13	3	f	f
418	4	11	13	4	f	f
419	4	11	14	3	f	f
420	4	11	14	4	f	f
421	4	11	12	3	f	f
422	4	11	12	4	f	f
423	4	13	1	3	f	f
424	4	13	1	4	f	f
425	4	13	2	3	f	f
426	4	13	2	4	f	f
427	4	13	3	3	f	f
428	4	13	3	4	f	f
429	4	13	7	3	f	f
430	4	13	7	4	f	f
431	4	13	8	3	f	f
432	4	13	8	4	f	f
433	4	13	9	3	f	f
434	4	13	9	4	f	f
435	4	13	10	3	f	f
436	4	13	10	4	f	f
437	4	13	11	3	f	f
438	4	13	11	4	f	f
439	4	13	13	3	f	f
440	4	13	13	4	f	f
441	4	13	14	3	f	f
442	4	13	14	4	f	f
443	4	13	12	3	f	f
444	4	13	12	4	f	f
445	4	14	1	3	f	f
446	4	14	1	4	f	f
447	4	14	2	3	f	f
448	4	14	2	4	f	f
449	4	14	3	3	f	f
450	4	14	3	4	f	f
451	4	14	7	3	f	f
452	4	14	7	4	f	f
453	4	14	8	3	f	f
454	4	14	8	4	f	f
455	4	14	9	3	f	f
456	4	14	9	4	f	f
457	4	14	10	3	f	f
458	4	14	10	4	f	f
459	4	14	11	3	f	f
460	4	14	11	4	f	f
461	4	14	13	3	f	f
462	4	14	13	4	f	f
463	4	14	14	3	f	f
464	4	14	14	4	f	f
465	4	14	12	3	f	f
466	4	14	12	4	f	f
467	4	12	1	3	f	f
468	4	12	1	4	f	f
469	4	12	2	3	f	f
470	4	12	2	4	f	f
471	4	12	3	3	f	f
472	4	12	3	4	f	f
473	4	12	7	3	f	f
474	4	12	7	4	f	f
475	4	12	8	3	f	f
476	4	12	8	4	f	f
477	4	12	9	3	f	f
478	4	12	9	4	f	f
479	4	12	10	3	f	f
480	4	12	10	4	f	f
481	4	12	11	3	f	f
482	4	12	11	4	f	f
483	4	12	13	3	f	f
484	4	12	13	4	f	f
485	4	12	14	3	f	f
486	4	12	14	4	f	f
487	4	12	12	3	f	f
488	4	12	12	4	f	f
489	5	1	1	3	f	f
490	5	1	1	4	f	f
491	5	1	2	3	f	f
492	5	1	2	4	f	f
493	5	1	3	3	f	f
494	5	1	3	4	f	f
495	5	1	7	3	f	f
496	5	1	7	4	f	f
497	5	1	8	3	f	f
498	5	1	8	4	f	f
499	5	1	9	3	f	f
500	5	1	9	4	f	f
501	5	1	10	3	f	f
502	5	1	10	4	f	f
503	5	1	11	3	f	f
504	5	1	11	4	f	f
505	5	1	13	3	f	f
506	5	1	13	4	f	f
507	5	1	14	3	f	f
508	5	1	14	4	f	f
509	5	1	12	3	f	f
510	5	1	12	4	f	f
511	5	2	1	3	f	f
512	5	2	1	4	f	f
513	5	2	2	3	f	f
514	5	2	2	4	f	f
515	5	2	3	3	f	f
516	5	2	3	4	f	f
517	5	2	7	3	f	f
518	5	2	7	4	f	f
519	5	2	8	3	f	f
520	5	2	8	4	f	f
521	5	2	9	3	f	f
522	5	2	9	4	f	f
523	5	2	10	3	f	f
524	5	2	10	4	f	f
525	5	2	11	3	f	f
526	5	2	11	4	f	f
527	5	2	13	3	f	f
528	5	2	13	4	f	f
529	5	2	14	3	f	f
530	5	2	14	4	f	f
531	5	2	12	3	f	f
532	5	2	12	4	f	f
533	5	3	1	3	f	f
534	5	3	1	4	f	f
535	5	3	2	3	f	f
536	5	3	2	4	f	f
537	5	3	3	3	f	f
538	5	3	3	4	f	f
539	5	3	7	3	f	f
540	5	3	7	4	f	f
541	5	3	8	3	f	f
542	5	3	8	4	f	f
543	5	3	9	3	f	f
544	5	3	9	4	f	f
545	5	3	10	3	f	f
546	5	3	10	4	f	f
547	5	3	11	3	f	f
548	5	3	11	4	f	f
549	5	3	13	3	f	f
550	5	3	13	4	f	f
551	5	3	14	3	f	f
552	5	3	14	4	f	f
553	5	3	12	3	f	f
554	5	3	12	4	f	f
555	5	7	1	3	f	f
556	5	7	1	4	f	f
557	5	7	2	3	f	f
558	5	7	2	4	f	f
559	5	7	3	3	f	f
560	5	7	3	4	f	f
561	5	7	7	3	f	f
562	5	7	7	4	f	f
563	5	7	8	3	f	f
564	5	7	8	4	f	f
565	5	7	9	3	f	f
566	5	7	9	4	f	f
567	5	7	10	3	f	f
568	5	7	10	4	f	f
569	5	7	11	3	f	f
570	5	7	11	4	f	f
571	5	7	13	3	f	f
572	5	7	13	4	f	f
573	5	7	14	3	f	f
574	5	7	14	4	f	f
575	5	7	12	3	f	f
576	5	7	12	4	f	f
577	5	8	1	3	f	f
578	5	8	1	4	f	f
579	5	8	2	3	f	f
580	5	8	2	4	f	f
581	5	8	3	3	f	f
582	5	8	3	4	f	f
583	5	8	7	3	f	f
584	5	8	7	4	f	f
585	5	8	8	3	f	f
586	5	8	8	4	f	f
587	5	8	9	3	f	f
588	5	8	9	4	f	f
589	5	8	10	3	f	f
590	5	8	10	4	f	f
591	5	8	11	3	f	f
592	5	8	11	4	f	f
593	5	8	13	3	f	f
594	5	8	13	4	f	f
595	5	8	14	3	f	f
596	5	8	14	4	f	f
597	5	8	12	3	f	f
598	5	8	12	4	f	f
599	5	9	1	3	f	f
600	5	9	1	4	f	f
601	5	9	2	3	f	f
602	5	9	2	4	f	f
603	5	9	3	3	f	f
604	5	9	3	4	f	f
605	5	9	7	3	f	f
606	5	9	7	4	f	f
607	5	9	8	3	f	f
608	5	9	8	4	f	f
609	5	9	9	3	f	f
610	5	9	9	4	f	f
611	5	9	10	3	f	f
612	5	9	10	4	f	f
613	5	9	11	3	f	f
614	5	9	11	4	f	f
615	5	9	13	3	f	f
616	5	9	13	4	f	f
617	5	9	14	3	f	f
618	5	9	14	4	f	f
619	5	9	12	3	f	f
620	5	9	12	4	f	f
621	5	10	1	3	f	f
622	5	10	1	4	f	f
623	5	10	2	3	f	f
624	5	10	2	4	f	f
625	5	10	3	3	f	f
626	5	10	3	4	f	f
627	5	10	7	3	f	f
628	5	10	7	4	f	f
629	5	10	8	3	f	f
630	5	10	8	4	f	f
631	5	10	9	3	f	f
632	5	10	9	4	f	f
633	5	10	10	3	f	f
634	5	10	10	4	f	f
635	5	10	11	3	f	f
636	5	10	11	4	f	f
637	5	10	13	3	f	f
638	5	10	13	4	f	f
639	5	10	14	3	f	f
640	5	10	14	4	f	f
641	5	10	12	3	f	f
642	5	10	12	4	f	f
643	5	11	1	3	f	f
644	5	11	1	4	f	f
645	5	11	2	3	f	f
646	5	11	2	4	f	f
647	5	11	3	3	f	f
648	5	11	3	4	f	f
649	5	11	7	3	f	f
650	5	11	7	4	f	f
651	5	11	8	3	f	f
652	5	11	8	4	f	f
653	5	11	9	3	f	f
654	5	11	9	4	f	f
655	5	11	10	3	f	f
656	5	11	10	4	f	f
657	5	11	11	3	f	f
658	5	11	11	4	f	f
659	5	11	13	3	f	f
660	5	11	13	4	f	f
661	5	11	14	3	f	f
662	5	11	14	4	f	f
663	5	11	12	3	f	f
664	5	11	12	4	f	f
665	5	13	1	3	f	f
666	5	13	1	4	f	f
667	5	13	2	3	f	f
668	5	13	2	4	f	f
669	5	13	3	3	f	f
670	5	13	3	4	f	f
671	5	13	7	3	f	f
672	5	13	7	4	f	f
673	5	13	8	3	f	f
674	5	13	8	4	f	f
675	5	13	9	3	f	f
676	5	13	9	4	f	f
677	5	13	10	3	f	f
678	5	13	10	4	f	f
679	5	13	11	3	f	f
680	5	13	11	4	f	f
681	5	13	13	3	f	f
682	5	13	13	4	f	f
683	5	13	14	3	f	f
684	5	13	14	4	f	f
685	5	13	12	3	f	f
686	5	13	12	4	f	f
687	5	14	1	3	f	f
688	5	14	1	4	f	f
689	5	14	2	3	f	f
690	5	14	2	4	f	f
691	5	14	3	3	f	f
692	5	14	3	4	f	f
693	5	14	7	3	f	f
694	5	14	7	4	f	f
695	5	14	8	3	f	f
696	5	14	8	4	f	f
697	5	14	9	3	f	f
698	5	14	9	4	f	f
699	5	14	10	3	f	f
700	5	14	10	4	f	f
701	5	14	11	3	f	f
702	5	14	11	4	f	f
703	5	14	13	3	f	f
704	5	14	13	4	f	f
705	5	14	14	3	f	f
706	5	14	14	4	f	f
707	5	14	12	3	f	f
708	5	14	12	4	f	f
709	5	12	1	3	f	f
710	5	12	1	4	f	f
711	5	12	2	3	f	f
712	5	12	2	4	f	f
713	5	12	3	3	f	f
714	5	12	3	4	f	f
715	5	12	7	3	f	f
716	5	12	7	4	f	f
717	5	12	8	3	f	f
718	5	12	8	4	f	f
719	5	12	9	3	f	f
720	5	12	9	4	f	f
721	5	12	10	3	f	f
722	5	12	10	4	f	f
723	5	12	11	3	f	f
724	5	12	11	4	f	f
725	5	12	13	3	f	f
726	5	12	13	4	f	f
727	5	12	14	3	f	f
728	5	12	14	4	f	f
729	5	12	12	3	f	f
730	5	12	12	4	f	f
731	6	1	1	3	f	f
732	6	1	1	4	f	f
733	6	1	2	3	f	f
734	6	1	2	4	f	f
735	6	1	3	3	f	f
736	6	1	3	4	f	f
737	6	1	7	3	f	f
738	6	1	7	4	f	f
739	6	1	8	3	f	f
740	6	1	8	4	f	f
741	6	1	9	3	f	f
742	6	1	9	4	f	f
743	6	1	10	3	f	f
744	6	1	10	4	f	f
745	6	1	11	3	f	f
746	6	1	11	4	f	f
747	6	1	13	3	f	f
748	6	1	13	4	f	f
749	6	1	14	3	f	f
750	6	1	14	4	f	f
751	6	1	12	3	f	f
752	6	1	12	4	f	f
753	6	2	1	3	f	f
754	6	2	1	4	f	f
755	6	2	2	3	f	f
756	6	2	2	4	f	f
757	6	2	3	3	f	f
758	6	2	3	4	f	f
759	6	2	7	3	f	f
760	6	2	7	4	f	f
761	6	2	8	3	f	f
762	6	2	8	4	f	f
763	6	2	9	3	f	f
764	6	2	9	4	f	f
765	6	2	10	3	f	f
766	6	2	10	4	f	f
767	6	2	11	3	f	f
768	6	2	11	4	f	f
769	6	2	13	3	f	f
770	6	2	13	4	f	f
771	6	2	14	3	f	f
772	6	2	14	4	f	f
773	6	2	12	3	f	f
774	6	2	12	4	f	f
775	6	3	1	3	f	f
776	6	3	1	4	f	f
777	6	3	2	3	f	f
778	6	3	2	4	f	f
779	6	3	3	3	f	f
780	6	3	3	4	f	f
781	6	3	7	3	f	f
782	6	3	7	4	f	f
783	6	3	8	3	f	f
784	6	3	8	4	f	f
785	6	3	9	3	f	f
786	6	3	9	4	f	f
787	6	3	10	3	f	f
788	6	3	10	4	f	f
789	6	3	11	3	f	f
790	6	3	11	4	f	f
791	6	3	13	3	f	f
792	6	3	13	4	f	f
793	6	3	14	3	f	f
794	6	3	14	4	f	f
795	6	3	12	3	f	f
796	6	3	12	4	f	f
797	6	7	1	3	f	f
798	6	7	1	4	f	f
799	6	7	2	3	f	f
800	6	7	2	4	f	f
801	6	7	3	3	f	f
802	6	7	3	4	f	f
803	6	7	7	3	f	f
804	6	7	7	4	f	f
805	6	7	8	3	f	f
806	6	7	8	4	f	f
807	6	7	9	3	f	f
808	6	7	9	4	f	f
809	6	7	10	3	f	f
810	6	7	10	4	f	f
811	6	7	11	3	f	f
812	6	7	11	4	f	f
813	6	7	13	3	f	f
814	6	7	13	4	f	f
815	6	7	14	3	f	f
816	6	7	14	4	f	f
817	6	7	12	3	f	f
818	6	7	12	4	f	f
819	6	8	1	3	f	f
820	6	8	1	4	f	f
821	6	8	2	3	f	f
822	6	8	2	4	f	f
823	6	8	3	3	f	f
824	6	8	3	4	f	f
825	6	8	7	3	f	f
826	6	8	7	4	f	f
827	6	8	8	3	f	f
828	6	8	8	4	f	f
829	6	8	9	3	f	f
830	6	8	9	4	f	f
831	6	8	10	3	f	f
832	6	8	10	4	f	f
833	6	8	11	3	f	f
834	6	8	11	4	f	f
835	6	8	13	3	f	f
836	6	8	13	4	f	f
837	6	8	14	3	f	f
838	6	8	14	4	f	f
839	6	8	12	3	f	f
840	6	8	12	4	f	f
841	6	9	1	3	f	f
842	6	9	1	4	f	f
843	6	9	2	3	f	f
844	6	9	2	4	f	f
845	6	9	3	3	f	f
846	6	9	3	4	f	f
847	6	9	7	3	f	f
848	6	9	7	4	f	f
849	6	9	8	3	f	f
850	6	9	8	4	f	f
851	6	9	9	3	f	f
852	6	9	9	4	f	f
853	6	9	10	3	f	f
854	6	9	10	4	f	f
855	6	9	11	3	f	f
856	6	9	11	4	f	f
857	6	9	13	3	f	f
858	6	9	13	4	f	f
859	6	9	14	3	f	f
860	6	9	14	4	f	f
861	6	9	12	3	f	f
862	6	9	12	4	f	f
863	6	10	1	3	f	f
864	6	10	1	4	f	f
865	6	10	2	3	f	f
866	6	10	2	4	f	f
867	6	10	3	3	f	f
868	6	10	3	4	f	f
869	6	10	7	3	f	f
870	6	10	7	4	f	f
871	6	10	8	3	f	f
872	6	10	8	4	f	f
873	6	10	9	3	f	f
874	6	10	9	4	f	f
875	6	10	10	3	f	f
876	6	10	10	4	f	f
877	6	10	11	3	f	f
878	6	10	11	4	f	f
879	6	10	13	3	f	f
880	6	10	13	4	f	f
881	6	10	14	3	f	f
882	6	10	14	4	f	f
883	6	10	12	3	f	f
884	6	10	12	4	f	f
885	6	11	1	3	f	f
886	6	11	1	4	f	f
887	6	11	2	3	f	f
888	6	11	2	4	f	f
889	6	11	3	3	f	f
890	6	11	3	4	f	f
891	6	11	7	3	f	f
892	6	11	7	4	f	f
893	6	11	8	3	f	f
894	6	11	8	4	f	f
895	6	11	9	3	f	f
896	6	11	9	4	f	f
897	6	11	10	3	f	f
898	6	11	10	4	f	f
899	6	11	11	3	f	f
900	6	11	11	4	f	f
901	6	11	13	3	f	f
902	6	11	13	4	f	f
903	6	11	14	3	f	f
904	6	11	14	4	f	f
905	6	11	12	3	f	f
906	6	11	12	4	f	f
907	6	13	1	3	f	f
908	6	13	1	4	f	f
909	6	13	2	3	f	f
910	6	13	2	4	f	f
911	6	13	3	3	f	f
912	6	13	3	4	f	f
913	6	13	7	3	f	f
914	6	13	7	4	f	f
915	6	13	8	3	f	f
916	6	13	8	4	f	f
917	6	13	9	3	f	f
918	6	13	9	4	f	f
919	6	13	10	3	f	f
920	6	13	10	4	f	f
921	6	13	11	3	f	f
922	6	13	11	4	f	f
923	6	13	13	3	f	f
924	6	13	13	4	f	f
925	6	13	14	3	f	f
926	6	13	14	4	f	f
927	6	13	12	3	f	f
928	6	13	12	4	f	f
929	6	14	1	3	f	f
930	6	14	1	4	f	f
931	6	14	2	3	f	f
932	6	14	2	4	f	f
933	6	14	3	3	f	f
934	6	14	3	4	f	f
935	6	14	7	3	f	f
936	6	14	7	4	f	f
937	6	14	8	3	f	f
938	6	14	8	4	f	f
939	6	14	9	3	f	f
940	6	14	9	4	f	f
941	6	14	10	3	f	f
942	6	14	10	4	f	f
943	6	14	11	3	f	f
944	6	14	11	4	f	f
945	6	14	13	3	f	f
946	6	14	13	4	f	f
947	6	14	14	3	f	f
948	6	14	14	4	f	f
949	6	14	12	3	f	f
950	6	14	12	4	f	f
951	6	12	1	3	f	f
952	6	12	1	4	f	f
953	6	12	2	3	f	f
954	6	12	2	4	f	f
955	6	12	3	3	f	f
956	6	12	3	4	f	f
957	6	12	7	3	f	f
958	6	12	7	4	f	f
959	6	12	8	3	f	f
960	6	12	8	4	f	f
961	6	12	9	3	f	f
962	6	12	9	4	f	f
963	6	12	10	3	f	f
964	6	12	10	4	f	f
965	6	12	11	3	f	f
966	6	12	11	4	f	f
967	6	12	13	3	f	f
968	6	12	13	4	f	f
969	6	12	14	3	f	f
970	6	12	14	4	f	f
971	6	12	12	3	f	f
972	6	12	12	4	f	f
973	7	1	1	3	f	f
974	7	1	1	4	f	f
975	7	1	4	3	f	f
976	7	1	4	4	f	f
977	7	1	7	3	f	f
978	7	1	7	4	f	f
979	7	1	8	3	f	f
980	7	1	8	4	f	f
981	7	1	9	3	f	f
982	7	1	9	4	f	f
983	7	1	10	3	f	f
984	7	1	10	4	f	f
985	7	1	11	3	f	f
986	7	1	11	4	f	f
987	7	1	13	3	f	f
988	7	1	13	4	f	f
989	7	1	14	3	f	f
990	7	1	14	4	f	f
991	7	1	12	3	f	f
992	7	1	12	4	f	f
993	7	4	1	3	f	f
994	7	4	1	4	f	f
995	7	4	4	3	f	f
996	7	4	4	4	f	f
997	7	4	7	3	f	f
998	7	4	7	4	f	f
999	7	4	8	3	f	f
1000	7	4	8	4	f	f
1001	7	4	9	3	f	f
1002	7	4	9	4	f	f
1003	7	4	10	3	f	f
1004	7	4	10	4	f	f
1005	7	4	11	3	f	f
1006	7	4	11	4	f	f
1007	7	4	13	3	f	f
1008	7	4	13	4	f	f
1009	7	4	14	3	f	f
1010	7	4	14	4	f	f
1011	7	4	12	3	f	f
1012	7	4	12	4	f	f
1013	7	7	1	3	f	f
1014	7	7	1	4	f	f
1015	7	7	4	3	f	f
1016	7	7	4	4	f	f
1017	7	7	7	3	f	f
1018	7	7	7	4	f	f
1019	7	7	8	3	f	f
1020	7	7	8	4	f	f
1021	7	7	9	3	f	f
1022	7	7	9	4	f	f
1023	7	7	10	3	f	f
1024	7	7	10	4	f	f
1025	7	7	11	3	f	f
1026	7	7	11	4	f	f
1027	7	7	13	3	f	f
1028	7	7	13	4	f	f
1029	7	7	14	3	f	f
1030	7	7	14	4	f	f
1031	7	7	12	3	f	f
1032	7	7	12	4	f	f
1033	7	8	1	3	f	f
1034	7	8	1	4	f	f
1035	7	8	4	3	f	f
1036	7	8	4	4	f	f
1037	7	8	7	3	f	f
1038	7	8	7	4	f	f
1039	7	8	8	3	f	f
1040	7	8	8	4	f	f
1041	7	8	9	3	f	f
1042	7	8	9	4	f	f
1043	7	8	10	3	f	f
1044	7	8	10	4	f	f
1045	7	8	11	3	f	f
1046	7	8	11	4	f	f
1047	7	8	13	3	f	f
1048	7	8	13	4	f	f
1049	7	8	14	3	f	f
1050	7	8	14	4	f	f
1051	7	8	12	3	f	f
1052	7	8	12	4	f	f
1053	7	9	1	3	f	f
1054	7	9	1	4	f	f
1055	7	9	4	3	f	f
1056	7	9	4	4	f	f
1057	7	9	7	3	f	f
1058	7	9	7	4	f	f
1059	7	9	8	3	f	f
1060	7	9	8	4	f	f
1061	7	9	9	3	f	f
1062	7	9	9	4	f	f
1063	7	9	10	3	f	f
1064	7	9	10	4	f	f
1065	7	9	11	3	f	f
1066	7	9	11	4	f	f
1067	7	9	13	3	f	f
1068	7	9	13	4	f	f
1069	7	9	14	3	f	f
1070	7	9	14	4	f	f
1071	7	9	12	3	f	f
1072	7	9	12	4	f	f
1073	7	10	1	3	f	f
1074	7	10	1	4	f	f
1075	7	10	4	3	f	f
1076	7	10	4	4	f	f
1077	7	10	7	3	f	f
1078	7	10	7	4	f	f
1079	7	10	8	3	f	f
1080	7	10	8	4	f	f
1081	7	10	9	3	f	f
1082	7	10	9	4	f	f
1083	7	10	10	3	f	f
1084	7	10	10	4	f	f
1085	7	10	11	3	f	f
1086	7	10	11	4	f	f
1087	7	10	13	3	f	f
1088	7	10	13	4	f	f
1089	7	10	14	3	f	f
1090	7	10	14	4	f	f
1091	7	10	12	3	f	f
1092	7	10	12	4	f	f
1093	7	11	1	3	f	f
1094	7	11	1	4	f	f
1095	7	11	4	3	f	f
1096	7	11	4	4	f	f
1097	7	11	7	3	f	f
1098	7	11	7	4	f	f
1099	7	11	8	3	f	f
1100	7	11	8	4	f	f
1101	7	11	9	3	f	f
1102	7	11	9	4	f	f
1103	7	11	10	3	f	f
1104	7	11	10	4	f	f
1105	7	11	11	3	f	f
1106	7	11	11	4	f	f
1107	7	11	13	3	f	f
1108	7	11	13	4	f	f
1109	7	11	14	3	f	f
1110	7	11	14	4	f	f
1111	7	11	12	3	f	f
1112	7	11	12	4	f	f
1113	7	13	1	3	f	f
1114	7	13	1	4	f	f
1115	7	13	4	3	f	f
1116	7	13	4	4	f	f
1117	7	13	7	3	f	f
1118	7	13	7	4	f	f
1119	7	13	8	3	f	f
1120	7	13	8	4	f	f
1121	7	13	9	3	f	f
1122	7	13	9	4	f	f
1123	7	13	10	3	f	f
1124	7	13	10	4	f	f
1125	7	13	11	3	f	f
1126	7	13	11	4	f	f
1127	7	13	13	3	f	f
1128	7	13	13	4	f	f
1129	7	13	14	3	f	f
1130	7	13	14	4	f	f
1131	7	13	12	3	f	f
1132	7	13	12	4	f	f
1133	7	14	1	3	f	f
1134	7	14	1	4	f	f
1135	7	14	4	3	f	f
1136	7	14	4	4	f	f
1137	7	14	7	3	f	f
1138	7	14	7	4	f	f
1139	7	14	8	3	f	f
1140	7	14	8	4	f	f
1141	7	14	9	3	f	f
1142	7	14	9	4	f	f
1143	7	14	10	3	f	f
1144	7	14	10	4	f	f
1145	7	14	11	3	f	f
1146	7	14	11	4	f	f
1147	7	14	13	3	f	f
1148	7	14	13	4	f	f
1149	7	14	14	3	f	f
1150	7	14	14	4	f	f
1151	7	14	12	3	f	f
1152	7	14	12	4	f	f
1153	7	12	1	3	f	f
1154	7	12	1	4	f	f
1155	7	12	4	3	f	f
1156	7	12	4	4	f	f
1157	7	12	7	3	f	f
1158	7	12	7	4	f	f
1159	7	12	8	3	f	f
1160	7	12	8	4	f	f
1161	7	12	9	3	f	f
1162	7	12	9	4	f	f
1163	7	12	10	3	f	f
1164	7	12	10	4	f	f
1165	7	12	11	3	f	f
1166	7	12	11	4	f	f
1167	7	12	13	3	f	f
1168	7	12	13	4	f	f
1169	7	12	14	3	f	f
1170	7	12	14	4	f	f
1171	7	12	12	3	f	f
1172	7	12	12	4	f	f
\.


--
-- Name: announcements_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.announcements_id_seq', 1, false);


--
-- Name: attachable_journals_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.attachable_journals_id_seq', 1, false);


--
-- Name: attachment_journals_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.attachment_journals_id_seq', 2, true);


--
-- Name: attachments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.attachments_id_seq', 2, true);


--
-- Name: attribute_help_texts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.attribute_help_texts_id_seq', 1, false);


--
-- Name: auth_sources_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.auth_sources_id_seq', 1, false);


--
-- Name: bcf_comments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.bcf_comments_id_seq', 1, false);


--
-- Name: bcf_issues_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.bcf_issues_id_seq', 1, false);


--
-- Name: bcf_viewpoints_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.bcf_viewpoints_id_seq', 1, false);


--
-- Name: budget_journals_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.budget_journals_id_seq', 1, false);


--
-- Name: budgets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.budgets_id_seq', 1, false);


--
-- Name: categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.categories_id_seq', 2, true);


--
-- Name: changes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.changes_id_seq', 1, false);


--
-- Name: changeset_journals_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.changeset_journals_id_seq', 1, false);


--
-- Name: changesets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.changesets_id_seq', 1, false);


--
-- Name: colors_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.colors_id_seq', 144, true);


--
-- Name: comments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.comments_id_seq', 1, false);


--
-- Name: cost_entries_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.cost_entries_id_seq', 1, false);


--
-- Name: cost_queries_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.cost_queries_id_seq', 1, false);


--
-- Name: cost_types_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.cost_types_id_seq', 1, false);


--
-- Name: custom_actions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.custom_actions_id_seq', 1, false);


--
-- Name: custom_actions_projects_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.custom_actions_projects_id_seq', 1, false);


--
-- Name: custom_actions_roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.custom_actions_roles_id_seq', 1, false);


--
-- Name: custom_actions_statuses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.custom_actions_statuses_id_seq', 1, false);


--
-- Name: custom_actions_types_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.custom_actions_types_id_seq', 1, false);


--
-- Name: custom_fields_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.custom_fields_id_seq', 1, false);


--
-- Name: custom_options_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.custom_options_id_seq', 1, false);


--
-- Name: custom_styles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.custom_styles_id_seq', 1, false);


--
-- Name: custom_values_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.custom_values_id_seq', 1, false);


--
-- Name: customizable_journals_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.customizable_journals_id_seq', 1, false);


--
-- Name: delayed_job_statuses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.delayed_job_statuses_id_seq', 1, true);


--
-- Name: delayed_jobs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.delayed_jobs_id_seq', 31, true);


--
-- Name: design_colors_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.design_colors_id_seq', 1, false);


--
-- Name: document_journals_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.document_journals_id_seq', 1, false);


--
-- Name: documents_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.documents_id_seq', 1, false);


--
-- Name: enabled_modules_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.enabled_modules_id_seq', 10, true);


--
-- Name: enterprise_tokens_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.enterprise_tokens_id_seq', 1, false);


--
-- Name: enumerations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.enumerations_id_seq', 13, true);


--
-- Name: export_card_configurations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.export_card_configurations_id_seq', 1, false);


--
-- Name: exports_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.exports_id_seq', 1, true);


--
-- Name: file_links_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.file_links_id_seq', 1, false);


--
-- Name: forums_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.forums_id_seq', 1, false);


--
-- Name: github_check_runs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.github_check_runs_id_seq', 1, false);


--
-- Name: github_pull_requests_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.github_pull_requests_id_seq', 1, false);


--
-- Name: github_users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.github_users_id_seq', 1, false);


--
-- Name: grid_widgets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.grid_widgets_id_seq', 32, true);


--
-- Name: grids_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.grids_id_seq', 7, true);


--
-- Name: group_users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.group_users_id_seq', 1, false);


--
-- Name: ifc_models_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ifc_models_id_seq', 1, false);


--
-- Name: journals_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.journals_id_seq', 46, true);


--
-- Name: labor_budget_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.labor_budget_items_id_seq', 1, false);


--
-- Name: ldap_groups_memberships_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ldap_groups_memberships_id_seq', 1, false);


--
-- Name: ldap_groups_synchronized_filters_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ldap_groups_synchronized_filters_id_seq', 1, false);


--
-- Name: ldap_groups_synchronized_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ldap_groups_synchronized_groups_id_seq', 1, false);


--
-- Name: material_budget_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.material_budget_items_id_seq', 1, false);


--
-- Name: meeting_content_journals_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.meeting_content_journals_id_seq', 1, false);


--
-- Name: meeting_contents_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.meeting_contents_id_seq', 1, false);


--
-- Name: meeting_journals_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.meeting_journals_id_seq', 1, false);


--
-- Name: meeting_participants_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.meeting_participants_id_seq', 1, false);


--
-- Name: meetings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.meetings_id_seq', 1, false);


--
-- Name: member_roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.member_roles_id_seq', 2, true);


--
-- Name: members_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.members_id_seq', 2, true);


--
-- Name: menu_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.menu_items_id_seq', 2, true);


--
-- Name: message_journals_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.message_journals_id_seq', 1, false);


--
-- Name: messages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.messages_id_seq', 1, false);


--
-- Name: news_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.news_id_seq', 2, true);


--
-- Name: news_journals_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.news_journals_id_seq', 2, true);


--
-- Name: non_working_days_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.non_working_days_id_seq', 1, false);


--
-- Name: notification_settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.notification_settings_id_seq', 1, true);


--
-- Name: notifications_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.notifications_id_seq', 1, false);


--
-- Name: oauth_access_grants_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.oauth_access_grants_id_seq', 1, false);


--
-- Name: oauth_access_tokens_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.oauth_access_tokens_id_seq', 1, false);


--
-- Name: oauth_applications_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.oauth_applications_id_seq', 1, false);


--
-- Name: oauth_client_tokens_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.oauth_client_tokens_id_seq', 1, false);


--
-- Name: oauth_clients_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.oauth_clients_id_seq', 1, false);


--
-- Name: oidc_user_session_links_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.oidc_user_session_links_id_seq', 1, false);


--
-- Name: ordered_work_packages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ordered_work_packages_id_seq', 10, true);


--
-- Name: paper_trail_audits_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.paper_trail_audits_id_seq', 1, false);


--
-- Name: project_journals_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.project_journals_id_seq', 3, true);


--
-- Name: project_statuses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.project_statuses_id_seq', 2, true);


--
-- Name: projects_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.projects_id_seq', 2, true);


--
-- Name: projects_storages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.projects_storages_id_seq', 1, false);


--
-- Name: queries_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.queries_id_seq', 26, true);


--
-- Name: rates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.rates_id_seq', 1, false);


--
-- Name: recaptcha_entries_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.recaptcha_entries_id_seq', 1, false);


--
-- Name: relations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.relations_id_seq', 7, true);


--
-- Name: repositories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.repositories_id_seq', 1, false);


--
-- Name: role_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.role_permissions_id_seq', 228, true);


--
-- Name: roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.roles_id_seq', 6, true);


--
-- Name: sessions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.sessions_id_seq', 2, true);


--
-- Name: settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.settings_id_seq', 114, true);


--
-- Name: statuses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.statuses_id_seq', 14, true);


--
-- Name: storages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.storages_id_seq', 1, false);


--
-- Name: time_entries_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.time_entries_id_seq', 1, false);


--
-- Name: time_entry_activities_projects_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.time_entry_activities_projects_id_seq', 1, false);


--
-- Name: time_entry_journals_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.time_entry_journals_id_seq', 1, false);


--
-- Name: tokens_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.tokens_id_seq', 3, true);


--
-- Name: two_factor_authentication_devices_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.two_factor_authentication_devices_id_seq', 1, false);


--
-- Name: types_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.types_id_seq', 7, true);


--
-- Name: user_passwords_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.user_passwords_id_seq', 2, true);


--
-- Name: user_preferences_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.user_preferences_id_seq', 1, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.users_id_seq', 4, true);


--
-- Name: version_settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.version_settings_id_seq', 4, true);


--
-- Name: versions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.versions_id_seq', 4, true);


--
-- Name: views_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.views_id_seq', 8, true);


--
-- Name: watchers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.watchers_id_seq', 3, true);


--
-- Name: webhooks_events_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.webhooks_events_id_seq', 1, false);


--
-- Name: webhooks_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.webhooks_logs_id_seq', 1, false);


--
-- Name: webhooks_projects_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.webhooks_projects_id_seq', 1, false);


--
-- Name: webhooks_webhooks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.webhooks_webhooks_id_seq', 1, false);


--
-- Name: wiki_content_journals_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.wiki_content_journals_id_seq', 2, true);


--
-- Name: wiki_contents_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.wiki_contents_id_seq', 2, true);


--
-- Name: wiki_pages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.wiki_pages_id_seq', 2, true);


--
-- Name: wiki_redirects_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.wiki_redirects_id_seq', 1, false);


--
-- Name: wikis_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.wikis_id_seq', 2, true);


--
-- Name: work_package_journals_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.work_package_journals_id_seq', 61, true);


--
-- Name: work_packages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.work_packages_id_seq', 37, true);


--
-- Name: workflows_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.workflows_id_seq', 1172, true);


--
-- Name: announcements announcements_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.announcements
    ADD CONSTRAINT announcements_pkey PRIMARY KEY (id);


--
-- Name: ar_internal_metadata ar_internal_metadata_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ar_internal_metadata
    ADD CONSTRAINT ar_internal_metadata_pkey PRIMARY KEY (key);


--
-- Name: attachable_journals attachable_journals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attachable_journals
    ADD CONSTRAINT attachable_journals_pkey PRIMARY KEY (id);


--
-- Name: attachment_journals attachment_journals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attachment_journals
    ADD CONSTRAINT attachment_journals_pkey PRIMARY KEY (id);


--
-- Name: attachments attachments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attachments
    ADD CONSTRAINT attachments_pkey PRIMARY KEY (id);


--
-- Name: attribute_help_texts attribute_help_texts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attribute_help_texts
    ADD CONSTRAINT attribute_help_texts_pkey PRIMARY KEY (id);


--
-- Name: auth_sources auth_sources_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_sources
    ADD CONSTRAINT auth_sources_pkey PRIMARY KEY (id);


--
-- Name: bcf_comments bcf_comments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bcf_comments
    ADD CONSTRAINT bcf_comments_pkey PRIMARY KEY (id);


--
-- Name: bcf_issues bcf_issues_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bcf_issues
    ADD CONSTRAINT bcf_issues_pkey PRIMARY KEY (id);


--
-- Name: bcf_viewpoints bcf_viewpoints_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bcf_viewpoints
    ADD CONSTRAINT bcf_viewpoints_pkey PRIMARY KEY (id);


--
-- Name: budget_journals budget_journals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.budget_journals
    ADD CONSTRAINT budget_journals_pkey PRIMARY KEY (id);


--
-- Name: budgets budgets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.budgets
    ADD CONSTRAINT budgets_pkey PRIMARY KEY (id);


--
-- Name: categories categories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_pkey PRIMARY KEY (id);


--
-- Name: changes changes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.changes
    ADD CONSTRAINT changes_pkey PRIMARY KEY (id);


--
-- Name: changeset_journals changeset_journals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.changeset_journals
    ADD CONSTRAINT changeset_journals_pkey PRIMARY KEY (id);


--
-- Name: changesets changesets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.changesets
    ADD CONSTRAINT changesets_pkey PRIMARY KEY (id);


--
-- Name: colors colors_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.colors
    ADD CONSTRAINT colors_pkey PRIMARY KEY (id);


--
-- Name: comments comments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.comments
    ADD CONSTRAINT comments_pkey PRIMARY KEY (id);


--
-- Name: cost_entries cost_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cost_entries
    ADD CONSTRAINT cost_entries_pkey PRIMARY KEY (id);


--
-- Name: cost_queries cost_queries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cost_queries
    ADD CONSTRAINT cost_queries_pkey PRIMARY KEY (id);


--
-- Name: cost_types cost_types_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cost_types
    ADD CONSTRAINT cost_types_pkey PRIMARY KEY (id);


--
-- Name: custom_actions custom_actions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.custom_actions
    ADD CONSTRAINT custom_actions_pkey PRIMARY KEY (id);


--
-- Name: custom_actions_projects custom_actions_projects_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.custom_actions_projects
    ADD CONSTRAINT custom_actions_projects_pkey PRIMARY KEY (id);


--
-- Name: custom_actions_roles custom_actions_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.custom_actions_roles
    ADD CONSTRAINT custom_actions_roles_pkey PRIMARY KEY (id);


--
-- Name: custom_actions_statuses custom_actions_statuses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.custom_actions_statuses
    ADD CONSTRAINT custom_actions_statuses_pkey PRIMARY KEY (id);


--
-- Name: custom_actions_types custom_actions_types_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.custom_actions_types
    ADD CONSTRAINT custom_actions_types_pkey PRIMARY KEY (id);


--
-- Name: custom_fields custom_fields_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.custom_fields
    ADD CONSTRAINT custom_fields_pkey PRIMARY KEY (id);


--
-- Name: custom_options custom_options_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.custom_options
    ADD CONSTRAINT custom_options_pkey PRIMARY KEY (id);


--
-- Name: custom_styles custom_styles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.custom_styles
    ADD CONSTRAINT custom_styles_pkey PRIMARY KEY (id);


--
-- Name: custom_values custom_values_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.custom_values
    ADD CONSTRAINT custom_values_pkey PRIMARY KEY (id);


--
-- Name: customizable_journals customizable_journals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customizable_journals
    ADD CONSTRAINT customizable_journals_pkey PRIMARY KEY (id);


--
-- Name: delayed_job_statuses delayed_job_statuses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.delayed_job_statuses
    ADD CONSTRAINT delayed_job_statuses_pkey PRIMARY KEY (id);


--
-- Name: delayed_jobs delayed_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.delayed_jobs
    ADD CONSTRAINT delayed_jobs_pkey PRIMARY KEY (id);


--
-- Name: design_colors design_colors_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.design_colors
    ADD CONSTRAINT design_colors_pkey PRIMARY KEY (id);


--
-- Name: document_journals document_journals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_journals
    ADD CONSTRAINT document_journals_pkey PRIMARY KEY (id);


--
-- Name: documents documents_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_pkey PRIMARY KEY (id);


--
-- Name: enabled_modules enabled_modules_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.enabled_modules
    ADD CONSTRAINT enabled_modules_pkey PRIMARY KEY (id);


--
-- Name: enterprise_tokens enterprise_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.enterprise_tokens
    ADD CONSTRAINT enterprise_tokens_pkey PRIMARY KEY (id);


--
-- Name: enumerations enumerations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.enumerations
    ADD CONSTRAINT enumerations_pkey PRIMARY KEY (id);


--
-- Name: export_card_configurations export_card_configurations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.export_card_configurations
    ADD CONSTRAINT export_card_configurations_pkey PRIMARY KEY (id);


--
-- Name: exports exports_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.exports
    ADD CONSTRAINT exports_pkey PRIMARY KEY (id);


--
-- Name: file_links file_links_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.file_links
    ADD CONSTRAINT file_links_pkey PRIMARY KEY (id);


--
-- Name: forums forums_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.forums
    ADD CONSTRAINT forums_pkey PRIMARY KEY (id);


--
-- Name: github_check_runs github_check_runs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.github_check_runs
    ADD CONSTRAINT github_check_runs_pkey PRIMARY KEY (id);


--
-- Name: github_pull_requests github_pull_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.github_pull_requests
    ADD CONSTRAINT github_pull_requests_pkey PRIMARY KEY (id);


--
-- Name: github_users github_users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.github_users
    ADD CONSTRAINT github_users_pkey PRIMARY KEY (id);


--
-- Name: grid_widgets grid_widgets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.grid_widgets
    ADD CONSTRAINT grid_widgets_pkey PRIMARY KEY (id);


--
-- Name: grids grids_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.grids
    ADD CONSTRAINT grids_pkey PRIMARY KEY (id);


--
-- Name: group_users group_users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.group_users
    ADD CONSTRAINT group_users_pkey PRIMARY KEY (id);


--
-- Name: ifc_models ifc_models_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ifc_models
    ADD CONSTRAINT ifc_models_pkey PRIMARY KEY (id);


--
-- Name: journals journals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.journals
    ADD CONSTRAINT journals_pkey PRIMARY KEY (id);


--
-- Name: labor_budget_items labor_budget_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.labor_budget_items
    ADD CONSTRAINT labor_budget_items_pkey PRIMARY KEY (id);


--
-- Name: ldap_groups_memberships ldap_groups_memberships_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ldap_groups_memberships
    ADD CONSTRAINT ldap_groups_memberships_pkey PRIMARY KEY (id);


--
-- Name: ldap_groups_synchronized_filters ldap_groups_synchronized_filters_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ldap_groups_synchronized_filters
    ADD CONSTRAINT ldap_groups_synchronized_filters_pkey PRIMARY KEY (id);


--
-- Name: ldap_groups_synchronized_groups ldap_groups_synchronized_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ldap_groups_synchronized_groups
    ADD CONSTRAINT ldap_groups_synchronized_groups_pkey PRIMARY KEY (id);


--
-- Name: material_budget_items material_budget_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.material_budget_items
    ADD CONSTRAINT material_budget_items_pkey PRIMARY KEY (id);


--
-- Name: meeting_content_journals meeting_content_journals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.meeting_content_journals
    ADD CONSTRAINT meeting_content_journals_pkey PRIMARY KEY (id);


--
-- Name: meeting_contents meeting_contents_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.meeting_contents
    ADD CONSTRAINT meeting_contents_pkey PRIMARY KEY (id);


--
-- Name: meeting_journals meeting_journals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.meeting_journals
    ADD CONSTRAINT meeting_journals_pkey PRIMARY KEY (id);


--
-- Name: meeting_participants meeting_participants_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.meeting_participants
    ADD CONSTRAINT meeting_participants_pkey PRIMARY KEY (id);


--
-- Name: meetings meetings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.meetings
    ADD CONSTRAINT meetings_pkey PRIMARY KEY (id);


--
-- Name: member_roles member_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_roles
    ADD CONSTRAINT member_roles_pkey PRIMARY KEY (id);


--
-- Name: members members_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.members
    ADD CONSTRAINT members_pkey PRIMARY KEY (id);


--
-- Name: menu_items menu_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.menu_items
    ADD CONSTRAINT menu_items_pkey PRIMARY KEY (id);


--
-- Name: message_journals message_journals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.message_journals
    ADD CONSTRAINT message_journals_pkey PRIMARY KEY (id);


--
-- Name: messages messages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_pkey PRIMARY KEY (id);


--
-- Name: news_journals news_journals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.news_journals
    ADD CONSTRAINT news_journals_pkey PRIMARY KEY (id);


--
-- Name: news news_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.news
    ADD CONSTRAINT news_pkey PRIMARY KEY (id);


--
-- Name: non_working_days non_working_days_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.non_working_days
    ADD CONSTRAINT non_working_days_pkey PRIMARY KEY (id);


--
-- Name: notification_settings notification_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_settings
    ADD CONSTRAINT notification_settings_pkey PRIMARY KEY (id);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: oauth_access_grants oauth_access_grants_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth_access_grants
    ADD CONSTRAINT oauth_access_grants_pkey PRIMARY KEY (id);


--
-- Name: oauth_access_tokens oauth_access_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth_access_tokens
    ADD CONSTRAINT oauth_access_tokens_pkey PRIMARY KEY (id);


--
-- Name: oauth_applications oauth_applications_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth_applications
    ADD CONSTRAINT oauth_applications_pkey PRIMARY KEY (id);


--
-- Name: oauth_client_tokens oauth_client_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth_client_tokens
    ADD CONSTRAINT oauth_client_tokens_pkey PRIMARY KEY (id);


--
-- Name: oauth_clients oauth_clients_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth_clients
    ADD CONSTRAINT oauth_clients_pkey PRIMARY KEY (id);


--
-- Name: oidc_user_session_links oidc_user_session_links_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oidc_user_session_links
    ADD CONSTRAINT oidc_user_session_links_pkey PRIMARY KEY (id);


--
-- Name: ordered_work_packages ordered_work_packages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ordered_work_packages
    ADD CONSTRAINT ordered_work_packages_pkey PRIMARY KEY (id);


--
-- Name: paper_trail_audits paper_trail_audits_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.paper_trail_audits
    ADD CONSTRAINT paper_trail_audits_pkey PRIMARY KEY (id);


--
-- Name: project_journals project_journals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_journals
    ADD CONSTRAINT project_journals_pkey PRIMARY KEY (id);


--
-- Name: project_statuses project_statuses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_statuses
    ADD CONSTRAINT project_statuses_pkey PRIMARY KEY (id);


--
-- Name: projects projects_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_pkey PRIMARY KEY (id);


--
-- Name: projects_storages projects_storages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.projects_storages
    ADD CONSTRAINT projects_storages_pkey PRIMARY KEY (id);


--
-- Name: queries queries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.queries
    ADD CONSTRAINT queries_pkey PRIMARY KEY (id);


--
-- Name: rates rates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rates
    ADD CONSTRAINT rates_pkey PRIMARY KEY (id);


--
-- Name: recaptcha_entries recaptcha_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recaptcha_entries
    ADD CONSTRAINT recaptcha_entries_pkey PRIMARY KEY (id);


--
-- Name: relations relations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.relations
    ADD CONSTRAINT relations_pkey PRIMARY KEY (id);


--
-- Name: repositories repositories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.repositories
    ADD CONSTRAINT repositories_pkey PRIMARY KEY (id);


--
-- Name: role_permissions role_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT role_permissions_pkey PRIMARY KEY (id);


--
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (version);


--
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (id);


--
-- Name: settings settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.settings
    ADD CONSTRAINT settings_pkey PRIMARY KEY (id);


--
-- Name: statuses statuses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.statuses
    ADD CONSTRAINT statuses_pkey PRIMARY KEY (id);


--
-- Name: storages storages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.storages
    ADD CONSTRAINT storages_pkey PRIMARY KEY (id);


--
-- Name: time_entries time_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.time_entries
    ADD CONSTRAINT time_entries_pkey PRIMARY KEY (id);


--
-- Name: time_entry_activities_projects time_entry_activities_projects_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.time_entry_activities_projects
    ADD CONSTRAINT time_entry_activities_projects_pkey PRIMARY KEY (id);


--
-- Name: time_entry_journals time_entry_journals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.time_entry_journals
    ADD CONSTRAINT time_entry_journals_pkey PRIMARY KEY (id);


--
-- Name: tokens tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tokens
    ADD CONSTRAINT tokens_pkey PRIMARY KEY (id);


--
-- Name: two_factor_authentication_devices two_factor_authentication_devices_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.two_factor_authentication_devices
    ADD CONSTRAINT two_factor_authentication_devices_pkey PRIMARY KEY (id);


--
-- Name: types types_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.types
    ADD CONSTRAINT types_pkey PRIMARY KEY (id);


--
-- Name: user_passwords user_passwords_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_passwords
    ADD CONSTRAINT user_passwords_pkey PRIMARY KEY (id);


--
-- Name: user_preferences user_preferences_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_preferences
    ADD CONSTRAINT user_preferences_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: version_settings version_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.version_settings
    ADD CONSTRAINT version_settings_pkey PRIMARY KEY (id);


--
-- Name: versions versions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.versions
    ADD CONSTRAINT versions_pkey PRIMARY KEY (id);


--
-- Name: views views_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.views
    ADD CONSTRAINT views_pkey PRIMARY KEY (id);


--
-- Name: watchers watchers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.watchers
    ADD CONSTRAINT watchers_pkey PRIMARY KEY (id);


--
-- Name: webhooks_events webhooks_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.webhooks_events
    ADD CONSTRAINT webhooks_events_pkey PRIMARY KEY (id);


--
-- Name: webhooks_logs webhooks_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.webhooks_logs
    ADD CONSTRAINT webhooks_logs_pkey PRIMARY KEY (id);


--
-- Name: webhooks_projects webhooks_projects_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.webhooks_projects
    ADD CONSTRAINT webhooks_projects_pkey PRIMARY KEY (id);


--
-- Name: webhooks_webhooks webhooks_webhooks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.webhooks_webhooks
    ADD CONSTRAINT webhooks_webhooks_pkey PRIMARY KEY (id);


--
-- Name: wiki_content_journals wiki_content_journals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wiki_content_journals
    ADD CONSTRAINT wiki_content_journals_pkey PRIMARY KEY (id);


--
-- Name: wiki_contents wiki_contents_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wiki_contents
    ADD CONSTRAINT wiki_contents_pkey PRIMARY KEY (id);


--
-- Name: wiki_pages wiki_pages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wiki_pages
    ADD CONSTRAINT wiki_pages_pkey PRIMARY KEY (id);


--
-- Name: wiki_redirects wiki_redirects_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wiki_redirects
    ADD CONSTRAINT wiki_redirects_pkey PRIMARY KEY (id);


--
-- Name: wikis wikis_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wikis
    ADD CONSTRAINT wikis_pkey PRIMARY KEY (id);


--
-- Name: work_package_journals work_package_journals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_package_journals
    ADD CONSTRAINT work_package_journals_pkey PRIMARY KEY (id);


--
-- Name: work_packages work_packages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_packages
    ADD CONSTRAINT work_packages_pkey PRIMARY KEY (id);


--
-- Name: workflows workflows_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workflows
    ADD CONSTRAINT workflows_pkey PRIMARY KEY (id);


--
-- Name: changesets_changeset_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX changesets_changeset_id ON public.changes USING btree (changeset_id);


--
-- Name: changesets_repos_rev; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX changesets_repos_rev ON public.changesets USING btree (repository_id, revision);


--
-- Name: changesets_repos_scmid; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX changesets_repos_scmid ON public.changesets USING btree (repository_id, scmid);


--
-- Name: changesets_work_packages_ids; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX changesets_work_packages_ids ON public.changesets_work_packages USING btree (changeset_id, work_package_id);


--
-- Name: custom_fields_types_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX custom_fields_types_unique ON public.custom_fields_types USING btree (custom_field_id, type_id);


--
-- Name: custom_values_customized; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX custom_values_customized ON public.custom_values USING btree (customized_type, customized_id);


--
-- Name: delayed_jobs_priority; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX delayed_jobs_priority ON public.delayed_jobs USING btree (priority, run_at);


--
-- Name: documents_project_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX documents_project_id ON public.documents USING btree (project_id);


--
-- Name: enabled_modules_project_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX enabled_modules_project_id ON public.enabled_modules USING btree (project_id);


--
-- Name: forums_project_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX forums_project_id ON public.forums USING btree (project_id);


--
-- Name: github_pr_wp_pr_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX github_pr_wp_pr_id ON public.github_pull_requests_work_packages USING btree (github_pull_request_id);


--
-- Name: group_user_ids; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX group_user_ids ON public.group_users USING btree (group_id, user_id);


--
-- Name: index_announcements_on_show_until_and_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_announcements_on_show_until_and_active ON public.announcements USING btree (show_until, active);


--
-- Name: index_attachable_journals_on_attachment_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_attachable_journals_on_attachment_id ON public.attachable_journals USING btree (attachment_id);


--
-- Name: index_attachable_journals_on_journal_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_attachable_journals_on_journal_id ON public.attachable_journals USING btree (journal_id);


--
-- Name: index_attachments_on_author_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_attachments_on_author_id ON public.attachments USING btree (author_id);


--
-- Name: index_attachments_on_container_id_and_container_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_attachments_on_container_id_and_container_type ON public.attachments USING btree (container_id, container_type);


--
-- Name: index_attachments_on_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_attachments_on_created_at ON public.attachments USING btree (created_at);


--
-- Name: index_attachments_on_file_tsv; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_attachments_on_file_tsv ON public.attachments USING gin (file_tsv);


--
-- Name: index_attachments_on_fulltext_tsv; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_attachments_on_fulltext_tsv ON public.attachments USING gin (fulltext_tsv);


--
-- Name: index_auth_sources_on_id_and_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_auth_sources_on_id_and_type ON public.auth_sources USING btree (id, type);


--
-- Name: index_bcf_comments_on_issue_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_bcf_comments_on_issue_id ON public.bcf_comments USING btree (issue_id);


--
-- Name: index_bcf_comments_on_journal_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_bcf_comments_on_journal_id ON public.bcf_comments USING btree (journal_id);


--
-- Name: index_bcf_comments_on_uuid; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_bcf_comments_on_uuid ON public.bcf_comments USING btree (uuid);


--
-- Name: index_bcf_comments_on_uuid_and_issue_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_bcf_comments_on_uuid_and_issue_id ON public.bcf_comments USING btree (uuid, issue_id);


--
-- Name: index_bcf_comments_on_viewpoint_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_bcf_comments_on_viewpoint_id ON public.bcf_comments USING btree (viewpoint_id);


--
-- Name: index_bcf_issues_on_uuid; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_bcf_issues_on_uuid ON public.bcf_issues USING btree (uuid);


--
-- Name: index_bcf_issues_on_work_package_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_bcf_issues_on_work_package_id ON public.bcf_issues USING btree (work_package_id);


--
-- Name: index_bcf_viewpoints_on_issue_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_bcf_viewpoints_on_issue_id ON public.bcf_viewpoints USING btree (issue_id);


--
-- Name: index_bcf_viewpoints_on_uuid; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_bcf_viewpoints_on_uuid ON public.bcf_viewpoints USING btree (uuid);


--
-- Name: index_bcf_viewpoints_on_uuid_and_issue_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_bcf_viewpoints_on_uuid_and_issue_id ON public.bcf_viewpoints USING btree (uuid, issue_id);


--
-- Name: index_budgets_on_project_id_and_updated_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_budgets_on_project_id_and_updated_at ON public.budgets USING btree (project_id, updated_at);


--
-- Name: index_categories_on_assigned_to_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_categories_on_assigned_to_id ON public.categories USING btree (assigned_to_id);


--
-- Name: index_changesets_on_committed_on; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_changesets_on_committed_on ON public.changesets USING btree (committed_on);


--
-- Name: index_changesets_on_repository_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_changesets_on_repository_id ON public.changesets USING btree (repository_id);


--
-- Name: index_changesets_on_repository_id_and_committed_on; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_changesets_on_repository_id_and_committed_on ON public.changesets USING btree (repository_id, committed_on);


--
-- Name: index_changesets_on_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_changesets_on_user_id ON public.changesets USING btree (user_id);


--
-- Name: index_comments_on_author_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_comments_on_author_id ON public.comments USING btree (author_id);


--
-- Name: index_comments_on_commented_id_and_commented_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_comments_on_commented_id_and_commented_type ON public.comments USING btree (commented_id, commented_type);


--
-- Name: index_cost_entries_on_logged_by_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_cost_entries_on_logged_by_id ON public.cost_entries USING btree (logged_by_id);


--
-- Name: index_custom_actions_projects_on_custom_action_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_custom_actions_projects_on_custom_action_id ON public.custom_actions_projects USING btree (custom_action_id);


--
-- Name: index_custom_actions_projects_on_project_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_custom_actions_projects_on_project_id ON public.custom_actions_projects USING btree (project_id);


--
-- Name: index_custom_actions_roles_on_custom_action_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_custom_actions_roles_on_custom_action_id ON public.custom_actions_roles USING btree (custom_action_id);


--
-- Name: index_custom_actions_roles_on_role_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_custom_actions_roles_on_role_id ON public.custom_actions_roles USING btree (role_id);


--
-- Name: index_custom_actions_statuses_on_custom_action_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_custom_actions_statuses_on_custom_action_id ON public.custom_actions_statuses USING btree (custom_action_id);


--
-- Name: index_custom_actions_statuses_on_status_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_custom_actions_statuses_on_status_id ON public.custom_actions_statuses USING btree (status_id);


--
-- Name: index_custom_actions_types_on_custom_action_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_custom_actions_types_on_custom_action_id ON public.custom_actions_types USING btree (custom_action_id);


--
-- Name: index_custom_actions_types_on_type_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_custom_actions_types_on_type_id ON public.custom_actions_types USING btree (type_id);


--
-- Name: index_custom_fields_on_id_and_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_custom_fields_on_id_and_type ON public.custom_fields USING btree (id, type);


--
-- Name: index_custom_fields_projects_on_custom_field_id_and_project_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_custom_fields_projects_on_custom_field_id_and_project_id ON public.custom_fields_projects USING btree (custom_field_id, project_id);


--
-- Name: index_custom_values_on_custom_field_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_custom_values_on_custom_field_id ON public.custom_values USING btree (custom_field_id);


--
-- Name: index_customizable_journals_on_custom_field_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_customizable_journals_on_custom_field_id ON public.customizable_journals USING btree (custom_field_id);


--
-- Name: index_customizable_journals_on_journal_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_customizable_journals_on_journal_id ON public.customizable_journals USING btree (journal_id);


--
-- Name: index_delayed_job_statuses_on_job_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_delayed_job_statuses_on_job_id ON public.delayed_job_statuses USING btree (job_id);


--
-- Name: index_delayed_job_statuses_on_reference_type_and_reference_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_delayed_job_statuses_on_reference_type_and_reference_id ON public.delayed_job_statuses USING btree (reference_type, reference_id);


--
-- Name: index_delayed_job_statuses_on_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_delayed_job_statuses_on_user_id ON public.delayed_job_statuses USING btree (user_id);


--
-- Name: index_design_colors_on_variable; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_design_colors_on_variable ON public.design_colors USING btree (variable);


--
-- Name: index_documents_on_category_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_documents_on_category_id ON public.documents USING btree (category_id);


--
-- Name: index_documents_on_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_documents_on_created_at ON public.documents USING btree (created_at);


--
-- Name: index_enabled_modules_on_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_enabled_modules_on_name ON public.enabled_modules USING btree (name);


--
-- Name: index_enumerations_on_color_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_enumerations_on_color_id ON public.enumerations USING btree (color_id);


--
-- Name: index_enumerations_on_id_and_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_enumerations_on_id_and_type ON public.enumerations USING btree (id, type);


--
-- Name: index_enumerations_on_project_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_enumerations_on_project_id ON public.enumerations USING btree (project_id);


--
-- Name: index_file_links_on_container_id_and_container_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_file_links_on_container_id_and_container_type ON public.file_links USING btree (container_id, container_type);


--
-- Name: index_file_links_on_creator_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_file_links_on_creator_id ON public.file_links USING btree (creator_id);


--
-- Name: index_file_links_on_origin_id_and_storage_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_file_links_on_origin_id_and_storage_id ON public.file_links USING btree (origin_id, storage_id);


--
-- Name: index_file_links_on_storage_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_file_links_on_storage_id ON public.file_links USING btree (storage_id);


--
-- Name: index_forums_on_last_message_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_forums_on_last_message_id ON public.forums USING btree (last_message_id);


--
-- Name: index_github_check_runs_on_github_pull_request_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_github_check_runs_on_github_pull_request_id ON public.github_check_runs USING btree (github_pull_request_id);


--
-- Name: index_github_pull_requests_on_github_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_github_pull_requests_on_github_user_id ON public.github_pull_requests USING btree (github_user_id);


--
-- Name: index_github_pull_requests_on_merged_by_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_github_pull_requests_on_merged_by_id ON public.github_pull_requests USING btree (merged_by_id);


--
-- Name: index_grid_widgets_on_grid_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_grid_widgets_on_grid_id ON public.grid_widgets USING btree (grid_id);


--
-- Name: index_grids_on_project_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_grids_on_project_id ON public.grids USING btree (project_id);


--
-- Name: index_grids_on_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_grids_on_user_id ON public.grids USING btree (user_id);


--
-- Name: index_group_users_on_user_id_and_group_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_group_users_on_user_id_and_group_id ON public.group_users USING btree (user_id, group_id);


--
-- Name: index_ifc_models_on_is_default; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_ifc_models_on_is_default ON public.ifc_models USING btree (is_default);


--
-- Name: index_ifc_models_on_project_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_ifc_models_on_project_id ON public.ifc_models USING btree (project_id);


--
-- Name: index_ifc_models_on_uploader_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_ifc_models_on_uploader_id ON public.ifc_models USING btree (uploader_id);


--
-- Name: index_journals_on_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_journals_on_created_at ON public.journals USING btree (created_at);


--
-- Name: index_journals_on_data_id_and_data_type; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_journals_on_data_id_and_data_type ON public.journals USING btree (data_id, data_type);


--
-- Name: index_journals_on_journable_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_journals_on_journable_id ON public.journals USING btree (journable_id);


--
-- Name: index_journals_on_journable_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_journals_on_journable_type ON public.journals USING btree (journable_type);


--
-- Name: index_journals_on_journable_type_and_journable_id_and_version; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_journals_on_journable_type_and_journable_id_and_version ON public.journals USING btree (journable_type, journable_id, version);


--
-- Name: index_journals_on_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_journals_on_user_id ON public.journals USING btree (user_id);


--
-- Name: index_ldap_groups_memberships_on_group_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_ldap_groups_memberships_on_group_id ON public.ldap_groups_memberships USING btree (group_id);


--
-- Name: index_ldap_groups_memberships_on_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_ldap_groups_memberships_on_user_id ON public.ldap_groups_memberships USING btree (user_id);


--
-- Name: index_ldap_groups_memberships_on_user_id_and_group_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_ldap_groups_memberships_on_user_id_and_group_id ON public.ldap_groups_memberships USING btree (user_id, group_id);


--
-- Name: index_ldap_groups_synchronized_filters_on_auth_source_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_ldap_groups_synchronized_filters_on_auth_source_id ON public.ldap_groups_synchronized_filters USING btree (auth_source_id);


--
-- Name: index_ldap_groups_synchronized_groups_on_auth_source_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_ldap_groups_synchronized_groups_on_auth_source_id ON public.ldap_groups_synchronized_groups USING btree (auth_source_id);


--
-- Name: index_ldap_groups_synchronized_groups_on_filter_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_ldap_groups_synchronized_groups_on_filter_id ON public.ldap_groups_synchronized_groups USING btree (filter_id);


--
-- Name: index_ldap_groups_synchronized_groups_on_group_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_ldap_groups_synchronized_groups_on_group_id ON public.ldap_groups_synchronized_groups USING btree (group_id);


--
-- Name: index_meetings_on_project_id_and_updated_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_meetings_on_project_id_and_updated_at ON public.meetings USING btree (project_id, updated_at);


--
-- Name: index_member_roles_on_inherited_from; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_member_roles_on_inherited_from ON public.member_roles USING btree (inherited_from);


--
-- Name: index_member_roles_on_member_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_member_roles_on_member_id ON public.member_roles USING btree (member_id);


--
-- Name: index_member_roles_on_role_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_member_roles_on_role_id ON public.member_roles USING btree (role_id);


--
-- Name: index_members_on_project_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_members_on_project_id ON public.members USING btree (project_id);


--
-- Name: index_members_on_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_members_on_user_id ON public.members USING btree (user_id);


--
-- Name: index_members_on_user_id_and_project_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_members_on_user_id_and_project_id ON public.members USING btree (user_id, project_id);


--
-- Name: index_menu_items_on_navigatable_id_and_title; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_menu_items_on_navigatable_id_and_title ON public.menu_items USING btree (navigatable_id, title);


--
-- Name: index_menu_items_on_parent_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_menu_items_on_parent_id ON public.menu_items USING btree (parent_id);


--
-- Name: index_messages_on_author_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_messages_on_author_id ON public.messages USING btree (author_id);


--
-- Name: index_messages_on_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_messages_on_created_at ON public.messages USING btree (created_at);


--
-- Name: index_messages_on_forum_id_and_updated_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_messages_on_forum_id_and_updated_at ON public.messages USING btree (forum_id, updated_at);


--
-- Name: index_messages_on_last_reply_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_messages_on_last_reply_id ON public.messages USING btree (last_reply_id);


--
-- Name: index_news_journals_on_project_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_news_journals_on_project_id ON public.news_journals USING btree (project_id);


--
-- Name: index_news_on_author_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_news_on_author_id ON public.news USING btree (author_id);


--
-- Name: index_news_on_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_news_on_created_at ON public.news USING btree (created_at);


--
-- Name: index_news_on_project_id_and_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_news_on_project_id_and_created_at ON public.news USING btree (project_id, created_at);


--
-- Name: index_non_working_days_on_date; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_non_working_days_on_date ON public.non_working_days USING btree (date);


--
-- Name: index_notification_settings_on_document_added; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_notification_settings_on_document_added ON public.notification_settings USING btree (document_added);


--
-- Name: index_notification_settings_on_forum_messages; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_notification_settings_on_forum_messages ON public.notification_settings USING btree (forum_messages);


--
-- Name: index_notification_settings_on_membership_added; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_notification_settings_on_membership_added ON public.notification_settings USING btree (membership_added);


--
-- Name: index_notification_settings_on_membership_updated; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_notification_settings_on_membership_updated ON public.notification_settings USING btree (membership_updated);


--
-- Name: index_notification_settings_on_news_added; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_notification_settings_on_news_added ON public.notification_settings USING btree (news_added);


--
-- Name: index_notification_settings_on_news_commented; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_notification_settings_on_news_commented ON public.notification_settings USING btree (news_commented);


--
-- Name: index_notification_settings_on_project_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_notification_settings_on_project_id ON public.notification_settings USING btree (project_id);


--
-- Name: index_notification_settings_on_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_notification_settings_on_user_id ON public.notification_settings USING btree (user_id);


--
-- Name: index_notification_settings_on_wiki_page_added; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_notification_settings_on_wiki_page_added ON public.notification_settings USING btree (wiki_page_added);


--
-- Name: index_notification_settings_on_wiki_page_updated; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_notification_settings_on_wiki_page_updated ON public.notification_settings USING btree (wiki_page_updated);


--
-- Name: index_notification_settings_on_work_package_commented; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_notification_settings_on_work_package_commented ON public.notification_settings USING btree (work_package_commented);


--
-- Name: index_notification_settings_on_work_package_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_notification_settings_on_work_package_created ON public.notification_settings USING btree (work_package_created);


--
-- Name: index_notification_settings_on_work_package_prioritized; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_notification_settings_on_work_package_prioritized ON public.notification_settings USING btree (work_package_prioritized);


--
-- Name: index_notification_settings_on_work_package_processed; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_notification_settings_on_work_package_processed ON public.notification_settings USING btree (work_package_processed);


--
-- Name: index_notification_settings_on_work_package_scheduled; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_notification_settings_on_work_package_scheduled ON public.notification_settings USING btree (work_package_scheduled);


--
-- Name: index_notification_settings_unique_project; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_notification_settings_unique_project ON public.notification_settings USING btree (user_id, project_id) WHERE (project_id IS NOT NULL);


--
-- Name: index_notification_settings_unique_project_null; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_notification_settings_unique_project_null ON public.notification_settings USING btree (user_id) WHERE (project_id IS NULL);


--
-- Name: index_notifications_on_actor_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_notifications_on_actor_id ON public.notifications USING btree (actor_id);


--
-- Name: index_notifications_on_journal_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_notifications_on_journal_id ON public.notifications USING btree (journal_id);


--
-- Name: index_notifications_on_mail_alert_sent; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_notifications_on_mail_alert_sent ON public.notifications USING btree (mail_alert_sent);


--
-- Name: index_notifications_on_mail_reminder_sent; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_notifications_on_mail_reminder_sent ON public.notifications USING btree (mail_reminder_sent);


--
-- Name: index_notifications_on_project_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_notifications_on_project_id ON public.notifications USING btree (project_id);


--
-- Name: index_notifications_on_read_ian; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_notifications_on_read_ian ON public.notifications USING btree (read_ian);


--
-- Name: index_notifications_on_recipient_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_notifications_on_recipient_id ON public.notifications USING btree (recipient_id);


--
-- Name: index_notifications_on_resource; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_notifications_on_resource ON public.notifications USING btree (resource_type, resource_id);


--
-- Name: index_oauth_access_grants_on_application_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_oauth_access_grants_on_application_id ON public.oauth_access_grants USING btree (application_id);


--
-- Name: index_oauth_access_grants_on_resource_owner_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_oauth_access_grants_on_resource_owner_id ON public.oauth_access_grants USING btree (resource_owner_id);


--
-- Name: index_oauth_access_grants_on_token; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_oauth_access_grants_on_token ON public.oauth_access_grants USING btree (token);


--
-- Name: index_oauth_access_tokens_on_application_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_oauth_access_tokens_on_application_id ON public.oauth_access_tokens USING btree (application_id);


--
-- Name: index_oauth_access_tokens_on_refresh_token; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_oauth_access_tokens_on_refresh_token ON public.oauth_access_tokens USING btree (refresh_token);


--
-- Name: index_oauth_access_tokens_on_resource_owner_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_oauth_access_tokens_on_resource_owner_id ON public.oauth_access_tokens USING btree (resource_owner_id);


--
-- Name: index_oauth_access_tokens_on_token; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_oauth_access_tokens_on_token ON public.oauth_access_tokens USING btree (token);


--
-- Name: index_oauth_applications_on_integration; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_oauth_applications_on_integration ON public.oauth_applications USING btree (integration_type, integration_id);


--
-- Name: index_oauth_applications_on_owner_id_and_owner_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_oauth_applications_on_owner_id_and_owner_type ON public.oauth_applications USING btree (owner_id, owner_type);


--
-- Name: index_oauth_applications_on_uid; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_oauth_applications_on_uid ON public.oauth_applications USING btree (uid);


--
-- Name: index_oauth_client_tokens_on_oauth_client_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_oauth_client_tokens_on_oauth_client_id ON public.oauth_client_tokens USING btree (oauth_client_id);


--
-- Name: index_oauth_client_tokens_on_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_oauth_client_tokens_on_user_id ON public.oauth_client_tokens USING btree (user_id);


--
-- Name: index_oauth_client_tokens_on_user_id_and_oauth_client_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_oauth_client_tokens_on_user_id_and_oauth_client_id ON public.oauth_client_tokens USING btree (user_id, oauth_client_id);


--
-- Name: index_oauth_clients_on_integration; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_oauth_clients_on_integration ON public.oauth_clients USING btree (integration_type, integration_id);


--
-- Name: index_oidc_user_session_links_on_oidc_session; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_oidc_user_session_links_on_oidc_session ON public.oidc_user_session_links USING btree (oidc_session);


--
-- Name: index_oidc_user_session_links_on_session_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_oidc_user_session_links_on_session_id ON public.oidc_user_session_links USING btree (session_id);


--
-- Name: index_ordered_work_packages_on_position; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_ordered_work_packages_on_position ON public.ordered_work_packages USING btree ("position");


--
-- Name: index_ordered_work_packages_on_query_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_ordered_work_packages_on_query_id ON public.ordered_work_packages USING btree (query_id);


--
-- Name: index_ordered_work_packages_on_work_package_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_ordered_work_packages_on_work_package_id ON public.ordered_work_packages USING btree (work_package_id);


--
-- Name: index_paper_trail_audits_on_item_type_and_item_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_paper_trail_audits_on_item_type_and_item_id ON public.paper_trail_audits USING btree (item_type, item_id);


--
-- Name: index_project_statuses_on_project_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_project_statuses_on_project_id ON public.project_statuses USING btree (project_id);


--
-- Name: index_projects_on_identifier; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_projects_on_identifier ON public.projects USING btree (identifier);


--
-- Name: index_projects_on_lft; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_projects_on_lft ON public.projects USING btree (lft);


--
-- Name: index_projects_on_lft_and_rgt; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_projects_on_lft_and_rgt ON public.projects USING btree (lft, rgt);


--
-- Name: index_projects_on_rgt; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_projects_on_rgt ON public.projects USING btree (rgt);


--
-- Name: index_projects_storages_on_creator_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_projects_storages_on_creator_id ON public.projects_storages USING btree (creator_id);


--
-- Name: index_projects_storages_on_project_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_projects_storages_on_project_id ON public.projects_storages USING btree (project_id);


--
-- Name: index_projects_storages_on_project_id_and_storage_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_projects_storages_on_project_id_and_storage_id ON public.projects_storages USING btree (project_id, storage_id);


--
-- Name: index_projects_storages_on_storage_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_projects_storages_on_storage_id ON public.projects_storages USING btree (storage_id);


--
-- Name: index_queries_on_project_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_queries_on_project_id ON public.queries USING btree (project_id);


--
-- Name: index_queries_on_updated_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_queries_on_updated_at ON public.queries USING btree (updated_at);


--
-- Name: index_queries_on_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_queries_on_user_id ON public.queries USING btree (user_id);


--
-- Name: index_recaptcha_entries_on_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_recaptcha_entries_on_user_id ON public.recaptcha_entries USING btree (user_id);


--
-- Name: index_relations_on_from_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_relations_on_from_id ON public.relations USING btree (from_id);


--
-- Name: index_relations_on_from_id_and_to_id_and_relation_type; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_relations_on_from_id_and_to_id_and_relation_type ON public.relations USING btree (from_id, to_id, relation_type);


--
-- Name: index_relations_on_to_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_relations_on_to_id ON public.relations USING btree (to_id);


--
-- Name: index_relations_on_to_id_and_from_id_and_relation_type; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_relations_on_to_id_and_from_id_and_relation_type ON public.relations USING btree (to_id, from_id, relation_type);


--
-- Name: index_repositories_on_project_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_repositories_on_project_id ON public.repositories USING btree (project_id);


--
-- Name: index_role_permissions_on_role_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_role_permissions_on_role_id ON public.role_permissions USING btree (role_id);


--
-- Name: index_sessions_on_session_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_sessions_on_session_id ON public.sessions USING btree (session_id);


--
-- Name: index_sessions_on_updated_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_sessions_on_updated_at ON public.sessions USING btree (updated_at);


--
-- Name: index_settings_on_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_settings_on_name ON public.settings USING btree (name);


--
-- Name: index_statuses_on_color_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_statuses_on_color_id ON public.statuses USING btree (color_id);


--
-- Name: index_statuses_on_is_closed; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_statuses_on_is_closed ON public.statuses USING btree (is_closed);


--
-- Name: index_statuses_on_is_default; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_statuses_on_is_default ON public.statuses USING btree (is_default);


--
-- Name: index_statuses_on_position; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_statuses_on_position ON public.statuses USING btree ("position");


--
-- Name: index_storages_on_creator_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_storages_on_creator_id ON public.storages USING btree (creator_id);


--
-- Name: index_storages_on_host; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_storages_on_host ON public.storages USING btree (host);


--
-- Name: index_storages_on_name; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_storages_on_name ON public.storages USING btree (name);


--
-- Name: index_teap_on_project_id_and_activity_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_teap_on_project_id_and_activity_id ON public.time_entry_activities_projects USING btree (project_id, activity_id);


--
-- Name: index_time_entries_on_activity_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_time_entries_on_activity_id ON public.time_entries USING btree (activity_id);


--
-- Name: index_time_entries_on_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_time_entries_on_created_at ON public.time_entries USING btree (created_at);


--
-- Name: index_time_entries_on_logged_by_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_time_entries_on_logged_by_id ON public.time_entries USING btree (logged_by_id);


--
-- Name: index_time_entries_on_project_id_and_updated_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_time_entries_on_project_id_and_updated_at ON public.time_entries USING btree (project_id, updated_at);


--
-- Name: index_time_entries_on_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_time_entries_on_user_id ON public.time_entries USING btree (user_id);


--
-- Name: index_time_entry_activities_projects_on_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_time_entry_activities_projects_on_active ON public.time_entry_activities_projects USING btree (active);


--
-- Name: index_time_entry_activities_projects_on_activity_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_time_entry_activities_projects_on_activity_id ON public.time_entry_activities_projects USING btree (activity_id);


--
-- Name: index_time_entry_activities_projects_on_project_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_time_entry_activities_projects_on_project_id ON public.time_entry_activities_projects USING btree (project_id);


--
-- Name: index_time_entry_journals_on_logged_by_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_time_entry_journals_on_logged_by_id ON public.time_entry_journals USING btree (logged_by_id);


--
-- Name: index_time_entry_journals_on_project_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_time_entry_journals_on_project_id ON public.time_entry_journals USING btree (project_id);


--
-- Name: index_tokens_on_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_tokens_on_user_id ON public.tokens USING btree (user_id);


--
-- Name: index_two_factor_authentication_devices_on_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_two_factor_authentication_devices_on_user_id ON public.two_factor_authentication_devices USING btree (user_id);


--
-- Name: index_types_on_color_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_types_on_color_id ON public.types USING btree (color_id);


--
-- Name: index_user_passwords_on_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_user_passwords_on_user_id ON public.user_passwords USING btree (user_id);


--
-- Name: index_user_preferences_on_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_user_preferences_on_user_id ON public.user_preferences USING btree (user_id);


--
-- Name: index_user_prefs_settings_daily_reminders_enabled; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_user_prefs_settings_daily_reminders_enabled ON public.user_preferences USING gin ((((settings -> 'daily_reminders'::text) -> 'enabled'::text)));


--
-- Name: index_user_prefs_settings_daily_reminders_times; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_user_prefs_settings_daily_reminders_times ON public.user_preferences USING gin ((((settings -> 'daily_reminders'::text) -> 'times'::text)));


--
-- Name: index_user_prefs_settings_pause_reminders_enabled; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_user_prefs_settings_pause_reminders_enabled ON public.user_preferences USING btree (((((settings -> 'pause_reminders'::text) ->> 'enabled'::text))::boolean));


--
-- Name: index_user_prefs_settings_time_zone; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_user_prefs_settings_time_zone ON public.user_preferences USING gin (((settings -> 'time_zone'::text)));


--
-- Name: index_user_prefs_settings_workdays; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_user_prefs_settings_workdays ON public.user_preferences USING gin (((settings -> 'workdays'::text)));


--
-- Name: index_users_on_auth_source_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_users_on_auth_source_id ON public.users USING btree (auth_source_id);


--
-- Name: index_users_on_id_and_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_users_on_id_and_type ON public.users USING btree (id, type);


--
-- Name: index_users_on_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_users_on_type ON public.users USING btree (type);


--
-- Name: index_users_on_type_and_login; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_users_on_type_and_login ON public.users USING btree (type, login);


--
-- Name: index_users_on_type_and_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_users_on_type_and_status ON public.users USING btree (type, status);


--
-- Name: index_version_settings_on_project_id_and_version_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_version_settings_on_project_id_and_version_id ON public.version_settings USING btree (project_id, version_id);


--
-- Name: index_versions_on_sharing; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_versions_on_sharing ON public.versions USING btree (sharing);


--
-- Name: index_views_on_query_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_views_on_query_id ON public.views USING btree (query_id);


--
-- Name: index_watchers_on_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_watchers_on_user_id ON public.watchers USING btree (user_id);


--
-- Name: index_watchers_on_watchable_id_and_watchable_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_watchers_on_watchable_id_and_watchable_type ON public.watchers USING btree (watchable_id, watchable_type);


--
-- Name: index_webhooks_events_on_webhooks_webhook_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_webhooks_events_on_webhooks_webhook_id ON public.webhooks_events USING btree (webhooks_webhook_id);


--
-- Name: index_webhooks_logs_on_webhooks_webhook_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_webhooks_logs_on_webhooks_webhook_id ON public.webhooks_logs USING btree (webhooks_webhook_id);


--
-- Name: index_webhooks_projects_on_project_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_webhooks_projects_on_project_id ON public.webhooks_projects USING btree (project_id);


--
-- Name: index_webhooks_projects_on_webhooks_webhook_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_webhooks_projects_on_webhooks_webhook_id ON public.webhooks_projects USING btree (webhooks_webhook_id);


--
-- Name: index_wiki_contents_on_author_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_wiki_contents_on_author_id ON public.wiki_contents USING btree (author_id);


--
-- Name: index_wiki_contents_on_page_id_and_updated_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_wiki_contents_on_page_id_and_updated_at ON public.wiki_contents USING btree (page_id, updated_at);


--
-- Name: index_wiki_pages_on_parent_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_wiki_pages_on_parent_id ON public.wiki_pages USING btree (parent_id);


--
-- Name: index_wiki_pages_on_wiki_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_wiki_pages_on_wiki_id ON public.wiki_pages USING btree (wiki_id);


--
-- Name: index_wiki_redirects_on_wiki_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_wiki_redirects_on_wiki_id ON public.wiki_redirects USING btree (wiki_id);


--
-- Name: index_work_package_journals_on_project_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_work_package_journals_on_project_id ON public.work_package_journals USING btree (project_id);


--
-- Name: index_work_packages_on_assigned_to_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_work_packages_on_assigned_to_id ON public.work_packages USING btree (assigned_to_id);


--
-- Name: index_work_packages_on_author_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_work_packages_on_author_id ON public.work_packages USING btree (author_id);


--
-- Name: index_work_packages_on_category_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_work_packages_on_category_id ON public.work_packages USING btree (category_id);


--
-- Name: index_work_packages_on_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_work_packages_on_created_at ON public.work_packages USING btree (created_at);


--
-- Name: index_work_packages_on_due_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_work_packages_on_due_date ON public.work_packages USING btree (due_date);


--
-- Name: index_work_packages_on_parent_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_work_packages_on_parent_id ON public.work_packages USING btree (parent_id);


--
-- Name: index_work_packages_on_project_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_work_packages_on_project_id ON public.work_packages USING btree (project_id);


--
-- Name: index_work_packages_on_project_id_and_updated_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_work_packages_on_project_id_and_updated_at ON public.work_packages USING btree (project_id, updated_at);


--
-- Name: index_work_packages_on_responsible_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_work_packages_on_responsible_id ON public.work_packages USING btree (responsible_id);


--
-- Name: index_work_packages_on_schedule_manually; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_work_packages_on_schedule_manually ON public.work_packages USING btree (schedule_manually) WHERE schedule_manually;


--
-- Name: index_work_packages_on_start_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_work_packages_on_start_date ON public.work_packages USING btree (start_date);


--
-- Name: index_work_packages_on_status_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_work_packages_on_status_id ON public.work_packages USING btree (status_id);


--
-- Name: index_work_packages_on_type_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_work_packages_on_type_id ON public.work_packages USING btree (type_id);


--
-- Name: index_work_packages_on_updated_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_work_packages_on_updated_at ON public.work_packages USING btree (updated_at);


--
-- Name: index_work_packages_on_version_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_work_packages_on_version_id ON public.work_packages USING btree (version_id);


--
-- Name: index_workflows_on_new_status_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_workflows_on_new_status_id ON public.workflows USING btree (new_status_id);


--
-- Name: index_workflows_on_old_status_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_workflows_on_old_status_id ON public.workflows USING btree (old_status_id);


--
-- Name: index_workflows_on_role_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_workflows_on_role_id ON public.workflows USING btree (role_id);


--
-- Name: issue_categories_project_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX issue_categories_project_id ON public.categories USING btree (project_id);


--
-- Name: messages_board_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX messages_board_id ON public.messages USING btree (forum_id);


--
-- Name: messages_parent_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX messages_parent_id ON public.messages USING btree (parent_id);


--
-- Name: news_project_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX news_project_id ON public.news USING btree (project_id);


--
-- Name: projects_types_project_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX projects_types_project_id ON public.projects_types USING btree (project_id);


--
-- Name: projects_types_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX projects_types_unique ON public.projects_types USING btree (project_id, type_id);


--
-- Name: time_entries_issue_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX time_entries_issue_id ON public.time_entries USING btree (work_package_id);


--
-- Name: time_entries_project_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX time_entries_project_id ON public.time_entries USING btree (project_id);


--
-- Name: unique_index_gh_prs_wps_on_gh_pr_id_and_wp_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX unique_index_gh_prs_wps_on_gh_pr_id_and_wp_id ON public.github_pull_requests_work_packages USING btree (github_pull_request_id, work_package_id);


--
-- Name: unique_inherited_role; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX unique_inherited_role ON public.member_roles USING btree (member_id, role_id, inherited_from);


--
-- Name: unique_lastname_for_groups_and_placeholder_users; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX unique_lastname_for_groups_and_placeholder_users ON public.users USING btree (lastname, type) WHERE (((type)::text = 'Group'::text) OR ((type)::text = 'PlaceholderUser'::text));


--
-- Name: versions_project_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX versions_project_id ON public.versions USING btree (project_id);


--
-- Name: watchers_user_id_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX watchers_user_id_type ON public.watchers USING btree (user_id, watchable_type);


--
-- Name: wiki_contents_page_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX wiki_contents_page_id ON public.wiki_contents USING btree (page_id);


--
-- Name: wiki_pages_wiki_id_slug; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX wiki_pages_wiki_id_slug ON public.wiki_pages USING btree (wiki_id, slug);


--
-- Name: wiki_pages_wiki_id_title; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX wiki_pages_wiki_id_title ON public.wiki_pages USING btree (wiki_id, title);


--
-- Name: wiki_redirects_wiki_id_title; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX wiki_redirects_wiki_id_title ON public.wiki_redirects USING btree (wiki_id, title);


--
-- Name: wikis_project_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX wikis_project_id ON public.wikis USING btree (project_id);


--
-- Name: wkfs_role_type_old_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX wkfs_role_type_old_status ON public.workflows USING btree (role_id, type_id, old_status_id);


--
-- Name: work_package_anc_desc_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX work_package_anc_desc_idx ON public.work_package_hierarchies USING btree (ancestor_id, descendant_id, generations);


--
-- Name: work_package_desc_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX work_package_desc_idx ON public.work_package_hierarchies USING btree (descendant_id);


--
-- Name: work_package_journal_on_burndown_attributes; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX work_package_journal_on_burndown_attributes ON public.work_package_journals USING btree (version_id, status_id, project_id, type_id);


--
-- Name: projects_storages fk_rails_04546d7b88; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.projects_storages
    ADD CONSTRAINT fk_rails_04546d7b88 FOREIGN KEY (storage_id) REFERENCES public.storages(id) ON DELETE CASCADE;


--
-- Name: bcf_comments fk_rails_0571c4b386; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bcf_comments
    ADD CONSTRAINT fk_rails_0571c4b386 FOREIGN KEY (reply_to) REFERENCES public.bcf_comments(id) ON DELETE SET NULL;


--
-- Name: notifications fk_rails_06a39bb8cc; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT fk_rails_06a39bb8cc FOREIGN KEY (actor_id) REFERENCES public.users(id);


--
-- Name: two_factor_authentication_devices fk_rails_0b09e132e7; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.two_factor_authentication_devices
    ADD CONSTRAINT fk_rails_0b09e132e7 FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: notification_settings fk_rails_0c95e91db7; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_settings
    ADD CONSTRAINT fk_rails_0c95e91db7 FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: cost_entries fk_rails_0d35f09506; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cost_entries
    ADD CONSTRAINT fk_rails_0d35f09506 FOREIGN KEY (logged_by_id) REFERENCES public.users(id);


--
-- Name: project_statuses fk_rails_3cf2a2e96d; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_statuses
    ADD CONSTRAINT fk_rails_3cf2a2e96d FOREIGN KEY (project_id) REFERENCES public.projects(id);


--
-- Name: oauth_applications fk_rails_3d1f3b58d2; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth_applications
    ADD CONSTRAINT fk_rails_3d1f3b58d2 FOREIGN KEY (client_credentials_user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: ldap_groups_synchronized_groups fk_rails_44dac1537e; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ldap_groups_synchronized_groups
    ADD CONSTRAINT fk_rails_44dac1537e FOREIGN KEY (filter_id) REFERENCES public.ldap_groups_synchronized_filters(id);


--
-- Name: types fk_rails_46ceaf0e5b; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.types
    ADD CONSTRAINT fk_rails_46ceaf0e5b FOREIGN KEY (color_id) REFERENCES public.colors(id) ON DELETE SET NULL;


--
-- Name: notification_settings fk_rails_496a500fda; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_settings
    ADD CONSTRAINT fk_rails_496a500fda FOREIGN KEY (project_id) REFERENCES public.projects(id);


--
-- Name: notifications fk_rails_4aea6afa11; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT fk_rails_4aea6afa11 FOREIGN KEY (recipient_id) REFERENCES public.users(id);


--
-- Name: bcf_issues fk_rails_4e35bc3056; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bcf_issues
    ADD CONSTRAINT fk_rails_4e35bc3056 FOREIGN KEY (work_package_id) REFERENCES public.work_packages(id) ON DELETE CASCADE;


--
-- Name: ifc_models fk_rails_4f53d4601c; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ifc_models
    ADD CONSTRAINT fk_rails_4f53d4601c FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE CASCADE;


--
-- Name: webhooks_logs fk_rails_551257cdac; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.webhooks_logs
    ADD CONSTRAINT fk_rails_551257cdac FOREIGN KEY (webhooks_webhook_id) REFERENCES public.webhooks_webhooks(id) ON DELETE CASCADE;


--
-- Name: bcf_comments fk_rails_556ef6e73e; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bcf_comments
    ADD CONSTRAINT fk_rails_556ef6e73e FOREIGN KEY (viewpoint_id) REFERENCES public.bcf_viewpoints(id) ON DELETE SET NULL;


--
-- Name: notifications fk_rails_595318131c; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT fk_rails_595318131c FOREIGN KEY (journal_id) REFERENCES public.journals(id) ON DELETE CASCADE;


--
-- Name: time_entry_activities_projects fk_rails_5b669d4f34; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.time_entry_activities_projects
    ADD CONSTRAINT fk_rails_5b669d4f34 FOREIGN KEY (project_id) REFERENCES public.projects(id);


--
-- Name: oidc_user_session_links fk_rails_5e6a849f92; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oidc_user_session_links
    ADD CONSTRAINT fk_rails_5e6a849f92 FOREIGN KEY (session_id) REFERENCES public.sessions(id) ON DELETE CASCADE;


--
-- Name: file_links fk_rails_650ebb2e1a; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.file_links
    ADD CONSTRAINT fk_rails_650ebb2e1a FOREIGN KEY (creator_id) REFERENCES public.users(id);


--
-- Name: oauth_client_tokens fk_rails_65a92bfbf4; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth_client_tokens
    ADD CONSTRAINT fk_rails_65a92bfbf4 FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: storages fk_rails_6c69bacb8d; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.storages
    ADD CONSTRAINT fk_rails_6c69bacb8d FOREIGN KEY (creator_id) REFERENCES public.users(id);


--
-- Name: oauth_client_tokens fk_rails_6e922d4135; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth_client_tokens
    ADD CONSTRAINT fk_rails_6e922d4135 FOREIGN KEY (oauth_client_id) REFERENCES public.oauth_clients(id) ON DELETE CASCADE;


--
-- Name: time_entries fk_rails_709864c72f; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.time_entries
    ADD CONSTRAINT fk_rails_709864c72f FOREIGN KEY (logged_by_id) REFERENCES public.users(id);


--
-- Name: oauth_access_tokens fk_rails_732cb83ab7; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth_access_tokens
    ADD CONSTRAINT fk_rails_732cb83ab7 FOREIGN KEY (application_id) REFERENCES public.oauth_applications(id);


--
-- Name: bcf_comments fk_rails_7ac870008c; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bcf_comments
    ADD CONSTRAINT fk_rails_7ac870008c FOREIGN KEY (issue_id) REFERENCES public.bcf_issues(id) ON DELETE CASCADE;


--
-- Name: recaptcha_entries fk_rails_890a90efa9; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recaptcha_entries
    ADD CONSTRAINT fk_rails_890a90efa9 FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: work_packages fk_rails_931ad309e8; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_packages
    ADD CONSTRAINT fk_rails_931ad309e8 FOREIGN KEY (project_id) REFERENCES public.projects(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: projects_storages fk_rails_96ab713fe3; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.projects_storages
    ADD CONSTRAINT fk_rails_96ab713fe3 FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE CASCADE;


--
-- Name: webhooks_events fk_rails_a166925c91; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.webhooks_events
    ADD CONSTRAINT fk_rails_a166925c91 FOREIGN KEY (webhooks_webhook_id) REFERENCES public.webhooks_webhooks(id);


--
-- Name: file_links fk_rails_a29c1fb981; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.file_links
    ADD CONSTRAINT fk_rails_a29c1fb981 FOREIGN KEY (storage_id) REFERENCES public.storages(id) ON DELETE CASCADE;


--
-- Name: tokens fk_rails_ac8a5d0441; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tokens
    ADD CONSTRAINT fk_rails_ac8a5d0441 FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: projects_storages fk_rails_acca00a591; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.projects_storages
    ADD CONSTRAINT fk_rails_acca00a591 FOREIGN KEY (creator_id) REFERENCES public.users(id);


--
-- Name: oauth_access_grants fk_rails_b4b53e07b8; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth_access_grants
    ADD CONSTRAINT fk_rails_b4b53e07b8 FOREIGN KEY (application_id) REFERENCES public.oauth_applications(id);


--
-- Name: time_entry_activities_projects fk_rails_bc6c409022; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.time_entry_activities_projects
    ADD CONSTRAINT fk_rails_bc6c409022 FOREIGN KEY (activity_id) REFERENCES public.enumerations(id);


--
-- Name: oauth_applications fk_rails_cc886e315a; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth_applications
    ADD CONSTRAINT fk_rails_cc886e315a FOREIGN KEY (owner_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: webhooks_projects fk_rails_d7ea5de5b8; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.webhooks_projects
    ADD CONSTRAINT fk_rails_d7ea5de5b8 FOREIGN KEY (webhooks_webhook_id) REFERENCES public.webhooks_webhooks(id);


--
-- Name: webhooks_projects fk_rails_e978b5e3d7; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.webhooks_projects
    ADD CONSTRAINT fk_rails_e978b5e3d7 FOREIGN KEY (project_id) REFERENCES public.projects(id);


--
-- Name: ordered_work_packages fk_rails_e99c4d5dfe; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ordered_work_packages
    ADD CONSTRAINT fk_rails_e99c4d5dfe FOREIGN KEY (query_id) REFERENCES public.queries(id) ON DELETE CASCADE;


--
-- Name: views fk_rails_ef3c430897; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.views
    ADD CONSTRAINT fk_rails_ef3c430897 FOREIGN KEY (query_id) REFERENCES public.queries(id);


--
-- Name: time_entry_journals fk_rails_f6e3d60ab5; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.time_entry_journals
    ADD CONSTRAINT fk_rails_f6e3d60ab5 FOREIGN KEY (logged_by_id) REFERENCES public.users(id);


--
-- Name: bcf_viewpoints fk_rails_fa5c88e5be; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bcf_viewpoints
    ADD CONSTRAINT fk_rails_fa5c88e5be FOREIGN KEY (issue_id) REFERENCES public.bcf_issues(id) ON DELETE CASCADE;


--
-- Name: ordered_work_packages fk_rails_fe038e4e03; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ordered_work_packages
    ADD CONSTRAINT fk_rails_fe038e4e03 FOREIGN KEY (work_package_id) REFERENCES public.work_packages(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

