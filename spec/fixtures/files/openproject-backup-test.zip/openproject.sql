--
-- PostgreSQL database dump
--

-- Dumped from database version 14.8 (Ubuntu 14.8-0ubuntu0.22.04.1)
-- Dumped by pg_dump version 14.8 (Ubuntu 14.8-0ubuntu0.22.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: backup_preview_5; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA backup_preview_5;


--
-- Name: pg_trgm; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_trgm WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION pg_trgm; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION pg_trgm IS 'text similarity measurement and index searching based on trigrams';


--
-- Name: delayed_job_status; Type: TYPE; Schema: backup_preview_5; Owner: -
--

CREATE TYPE backup_preview_5.delayed_job_status AS ENUM (
    'in_queue',
    'error',
    'in_process',
    'success',
    'failure',
    'cancelled'
);


--
-- Name: project_folder_modes; Type: TYPE; Schema: backup_preview_5; Owner: -
--

CREATE TYPE backup_preview_5.project_folder_modes AS ENUM (
    'inactive',
    'manual',
    'automatic'
);


--
-- Name: delayed_job_status; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.delayed_job_status AS ENUM (
    'in_queue',
    'error',
    'in_process',
    'success',
    'failure',
    'cancelled'
);


--
-- Name: project_folder_modes; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.project_folder_modes AS ENUM (
    'inactive',
    'manual',
    'automatic'
);


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: announcements; Type: TABLE; Schema: backup_preview_5; Owner: -
--

CREATE TABLE backup_preview_5.announcements (
    id bigint NOT NULL,
    text text,
    show_until date,
    active boolean DEFAULT false,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


--
-- Name: announcements_id_seq; Type: SEQUENCE; Schema: backup_preview_5; Owner: -
--

CREATE SEQUENCE backup_preview_5.announcements_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: announcements_id_seq; Type: SEQUENCE OWNED BY; Schema: backup_preview_5; Owner: -
--

ALTER SEQUENCE backup_preview_5.announcements_id_seq OWNED BY backup_preview_5.announcements.id;


--
-- Name: ar_internal_metadata; Type: TABLE; Schema: backup_preview_5; Owner: -
--

CREATE TABLE backup_preview_5.ar_internal_metadata (
    key character varying NOT NULL,
    value character varying,
    created_at timestamp(6) with time zone NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL
);


--
-- Name: attachable_journals; Type: TABLE; Schema: backup_preview_5; Owner: -
--

CREATE TABLE backup_preview_5.attachable_journals (
    id bigint NOT NULL,
    journal_id bigint NOT NULL,
    attachment_id bigint NOT NULL,
    filename character varying NOT NULL
);


--
-- Name: attachable_journals_id_seq; Type: SEQUENCE; Schema: backup_preview_5; Owner: -
--

CREATE SEQUENCE backup_preview_5.attachable_journals_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: attachable_journals_id_seq; Type: SEQUENCE OWNED BY; Schema: backup_preview_5; Owner: -
--

ALTER SEQUENCE backup_preview_5.attachable_journals_id_seq OWNED BY backup_preview_5.attachable_journals.id;


--
-- Name: attachment_journals; Type: TABLE; Schema: backup_preview_5; Owner: -
--

CREATE TABLE backup_preview_5.attachment_journals (
    id bigint NOT NULL,
    container_id bigint,
    container_type character varying(30),
    filename character varying NOT NULL,
    disk_filename character varying NOT NULL,
    filesize bigint NOT NULL,
    content_type character varying,
    digest character varying(40) NOT NULL,
    downloads integer NOT NULL,
    author_id bigint NOT NULL,
    description text
);


--
-- Name: attachment_journals_id_seq; Type: SEQUENCE; Schema: backup_preview_5; Owner: -
--

CREATE SEQUENCE backup_preview_5.attachment_journals_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: attachment_journals_id_seq; Type: SEQUENCE OWNED BY; Schema: backup_preview_5; Owner: -
--

ALTER SEQUENCE backup_preview_5.attachment_journals_id_seq OWNED BY backup_preview_5.attachment_journals.id;


--
-- Name: attachments; Type: TABLE; Schema: backup_preview_5; Owner: -
--

CREATE TABLE backup_preview_5.attachments (
    id bigint NOT NULL,
    container_id bigint,
    container_type character varying(30),
    filename character varying DEFAULT ''::character varying NOT NULL,
    disk_filename character varying DEFAULT ''::character varying NOT NULL,
    filesize bigint DEFAULT 0 NOT NULL,
    content_type character varying DEFAULT ''::character varying,
    digest character varying(40) DEFAULT ''::character varying NOT NULL,
    downloads integer DEFAULT 0 NOT NULL,
    author_id bigint NOT NULL,
    created_at timestamp with time zone,
    description character varying,
    file character varying,
    fulltext text,
    fulltext_tsv tsvector,
    file_tsv tsvector,
    updated_at timestamp with time zone
);


--
-- Name: attachments_id_seq; Type: SEQUENCE; Schema: backup_preview_5; Owner: -
--

CREATE SEQUENCE backup_preview_5.attachments_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: attachments_id_seq; Type: SEQUENCE OWNED BY; Schema: backup_preview_5; Owner: -
--

ALTER SEQUENCE backup_preview_5.attachments_id_seq OWNED BY backup_preview_5.attachments.id;


--
-- Name: attribute_help_texts; Type: TABLE; Schema: backup_preview_5; Owner: -
--

CREATE TABLE backup_preview_5.attribute_help_texts (
    id bigint NOT NULL,
    help_text text NOT NULL,
    type character varying NOT NULL,
    attribute_name character varying NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- Name: attribute_help_texts_id_seq; Type: SEQUENCE; Schema: backup_preview_5; Owner: -
--

CREATE SEQUENCE backup_preview_5.attribute_help_texts_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: attribute_help_texts_id_seq; Type: SEQUENCE OWNED BY; Schema: backup_preview_5; Owner: -
--

ALTER SEQUENCE backup_preview_5.attribute_help_texts_id_seq OWNED BY backup_preview_5.attribute_help_texts.id;


--
-- Name: auth_sources; Type: TABLE; Schema: backup_preview_5; Owner: -
--

CREATE TABLE backup_preview_5.auth_sources (
    id bigint NOT NULL,
    type character varying(30) DEFAULT ''::character varying NOT NULL,
    name character varying(60) DEFAULT ''::character varying NOT NULL,
    host character varying(60),
    port integer,
    account character varying,
    account_password character varying DEFAULT ''::character varying,
    base_dn character varying,
    attr_login character varying(30),
    attr_firstname character varying(30),
    attr_lastname character varying(30),
    attr_mail character varying(30),
    onthefly_register boolean DEFAULT false NOT NULL,
    attr_admin character varying,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    tls_mode integer DEFAULT 0 NOT NULL,
    filter_string text,
    verify_peer boolean DEFAULT true NOT NULL,
    tls_certificate_string text
);


--
-- Name: auth_sources_id_seq; Type: SEQUENCE; Schema: backup_preview_5; Owner: -
--

CREATE SEQUENCE backup_preview_5.auth_sources_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: auth_sources_id_seq; Type: SEQUENCE OWNED BY; Schema: backup_preview_5; Owner: -
--

ALTER SEQUENCE backup_preview_5.auth_sources_id_seq OWNED BY backup_preview_5.auth_sources.id;


--
-- Name: backups; Type: TABLE; Schema: backup_preview_5; Owner: -
--

CREATE TABLE backup_preview_5.backups (
    id bigint NOT NULL,
    comment character varying,
    size_in_mb integer,
    creator_id bigint NOT NULL,
    created_at timestamp(6) with time zone NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL
);


--
-- Name: backups_id_seq; Type: SEQUENCE; Schema: backup_preview_5; Owner: -
--

CREATE SEQUENCE backup_preview_5.backups_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: backups_id_seq; Type: SEQUENCE OWNED BY; Schema: backup_preview_5; Owner: -
--

ALTER SEQUENCE backup_preview_5.backups_id_seq OWNED BY backup_preview_5.backups.id;


--
-- Name: bcf_comments; Type: TABLE; Schema: backup_preview_5; Owner: -
--

CREATE TABLE backup_preview_5.bcf_comments (
    id bigint NOT NULL,
    uuid text,
    journal_id bigint,
    issue_id bigint,
    viewpoint_id bigint,
    reply_to bigint
);


--
-- Name: bcf_comments_id_seq; Type: SEQUENCE; Schema: backup_preview_5; Owner: -
--

CREATE SEQUENCE backup_preview_5.bcf_comments_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bcf_comments_id_seq; Type: SEQUENCE OWNED BY; Schema: backup_preview_5; Owner: -
--

ALTER SEQUENCE backup_preview_5.bcf_comments_id_seq OWNED BY backup_preview_5.bcf_comments.id;


--
-- Name: bcf_issues; Type: TABLE; Schema: backup_preview_5; Owner: -
--

CREATE TABLE backup_preview_5.bcf_issues (
    id bigint NOT NULL,
    uuid text,
    markup xml,
    work_package_id bigint,
    stage character varying,
    index integer,
    labels text[] DEFAULT '{}'::text[],
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: bcf_issues_id_seq; Type: SEQUENCE; Schema: backup_preview_5; Owner: -
--

CREATE SEQUENCE backup_preview_5.bcf_issues_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bcf_issues_id_seq; Type: SEQUENCE OWNED BY; Schema: backup_preview_5; Owner: -
--

ALTER SEQUENCE backup_preview_5.bcf_issues_id_seq OWNED BY backup_preview_5.bcf_issues.id;


--
-- Name: bcf_viewpoints; Type: TABLE; Schema: backup_preview_5; Owner: -
--

CREATE TABLE backup_preview_5.bcf_viewpoints (
    id bigint NOT NULL,
    uuid text,
    viewpoint_name text,
    issue_id bigint,
    json_viewpoint jsonb,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: bcf_viewpoints_id_seq; Type: SEQUENCE; Schema: backup_preview_5; Owner: -
--

CREATE SEQUENCE backup_preview_5.bcf_viewpoints_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bcf_viewpoints_id_seq; Type: SEQUENCE OWNED BY; Schema: backup_preview_5; Owner: -
--

ALTER SEQUENCE backup_preview_5.bcf_viewpoints_id_seq OWNED BY backup_preview_5.bcf_viewpoints.id;


--
-- Name: budget_journals; Type: TABLE; Schema: backup_preview_5; Owner: -
--

CREATE TABLE backup_preview_5.budget_journals (
    id bigint NOT NULL,
    project_id bigint NOT NULL,
    author_id bigint NOT NULL,
    subject character varying NOT NULL,
    description text,
    fixed_date date NOT NULL
);


--
-- Name: budget_journals_id_seq; Type: SEQUENCE; Schema: backup_preview_5; Owner: -
--

CREATE SEQUENCE backup_preview_5.budget_journals_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: budget_journals_id_seq; Type: SEQUENCE OWNED BY; Schema: backup_preview_5; Owner: -
--

ALTER SEQUENCE backup_preview_5.budget_journals_id_seq OWNED BY backup_preview_5.budget_journals.id;


--
-- Name: budgets; Type: TABLE; Schema: backup_preview_5; Owner: -
--

CREATE TABLE backup_preview_5.budgets (
    id bigint NOT NULL,
    project_id bigint NOT NULL,
    author_id bigint NOT NULL,
    subject character varying NOT NULL,
    description text NOT NULL,
    fixed_date date NOT NULL,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


--
-- Name: budgets_id_seq; Type: SEQUENCE; Schema: backup_preview_5; Owner: -
--

CREATE SEQUENCE backup_preview_5.budgets_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: budgets_id_seq; Type: SEQUENCE OWNED BY; Schema: backup_preview_5; Owner: -
--

ALTER SEQUENCE backup_preview_5.budgets_id_seq OWNED BY backup_preview_5.budgets.id;


--
-- Name: categories; Type: TABLE; Schema: backup_preview_5; Owner: -
--

CREATE TABLE backup_preview_5.categories (
    id bigint NOT NULL,
    project_id bigint NOT NULL,
    name character varying(256) DEFAULT ''::character varying NOT NULL,
    assigned_to_id bigint,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- Name: categories_id_seq; Type: SEQUENCE; Schema: backup_preview_5; Owner: -
--

CREATE SEQUENCE backup_preview_5.categories_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: categories_id_seq; Type: SEQUENCE OWNED BY; Schema: backup_preview_5; Owner: -
--

ALTER SEQUENCE backup_preview_5.categories_id_seq OWNED BY backup_preview_5.categories.id;


--
-- Name: changes; Type: TABLE; Schema: backup_preview_5; Owner: -
--

CREATE TABLE backup_preview_5.changes (
    id bigint NOT NULL,
    changeset_id bigint NOT NULL,
    action character varying(1) DEFAULT ''::character varying NOT NULL,
    path text NOT NULL,
    from_path text,
    from_revision character varying,
    revision character varying,
    branch character varying
);


--
-- Name: changes_id_seq; Type: SEQUENCE; Schema: backup_preview_5; Owner: -
--

CREATE SEQUENCE backup_preview_5.changes_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: changes_id_seq; Type: SEQUENCE OWNED BY; Schema: backup_preview_5; Owner: -
--

ALTER SEQUENCE backup_preview_5.changes_id_seq OWNED BY backup_preview_5.changes.id;


--
-- Name: changeset_journals; Type: TABLE; Schema: backup_preview_5; Owner: -
--

CREATE TABLE backup_preview_5.changeset_journals (
    id bigint NOT NULL,
    repository_id bigint NOT NULL,
    revision character varying NOT NULL,
    committer character varying,
    committed_on timestamp with time zone NOT NULL,
    comments text,
    commit_date date,
    scmid character varying,
    user_id bigint
);


--
-- Name: changeset_journals_id_seq; Type: SEQUENCE; Schema: backup_preview_5; Owner: -
--

CREATE SEQUENCE backup_preview_5.changeset_journals_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: changeset_journals_id_seq; Type: SEQUENCE OWNED BY; Schema: backup_preview_5; Owner: -
--

ALTER SEQUENCE backup_preview_5.changeset_journals_id_seq OWNED BY backup_preview_5.changeset_journals.id;


--
-- Name: changesets; Type: TABLE; Schema: backup_preview_5; Owner: -
--

CREATE TABLE backup_preview_5.changesets (
    id bigint NOT NULL,
    repository_id bigint NOT NULL,
    revision character varying NOT NULL,
    committer character varying,
    committed_on timestamp with time zone NOT NULL,
    comments text,
    commit_date date,
    scmid character varying,
    user_id bigint
);


--
-- Name: changesets_id_seq; Type: SEQUENCE; Schema: backup_preview_5; Owner: -
--

CREATE SEQUENCE backup_preview_5.changesets_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: changesets_id_seq; Type: SEQUENCE OWNED BY; Schema: backup_preview_5; Owner: -
--

ALTER SEQUENCE backup_preview_5.changesets_id_seq OWNED BY backup_preview_5.changesets.id;


--
-- Name: changesets_work_packages; Type: TABLE; Schema: backup_preview_5; Owner: -
--

CREATE TABLE backup_preview_5.changesets_work_packages (
    changeset_id bigint NOT NULL,
    work_package_id bigint NOT NULL
);


--
-- Name: colors; Type: TABLE; Schema: backup_preview_5; Owner: -
--

CREATE TABLE backup_preview_5.colors (
    id bigint NOT NULL,
    name character varying NOT NULL,
    hexcode character varying NOT NULL,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


--
-- Name: colors_id_seq; Type: SEQUENCE; Schema: backup_preview_5; Owner: -
--

CREATE SEQUENCE backup_preview_5.colors_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: colors_id_seq; Type: SEQUENCE OWNED BY; Schema: backup_preview_5; Owner: -
--

ALTER SEQUENCE backup_preview_5.colors_id_seq OWNED BY backup_preview_5.colors.id;


--
-- Name: comments; Type: TABLE; Schema: backup_preview_5; Owner: -
--

CREATE TABLE backup_preview_5.comments (
    id bigint NOT NULL,
    commented_type character varying(30) DEFAULT ''::character varying NOT NULL,
    commented_id bigint NOT NULL,
    author_id bigint NOT NULL,
    comments text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: comments_id_seq; Type: SEQUENCE; Schema: backup_preview_5; Owner: -
--

CREATE SEQUENCE backup_preview_5.comments_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: comments_id_seq; Type: SEQUENCE OWNED BY; Schema: backup_preview_5; Owner: -
--

ALTER SEQUENCE backup_preview_5.comments_id_seq OWNED BY backup_preview_5.comments.id;


--
-- Name: cost_entries; Type: TABLE; Schema: backup_preview_5; Owner: -
--

CREATE TABLE backup_preview_5.cost_entries (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    project_id bigint NOT NULL,
    work_package_id bigint NOT NULL,
    cost_type_id bigint NOT NULL,
    units double precision NOT NULL,
    spent_on date NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    comments character varying NOT NULL,
    blocked boolean DEFAULT false NOT NULL,
    overridden_costs numeric(15,4),
    costs numeric(15,4),
    rate_id bigint,
    tyear integer NOT NULL,
    tmonth integer NOT NULL,
    tweek integer NOT NULL,
    logged_by_id bigint
);


--
-- Name: cost_entries_id_seq; Type: SEQUENCE; Schema: backup_preview_5; Owner: -
--

CREATE SEQUENCE backup_preview_5.cost_entries_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: cost_entries_id_seq; Type: SEQUENCE OWNED BY; Schema: backup_preview_5; Owner: -
--

ALTER SEQUENCE backup_preview_5.cost_entries_id_seq OWNED BY backup_preview_5.cost_entries.id;


--
-- Name: cost_queries; Type: TABLE; Schema: backup_preview_5; Owner: -
--

CREATE TABLE backup_preview_5.cost_queries (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    project_id bigint,
    name character varying NOT NULL,
    is_public boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    serialized character varying(2000) NOT NULL
);


--
-- Name: cost_queries_id_seq; Type: SEQUENCE; Schema: backup_preview_5; Owner: -
--

CREATE SEQUENCE backup_preview_5.cost_queries_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: cost_queries_id_seq; Type: SEQUENCE OWNED BY; Schema: backup_preview_5; Owner: -
--

ALTER SEQUENCE backup_preview_5.cost_queries_id_seq OWNED BY backup_preview_5.cost_queries.id;


--
-- Name: cost_types; Type: TABLE; Schema: backup_preview_5; Owner: -
--

CREATE TABLE backup_preview_5.cost_types (
    id bigint NOT NULL,
    name character varying NOT NULL,
    unit character varying NOT NULL,
    unit_plural character varying NOT NULL,
    "default" boolean DEFAULT false NOT NULL,
    deleted_at timestamp with time zone
);


--
-- Name: cost_types_id_seq; Type: SEQUENCE; Schema: backup_preview_5; Owner: -
--

CREATE SEQUENCE backup_preview_5.cost_types_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: cost_types_id_seq; Type: SEQUENCE OWNED BY; Schema: backup_preview_5; Owner: -
--

ALTER SEQUENCE backup_preview_5.cost_types_id_seq OWNED BY backup_preview_5.cost_types.id;


--
-- Name: custom_actions; Type: TABLE; Schema: backup_preview_5; Owner: -
--

CREATE TABLE backup_preview_5.custom_actions (
    id bigint NOT NULL,
    name character varying,
    actions text,
    description text,
    "position" integer
);


--
-- Name: custom_actions_id_seq; Type: SEQUENCE; Schema: backup_preview_5; Owner: -
--

CREATE SEQUENCE backup_preview_5.custom_actions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: custom_actions_id_seq; Type: SEQUENCE OWNED BY; Schema: backup_preview_5; Owner: -
--

ALTER SEQUENCE backup_preview_5.custom_actions_id_seq OWNED BY backup_preview_5.custom_actions.id;


--
-- Name: custom_actions_projects; Type: TABLE; Schema: backup_preview_5; Owner: -
--

CREATE TABLE backup_preview_5.custom_actions_projects (
    id bigint NOT NULL,
    project_id bigint,
    custom_action_id bigint
);


--
-- Name: custom_actions_projects_id_seq; Type: SEQUENCE; Schema: backup_preview_5; Owner: -
--

CREATE SEQUENCE backup_preview_5.custom_actions_projects_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: custom_actions_projects_id_seq; Type: SEQUENCE OWNED BY; Schema: backup_preview_5; Owner: -
--

ALTER SEQUENCE backup_preview_5.custom_actions_projects_id_seq OWNED BY backup_preview_5.custom_actions_projects.id;


--
-- Name: custom_actions_roles; Type: TABLE; Schema: backup_preview_5; Owner: -
--

CREATE TABLE backup_preview_5.custom_actions_roles (
    id bigint NOT NULL,
    role_id bigint,
    custom_action_id bigint
);


--
-- Name: custom_actions_roles_id_seq; Type: SEQUENCE; Schema: backup_preview_5; Owner: -
--

CREATE SEQUENCE backup_preview_5.custom_actions_roles_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: custom_actions_roles_id_seq; Type: SEQUENCE OWNED BY; Schema: backup_preview_5; Owner: -
--

ALTER SEQUENCE backup_preview_5.custom_actions_roles_id_seq OWNED BY backup_preview_5.custom_actions_roles.id;


--
-- Name: custom_actions_statuses; Type: TABLE; Schema: backup_preview_5; Owner: -
--

CREATE TABLE backup_preview_5.custom_actions_statuses (
    id bigint NOT NULL,
    status_id bigint,
    custom_action_id bigint
);


--
-- Name: custom_actions_statuses_id_seq; Type: SEQUENCE; Schema: backup_preview_5; Owner: -
--

CREATE SEQUENCE backup_preview_5.custom_actions_statuses_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: custom_actions_statuses_id_seq; Type: SEQUENCE OWNED BY; Schema: backup_preview_5; Owner: -
--

ALTER SEQUENCE backup_preview_5.custom_actions_statuses_id_seq OWNED BY backup_preview_5.custom_actions_statuses.id;


--
-- Name: custom_actions_types; Type: TABLE; Schema: backup_preview_5; Owner: -
--

CREATE TABLE backup_preview_5.custom_actions_types (
    id bigint NOT NULL,
    type_id bigint,
    custom_action_id bigint
);


--
-- Name: custom_actions_types_id_seq; Type: SEQUENCE; Schema: backup_preview_5; Owner: -
--

CREATE SEQUENCE backup_preview_5.custom_actions_types_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: custom_actions_types_id_seq; Type: SEQUENCE OWNED BY; Schema: backup_preview_5; Owner: -
--

ALTER SEQUENCE backup_preview_5.custom_actions_types_id_seq OWNED BY backup_preview_5.custom_actions_types.id;


--
-- Name: custom_fields; Type: TABLE; Schema: backup_preview_5; Owner: -
--

CREATE TABLE backup_preview_5.custom_fields (
    id bigint NOT NULL,
    type character varying(30) DEFAULT ''::character varying NOT NULL,
    field_format character varying(30) DEFAULT ''::character varying NOT NULL,
    regexp character varying DEFAULT ''::character varying,
    min_length integer DEFAULT 0 NOT NULL,
    max_length integer DEFAULT 0 NOT NULL,
    is_required boolean DEFAULT false NOT NULL,
    is_for_all boolean DEFAULT false NOT NULL,
    is_filter boolean DEFAULT false NOT NULL,
    "position" integer DEFAULT 1,
    searchable boolean DEFAULT false,
    editable boolean DEFAULT true,
    visible boolean DEFAULT true NOT NULL,
    multi_value boolean DEFAULT false,
    default_value text,
    name character varying,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    content_right_to_left boolean DEFAULT false
);


--
-- Name: custom_fields_id_seq; Type: SEQUENCE; Schema: backup_preview_5; Owner: -
--

CREATE SEQUENCE backup_preview_5.custom_fields_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: custom_fields_id_seq; Type: SEQUENCE OWNED BY; Schema: backup_preview_5; Owner: -
--

ALTER SEQUENCE backup_preview_5.custom_fields_id_seq OWNED BY backup_preview_5.custom_fields.id;


--
-- Name: custom_fields_projects; Type: TABLE; Schema: backup_preview_5; Owner: -
--

CREATE TABLE backup_preview_5.custom_fields_projects (
    custom_field_id bigint NOT NULL,
    project_id bigint NOT NULL
);


--
-- Name: custom_fields_types; Type: TABLE; Schema: backup_preview_5; Owner: -
--

CREATE TABLE backup_preview_5.custom_fields_types (
    custom_field_id bigint NOT NULL,
    type_id bigint NOT NULL
);


--
-- Name: custom_options; Type: TABLE; Schema: backup_preview_5; Owner: -
--

CREATE TABLE backup_preview_5.custom_options (
    id bigint NOT NULL,
    custom_field_id bigint,
    "position" integer,
    default_value boolean,
    value text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


--
-- Name: custom_options_id_seq; Type: SEQUENCE; Schema: backup_preview_5; Owner: -
--

CREATE SEQUENCE backup_preview_5.custom_options_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: custom_options_id_seq; Type: SEQUENCE OWNED BY; Schema: backup_preview_5; Owner: -
--

ALTER SEQUENCE backup_preview_5.custom_options_id_seq OWNED BY backup_preview_5.custom_options.id;


--
-- Name: custom_styles; Type: TABLE; Schema: backup_preview_5; Owner: -
--

CREATE TABLE backup_preview_5.custom_styles (
    id bigint NOT NULL,
    logo character varying,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    favicon character varying,
    touch_icon character varying,
    theme character varying DEFAULT 'OpenProject'::character varying,
    theme_logo character varying
);


--
-- Name: custom_styles_id_seq; Type: SEQUENCE; Schema: backup_preview_5; Owner: -
--

CREATE SEQUENCE backup_preview_5.custom_styles_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: custom_styles_id_seq; Type: SEQUENCE OWNED BY; Schema: backup_preview_5; Owner: -
--

ALTER SEQUENCE backup_preview_5.custom_styles_id_seq OWNED BY backup_preview_5.custom_styles.id;


--
-- Name: custom_values; Type: TABLE; Schema: backup_preview_5; Owner: -
--

CREATE TABLE backup_preview_5.custom_values (
    id bigint NOT NULL,
    customized_type character varying(30) DEFAULT ''::character varying NOT NULL,
    customized_id bigint NOT NULL,
    custom_field_id bigint NOT NULL,
    value text
);


--
-- Name: custom_values_id_seq; Type: SEQUENCE; Schema: backup_preview_5; Owner: -
--

CREATE SEQUENCE backup_preview_5.custom_values_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: custom_values_id_seq; Type: SEQUENCE OWNED BY; Schema: backup_preview_5; Owner: -
--

ALTER SEQUENCE backup_preview_5.custom_values_id_seq OWNED BY backup_preview_5.custom_values.id;


--
-- Name: customizable_journals; Type: TABLE; Schema: backup_preview_5; Owner: -
--

CREATE TABLE backup_preview_5.customizable_journals (
    id bigint NOT NULL,
    journal_id bigint NOT NULL,
    custom_field_id bigint NOT NULL,
    value text
);


--
-- Name: customizable_journals_id_seq; Type: SEQUENCE; Schema: backup_preview_5; Owner: -
--

CREATE SEQUENCE backup_preview_5.customizable_journals_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: customizable_journals_id_seq; Type: SEQUENCE OWNED BY; Schema: backup_preview_5; Owner: -
--

ALTER SEQUENCE backup_preview_5.customizable_journals_id_seq OWNED BY backup_preview_5.customizable_journals.id;


--
-- Name: delayed_job_statuses; Type: TABLE; Schema: backup_preview_5; Owner: -
--

CREATE TABLE backup_preview_5.delayed_job_statuses (
    id bigint NOT NULL,
    reference_type character varying,
    reference_id bigint,
    message character varying,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    status backup_preview_5.delayed_job_status DEFAULT 'in_queue'::backup_preview_5.delayed_job_status,
    user_id bigint,
    job_id character varying,
    payload jsonb
);


--
-- Name: delayed_job_statuses_id_seq; Type: SEQUENCE; Schema: backup_preview_5; Owner: -
--

CREATE SEQUENCE backup_preview_5.delayed_job_statuses_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: delayed_job_statuses_id_seq; Type: SEQUENCE OWNED BY; Schema: backup_preview_5; Owner: -
--

ALTER SEQUENCE backup_preview_5.delayed_job_statuses_id_seq OWNED BY backup_preview_5.delayed_job_statuses.id;


--
-- Name: delayed_jobs; Type: TABLE; Schema: backup_preview_5; Owner: -
--

CREATE TABLE backup_preview_5.delayed_jobs (
    id bigint NOT NULL,
    priority integer DEFAULT 0,
    attempts integer DEFAULT 0,
    handler text,
    last_error text,
    run_at timestamp with time zone,
    locked_at timestamp with time zone,
    failed_at timestamp with time zone,
    locked_by character varying,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    queue character varying,
    cron character varying
);


--
-- Name: delayed_jobs_id_seq; Type: SEQUENCE; Schema: backup_preview_5; Owner: -
--

CREATE SEQUENCE backup_preview_5.delayed_jobs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: delayed_jobs_id_seq; Type: SEQUENCE OWNED BY; Schema: backup_preview_5; Owner: -
--

ALTER SEQUENCE backup_preview_5.delayed_jobs_id_seq OWNED BY backup_preview_5.delayed_jobs.id;


--
-- Name: design_colors; Type: TABLE; Schema: backup_preview_5; Owner: -
--

CREATE TABLE backup_preview_5.design_colors (
    id bigint NOT NULL,
    variable character varying,
    hexcode character varying,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- Name: design_colors_id_seq; Type: SEQUENCE; Schema: backup_preview_5; Owner: -
--

CREATE SEQUENCE backup_preview_5.design_colors_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: design_colors_id_seq; Type: SEQUENCE OWNED BY; Schema: backup_preview_5; Owner: -
--

ALTER SEQUENCE backup_preview_5.design_colors_id_seq OWNED BY backup_preview_5.design_colors.id;


--
-- Name: document_journals; Type: TABLE; Schema: backup_preview_5; Owner: -
--

CREATE TABLE backup_preview_5.document_journals (
    id bigint NOT NULL,
    project_id bigint NOT NULL,
    category_id bigint NOT NULL,
    title character varying(60) NOT NULL,
    description text
);


--
-- Name: document_journals_id_seq; Type: SEQUENCE; Schema: backup_preview_5; Owner: -
--

CREATE SEQUENCE backup_preview_5.document_journals_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: document_journals_id_seq; Type: SEQUENCE OWNED BY; Schema: backup_preview_5; Owner: -
--

ALTER SEQUENCE backup_preview_5.document_journals_id_seq OWNED BY backup_preview_5.document_journals.id;


--
-- Name: documents; Type: TABLE; Schema: backup_preview_5; Owner: -
--

CREATE TABLE backup_preview_5.documents (
    id bigint NOT NULL,
    project_id bigint NOT NULL,
    category_id bigint NOT NULL,
    title character varying(60) DEFAULT ''::character varying NOT NULL,
    description text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


--
-- Name: documents_id_seq; Type: SEQUENCE; Schema: backup_preview_5; Owner: -
--

CREATE SEQUENCE backup_preview_5.documents_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: documents_id_seq; Type: SEQUENCE OWNED BY; Schema: backup_preview_5; Owner: -
--

ALTER SEQUENCE backup_preview_5.documents_id_seq OWNED BY backup_preview_5.documents.id;


--
-- Name: done_statuses_for_project; Type: TABLE; Schema: backup_preview_5; Owner: -
--

CREATE TABLE backup_preview_5.done_statuses_for_project (
    project_id bigint,
    status_id bigint
);


--
-- Name: enabled_modules; Type: TABLE; Schema: backup_preview_5; Owner: -
--

CREATE TABLE backup_preview_5.enabled_modules (
    id bigint NOT NULL,
    project_id bigint,
    name character varying NOT NULL
);


--
-- Name: enabled_modules_id_seq; Type: SEQUENCE; Schema: backup_preview_5; Owner: -
--

CREATE SEQUENCE backup_preview_5.enabled_modules_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: enabled_modules_id_seq; Type: SEQUENCE OWNED BY; Schema: backup_preview_5; Owner: -
--

ALTER SEQUENCE backup_preview_5.enabled_modules_id_seq OWNED BY backup_preview_5.enabled_modules.id;


--
-- Name: enterprise_tokens; Type: TABLE; Schema: backup_preview_5; Owner: -
--

CREATE TABLE backup_preview_5.enterprise_tokens (
    id bigint NOT NULL,
    encoded_token text,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- Name: enterprise_tokens_id_seq; Type: SEQUENCE; Schema: backup_preview_5; Owner: -
--

CREATE SEQUENCE backup_preview_5.enterprise_tokens_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: enterprise_tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: backup_preview_5; Owner: -
--

ALTER SEQUENCE backup_preview_5.enterprise_tokens_id_seq OWNED BY backup_preview_5.enterprise_tokens.id;


--
-- Name: enumerations; Type: TABLE; Schema: backup_preview_5; Owner: -
--

CREATE TABLE backup_preview_5.enumerations (
    id bigint NOT NULL,
    name character varying(30) DEFAULT ''::character varying NOT NULL,
    "position" integer DEFAULT 1,
    is_default boolean DEFAULT false NOT NULL,
    type character varying,
    active boolean DEFAULT true NOT NULL,
    project_id bigint,
    parent_id bigint,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    color_id bigint
);


--
-- Name: enumerations_id_seq; Type: SEQUENCE; Schema: backup_preview_5; Owner: -
--

CREATE SEQUENCE backup_preview_5.enumerations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: enumerations_id_seq; Type: SEQUENCE OWNED BY; Schema: backup_preview_5; Owner: -
--

ALTER SEQUENCE backup_preview_5.enumerations_id_seq OWNED BY backup_preview_5.enumerations.id;


--
-- Name: export_card_configurations; Type: TABLE; Schema: backup_preview_5; Owner: -
--

CREATE TABLE backup_preview_5.export_card_configurations (
    id bigint NOT NULL,
    name character varying,
    per_page integer,
    page_size character varying,
    orientation character varying,
    rows text,
    active boolean DEFAULT true,
    description text
);


--
-- Name: export_card_configurations_id_seq; Type: SEQUENCE; Schema: backup_preview_5; Owner: -
--

CREATE SEQUENCE backup_preview_5.export_card_configurations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: export_card_configurations_id_seq; Type: SEQUENCE OWNED BY; Schema: backup_preview_5; Owner: -
--

ALTER SEQUENCE backup_preview_5.export_card_configurations_id_seq OWNED BY backup_preview_5.export_card_configurations.id;


--
-- Name: exports; Type: TABLE; Schema: backup_preview_5; Owner: -
--

CREATE TABLE backup_preview_5.exports (
    id bigint NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    type character varying
);


--
-- Name: exports_id_seq; Type: SEQUENCE; Schema: backup_preview_5; Owner: -
--

CREATE SEQUENCE backup_preview_5.exports_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: exports_id_seq; Type: SEQUENCE OWNED BY; Schema: backup_preview_5; Owner: -
--

ALTER SEQUENCE backup_preview_5.exports_id_seq OWNED BY backup_preview_5.exports.id;


--
-- Name: file_links; Type: TABLE; Schema: backup_preview_5; Owner: -
--

CREATE TABLE backup_preview_5.file_links (
    id bigint NOT NULL,
    storage_id bigint,
    creator_id bigint NOT NULL,
    container_id bigint,
    container_type character varying,
    origin_id character varying,
    origin_name character varying,
    origin_created_by_name character varying,
    origin_last_modified_by_name character varying,
    origin_mime_type character varying,
    origin_created_at timestamp with time zone,
    origin_updated_at timestamp with time zone,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- Name: file_links_id_seq; Type: SEQUENCE; Schema: backup_preview_5; Owner: -
--

CREATE SEQUENCE backup_preview_5.file_links_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: file_links_id_seq; Type: SEQUENCE OWNED BY; Schema: backup_preview_5; Owner: -
--

ALTER SEQUENCE backup_preview_5.file_links_id_seq OWNED BY backup_preview_5.file_links.id;


--
-- Name: forums; Type: TABLE; Schema: backup_preview_5; Owner: -
--

CREATE TABLE backup_preview_5.forums (
    id bigint NOT NULL,
    project_id bigint NOT NULL,
    name character varying DEFAULT ''::character varying NOT NULL,
    description character varying,
    "position" integer DEFAULT 1,
    topics_count integer DEFAULT 0 NOT NULL,
    messages_count integer DEFAULT 0 NOT NULL,
    last_message_id bigint
);


--
-- Name: forums_id_seq; Type: SEQUENCE; Schema: backup_preview_5; Owner: -
--

CREATE SEQUENCE backup_preview_5.forums_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: forums_id_seq; Type: SEQUENCE OWNED BY; Schema: backup_preview_5; Owner: -
--

ALTER SEQUENCE backup_preview_5.forums_id_seq OWNED BY backup_preview_5.forums.id;


--
-- Name: github_check_runs; Type: TABLE; Schema: backup_preview_5; Owner: -
--

CREATE TABLE backup_preview_5.github_check_runs (
    id bigint NOT NULL,
    github_pull_request_id bigint NOT NULL,
    github_id bigint NOT NULL,
    github_html_url character varying NOT NULL,
    app_id bigint NOT NULL,
    github_app_owner_avatar_url character varying NOT NULL,
    status character varying NOT NULL,
    name character varying NOT NULL,
    conclusion character varying,
    output_title character varying,
    output_summary character varying,
    details_url character varying,
    started_at timestamp with time zone,
    completed_at timestamp with time zone,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- Name: github_check_runs_id_seq; Type: SEQUENCE; Schema: backup_preview_5; Owner: -
--

CREATE SEQUENCE backup_preview_5.github_check_runs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: github_check_runs_id_seq; Type: SEQUENCE OWNED BY; Schema: backup_preview_5; Owner: -
--

ALTER SEQUENCE backup_preview_5.github_check_runs_id_seq OWNED BY backup_preview_5.github_check_runs.id;


--
-- Name: github_pull_requests; Type: TABLE; Schema: backup_preview_5; Owner: -
--

CREATE TABLE backup_preview_5.github_pull_requests (
    id bigint NOT NULL,
    github_user_id bigint,
    merged_by_id bigint,
    github_id bigint,
    number integer NOT NULL,
    github_html_url character varying NOT NULL,
    state character varying NOT NULL,
    repository character varying NOT NULL,
    github_updated_at timestamp with time zone,
    title character varying,
    body text,
    draft boolean,
    merged boolean,
    merged_at timestamp with time zone,
    comments_count integer,
    review_comments_count integer,
    additions_count integer,
    deletions_count integer,
    changed_files_count integer,
    labels json,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    repository_html_url character varying
);


--
-- Name: github_pull_requests_id_seq; Type: SEQUENCE; Schema: backup_preview_5; Owner: -
--

CREATE SEQUENCE backup_preview_5.github_pull_requests_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: github_pull_requests_id_seq; Type: SEQUENCE OWNED BY; Schema: backup_preview_5; Owner: -
--

ALTER SEQUENCE backup_preview_5.github_pull_requests_id_seq OWNED BY backup_preview_5.github_pull_requests.id;


--
-- Name: github_pull_requests_work_packages; Type: TABLE; Schema: backup_preview_5; Owner: -
--

CREATE TABLE backup_preview_5.github_pull_requests_work_packages (
    github_pull_request_id bigint NOT NULL,
    work_package_id bigint NOT NULL
);


--
-- Name: github_users; Type: TABLE; Schema: backup_preview_5; Owner: -
--

CREATE TABLE backup_preview_5.github_users (
    id bigint NOT NULL,
    github_id bigint NOT NULL,
    github_login character varying NOT NULL,
    github_html_url character varying NOT NULL,
    github_avatar_url character varying NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- Name: github_users_id_seq; Type: SEQUENCE; Schema: backup_preview_5; Owner: -
--

CREATE SEQUENCE backup_preview_5.github_users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: github_users_id_seq; Type: SEQUENCE OWNED BY; Schema: backup_preview_5; Owner: -
--

ALTER SEQUENCE backup_preview_5.github_users_id_seq OWNED BY backup_preview_5.github_users.id;


--
-- Name: grid_widgets; Type: TABLE; Schema: backup_preview_5; Owner: -
--

CREATE TABLE backup_preview_5.grid_widgets (
    id bigint NOT NULL,
    start_row integer NOT NULL,
    end_row integer NOT NULL,
    start_column integer NOT NULL,
    end_column integer NOT NULL,
    identifier character varying,
    options text,
    grid_id bigint
);


--
-- Name: grid_widgets_id_seq; Type: SEQUENCE; Schema: backup_preview_5; Owner: -
--

CREATE SEQUENCE backup_preview_5.grid_widgets_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: grid_widgets_id_seq; Type: SEQUENCE OWNED BY; Schema: backup_preview_5; Owner: -
--

ALTER SEQUENCE backup_preview_5.grid_widgets_id_seq OWNED BY backup_preview_5.grid_widgets.id;


--
-- Name: grids; Type: TABLE; Schema: backup_preview_5; Owner: -
--

CREATE TABLE backup_preview_5.grids (
    id bigint NOT NULL,
    row_count integer NOT NULL,
    column_count integer NOT NULL,
    type character varying,
    user_id bigint,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    project_id bigint,
    name text,
    options text
);


--
-- Name: grids_id_seq; Type: SEQUENCE; Schema: backup_preview_5; Owner: -
--

CREATE SEQUENCE backup_preview_5.grids_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: grids_id_seq; Type: SEQUENCE OWNED BY; Schema: backup_preview_5; Owner: -
--

ALTER SEQUENCE backup_preview_5.grids_id_seq OWNED BY backup_preview_5.grids.id;


--
-- Name: group_users; Type: TABLE; Schema: backup_preview_5; Owner: -
--

CREATE TABLE backup_preview_5.group_users (
    group_id bigint NOT NULL,
    user_id bigint NOT NULL,
    id bigint NOT NULL
);


--
-- Name: group_users_id_seq; Type: SEQUENCE; Schema: backup_preview_5; Owner: -
--

CREATE SEQUENCE backup_preview_5.group_users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: group_users_id_seq; Type: SEQUENCE OWNED BY; Schema: backup_preview_5; Owner: -
--

ALTER SEQUENCE backup_preview_5.group_users_id_seq OWNED BY backup_preview_5.group_users.id;


--
-- Name: ical_token_query_assignments; Type: TABLE; Schema: backup_preview_5; Owner: -
--

CREATE TABLE backup_preview_5.ical_token_query_assignments (
    id bigint NOT NULL,
    ical_token_id bigint,
    query_id bigint,
    created_at timestamp(6) with time zone NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    name character varying NOT NULL
);


--
-- Name: ical_token_query_assignments_id_seq; Type: SEQUENCE; Schema: backup_preview_5; Owner: -
--

CREATE SEQUENCE backup_preview_5.ical_token_query_assignments_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ical_token_query_assignments_id_seq; Type: SEQUENCE OWNED BY; Schema: backup_preview_5; Owner: -
--

ALTER SEQUENCE backup_preview_5.ical_token_query_assignments_id_seq OWNED BY backup_preview_5.ical_token_query_assignments.id;


--
-- Name: ifc_models; Type: TABLE; Schema: backup_preview_5; Owner: -
--

CREATE TABLE backup_preview_5.ifc_models (
    id bigint NOT NULL,
    title character varying,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    project_id bigint,
    uploader_id bigint,
    is_default boolean DEFAULT false NOT NULL,
    conversion_status integer DEFAULT 0,
    conversion_error_message text
);


--
-- Name: ifc_models_id_seq; Type: SEQUENCE; Schema: backup_preview_5; Owner: -
--

CREATE SEQUENCE backup_preview_5.ifc_models_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ifc_models_id_seq; Type: SEQUENCE OWNED BY; Schema: backup_preview_5; Owner: -
--

ALTER SEQUENCE backup_preview_5.ifc_models_id_seq OWNED BY backup_preview_5.ifc_models.id;


--
-- Name: journals; Type: TABLE; Schema: backup_preview_5; Owner: -
--

CREATE TABLE backup_preview_5.journals (
    id bigint NOT NULL,
    journable_type character varying,
    journable_id bigint,
    user_id bigint NOT NULL,
    notes text,
    created_at timestamp with time zone NOT NULL,
    version integer DEFAULT 0 NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    data_type character varying NOT NULL,
    data_id bigint NOT NULL
);


--
-- Name: journals_id_seq; Type: SEQUENCE; Schema: backup_preview_5; Owner: -
--

CREATE SEQUENCE backup_preview_5.journals_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: journals_id_seq; Type: SEQUENCE OWNED BY; Schema: backup_preview_5; Owner: -
--

ALTER SEQUENCE backup_preview_5.journals_id_seq OWNED BY backup_preview_5.journals.id;


--
-- Name: labor_budget_items; Type: TABLE; Schema: backup_preview_5; Owner: -
--

CREATE TABLE backup_preview_5.labor_budget_items (
    id bigint NOT NULL,
    budget_id bigint NOT NULL,
    hours double precision NOT NULL,
    user_id bigint,
    comments character varying DEFAULT ''::character varying NOT NULL,
    amount numeric(15,4)
);


--
-- Name: labor_budget_items_id_seq; Type: SEQUENCE; Schema: backup_preview_5; Owner: -
--

CREATE SEQUENCE backup_preview_5.labor_budget_items_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: labor_budget_items_id_seq; Type: SEQUENCE OWNED BY; Schema: backup_preview_5; Owner: -
--

ALTER SEQUENCE backup_preview_5.labor_budget_items_id_seq OWNED BY backup_preview_5.labor_budget_items.id;


--
-- Name: last_project_folders; Type: TABLE; Schema: backup_preview_5; Owner: -
--

CREATE TABLE backup_preview_5.last_project_folders (
    id bigint NOT NULL,
    projects_storage_id bigint NOT NULL,
    origin_folder_id character varying,
    mode backup_preview_5.project_folder_modes DEFAULT 'inactive'::backup_preview_5.project_folder_modes NOT NULL,
    created_at timestamp(6) with time zone NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL
);


--
-- Name: last_project_folders_id_seq; Type: SEQUENCE; Schema: backup_preview_5; Owner: -
--

CREATE SEQUENCE backup_preview_5.last_project_folders_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: last_project_folders_id_seq; Type: SEQUENCE OWNED BY; Schema: backup_preview_5; Owner: -
--

ALTER SEQUENCE backup_preview_5.last_project_folders_id_seq OWNED BY backup_preview_5.last_project_folders.id;


--
-- Name: ldap_groups_memberships; Type: TABLE; Schema: backup_preview_5; Owner: -
--

CREATE TABLE backup_preview_5.ldap_groups_memberships (
    id bigint NOT NULL,
    user_id bigint,
    group_id bigint,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: ldap_groups_memberships_id_seq; Type: SEQUENCE; Schema: backup_preview_5; Owner: -
--

CREATE SEQUENCE backup_preview_5.ldap_groups_memberships_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ldap_groups_memberships_id_seq; Type: SEQUENCE OWNED BY; Schema: backup_preview_5; Owner: -
--

ALTER SEQUENCE backup_preview_5.ldap_groups_memberships_id_seq OWNED BY backup_preview_5.ldap_groups_memberships.id;


--
-- Name: ldap_groups_synchronized_filters; Type: TABLE; Schema: backup_preview_5; Owner: -
--

CREATE TABLE backup_preview_5.ldap_groups_synchronized_filters (
    id bigint NOT NULL,
    name character varying,
    group_name_attribute character varying,
    filter_string character varying,
    auth_source_id bigint,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    base_dn text,
    sync_users boolean DEFAULT false NOT NULL
);


--
-- Name: ldap_groups_synchronized_filters_id_seq; Type: SEQUENCE; Schema: backup_preview_5; Owner: -
--

CREATE SEQUENCE backup_preview_5.ldap_groups_synchronized_filters_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ldap_groups_synchronized_filters_id_seq; Type: SEQUENCE OWNED BY; Schema: backup_preview_5; Owner: -
--

ALTER SEQUENCE backup_preview_5.ldap_groups_synchronized_filters_id_seq OWNED BY backup_preview_5.ldap_groups_synchronized_filters.id;


--
-- Name: ldap_groups_synchronized_groups; Type: TABLE; Schema: backup_preview_5; Owner: -
--

CREATE TABLE backup_preview_5.ldap_groups_synchronized_groups (
    id bigint NOT NULL,
    group_id bigint,
    auth_source_id bigint,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    dn text,
    users_count integer DEFAULT 0 NOT NULL,
    filter_id bigint,
    sync_users boolean DEFAULT false NOT NULL
);


--
-- Name: ldap_groups_synchronized_groups_id_seq; Type: SEQUENCE; Schema: backup_preview_5; Owner: -
--

CREATE SEQUENCE backup_preview_5.ldap_groups_synchronized_groups_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ldap_groups_synchronized_groups_id_seq; Type: SEQUENCE OWNED BY; Schema: backup_preview_5; Owner: -
--

ALTER SEQUENCE backup_preview_5.ldap_groups_synchronized_groups_id_seq OWNED BY backup_preview_5.ldap_groups_synchronized_groups.id;


--
-- Name: material_budget_items; Type: TABLE; Schema: backup_preview_5; Owner: -
--

CREATE TABLE backup_preview_5.material_budget_items (
    id bigint NOT NULL,
    budget_id bigint NOT NULL,
    units double precision NOT NULL,
    cost_type_id bigint,
    comments character varying DEFAULT ''::character varying NOT NULL,
    amount numeric(15,4)
);


--
-- Name: material_budget_items_id_seq; Type: SEQUENCE; Schema: backup_preview_5; Owner: -
--

CREATE SEQUENCE backup_preview_5.material_budget_items_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: material_budget_items_id_seq; Type: SEQUENCE OWNED BY; Schema: backup_preview_5; Owner: -
--

ALTER SEQUENCE backup_preview_5.material_budget_items_id_seq OWNED BY backup_preview_5.material_budget_items.id;


--
-- Name: meeting_content_journals; Type: TABLE; Schema: backup_preview_5; Owner: -
--

CREATE TABLE backup_preview_5.meeting_content_journals (
    id bigint NOT NULL,
    meeting_id bigint,
    author_id bigint,
    text text,
    locked boolean
);


--
-- Name: meeting_content_journals_id_seq; Type: SEQUENCE; Schema: backup_preview_5; Owner: -
--

CREATE SEQUENCE backup_preview_5.meeting_content_journals_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: meeting_content_journals_id_seq; Type: SEQUENCE OWNED BY; Schema: backup_preview_5; Owner: -
--

ALTER SEQUENCE backup_preview_5.meeting_content_journals_id_seq OWNED BY backup_preview_5.meeting_content_journals.id;


--
-- Name: meeting_contents; Type: TABLE; Schema: backup_preview_5; Owner: -
--

CREATE TABLE backup_preview_5.meeting_contents (
    id bigint NOT NULL,
    type character varying,
    meeting_id bigint,
    author_id bigint,
    text text,
    lock_version integer,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    locked boolean DEFAULT false
);


--
-- Name: meeting_contents_id_seq; Type: SEQUENCE; Schema: backup_preview_5; Owner: -
--

CREATE SEQUENCE backup_preview_5.meeting_contents_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: meeting_contents_id_seq; Type: SEQUENCE OWNED BY; Schema: backup_preview_5; Owner: -
--

ALTER SEQUENCE backup_preview_5.meeting_contents_id_seq OWNED BY backup_preview_5.meeting_contents.id;


--
-- Name: meeting_journals; Type: TABLE; Schema: backup_preview_5; Owner: -
--

CREATE TABLE backup_preview_5.meeting_journals (
    id bigint NOT NULL,
    title character varying,
    author_id bigint,
    project_id bigint,
    location character varying,
    start_time timestamp with time zone,
    duration double precision
);


--
-- Name: meeting_journals_id_seq; Type: SEQUENCE; Schema: backup_preview_5; Owner: -
--

CREATE SEQUENCE backup_preview_5.meeting_journals_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: meeting_journals_id_seq; Type: SEQUENCE OWNED BY; Schema: backup_preview_5; Owner: -
--

ALTER SEQUENCE backup_preview_5.meeting_journals_id_seq OWNED BY backup_preview_5.meeting_journals.id;


--
-- Name: meeting_participants; Type: TABLE; Schema: backup_preview_5; Owner: -
--

CREATE TABLE backup_preview_5.meeting_participants (
    id bigint NOT NULL,
    user_id bigint,
    meeting_id bigint,
    email character varying,
    name character varying,
    invited boolean,
    attended boolean,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- Name: meeting_participants_id_seq; Type: SEQUENCE; Schema: backup_preview_5; Owner: -
--

CREATE SEQUENCE backup_preview_5.meeting_participants_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: meeting_participants_id_seq; Type: SEQUENCE OWNED BY; Schema: backup_preview_5; Owner: -
--

ALTER SEQUENCE backup_preview_5.meeting_participants_id_seq OWNED BY backup_preview_5.meeting_participants.id;


--
-- Name: meetings; Type: TABLE; Schema: backup_preview_5; Owner: -
--

CREATE TABLE backup_preview_5.meetings (
    id bigint NOT NULL,
    title character varying,
    author_id bigint,
    project_id bigint,
    location character varying,
    start_time timestamp with time zone,
    duration double precision,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- Name: meetings_id_seq; Type: SEQUENCE; Schema: backup_preview_5; Owner: -
--

CREATE SEQUENCE backup_preview_5.meetings_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: meetings_id_seq; Type: SEQUENCE OWNED BY; Schema: backup_preview_5; Owner: -
--

ALTER SEQUENCE backup_preview_5.meetings_id_seq OWNED BY backup_preview_5.meetings.id;


--
-- Name: member_roles; Type: TABLE; Schema: backup_preview_5; Owner: -
--

CREATE TABLE backup_preview_5.member_roles (
    id bigint NOT NULL,
    member_id bigint NOT NULL,
    role_id bigint NOT NULL,
    inherited_from bigint
);


--
-- Name: member_roles_id_seq; Type: SEQUENCE; Schema: backup_preview_5; Owner: -
--

CREATE SEQUENCE backup_preview_5.member_roles_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: member_roles_id_seq; Type: SEQUENCE OWNED BY; Schema: backup_preview_5; Owner: -
--

ALTER SEQUENCE backup_preview_5.member_roles_id_seq OWNED BY backup_preview_5.member_roles.id;


--
-- Name: members; Type: TABLE; Schema: backup_preview_5; Owner: -
--

CREATE TABLE backup_preview_5.members (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    project_id bigint,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: members_id_seq; Type: SEQUENCE; Schema: backup_preview_5; Owner: -
--

CREATE SEQUENCE backup_preview_5.members_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: members_id_seq; Type: SEQUENCE OWNED BY; Schema: backup_preview_5; Owner: -
--

ALTER SEQUENCE backup_preview_5.members_id_seq OWNED BY backup_preview_5.members.id;


--
-- Name: menu_items; Type: TABLE; Schema: backup_preview_5; Owner: -
--

CREATE TABLE backup_preview_5.menu_items (
    id bigint NOT NULL,
    name character varying,
    title character varying,
    parent_id bigint,
    options text,
    navigatable_id bigint,
    type character varying
);


--
-- Name: menu_items_id_seq; Type: SEQUENCE; Schema: backup_preview_5; Owner: -
--

CREATE SEQUENCE backup_preview_5.menu_items_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: menu_items_id_seq; Type: SEQUENCE OWNED BY; Schema: backup_preview_5; Owner: -
--

ALTER SEQUENCE backup_preview_5.menu_items_id_seq OWNED BY backup_preview_5.menu_items.id;


--
-- Name: message_journals; Type: TABLE; Schema: backup_preview_5; Owner: -
--

CREATE TABLE backup_preview_5.message_journals (
    id bigint NOT NULL,
    forum_id bigint NOT NULL,
    parent_id bigint,
    subject character varying NOT NULL,
    content text,
    author_id bigint,
    locked boolean,
    sticky integer
);


--
-- Name: message_journals_id_seq; Type: SEQUENCE; Schema: backup_preview_5; Owner: -
--

CREATE SEQUENCE backup_preview_5.message_journals_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: message_journals_id_seq; Type: SEQUENCE OWNED BY; Schema: backup_preview_5; Owner: -
--

ALTER SEQUENCE backup_preview_5.message_journals_id_seq OWNED BY backup_preview_5.message_journals.id;


--
-- Name: messages; Type: TABLE; Schema: backup_preview_5; Owner: -
--

CREATE TABLE backup_preview_5.messages (
    id bigint NOT NULL,
    forum_id bigint NOT NULL,
    parent_id bigint,
    subject character varying DEFAULT ''::character varying NOT NULL,
    content text,
    author_id bigint,
    replies_count integer DEFAULT 0 NOT NULL,
    last_reply_id bigint,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    locked boolean DEFAULT false,
    sticky integer DEFAULT 0,
    sticked_on timestamp with time zone
);


--
-- Name: messages_id_seq; Type: SEQUENCE; Schema: backup_preview_5; Owner: -
--

CREATE SEQUENCE backup_preview_5.messages_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: messages_id_seq; Type: SEQUENCE OWNED BY; Schema: backup_preview_5; Owner: -
--

ALTER SEQUENCE backup_preview_5.messages_id_seq OWNED BY backup_preview_5.messages.id;


--
-- Name: news; Type: TABLE; Schema: backup_preview_5; Owner: -
--

CREATE TABLE backup_preview_5.news (
    id bigint NOT NULL,
    project_id bigint,
    title character varying(60) DEFAULT ''::character varying NOT NULL,
    summary character varying DEFAULT ''::character varying,
    description text,
    author_id bigint NOT NULL,
    created_at timestamp with time zone,
    comments_count integer DEFAULT 0 NOT NULL,
    updated_at timestamp with time zone
);


--
-- Name: news_id_seq; Type: SEQUENCE; Schema: backup_preview_5; Owner: -
--

CREATE SEQUENCE backup_preview_5.news_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: news_id_seq; Type: SEQUENCE OWNED BY; Schema: backup_preview_5; Owner: -
--

ALTER SEQUENCE backup_preview_5.news_id_seq OWNED BY backup_preview_5.news.id;


--
-- Name: news_journals; Type: TABLE; Schema: backup_preview_5; Owner: -
--

CREATE TABLE backup_preview_5.news_journals (
    id bigint NOT NULL,
    project_id bigint,
    title character varying(60) NOT NULL,
    summary character varying,
    description text,
    author_id bigint NOT NULL,
    comments_count integer NOT NULL
);


--
-- Name: news_journals_id_seq; Type: SEQUENCE; Schema: backup_preview_5; Owner: -
--

CREATE SEQUENCE backup_preview_5.news_journals_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: news_journals_id_seq; Type: SEQUENCE OWNED BY; Schema: backup_preview_5; Owner: -
--

ALTER SEQUENCE backup_preview_5.news_journals_id_seq OWNED BY backup_preview_5.news_journals.id;


--
-- Name: non_working_days; Type: TABLE; Schema: backup_preview_5; Owner: -
--

CREATE TABLE backup_preview_5.non_working_days (
    id bigint NOT NULL,
    name character varying NOT NULL,
    date date NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- Name: non_working_days_id_seq; Type: SEQUENCE; Schema: backup_preview_5; Owner: -
--

CREATE SEQUENCE backup_preview_5.non_working_days_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: non_working_days_id_seq; Type: SEQUENCE OWNED BY; Schema: backup_preview_5; Owner: -
--

ALTER SEQUENCE backup_preview_5.non_working_days_id_seq OWNED BY backup_preview_5.non_working_days.id;


--
-- Name: notification_settings; Type: TABLE; Schema: backup_preview_5; Owner: -
--

CREATE TABLE backup_preview_5.notification_settings (
    id bigint NOT NULL,
    project_id bigint,
    user_id bigint NOT NULL,
    watched boolean DEFAULT true,
    mentioned boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    work_package_commented boolean DEFAULT false,
    work_package_created boolean DEFAULT false,
    work_package_processed boolean DEFAULT false,
    work_package_prioritized boolean DEFAULT false,
    work_package_scheduled boolean DEFAULT false,
    news_added boolean DEFAULT false,
    news_commented boolean DEFAULT false,
    document_added boolean DEFAULT false,
    forum_messages boolean DEFAULT false,
    wiki_page_added boolean DEFAULT false,
    wiki_page_updated boolean DEFAULT false,
    membership_added boolean DEFAULT false,
    membership_updated boolean DEFAULT false,
    start_date integer DEFAULT 1,
    due_date integer DEFAULT 1,
    overdue integer,
    assignee boolean DEFAULT true NOT NULL,
    responsible boolean DEFAULT true NOT NULL
);


--
-- Name: notification_settings_id_seq; Type: SEQUENCE; Schema: backup_preview_5; Owner: -
--

CREATE SEQUENCE backup_preview_5.notification_settings_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: notification_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: backup_preview_5; Owner: -
--

ALTER SEQUENCE backup_preview_5.notification_settings_id_seq OWNED BY backup_preview_5.notification_settings.id;


--
-- Name: notifications; Type: TABLE; Schema: backup_preview_5; Owner: -
--

CREATE TABLE backup_preview_5.notifications (
    id bigint NOT NULL,
    subject text,
    read_ian boolean DEFAULT false,
    reason smallint,
    recipient_id bigint NOT NULL,
    actor_id bigint,
    resource_type character varying NOT NULL,
    resource_id bigint NOT NULL,
    project_id bigint,
    journal_id bigint,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    mail_reminder_sent boolean DEFAULT false,
    mail_alert_sent boolean
);


--
-- Name: notifications_id_seq; Type: SEQUENCE; Schema: backup_preview_5; Owner: -
--

CREATE SEQUENCE backup_preview_5.notifications_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: notifications_id_seq; Type: SEQUENCE OWNED BY; Schema: backup_preview_5; Owner: -
--

ALTER SEQUENCE backup_preview_5.notifications_id_seq OWNED BY backup_preview_5.notifications.id;


--
-- Name: oauth_access_grants; Type: TABLE; Schema: backup_preview_5; Owner: -
--

CREATE TABLE backup_preview_5.oauth_access_grants (
    id bigint NOT NULL,
    resource_owner_id bigint NOT NULL,
    application_id bigint NOT NULL,
    token character varying NOT NULL,
    expires_in integer NOT NULL,
    redirect_uri text NOT NULL,
    created_at timestamp with time zone NOT NULL,
    revoked_at timestamp with time zone,
    scopes character varying,
    code_challenge character varying,
    code_challenge_method character varying
);


--
-- Name: oauth_access_grants_id_seq; Type: SEQUENCE; Schema: backup_preview_5; Owner: -
--

CREATE SEQUENCE backup_preview_5.oauth_access_grants_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: oauth_access_grants_id_seq; Type: SEQUENCE OWNED BY; Schema: backup_preview_5; Owner: -
--

ALTER SEQUENCE backup_preview_5.oauth_access_grants_id_seq OWNED BY backup_preview_5.oauth_access_grants.id;


--
-- Name: oauth_access_tokens; Type: TABLE; Schema: backup_preview_5; Owner: -
--

CREATE TABLE backup_preview_5.oauth_access_tokens (
    id bigint NOT NULL,
    resource_owner_id bigint,
    application_id bigint,
    token character varying NOT NULL,
    refresh_token character varying,
    expires_in integer,
    revoked_at timestamp with time zone,
    created_at timestamp with time zone NOT NULL,
    scopes character varying,
    previous_refresh_token character varying DEFAULT ''::character varying NOT NULL
);


--
-- Name: oauth_access_tokens_id_seq; Type: SEQUENCE; Schema: backup_preview_5; Owner: -
--

CREATE SEQUENCE backup_preview_5.oauth_access_tokens_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: oauth_access_tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: backup_preview_5; Owner: -
--

ALTER SEQUENCE backup_preview_5.oauth_access_tokens_id_seq OWNED BY backup_preview_5.oauth_access_tokens.id;


--
-- Name: oauth_applications; Type: TABLE; Schema: backup_preview_5; Owner: -
--

CREATE TABLE backup_preview_5.oauth_applications (
    id bigint NOT NULL,
    name character varying NOT NULL,
    uid character varying NOT NULL,
    secret character varying NOT NULL,
    owner_type character varying,
    owner_id bigint,
    client_credentials_user_id bigint,
    redirect_uri text NOT NULL,
    scopes character varying DEFAULT ''::character varying NOT NULL,
    confidential boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    integration_type character varying,
    integration_id bigint
);


--
-- Name: oauth_applications_id_seq; Type: SEQUENCE; Schema: backup_preview_5; Owner: -
--

CREATE SEQUENCE backup_preview_5.oauth_applications_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: oauth_applications_id_seq; Type: SEQUENCE OWNED BY; Schema: backup_preview_5; Owner: -
--

ALTER SEQUENCE backup_preview_5.oauth_applications_id_seq OWNED BY backup_preview_5.oauth_applications.id;


--
-- Name: oauth_client_tokens; Type: TABLE; Schema: backup_preview_5; Owner: -
--

CREATE TABLE backup_preview_5.oauth_client_tokens (
    id bigint NOT NULL,
    oauth_client_id bigint NOT NULL,
    user_id bigint NOT NULL,
    access_token character varying,
    refresh_token character varying,
    token_type character varying,
    expires_in integer,
    scope character varying,
    origin_user_id character varying,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- Name: oauth_client_tokens_id_seq; Type: SEQUENCE; Schema: backup_preview_5; Owner: -
--

CREATE SEQUENCE backup_preview_5.oauth_client_tokens_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: oauth_client_tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: backup_preview_5; Owner: -
--

ALTER SEQUENCE backup_preview_5.oauth_client_tokens_id_seq OWNED BY backup_preview_5.oauth_client_tokens.id;


--
-- Name: oauth_clients; Type: TABLE; Schema: backup_preview_5; Owner: -
--

CREATE TABLE backup_preview_5.oauth_clients (
    id bigint NOT NULL,
    client_id character varying NOT NULL,
    client_secret character varying NOT NULL,
    integration_type character varying NOT NULL,
    integration_id bigint NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- Name: oauth_clients_id_seq; Type: SEQUENCE; Schema: backup_preview_5; Owner: -
--

CREATE SEQUENCE backup_preview_5.oauth_clients_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: oauth_clients_id_seq; Type: SEQUENCE OWNED BY; Schema: backup_preview_5; Owner: -
--

ALTER SEQUENCE backup_preview_5.oauth_clients_id_seq OWNED BY backup_preview_5.oauth_clients.id;


--
-- Name: oidc_user_session_links; Type: TABLE; Schema: backup_preview_5; Owner: -
--

CREATE UNLOGGED TABLE backup_preview_5.oidc_user_session_links (
    id bigint NOT NULL,
    oidc_session character varying NOT NULL,
    session_id bigint,
    created_at timestamp(6) with time zone NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL
);


--
-- Name: oidc_user_session_links_id_seq; Type: SEQUENCE; Schema: backup_preview_5; Owner: -
--

CREATE SEQUENCE backup_preview_5.oidc_user_session_links_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: oidc_user_session_links_id_seq; Type: SEQUENCE OWNED BY; Schema: backup_preview_5; Owner: -
--

ALTER SEQUENCE backup_preview_5.oidc_user_session_links_id_seq OWNED BY backup_preview_5.oidc_user_session_links.id;


--
-- Name: ordered_work_packages; Type: TABLE; Schema: backup_preview_5; Owner: -
--

CREATE TABLE backup_preview_5.ordered_work_packages (
    id bigint NOT NULL,
    "position" integer NOT NULL,
    query_id bigint,
    work_package_id bigint
);


--
-- Name: ordered_work_packages_id_seq; Type: SEQUENCE; Schema: backup_preview_5; Owner: -
--

CREATE SEQUENCE backup_preview_5.ordered_work_packages_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ordered_work_packages_id_seq; Type: SEQUENCE OWNED BY; Schema: backup_preview_5; Owner: -
--

ALTER SEQUENCE backup_preview_5.ordered_work_packages_id_seq OWNED BY backup_preview_5.ordered_work_packages.id;


--
-- Name: paper_trail_audits; Type: TABLE; Schema: backup_preview_5; Owner: -
--

CREATE TABLE backup_preview_5.paper_trail_audits (
    id bigint NOT NULL,
    item_type character varying NOT NULL,
    item_id bigint NOT NULL,
    event character varying NOT NULL,
    whodunnit character varying,
    stack text,
    object jsonb,
    object_changes jsonb,
    created_at timestamp(6) with time zone
);


--
-- Name: paper_trail_audits_id_seq; Type: SEQUENCE; Schema: backup_preview_5; Owner: -
--

CREATE SEQUENCE backup_preview_5.paper_trail_audits_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: paper_trail_audits_id_seq; Type: SEQUENCE OWNED BY; Schema: backup_preview_5; Owner: -
--

ALTER SEQUENCE backup_preview_5.paper_trail_audits_id_seq OWNED BY backup_preview_5.paper_trail_audits.id;


--
-- Name: project_journals; Type: TABLE; Schema: backup_preview_5; Owner: -
--

CREATE TABLE backup_preview_5.project_journals (
    id bigint NOT NULL,
    name character varying NOT NULL,
    description text,
    public boolean NOT NULL,
    parent_id bigint,
    identifier character varying NOT NULL,
    active boolean NOT NULL,
    templated boolean NOT NULL,
    status_code integer,
    status_explanation text
);


--
-- Name: project_journals_id_seq; Type: SEQUENCE; Schema: backup_preview_5; Owner: -
--

CREATE SEQUENCE backup_preview_5.project_journals_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: project_journals_id_seq; Type: SEQUENCE OWNED BY; Schema: backup_preview_5; Owner: -
--

ALTER SEQUENCE backup_preview_5.project_journals_id_seq OWNED BY backup_preview_5.project_journals.id;


--
-- Name: projects; Type: TABLE; Schema: backup_preview_5; Owner: -
--

CREATE TABLE backup_preview_5.projects (
    id bigint NOT NULL,
    name character varying DEFAULT ''::character varying NOT NULL,
    description text,
    public boolean DEFAULT true NOT NULL,
    parent_id bigint,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    identifier character varying NOT NULL,
    lft integer,
    rgt integer,
    active boolean DEFAULT true NOT NULL,
    templated boolean DEFAULT false NOT NULL,
    status_code integer,
    status_explanation text
);


--
-- Name: projects_id_seq; Type: SEQUENCE; Schema: backup_preview_5; Owner: -
--

CREATE SEQUENCE backup_preview_5.projects_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: projects_id_seq; Type: SEQUENCE OWNED BY; Schema: backup_preview_5; Owner: -
--

ALTER SEQUENCE backup_preview_5.projects_id_seq OWNED BY backup_preview_5.projects.id;


--
-- Name: projects_storages; Type: TABLE; Schema: backup_preview_5; Owner: -
--

CREATE TABLE backup_preview_5.projects_storages (
    id bigint NOT NULL,
    project_id bigint NOT NULL,
    storage_id bigint NOT NULL,
    creator_id bigint NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    project_folder_id character varying,
    project_folder_mode backup_preview_5.project_folder_modes DEFAULT 'inactive'::backup_preview_5.project_folder_modes NOT NULL
);


--
-- Name: projects_storages_id_seq; Type: SEQUENCE; Schema: backup_preview_5; Owner: -
--

CREATE SEQUENCE backup_preview_5.projects_storages_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: projects_storages_id_seq; Type: SEQUENCE OWNED BY; Schema: backup_preview_5; Owner: -
--

ALTER SEQUENCE backup_preview_5.projects_storages_id_seq OWNED BY backup_preview_5.projects_storages.id;


--
-- Name: projects_types; Type: TABLE; Schema: backup_preview_5; Owner: -
--

CREATE TABLE backup_preview_5.projects_types (
    project_id bigint NOT NULL,
    type_id bigint NOT NULL
);


--
-- Name: queries; Type: TABLE; Schema: backup_preview_5; Owner: -
--

CREATE TABLE backup_preview_5.queries (
    id bigint NOT NULL,
    project_id bigint,
    name character varying NOT NULL,
    filters text,
    user_id bigint NOT NULL,
    public boolean DEFAULT false NOT NULL,
    column_names text,
    sort_criteria text,
    group_by character varying,
    display_sums boolean DEFAULT false NOT NULL,
    timeline_visible boolean DEFAULT false,
    show_hierarchies boolean DEFAULT false,
    timeline_zoom_level integer DEFAULT 5,
    timeline_labels text,
    highlighting_mode text,
    highlighted_attributes text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    display_representation text,
    starred boolean DEFAULT false,
    include_subprojects boolean NOT NULL,
    timestamps character varying
);


--
-- Name: queries_id_seq; Type: SEQUENCE; Schema: backup_preview_5; Owner: -
--

CREATE SEQUENCE backup_preview_5.queries_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: queries_id_seq; Type: SEQUENCE OWNED BY; Schema: backup_preview_5; Owner: -
--

ALTER SEQUENCE backup_preview_5.queries_id_seq OWNED BY backup_preview_5.queries.id;


--
-- Name: rates; Type: TABLE; Schema: backup_preview_5; Owner: -
--

CREATE TABLE backup_preview_5.rates (
    id bigint NOT NULL,
    valid_from date NOT NULL,
    rate numeric(15,4) NOT NULL,
    type character varying NOT NULL,
    project_id bigint,
    user_id bigint,
    cost_type_id bigint
);


--
-- Name: rates_id_seq; Type: SEQUENCE; Schema: backup_preview_5; Owner: -
--

CREATE SEQUENCE backup_preview_5.rates_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: rates_id_seq; Type: SEQUENCE OWNED BY; Schema: backup_preview_5; Owner: -
--

ALTER SEQUENCE backup_preview_5.rates_id_seq OWNED BY backup_preview_5.rates.id;


--
-- Name: recaptcha_entries; Type: TABLE; Schema: backup_preview_5; Owner: -
--

CREATE TABLE backup_preview_5.recaptcha_entries (
    id integer NOT NULL,
    user_id bigint,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    version integer NOT NULL
);


--
-- Name: recaptcha_entries_id_seq; Type: SEQUENCE; Schema: backup_preview_5; Owner: -
--

CREATE SEQUENCE backup_preview_5.recaptcha_entries_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: recaptcha_entries_id_seq; Type: SEQUENCE OWNED BY; Schema: backup_preview_5; Owner: -
--

ALTER SEQUENCE backup_preview_5.recaptcha_entries_id_seq OWNED BY backup_preview_5.recaptcha_entries.id;


--
-- Name: relations; Type: TABLE; Schema: backup_preview_5; Owner: -
--

CREATE TABLE backup_preview_5.relations (
    id bigint NOT NULL,
    from_id integer NOT NULL,
    to_id integer NOT NULL,
    delay integer,
    description text,
    relation_type character varying
);


--
-- Name: relations_id_seq; Type: SEQUENCE; Schema: backup_preview_5; Owner: -
--

CREATE SEQUENCE backup_preview_5.relations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: relations_id_seq; Type: SEQUENCE OWNED BY; Schema: backup_preview_5; Owner: -
--

ALTER SEQUENCE backup_preview_5.relations_id_seq OWNED BY backup_preview_5.relations.id;


--
-- Name: repositories; Type: TABLE; Schema: backup_preview_5; Owner: -
--

CREATE TABLE backup_preview_5.repositories (
    id bigint NOT NULL,
    project_id bigint NOT NULL,
    url character varying DEFAULT ''::character varying NOT NULL,
    login character varying(60) DEFAULT ''::character varying,
    password character varying DEFAULT ''::character varying,
    root_url character varying DEFAULT ''::character varying,
    type character varying,
    path_encoding character varying(64),
    log_encoding character varying(64),
    scm_type character varying NOT NULL,
    required_storage_bytes bigint DEFAULT 0 NOT NULL,
    storage_updated_at timestamp with time zone
);


--
-- Name: repositories_id_seq; Type: SEQUENCE; Schema: backup_preview_5; Owner: -
--

CREATE SEQUENCE backup_preview_5.repositories_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: repositories_id_seq; Type: SEQUENCE OWNED BY; Schema: backup_preview_5; Owner: -
--

ALTER SEQUENCE backup_preview_5.repositories_id_seq OWNED BY backup_preview_5.repositories.id;


--
-- Name: role_permissions; Type: TABLE; Schema: backup_preview_5; Owner: -
--

CREATE TABLE backup_preview_5.role_permissions (
    id bigint NOT NULL,
    permission character varying,
    role_id bigint,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- Name: role_permissions_id_seq; Type: SEQUENCE; Schema: backup_preview_5; Owner: -
--

CREATE SEQUENCE backup_preview_5.role_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: role_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: backup_preview_5; Owner: -
--

ALTER SEQUENCE backup_preview_5.role_permissions_id_seq OWNED BY backup_preview_5.role_permissions.id;


--
-- Name: roles; Type: TABLE; Schema: backup_preview_5; Owner: -
--

CREATE TABLE backup_preview_5.roles (
    id bigint NOT NULL,
    name character varying(30) DEFAULT ''::character varying NOT NULL,
    "position" integer DEFAULT 1,
    builtin integer DEFAULT 0 NOT NULL,
    type character varying(30) DEFAULT 'Role'::character varying,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: roles_id_seq; Type: SEQUENCE; Schema: backup_preview_5; Owner: -
--

CREATE SEQUENCE backup_preview_5.roles_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: roles_id_seq; Type: SEQUENCE OWNED BY; Schema: backup_preview_5; Owner: -
--

ALTER SEQUENCE backup_preview_5.roles_id_seq OWNED BY backup_preview_5.roles.id;


--
-- Name: schema_migrations; Type: TABLE; Schema: backup_preview_5; Owner: -
--

CREATE TABLE backup_preview_5.schema_migrations (
    version character varying NOT NULL
);


--
-- Name: sessions; Type: TABLE; Schema: backup_preview_5; Owner: -
--

CREATE UNLOGGED TABLE backup_preview_5.sessions (
    id bigint NOT NULL,
    session_id character varying NOT NULL,
    data text,
    updated_at timestamp with time zone,
    user_id bigint
);


--
-- Name: sessions_id_seq; Type: SEQUENCE; Schema: backup_preview_5; Owner: -
--

CREATE SEQUENCE backup_preview_5.sessions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: sessions_id_seq; Type: SEQUENCE OWNED BY; Schema: backup_preview_5; Owner: -
--

ALTER SEQUENCE backup_preview_5.sessions_id_seq OWNED BY backup_preview_5.sessions.id;


--
-- Name: settings; Type: TABLE; Schema: backup_preview_5; Owner: -
--

CREATE TABLE backup_preview_5.settings (
    id bigint NOT NULL,
    name character varying DEFAULT ''::character varying NOT NULL,
    value text,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: settings_id_seq; Type: SEQUENCE; Schema: backup_preview_5; Owner: -
--

CREATE SEQUENCE backup_preview_5.settings_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: settings_id_seq; Type: SEQUENCE OWNED BY; Schema: backup_preview_5; Owner: -
--

ALTER SEQUENCE backup_preview_5.settings_id_seq OWNED BY backup_preview_5.settings.id;


--
-- Name: statuses; Type: TABLE; Schema: backup_preview_5; Owner: -
--

CREATE TABLE backup_preview_5.statuses (
    id bigint NOT NULL,
    name character varying(30) DEFAULT ''::character varying NOT NULL,
    is_closed boolean DEFAULT false NOT NULL,
    is_default boolean DEFAULT false NOT NULL,
    "position" integer DEFAULT 1,
    default_done_ratio integer,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    color_id bigint,
    is_readonly boolean DEFAULT false
);


--
-- Name: statuses_id_seq; Type: SEQUENCE; Schema: backup_preview_5; Owner: -
--

CREATE SEQUENCE backup_preview_5.statuses_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: statuses_id_seq; Type: SEQUENCE OWNED BY; Schema: backup_preview_5; Owner: -
--

ALTER SEQUENCE backup_preview_5.statuses_id_seq OWNED BY backup_preview_5.statuses.id;


--
-- Name: storages; Type: TABLE; Schema: backup_preview_5; Owner: -
--

CREATE TABLE backup_preview_5.storages (
    id bigint NOT NULL,
    provider_type character varying NOT NULL,
    name character varying NOT NULL,
    host character varying NOT NULL,
    creator_id bigint NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    provider_fields jsonb DEFAULT '{}'::jsonb NOT NULL
);


--
-- Name: storages_id_seq; Type: SEQUENCE; Schema: backup_preview_5; Owner: -
--

CREATE SEQUENCE backup_preview_5.storages_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: storages_id_seq; Type: SEQUENCE OWNED BY; Schema: backup_preview_5; Owner: -
--

ALTER SEQUENCE backup_preview_5.storages_id_seq OWNED BY backup_preview_5.storages.id;


--
-- Name: time_entries; Type: TABLE; Schema: backup_preview_5; Owner: -
--

CREATE TABLE backup_preview_5.time_entries (
    id bigint NOT NULL,
    project_id bigint NOT NULL,
    user_id bigint NOT NULL,
    work_package_id bigint,
    hours double precision NOT NULL,
    comments character varying,
    activity_id bigint NOT NULL,
    spent_on date NOT NULL,
    tyear integer NOT NULL,
    tmonth integer NOT NULL,
    tweek integer NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    overridden_costs numeric(15,4),
    costs numeric(15,4),
    rate_id bigint,
    logged_by_id bigint NOT NULL
);


--
-- Name: time_entries_id_seq; Type: SEQUENCE; Schema: backup_preview_5; Owner: -
--

CREATE SEQUENCE backup_preview_5.time_entries_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: time_entries_id_seq; Type: SEQUENCE OWNED BY; Schema: backup_preview_5; Owner: -
--

ALTER SEQUENCE backup_preview_5.time_entries_id_seq OWNED BY backup_preview_5.time_entries.id;


--
-- Name: time_entry_activities_projects; Type: TABLE; Schema: backup_preview_5; Owner: -
--

CREATE TABLE backup_preview_5.time_entry_activities_projects (
    id bigint NOT NULL,
    activity_id bigint NOT NULL,
    project_id bigint NOT NULL,
    active boolean DEFAULT true
);


--
-- Name: time_entry_activities_projects_id_seq; Type: SEQUENCE; Schema: backup_preview_5; Owner: -
--

CREATE SEQUENCE backup_preview_5.time_entry_activities_projects_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: time_entry_activities_projects_id_seq; Type: SEQUENCE OWNED BY; Schema: backup_preview_5; Owner: -
--

ALTER SEQUENCE backup_preview_5.time_entry_activities_projects_id_seq OWNED BY backup_preview_5.time_entry_activities_projects.id;


--
-- Name: time_entry_journals; Type: TABLE; Schema: backup_preview_5; Owner: -
--

CREATE TABLE backup_preview_5.time_entry_journals (
    id bigint NOT NULL,
    project_id bigint NOT NULL,
    user_id bigint NOT NULL,
    work_package_id bigint,
    hours double precision NOT NULL,
    comments character varying,
    activity_id bigint NOT NULL,
    spent_on date NOT NULL,
    tyear integer NOT NULL,
    tmonth integer NOT NULL,
    tweek integer NOT NULL,
    overridden_costs numeric(15,2),
    costs numeric(15,2),
    rate_id bigint,
    logged_by_id bigint NOT NULL
);


--
-- Name: time_entry_journals_id_seq; Type: SEQUENCE; Schema: backup_preview_5; Owner: -
--

CREATE SEQUENCE backup_preview_5.time_entry_journals_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: time_entry_journals_id_seq; Type: SEQUENCE OWNED BY; Schema: backup_preview_5; Owner: -
--

ALTER SEQUENCE backup_preview_5.time_entry_journals_id_seq OWNED BY backup_preview_5.time_entry_journals.id;


--
-- Name: tokens; Type: TABLE; Schema: backup_preview_5; Owner: -
--

CREATE TABLE backup_preview_5.tokens (
    id bigint NOT NULL,
    user_id bigint,
    type character varying,
    value character varying(128) DEFAULT ''::character varying NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    expires_on timestamp with time zone
);


--
-- Name: tokens_id_seq; Type: SEQUENCE; Schema: backup_preview_5; Owner: -
--

CREATE SEQUENCE backup_preview_5.tokens_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: backup_preview_5; Owner: -
--

ALTER SEQUENCE backup_preview_5.tokens_id_seq OWNED BY backup_preview_5.tokens.id;


--
-- Name: two_factor_authentication_devices; Type: TABLE; Schema: backup_preview_5; Owner: -
--

CREATE TABLE backup_preview_5.two_factor_authentication_devices (
    id bigint NOT NULL,
    type character varying,
    "default" boolean DEFAULT false NOT NULL,
    active boolean DEFAULT false NOT NULL,
    channel character varying NOT NULL,
    phone_number character varying,
    identifier character varying NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    last_used_at integer,
    otp_secret text,
    user_id bigint
);


--
-- Name: two_factor_authentication_devices_id_seq; Type: SEQUENCE; Schema: backup_preview_5; Owner: -
--

CREATE SEQUENCE backup_preview_5.two_factor_authentication_devices_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: two_factor_authentication_devices_id_seq; Type: SEQUENCE OWNED BY; Schema: backup_preview_5; Owner: -
--

ALTER SEQUENCE backup_preview_5.two_factor_authentication_devices_id_seq OWNED BY backup_preview_5.two_factor_authentication_devices.id;


--
-- Name: types; Type: TABLE; Schema: backup_preview_5; Owner: -
--

CREATE TABLE backup_preview_5.types (
    id bigint NOT NULL,
    name character varying DEFAULT ''::character varying NOT NULL,
    "position" integer DEFAULT 1,
    is_in_roadmap boolean DEFAULT true NOT NULL,
    is_milestone boolean DEFAULT false NOT NULL,
    is_default boolean DEFAULT false NOT NULL,
    color_id bigint,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    is_standard boolean DEFAULT false NOT NULL,
    attribute_groups text,
    description text
);


--
-- Name: types_id_seq; Type: SEQUENCE; Schema: backup_preview_5; Owner: -
--

CREATE SEQUENCE backup_preview_5.types_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: types_id_seq; Type: SEQUENCE OWNED BY; Schema: backup_preview_5; Owner: -
--

ALTER SEQUENCE backup_preview_5.types_id_seq OWNED BY backup_preview_5.types.id;


--
-- Name: user_passwords; Type: TABLE; Schema: backup_preview_5; Owner: -
--

CREATE TABLE backup_preview_5.user_passwords (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    hashed_password character varying(128) NOT NULL,
    salt character varying(64),
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    type character varying NOT NULL
);


--
-- Name: user_passwords_id_seq; Type: SEQUENCE; Schema: backup_preview_5; Owner: -
--

CREATE SEQUENCE backup_preview_5.user_passwords_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: user_passwords_id_seq; Type: SEQUENCE OWNED BY; Schema: backup_preview_5; Owner: -
--

ALTER SEQUENCE backup_preview_5.user_passwords_id_seq OWNED BY backup_preview_5.user_passwords.id;


--
-- Name: user_preferences; Type: TABLE; Schema: backup_preview_5; Owner: -
--

CREATE TABLE backup_preview_5.user_preferences (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    settings jsonb DEFAULT '{}'::jsonb
);


--
-- Name: user_preferences_id_seq; Type: SEQUENCE; Schema: backup_preview_5; Owner: -
--

CREATE SEQUENCE backup_preview_5.user_preferences_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: user_preferences_id_seq; Type: SEQUENCE OWNED BY; Schema: backup_preview_5; Owner: -
--

ALTER SEQUENCE backup_preview_5.user_preferences_id_seq OWNED BY backup_preview_5.user_preferences.id;


--
-- Name: users; Type: TABLE; Schema: backup_preview_5; Owner: -
--

CREATE TABLE backup_preview_5.users (
    id bigint NOT NULL,
    login character varying(256) DEFAULT ''::character varying NOT NULL,
    firstname character varying DEFAULT ''::character varying NOT NULL,
    lastname character varying DEFAULT ''::character varying NOT NULL,
    mail character varying DEFAULT ''::character varying NOT NULL,
    admin boolean DEFAULT false NOT NULL,
    status integer DEFAULT 1 NOT NULL,
    last_login_on timestamp with time zone,
    language character varying(5) DEFAULT ''::character varying,
    auth_source_id bigint,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    type character varying,
    identity_url character varying,
    first_login boolean DEFAULT true NOT NULL,
    force_password_change boolean DEFAULT false,
    failed_login_count integer DEFAULT 0,
    last_failed_login_on timestamp with time zone,
    consented_at timestamp with time zone
);


--
-- Name: users_id_seq; Type: SEQUENCE; Schema: backup_preview_5; Owner: -
--

CREATE SEQUENCE backup_preview_5.users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: backup_preview_5; Owner: -
--

ALTER SEQUENCE backup_preview_5.users_id_seq OWNED BY backup_preview_5.users.id;


--
-- Name: version_settings; Type: TABLE; Schema: backup_preview_5; Owner: -
--

CREATE TABLE backup_preview_5.version_settings (
    id bigint NOT NULL,
    project_id bigint,
    version_id bigint,
    display integer,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- Name: version_settings_id_seq; Type: SEQUENCE; Schema: backup_preview_5; Owner: -
--

CREATE SEQUENCE backup_preview_5.version_settings_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: version_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: backup_preview_5; Owner: -
--

ALTER SEQUENCE backup_preview_5.version_settings_id_seq OWNED BY backup_preview_5.version_settings.id;


--
-- Name: versions; Type: TABLE; Schema: backup_preview_5; Owner: -
--

CREATE TABLE backup_preview_5.versions (
    id bigint NOT NULL,
    project_id bigint NOT NULL,
    name character varying DEFAULT ''::character varying NOT NULL,
    description character varying DEFAULT ''::character varying,
    effective_date date,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    wiki_page_title character varying,
    status character varying DEFAULT 'open'::character varying,
    sharing character varying DEFAULT 'none'::character varying NOT NULL,
    start_date date
);


--
-- Name: versions_id_seq; Type: SEQUENCE; Schema: backup_preview_5; Owner: -
--

CREATE SEQUENCE backup_preview_5.versions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: versions_id_seq; Type: SEQUENCE OWNED BY; Schema: backup_preview_5; Owner: -
--

ALTER SEQUENCE backup_preview_5.versions_id_seq OWNED BY backup_preview_5.versions.id;


--
-- Name: views; Type: TABLE; Schema: backup_preview_5; Owner: -
--

CREATE TABLE backup_preview_5.views (
    id bigint NOT NULL,
    query_id bigint NOT NULL,
    options jsonb DEFAULT '{}'::jsonb NOT NULL,
    type character varying NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- Name: views_id_seq; Type: SEQUENCE; Schema: backup_preview_5; Owner: -
--

CREATE SEQUENCE backup_preview_5.views_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: views_id_seq; Type: SEQUENCE OWNED BY; Schema: backup_preview_5; Owner: -
--

ALTER SEQUENCE backup_preview_5.views_id_seq OWNED BY backup_preview_5.views.id;


--
-- Name: watchers; Type: TABLE; Schema: backup_preview_5; Owner: -
--

CREATE TABLE backup_preview_5.watchers (
    id bigint NOT NULL,
    watchable_type character varying DEFAULT ''::character varying NOT NULL,
    watchable_id bigint NOT NULL,
    user_id bigint
);


--
-- Name: watchers_id_seq; Type: SEQUENCE; Schema: backup_preview_5; Owner: -
--

CREATE SEQUENCE backup_preview_5.watchers_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: watchers_id_seq; Type: SEQUENCE OWNED BY; Schema: backup_preview_5; Owner: -
--

ALTER SEQUENCE backup_preview_5.watchers_id_seq OWNED BY backup_preview_5.watchers.id;


--
-- Name: webhooks_events; Type: TABLE; Schema: backup_preview_5; Owner: -
--

CREATE TABLE backup_preview_5.webhooks_events (
    id bigint NOT NULL,
    name character varying,
    webhooks_webhook_id bigint
);


--
-- Name: webhooks_events_id_seq; Type: SEQUENCE; Schema: backup_preview_5; Owner: -
--

CREATE SEQUENCE backup_preview_5.webhooks_events_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: webhooks_events_id_seq; Type: SEQUENCE OWNED BY; Schema: backup_preview_5; Owner: -
--

ALTER SEQUENCE backup_preview_5.webhooks_events_id_seq OWNED BY backup_preview_5.webhooks_events.id;


--
-- Name: webhooks_logs; Type: TABLE; Schema: backup_preview_5; Owner: -
--

CREATE TABLE backup_preview_5.webhooks_logs (
    id bigint NOT NULL,
    webhooks_webhook_id bigint,
    event_name character varying,
    url character varying,
    request_headers text,
    request_body text,
    response_code integer,
    response_headers text,
    response_body text,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- Name: webhooks_logs_id_seq; Type: SEQUENCE; Schema: backup_preview_5; Owner: -
--

CREATE SEQUENCE backup_preview_5.webhooks_logs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: webhooks_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: backup_preview_5; Owner: -
--

ALTER SEQUENCE backup_preview_5.webhooks_logs_id_seq OWNED BY backup_preview_5.webhooks_logs.id;


--
-- Name: webhooks_projects; Type: TABLE; Schema: backup_preview_5; Owner: -
--

CREATE TABLE backup_preview_5.webhooks_projects (
    id bigint NOT NULL,
    project_id bigint,
    webhooks_webhook_id bigint
);


--
-- Name: webhooks_projects_id_seq; Type: SEQUENCE; Schema: backup_preview_5; Owner: -
--

CREATE SEQUENCE backup_preview_5.webhooks_projects_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: webhooks_projects_id_seq; Type: SEQUENCE OWNED BY; Schema: backup_preview_5; Owner: -
--

ALTER SEQUENCE backup_preview_5.webhooks_projects_id_seq OWNED BY backup_preview_5.webhooks_projects.id;


--
-- Name: webhooks_webhooks; Type: TABLE; Schema: backup_preview_5; Owner: -
--

CREATE TABLE backup_preview_5.webhooks_webhooks (
    id bigint NOT NULL,
    name character varying,
    url text,
    description text NOT NULL,
    secret character varying,
    enabled boolean NOT NULL,
    all_projects boolean NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- Name: webhooks_webhooks_id_seq; Type: SEQUENCE; Schema: backup_preview_5; Owner: -
--

CREATE SEQUENCE backup_preview_5.webhooks_webhooks_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: webhooks_webhooks_id_seq; Type: SEQUENCE OWNED BY; Schema: backup_preview_5; Owner: -
--

ALTER SEQUENCE backup_preview_5.webhooks_webhooks_id_seq OWNED BY backup_preview_5.webhooks_webhooks.id;


--
-- Name: wiki_page_journals; Type: TABLE; Schema: backup_preview_5; Owner: -
--

CREATE TABLE backup_preview_5.wiki_page_journals (
    id bigint NOT NULL,
    author_id bigint,
    text text
);


--
-- Name: wiki_page_journals_id_seq; Type: SEQUENCE; Schema: backup_preview_5; Owner: -
--

CREATE SEQUENCE backup_preview_5.wiki_page_journals_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: wiki_page_journals_id_seq; Type: SEQUENCE OWNED BY; Schema: backup_preview_5; Owner: -
--

ALTER SEQUENCE backup_preview_5.wiki_page_journals_id_seq OWNED BY backup_preview_5.wiki_page_journals.id;


--
-- Name: wiki_pages; Type: TABLE; Schema: backup_preview_5; Owner: -
--

CREATE TABLE backup_preview_5.wiki_pages (
    id bigint NOT NULL,
    wiki_id bigint NOT NULL,
    title character varying NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    protected boolean DEFAULT false NOT NULL,
    parent_id bigint,
    slug character varying NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    author_id bigint NOT NULL,
    text text,
    lock_version integer NOT NULL
);


--
-- Name: wiki_pages_id_seq; Type: SEQUENCE; Schema: backup_preview_5; Owner: -
--

CREATE SEQUENCE backup_preview_5.wiki_pages_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: wiki_pages_id_seq; Type: SEQUENCE OWNED BY; Schema: backup_preview_5; Owner: -
--

ALTER SEQUENCE backup_preview_5.wiki_pages_id_seq OWNED BY backup_preview_5.wiki_pages.id;


--
-- Name: wiki_redirects; Type: TABLE; Schema: backup_preview_5; Owner: -
--

CREATE TABLE backup_preview_5.wiki_redirects (
    id bigint NOT NULL,
    wiki_id bigint NOT NULL,
    title character varying,
    redirects_to character varying,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: wiki_redirects_id_seq; Type: SEQUENCE; Schema: backup_preview_5; Owner: -
--

CREATE SEQUENCE backup_preview_5.wiki_redirects_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: wiki_redirects_id_seq; Type: SEQUENCE OWNED BY; Schema: backup_preview_5; Owner: -
--

ALTER SEQUENCE backup_preview_5.wiki_redirects_id_seq OWNED BY backup_preview_5.wiki_redirects.id;


--
-- Name: wikis; Type: TABLE; Schema: backup_preview_5; Owner: -
--

CREATE TABLE backup_preview_5.wikis (
    id bigint NOT NULL,
    project_id bigint NOT NULL,
    start_page character varying NOT NULL,
    status integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- Name: wikis_id_seq; Type: SEQUENCE; Schema: backup_preview_5; Owner: -
--

CREATE SEQUENCE backup_preview_5.wikis_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: wikis_id_seq; Type: SEQUENCE OWNED BY; Schema: backup_preview_5; Owner: -
--

ALTER SEQUENCE backup_preview_5.wikis_id_seq OWNED BY backup_preview_5.wikis.id;


--
-- Name: work_package_hierarchies; Type: TABLE; Schema: backup_preview_5; Owner: -
--

CREATE TABLE backup_preview_5.work_package_hierarchies (
    ancestor_id integer NOT NULL,
    descendant_id integer NOT NULL,
    generations integer NOT NULL
);


--
-- Name: work_package_journals; Type: TABLE; Schema: backup_preview_5; Owner: -
--

CREATE TABLE backup_preview_5.work_package_journals (
    id bigint NOT NULL,
    type_id bigint NOT NULL,
    project_id bigint NOT NULL,
    subject character varying NOT NULL,
    description text,
    due_date date,
    category_id bigint,
    status_id bigint NOT NULL,
    assigned_to_id bigint,
    priority_id bigint NOT NULL,
    version_id bigint,
    author_id bigint NOT NULL,
    done_ratio integer NOT NULL,
    estimated_hours double precision,
    start_date date,
    parent_id bigint,
    responsible_id bigint,
    budget_id bigint,
    story_points integer,
    remaining_hours double precision,
    derived_estimated_hours double precision,
    schedule_manually boolean,
    duration integer,
    ignore_non_working_days boolean NOT NULL
);


--
-- Name: work_package_journals_id_seq; Type: SEQUENCE; Schema: backup_preview_5; Owner: -
--

CREATE SEQUENCE backup_preview_5.work_package_journals_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: work_package_journals_id_seq; Type: SEQUENCE OWNED BY; Schema: backup_preview_5; Owner: -
--

ALTER SEQUENCE backup_preview_5.work_package_journals_id_seq OWNED BY backup_preview_5.work_package_journals.id;


--
-- Name: work_packages; Type: TABLE; Schema: backup_preview_5; Owner: -
--

CREATE TABLE backup_preview_5.work_packages (
    id bigint NOT NULL,
    type_id bigint NOT NULL,
    project_id bigint NOT NULL,
    subject character varying DEFAULT ''::character varying NOT NULL,
    description text,
    due_date date,
    category_id bigint,
    status_id bigint NOT NULL,
    assigned_to_id bigint,
    priority_id bigint,
    version_id bigint,
    author_id bigint NOT NULL,
    lock_version integer DEFAULT 0 NOT NULL,
    done_ratio integer DEFAULT 0 NOT NULL,
    estimated_hours double precision,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    start_date date,
    responsible_id bigint,
    budget_id bigint,
    "position" integer,
    story_points integer,
    remaining_hours double precision,
    derived_estimated_hours double precision,
    schedule_manually boolean DEFAULT false,
    parent_id bigint,
    duration integer,
    ignore_non_working_days boolean DEFAULT false NOT NULL,
    CONSTRAINT work_packages_due_larger_start_date CHECK ((due_date >= start_date))
);


--
-- Name: work_packages_id_seq; Type: SEQUENCE; Schema: backup_preview_5; Owner: -
--

CREATE SEQUENCE backup_preview_5.work_packages_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: work_packages_id_seq; Type: SEQUENCE OWNED BY; Schema: backup_preview_5; Owner: -
--

ALTER SEQUENCE backup_preview_5.work_packages_id_seq OWNED BY backup_preview_5.work_packages.id;


--
-- Name: workflows; Type: TABLE; Schema: backup_preview_5; Owner: -
--

CREATE TABLE backup_preview_5.workflows (
    id bigint NOT NULL,
    type_id bigint NOT NULL,
    old_status_id bigint NOT NULL,
    new_status_id bigint NOT NULL,
    role_id bigint NOT NULL,
    assignee boolean DEFAULT false NOT NULL,
    author boolean DEFAULT false NOT NULL
);


--
-- Name: workflows_id_seq; Type: SEQUENCE; Schema: backup_preview_5; Owner: -
--

CREATE SEQUENCE backup_preview_5.workflows_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: workflows_id_seq; Type: SEQUENCE OWNED BY; Schema: backup_preview_5; Owner: -
--

ALTER SEQUENCE backup_preview_5.workflows_id_seq OWNED BY backup_preview_5.workflows.id;


--
-- Name: announcements; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.announcements (
    id bigint NOT NULL,
    text text,
    show_until date,
    active boolean DEFAULT false,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


--
-- Name: announcements_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.announcements_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: announcements_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.announcements_id_seq OWNED BY public.announcements.id;


--
-- Name: ar_internal_metadata; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ar_internal_metadata (
    key character varying NOT NULL,
    value character varying,
    created_at timestamp(6) with time zone NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL
);


--
-- Name: attachable_journals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.attachable_journals (
    id bigint NOT NULL,
    journal_id bigint NOT NULL,
    attachment_id bigint NOT NULL,
    filename character varying NOT NULL
);


--
-- Name: attachable_journals_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.attachable_journals_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: attachable_journals_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.attachable_journals_id_seq OWNED BY public.attachable_journals.id;


--
-- Name: attachment_journals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.attachment_journals (
    id bigint NOT NULL,
    container_id bigint,
    container_type character varying(30),
    filename character varying NOT NULL,
    disk_filename character varying NOT NULL,
    filesize bigint NOT NULL,
    content_type character varying,
    digest character varying(40) NOT NULL,
    downloads integer NOT NULL,
    author_id bigint NOT NULL,
    description text
);


--
-- Name: attachment_journals_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.attachment_journals_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: attachment_journals_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.attachment_journals_id_seq OWNED BY public.attachment_journals.id;


--
-- Name: attachments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.attachments (
    id bigint NOT NULL,
    container_id bigint,
    container_type character varying(30),
    filename character varying DEFAULT ''::character varying NOT NULL,
    disk_filename character varying DEFAULT ''::character varying NOT NULL,
    filesize bigint DEFAULT 0 NOT NULL,
    content_type character varying DEFAULT ''::character varying,
    digest character varying(40) DEFAULT ''::character varying NOT NULL,
    downloads integer DEFAULT 0 NOT NULL,
    author_id bigint NOT NULL,
    created_at timestamp with time zone,
    description character varying,
    file character varying,
    fulltext text,
    fulltext_tsv tsvector,
    file_tsv tsvector,
    updated_at timestamp with time zone
);


--
-- Name: attachments_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.attachments_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: attachments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.attachments_id_seq OWNED BY public.attachments.id;


--
-- Name: attribute_help_texts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.attribute_help_texts (
    id bigint NOT NULL,
    help_text text NOT NULL,
    type character varying NOT NULL,
    attribute_name character varying NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- Name: attribute_help_texts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.attribute_help_texts_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: attribute_help_texts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.attribute_help_texts_id_seq OWNED BY public.attribute_help_texts.id;


--
-- Name: auth_sources; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.auth_sources (
    id bigint NOT NULL,
    type character varying(30) DEFAULT ''::character varying NOT NULL,
    name character varying(60) DEFAULT ''::character varying NOT NULL,
    host character varying(60),
    port integer,
    account character varying,
    account_password character varying DEFAULT ''::character varying,
    base_dn character varying,
    attr_login character varying(30),
    attr_firstname character varying(30),
    attr_lastname character varying(30),
    attr_mail character varying(30),
    onthefly_register boolean DEFAULT false NOT NULL,
    attr_admin character varying,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    tls_mode integer DEFAULT 0 NOT NULL,
    filter_string text,
    verify_peer boolean DEFAULT true NOT NULL,
    tls_certificate_string text
);


--
-- Name: auth_sources_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.auth_sources_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: auth_sources_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.auth_sources_id_seq OWNED BY public.auth_sources.id;


--
-- Name: backups; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.backups (
    id bigint NOT NULL,
    comment character varying,
    size_in_mb integer,
    creator_id bigint NOT NULL,
    created_at timestamp(6) with time zone NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL
);


--
-- Name: backups_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.backups_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: backups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.backups_id_seq OWNED BY public.backups.id;


--
-- Name: bcf_comments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.bcf_comments (
    id bigint NOT NULL,
    uuid text,
    journal_id bigint,
    issue_id bigint,
    viewpoint_id bigint,
    reply_to bigint
);


--
-- Name: bcf_comments_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.bcf_comments_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bcf_comments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.bcf_comments_id_seq OWNED BY public.bcf_comments.id;


--
-- Name: bcf_issues; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.bcf_issues (
    id bigint NOT NULL,
    uuid text,
    markup xml,
    work_package_id bigint,
    stage character varying,
    index integer,
    labels text[] DEFAULT '{}'::text[],
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: bcf_issues_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.bcf_issues_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bcf_issues_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.bcf_issues_id_seq OWNED BY public.bcf_issues.id;


--
-- Name: bcf_viewpoints; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.bcf_viewpoints (
    id bigint NOT NULL,
    uuid text,
    viewpoint_name text,
    issue_id bigint,
    json_viewpoint jsonb,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: bcf_viewpoints_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.bcf_viewpoints_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bcf_viewpoints_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.bcf_viewpoints_id_seq OWNED BY public.bcf_viewpoints.id;


--
-- Name: budget_journals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.budget_journals (
    id bigint NOT NULL,
    project_id bigint NOT NULL,
    author_id bigint NOT NULL,
    subject character varying NOT NULL,
    description text,
    fixed_date date NOT NULL
);


--
-- Name: budget_journals_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.budget_journals_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: budget_journals_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.budget_journals_id_seq OWNED BY public.budget_journals.id;


--
-- Name: budgets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.budgets (
    id bigint NOT NULL,
    project_id bigint NOT NULL,
    author_id bigint NOT NULL,
    subject character varying NOT NULL,
    description text NOT NULL,
    fixed_date date NOT NULL,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


--
-- Name: budgets_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.budgets_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: budgets_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.budgets_id_seq OWNED BY public.budgets.id;


--
-- Name: categories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.categories (
    id bigint NOT NULL,
    project_id bigint NOT NULL,
    name character varying(256) DEFAULT ''::character varying NOT NULL,
    assigned_to_id bigint,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- Name: categories_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.categories_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.categories_id_seq OWNED BY public.categories.id;


--
-- Name: changes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.changes (
    id bigint NOT NULL,
    changeset_id bigint NOT NULL,
    action character varying(1) DEFAULT ''::character varying NOT NULL,
    path text NOT NULL,
    from_path text,
    from_revision character varying,
    revision character varying,
    branch character varying
);


--
-- Name: changes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.changes_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: changes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.changes_id_seq OWNED BY public.changes.id;


--
-- Name: changeset_journals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.changeset_journals (
    id bigint NOT NULL,
    repository_id bigint NOT NULL,
    revision character varying NOT NULL,
    committer character varying,
    committed_on timestamp with time zone NOT NULL,
    comments text,
    commit_date date,
    scmid character varying,
    user_id bigint
);


--
-- Name: changeset_journals_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.changeset_journals_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: changeset_journals_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.changeset_journals_id_seq OWNED BY public.changeset_journals.id;


--
-- Name: changesets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.changesets (
    id bigint NOT NULL,
    repository_id bigint NOT NULL,
    revision character varying NOT NULL,
    committer character varying,
    committed_on timestamp with time zone NOT NULL,
    comments text,
    commit_date date,
    scmid character varying,
    user_id bigint
);


--
-- Name: changesets_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.changesets_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: changesets_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.changesets_id_seq OWNED BY public.changesets.id;


--
-- Name: changesets_work_packages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.changesets_work_packages (
    changeset_id bigint NOT NULL,
    work_package_id bigint NOT NULL
);


--
-- Name: colors; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.colors (
    id bigint NOT NULL,
    name character varying NOT NULL,
    hexcode character varying NOT NULL,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


--
-- Name: colors_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.colors_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: colors_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.colors_id_seq OWNED BY public.colors.id;


--
-- Name: comments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.comments (
    id bigint NOT NULL,
    commented_type character varying(30) DEFAULT ''::character varying NOT NULL,
    commented_id bigint NOT NULL,
    author_id bigint NOT NULL,
    comments text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: comments_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.comments_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: comments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.comments_id_seq OWNED BY public.comments.id;


--
-- Name: cost_entries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cost_entries (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    project_id bigint NOT NULL,
    work_package_id bigint NOT NULL,
    cost_type_id bigint NOT NULL,
    units double precision NOT NULL,
    spent_on date NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    comments character varying NOT NULL,
    blocked boolean DEFAULT false NOT NULL,
    overridden_costs numeric(15,4),
    costs numeric(15,4),
    rate_id bigint,
    tyear integer NOT NULL,
    tmonth integer NOT NULL,
    tweek integer NOT NULL,
    logged_by_id bigint
);


--
-- Name: cost_entries_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.cost_entries_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: cost_entries_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.cost_entries_id_seq OWNED BY public.cost_entries.id;


--
-- Name: cost_queries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cost_queries (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    project_id bigint,
    name character varying NOT NULL,
    is_public boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    serialized character varying(2000) NOT NULL
);


--
-- Name: cost_queries_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.cost_queries_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: cost_queries_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.cost_queries_id_seq OWNED BY public.cost_queries.id;


--
-- Name: cost_types; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cost_types (
    id bigint NOT NULL,
    name character varying NOT NULL,
    unit character varying NOT NULL,
    unit_plural character varying NOT NULL,
    "default" boolean DEFAULT false NOT NULL,
    deleted_at timestamp with time zone
);


--
-- Name: cost_types_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.cost_types_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: cost_types_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.cost_types_id_seq OWNED BY public.cost_types.id;


--
-- Name: custom_actions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.custom_actions (
    id bigint NOT NULL,
    name character varying,
    actions text,
    description text,
    "position" integer
);


--
-- Name: custom_actions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.custom_actions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: custom_actions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.custom_actions_id_seq OWNED BY public.custom_actions.id;


--
-- Name: custom_actions_projects; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.custom_actions_projects (
    id bigint NOT NULL,
    project_id bigint,
    custom_action_id bigint
);


--
-- Name: custom_actions_projects_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.custom_actions_projects_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: custom_actions_projects_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.custom_actions_projects_id_seq OWNED BY public.custom_actions_projects.id;


--
-- Name: custom_actions_roles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.custom_actions_roles (
    id bigint NOT NULL,
    role_id bigint,
    custom_action_id bigint
);


--
-- Name: custom_actions_roles_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.custom_actions_roles_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: custom_actions_roles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.custom_actions_roles_id_seq OWNED BY public.custom_actions_roles.id;


--
-- Name: custom_actions_statuses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.custom_actions_statuses (
    id bigint NOT NULL,
    status_id bigint,
    custom_action_id bigint
);


--
-- Name: custom_actions_statuses_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.custom_actions_statuses_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: custom_actions_statuses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.custom_actions_statuses_id_seq OWNED BY public.custom_actions_statuses.id;


--
-- Name: custom_actions_types; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.custom_actions_types (
    id bigint NOT NULL,
    type_id bigint,
    custom_action_id bigint
);


--
-- Name: custom_actions_types_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.custom_actions_types_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: custom_actions_types_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.custom_actions_types_id_seq OWNED BY public.custom_actions_types.id;


--
-- Name: custom_fields; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.custom_fields (
    id bigint NOT NULL,
    type character varying(30) DEFAULT ''::character varying NOT NULL,
    field_format character varying(30) DEFAULT ''::character varying NOT NULL,
    regexp character varying DEFAULT ''::character varying,
    min_length integer DEFAULT 0 NOT NULL,
    max_length integer DEFAULT 0 NOT NULL,
    is_required boolean DEFAULT false NOT NULL,
    is_for_all boolean DEFAULT false NOT NULL,
    is_filter boolean DEFAULT false NOT NULL,
    "position" integer DEFAULT 1,
    searchable boolean DEFAULT false,
    editable boolean DEFAULT true,
    visible boolean DEFAULT true NOT NULL,
    multi_value boolean DEFAULT false,
    default_value text,
    name character varying,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    content_right_to_left boolean DEFAULT false
);


--
-- Name: custom_fields_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.custom_fields_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: custom_fields_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.custom_fields_id_seq OWNED BY public.custom_fields.id;


--
-- Name: custom_fields_projects; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.custom_fields_projects (
    custom_field_id bigint NOT NULL,
    project_id bigint NOT NULL
);


--
-- Name: custom_fields_types; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.custom_fields_types (
    custom_field_id bigint NOT NULL,
    type_id bigint NOT NULL
);


--
-- Name: custom_options; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.custom_options (
    id bigint NOT NULL,
    custom_field_id bigint,
    "position" integer,
    default_value boolean,
    value text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


--
-- Name: custom_options_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.custom_options_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: custom_options_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.custom_options_id_seq OWNED BY public.custom_options.id;


--
-- Name: custom_styles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.custom_styles (
    id bigint NOT NULL,
    logo character varying,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    favicon character varying,
    touch_icon character varying,
    theme character varying DEFAULT 'OpenProject'::character varying,
    theme_logo character varying
);


--
-- Name: custom_styles_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.custom_styles_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: custom_styles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.custom_styles_id_seq OWNED BY public.custom_styles.id;


--
-- Name: custom_values; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.custom_values (
    id bigint NOT NULL,
    customized_type character varying(30) DEFAULT ''::character varying NOT NULL,
    customized_id bigint NOT NULL,
    custom_field_id bigint NOT NULL,
    value text
);


--
-- Name: custom_values_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.custom_values_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: custom_values_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.custom_values_id_seq OWNED BY public.custom_values.id;


--
-- Name: customizable_journals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.customizable_journals (
    id bigint NOT NULL,
    journal_id bigint NOT NULL,
    custom_field_id bigint NOT NULL,
    value text
);


--
-- Name: customizable_journals_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.customizable_journals_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: customizable_journals_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.customizable_journals_id_seq OWNED BY public.customizable_journals.id;


--
-- Name: delayed_job_statuses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.delayed_job_statuses (
    id bigint NOT NULL,
    reference_type character varying,
    reference_id bigint,
    message character varying,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    status public.delayed_job_status DEFAULT 'in_queue'::public.delayed_job_status,
    user_id bigint,
    job_id character varying,
    payload jsonb
);


--
-- Name: delayed_job_statuses_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.delayed_job_statuses_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: delayed_job_statuses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.delayed_job_statuses_id_seq OWNED BY public.delayed_job_statuses.id;


--
-- Name: delayed_jobs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.delayed_jobs (
    id bigint NOT NULL,
    priority integer DEFAULT 0,
    attempts integer DEFAULT 0,
    handler text,
    last_error text,
    run_at timestamp with time zone,
    locked_at timestamp with time zone,
    failed_at timestamp with time zone,
    locked_by character varying,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    queue character varying,
    cron character varying
);


--
-- Name: delayed_jobs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.delayed_jobs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: delayed_jobs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.delayed_jobs_id_seq OWNED BY public.delayed_jobs.id;


--
-- Name: design_colors; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.design_colors (
    id bigint NOT NULL,
    variable character varying,
    hexcode character varying,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- Name: design_colors_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.design_colors_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: design_colors_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.design_colors_id_seq OWNED BY public.design_colors.id;


--
-- Name: document_journals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.document_journals (
    id bigint NOT NULL,
    project_id bigint NOT NULL,
    category_id bigint NOT NULL,
    title character varying(60) NOT NULL,
    description text
);


--
-- Name: document_journals_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.document_journals_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: document_journals_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.document_journals_id_seq OWNED BY public.document_journals.id;


--
-- Name: documents; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.documents (
    id bigint NOT NULL,
    project_id bigint NOT NULL,
    category_id bigint NOT NULL,
    title character varying(60) DEFAULT ''::character varying NOT NULL,
    description text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


--
-- Name: documents_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.documents_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: documents_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.documents_id_seq OWNED BY public.documents.id;


--
-- Name: done_statuses_for_project; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.done_statuses_for_project (
    project_id bigint,
    status_id bigint
);


--
-- Name: enabled_modules; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.enabled_modules (
    id bigint NOT NULL,
    project_id bigint,
    name character varying NOT NULL
);


--
-- Name: enabled_modules_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.enabled_modules_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: enabled_modules_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.enabled_modules_id_seq OWNED BY public.enabled_modules.id;


--
-- Name: enterprise_tokens; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.enterprise_tokens (
    id bigint NOT NULL,
    encoded_token text,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- Name: enterprise_tokens_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.enterprise_tokens_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: enterprise_tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.enterprise_tokens_id_seq OWNED BY public.enterprise_tokens.id;


--
-- Name: enumerations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.enumerations (
    id bigint NOT NULL,
    name character varying(30) DEFAULT ''::character varying NOT NULL,
    "position" integer DEFAULT 1,
    is_default boolean DEFAULT false NOT NULL,
    type character varying,
    active boolean DEFAULT true NOT NULL,
    project_id bigint,
    parent_id bigint,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    color_id bigint
);


--
-- Name: enumerations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.enumerations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: enumerations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.enumerations_id_seq OWNED BY public.enumerations.id;


--
-- Name: export_card_configurations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.export_card_configurations (
    id bigint NOT NULL,
    name character varying,
    per_page integer,
    page_size character varying,
    orientation character varying,
    rows text,
    active boolean DEFAULT true,
    description text
);


--
-- Name: export_card_configurations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.export_card_configurations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: export_card_configurations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.export_card_configurations_id_seq OWNED BY public.export_card_configurations.id;


--
-- Name: exports; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.exports (
    id bigint NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    type character varying
);


--
-- Name: exports_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.exports_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: exports_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.exports_id_seq OWNED BY public.exports.id;


--
-- Name: file_links; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.file_links (
    id bigint NOT NULL,
    storage_id bigint,
    creator_id bigint NOT NULL,
    container_id bigint,
    container_type character varying,
    origin_id character varying,
    origin_name character varying,
    origin_created_by_name character varying,
    origin_last_modified_by_name character varying,
    origin_mime_type character varying,
    origin_created_at timestamp with time zone,
    origin_updated_at timestamp with time zone,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- Name: file_links_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.file_links_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: file_links_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.file_links_id_seq OWNED BY public.file_links.id;


--
-- Name: forums; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.forums (
    id bigint NOT NULL,
    project_id bigint NOT NULL,
    name character varying DEFAULT ''::character varying NOT NULL,
    description character varying,
    "position" integer DEFAULT 1,
    topics_count integer DEFAULT 0 NOT NULL,
    messages_count integer DEFAULT 0 NOT NULL,
    last_message_id bigint
);


--
-- Name: forums_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.forums_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: forums_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.forums_id_seq OWNED BY public.forums.id;


--
-- Name: github_check_runs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.github_check_runs (
    id bigint NOT NULL,
    github_pull_request_id bigint NOT NULL,
    github_id bigint NOT NULL,
    github_html_url character varying NOT NULL,
    app_id bigint NOT NULL,
    github_app_owner_avatar_url character varying NOT NULL,
    status character varying NOT NULL,
    name character varying NOT NULL,
    conclusion character varying,
    output_title character varying,
    output_summary character varying,
    details_url character varying,
    started_at timestamp with time zone,
    completed_at timestamp with time zone,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- Name: github_check_runs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.github_check_runs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: github_check_runs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.github_check_runs_id_seq OWNED BY public.github_check_runs.id;


--
-- Name: github_pull_requests; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.github_pull_requests (
    id bigint NOT NULL,
    github_user_id bigint,
    merged_by_id bigint,
    github_id bigint,
    number integer NOT NULL,
    github_html_url character varying NOT NULL,
    state character varying NOT NULL,
    repository character varying NOT NULL,
    github_updated_at timestamp with time zone,
    title character varying,
    body text,
    draft boolean,
    merged boolean,
    merged_at timestamp with time zone,
    comments_count integer,
    review_comments_count integer,
    additions_count integer,
    deletions_count integer,
    changed_files_count integer,
    labels json,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    repository_html_url character varying
);


--
-- Name: github_pull_requests_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.github_pull_requests_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: github_pull_requests_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.github_pull_requests_id_seq OWNED BY public.github_pull_requests.id;


--
-- Name: github_pull_requests_work_packages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.github_pull_requests_work_packages (
    github_pull_request_id bigint NOT NULL,
    work_package_id bigint NOT NULL
);


--
-- Name: github_users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.github_users (
    id bigint NOT NULL,
    github_id bigint NOT NULL,
    github_login character varying NOT NULL,
    github_html_url character varying NOT NULL,
    github_avatar_url character varying NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- Name: github_users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.github_users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: github_users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.github_users_id_seq OWNED BY public.github_users.id;


--
-- Name: grid_widgets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.grid_widgets (
    id bigint NOT NULL,
    start_row integer NOT NULL,
    end_row integer NOT NULL,
    start_column integer NOT NULL,
    end_column integer NOT NULL,
    identifier character varying,
    options text,
    grid_id bigint
);


--
-- Name: grid_widgets_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.grid_widgets_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: grid_widgets_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.grid_widgets_id_seq OWNED BY public.grid_widgets.id;


--
-- Name: grids; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.grids (
    id bigint NOT NULL,
    row_count integer NOT NULL,
    column_count integer NOT NULL,
    type character varying,
    user_id bigint,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    project_id bigint,
    name text,
    options text
);


--
-- Name: grids_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.grids_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: grids_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.grids_id_seq OWNED BY public.grids.id;


--
-- Name: group_users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.group_users (
    group_id bigint NOT NULL,
    user_id bigint NOT NULL,
    id bigint NOT NULL
);


--
-- Name: group_users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.group_users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: group_users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.group_users_id_seq OWNED BY public.group_users.id;


--
-- Name: ical_token_query_assignments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ical_token_query_assignments (
    id bigint NOT NULL,
    ical_token_id bigint,
    query_id bigint,
    created_at timestamp(6) with time zone NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    name character varying NOT NULL
);


--
-- Name: ical_token_query_assignments_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ical_token_query_assignments_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ical_token_query_assignments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.ical_token_query_assignments_id_seq OWNED BY public.ical_token_query_assignments.id;


--
-- Name: ifc_models; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ifc_models (
    id bigint NOT NULL,
    title character varying,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    project_id bigint,
    uploader_id bigint,
    is_default boolean DEFAULT false NOT NULL,
    conversion_status integer DEFAULT 0,
    conversion_error_message text
);


--
-- Name: ifc_models_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ifc_models_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ifc_models_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.ifc_models_id_seq OWNED BY public.ifc_models.id;


--
-- Name: journals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.journals (
    id bigint NOT NULL,
    journable_type character varying,
    journable_id bigint,
    user_id bigint NOT NULL,
    notes text,
    created_at timestamp with time zone NOT NULL,
    version integer DEFAULT 0 NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    data_type character varying NOT NULL,
    data_id bigint NOT NULL
);


--
-- Name: journals_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.journals_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: journals_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.journals_id_seq OWNED BY public.journals.id;


--
-- Name: labor_budget_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.labor_budget_items (
    id bigint NOT NULL,
    budget_id bigint NOT NULL,
    hours double precision NOT NULL,
    user_id bigint,
    comments character varying DEFAULT ''::character varying NOT NULL,
    amount numeric(15,4)
);


--
-- Name: labor_budget_items_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.labor_budget_items_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: labor_budget_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.labor_budget_items_id_seq OWNED BY public.labor_budget_items.id;


--
-- Name: last_project_folders; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.last_project_folders (
    id bigint NOT NULL,
    projects_storage_id bigint NOT NULL,
    origin_folder_id character varying,
    mode public.project_folder_modes DEFAULT 'inactive'::public.project_folder_modes NOT NULL,
    created_at timestamp(6) with time zone NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL
);


--
-- Name: TABLE last_project_folders; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.last_project_folders IS 'This table contains the last used project folder IDs for a project storage per mode.';


--
-- Name: last_project_folders_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.last_project_folders_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: last_project_folders_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.last_project_folders_id_seq OWNED BY public.last_project_folders.id;


--
-- Name: ldap_groups_memberships; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ldap_groups_memberships (
    id bigint NOT NULL,
    user_id bigint,
    group_id bigint,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: ldap_groups_memberships_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ldap_groups_memberships_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ldap_groups_memberships_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.ldap_groups_memberships_id_seq OWNED BY public.ldap_groups_memberships.id;


--
-- Name: ldap_groups_synchronized_filters; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ldap_groups_synchronized_filters (
    id bigint NOT NULL,
    name character varying,
    group_name_attribute character varying,
    filter_string character varying,
    auth_source_id bigint,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    base_dn text,
    sync_users boolean DEFAULT false NOT NULL
);


--
-- Name: ldap_groups_synchronized_filters_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ldap_groups_synchronized_filters_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ldap_groups_synchronized_filters_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.ldap_groups_synchronized_filters_id_seq OWNED BY public.ldap_groups_synchronized_filters.id;


--
-- Name: ldap_groups_synchronized_groups; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ldap_groups_synchronized_groups (
    id bigint NOT NULL,
    group_id bigint,
    auth_source_id bigint,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    dn text,
    users_count integer DEFAULT 0 NOT NULL,
    filter_id bigint,
    sync_users boolean DEFAULT false NOT NULL
);


--
-- Name: ldap_groups_synchronized_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ldap_groups_synchronized_groups_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ldap_groups_synchronized_groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.ldap_groups_synchronized_groups_id_seq OWNED BY public.ldap_groups_synchronized_groups.id;


--
-- Name: material_budget_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.material_budget_items (
    id bigint NOT NULL,
    budget_id bigint NOT NULL,
    units double precision NOT NULL,
    cost_type_id bigint,
    comments character varying DEFAULT ''::character varying NOT NULL,
    amount numeric(15,4)
);


--
-- Name: material_budget_items_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.material_budget_items_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: material_budget_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.material_budget_items_id_seq OWNED BY public.material_budget_items.id;


--
-- Name: meeting_content_journals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.meeting_content_journals (
    id bigint NOT NULL,
    meeting_id bigint,
    author_id bigint,
    text text,
    locked boolean
);


--
-- Name: meeting_content_journals_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.meeting_content_journals_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: meeting_content_journals_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.meeting_content_journals_id_seq OWNED BY public.meeting_content_journals.id;


--
-- Name: meeting_contents; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.meeting_contents (
    id bigint NOT NULL,
    type character varying,
    meeting_id bigint,
    author_id bigint,
    text text,
    lock_version integer,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    locked boolean DEFAULT false
);


--
-- Name: meeting_contents_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.meeting_contents_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: meeting_contents_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.meeting_contents_id_seq OWNED BY public.meeting_contents.id;


--
-- Name: meeting_journals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.meeting_journals (
    id bigint NOT NULL,
    title character varying,
    author_id bigint,
    project_id bigint,
    location character varying,
    start_time timestamp with time zone,
    duration double precision
);


--
-- Name: meeting_journals_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.meeting_journals_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: meeting_journals_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.meeting_journals_id_seq OWNED BY public.meeting_journals.id;


--
-- Name: meeting_participants; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.meeting_participants (
    id bigint NOT NULL,
    user_id bigint,
    meeting_id bigint,
    email character varying,
    name character varying,
    invited boolean,
    attended boolean,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- Name: meeting_participants_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.meeting_participants_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: meeting_participants_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.meeting_participants_id_seq OWNED BY public.meeting_participants.id;


--
-- Name: meetings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.meetings (
    id bigint NOT NULL,
    title character varying,
    author_id bigint,
    project_id bigint,
    location character varying,
    start_time timestamp with time zone,
    duration double precision,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- Name: meetings_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.meetings_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: meetings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.meetings_id_seq OWNED BY public.meetings.id;


--
-- Name: member_roles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.member_roles (
    id bigint NOT NULL,
    member_id bigint NOT NULL,
    role_id bigint NOT NULL,
    inherited_from bigint
);


--
-- Name: member_roles_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.member_roles_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: member_roles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.member_roles_id_seq OWNED BY public.member_roles.id;


--
-- Name: members; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.members (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    project_id bigint,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: members_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.members_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: members_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.members_id_seq OWNED BY public.members.id;


--
-- Name: menu_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.menu_items (
    id bigint NOT NULL,
    name character varying,
    title character varying,
    parent_id bigint,
    options text,
    navigatable_id bigint,
    type character varying
);


--
-- Name: menu_items_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.menu_items_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: menu_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.menu_items_id_seq OWNED BY public.menu_items.id;


--
-- Name: message_journals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.message_journals (
    id bigint NOT NULL,
    forum_id bigint NOT NULL,
    parent_id bigint,
    subject character varying NOT NULL,
    content text,
    author_id bigint,
    locked boolean,
    sticky integer
);


--
-- Name: message_journals_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.message_journals_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: message_journals_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.message_journals_id_seq OWNED BY public.message_journals.id;


--
-- Name: messages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.messages (
    id bigint NOT NULL,
    forum_id bigint NOT NULL,
    parent_id bigint,
    subject character varying DEFAULT ''::character varying NOT NULL,
    content text,
    author_id bigint,
    replies_count integer DEFAULT 0 NOT NULL,
    last_reply_id bigint,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    locked boolean DEFAULT false,
    sticky integer DEFAULT 0,
    sticked_on timestamp with time zone
);


--
-- Name: messages_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.messages_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: messages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.messages_id_seq OWNED BY public.messages.id;


--
-- Name: news; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.news (
    id bigint NOT NULL,
    project_id bigint,
    title character varying(60) DEFAULT ''::character varying NOT NULL,
    summary character varying DEFAULT ''::character varying,
    description text,
    author_id bigint NOT NULL,
    created_at timestamp with time zone,
    comments_count integer DEFAULT 0 NOT NULL,
    updated_at timestamp with time zone
);


--
-- Name: news_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.news_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: news_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.news_id_seq OWNED BY public.news.id;


--
-- Name: news_journals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.news_journals (
    id bigint NOT NULL,
    project_id bigint,
    title character varying(60) NOT NULL,
    summary character varying,
    description text,
    author_id bigint NOT NULL,
    comments_count integer NOT NULL
);


--
-- Name: news_journals_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.news_journals_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: news_journals_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.news_journals_id_seq OWNED BY public.news_journals.id;


--
-- Name: non_working_days; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.non_working_days (
    id bigint NOT NULL,
    name character varying NOT NULL,
    date date NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- Name: non_working_days_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.non_working_days_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: non_working_days_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.non_working_days_id_seq OWNED BY public.non_working_days.id;


--
-- Name: notification_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notification_settings (
    id bigint NOT NULL,
    project_id bigint,
    user_id bigint NOT NULL,
    watched boolean DEFAULT true,
    mentioned boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    work_package_commented boolean DEFAULT false,
    work_package_created boolean DEFAULT false,
    work_package_processed boolean DEFAULT false,
    work_package_prioritized boolean DEFAULT false,
    work_package_scheduled boolean DEFAULT false,
    news_added boolean DEFAULT false,
    news_commented boolean DEFAULT false,
    document_added boolean DEFAULT false,
    forum_messages boolean DEFAULT false,
    wiki_page_added boolean DEFAULT false,
    wiki_page_updated boolean DEFAULT false,
    membership_added boolean DEFAULT false,
    membership_updated boolean DEFAULT false,
    start_date integer DEFAULT 1,
    due_date integer DEFAULT 1,
    overdue integer,
    assignee boolean DEFAULT true NOT NULL,
    responsible boolean DEFAULT true NOT NULL
);


--
-- Name: notification_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.notification_settings_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: notification_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.notification_settings_id_seq OWNED BY public.notification_settings.id;


--
-- Name: notifications; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notifications (
    id bigint NOT NULL,
    subject text,
    read_ian boolean DEFAULT false,
    reason smallint,
    recipient_id bigint NOT NULL,
    actor_id bigint,
    resource_type character varying NOT NULL,
    resource_id bigint NOT NULL,
    project_id bigint,
    journal_id bigint,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    mail_reminder_sent boolean DEFAULT false,
    mail_alert_sent boolean
);


--
-- Name: notifications_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.notifications_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: notifications_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.notifications_id_seq OWNED BY public.notifications.id;


--
-- Name: oauth_access_grants; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.oauth_access_grants (
    id bigint NOT NULL,
    resource_owner_id bigint NOT NULL,
    application_id bigint NOT NULL,
    token character varying NOT NULL,
    expires_in integer NOT NULL,
    redirect_uri text NOT NULL,
    created_at timestamp with time zone NOT NULL,
    revoked_at timestamp with time zone,
    scopes character varying,
    code_challenge character varying,
    code_challenge_method character varying
);


--
-- Name: oauth_access_grants_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.oauth_access_grants_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: oauth_access_grants_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.oauth_access_grants_id_seq OWNED BY public.oauth_access_grants.id;


--
-- Name: oauth_access_tokens; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.oauth_access_tokens (
    id bigint NOT NULL,
    resource_owner_id bigint,
    application_id bigint,
    token character varying NOT NULL,
    refresh_token character varying,
    expires_in integer,
    revoked_at timestamp with time zone,
    created_at timestamp with time zone NOT NULL,
    scopes character varying,
    previous_refresh_token character varying DEFAULT ''::character varying NOT NULL
);


--
-- Name: oauth_access_tokens_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.oauth_access_tokens_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: oauth_access_tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.oauth_access_tokens_id_seq OWNED BY public.oauth_access_tokens.id;


--
-- Name: oauth_applications; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.oauth_applications (
    id bigint NOT NULL,
    name character varying NOT NULL,
    uid character varying NOT NULL,
    secret character varying NOT NULL,
    owner_type character varying,
    owner_id bigint,
    client_credentials_user_id bigint,
    redirect_uri text NOT NULL,
    scopes character varying DEFAULT ''::character varying NOT NULL,
    confidential boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    integration_type character varying,
    integration_id bigint
);


--
-- Name: oauth_applications_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.oauth_applications_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: oauth_applications_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.oauth_applications_id_seq OWNED BY public.oauth_applications.id;


--
-- Name: oauth_client_tokens; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.oauth_client_tokens (
    id bigint NOT NULL,
    oauth_client_id bigint NOT NULL,
    user_id bigint NOT NULL,
    access_token character varying,
    refresh_token character varying,
    token_type character varying,
    expires_in integer,
    scope character varying,
    origin_user_id character varying,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- Name: oauth_client_tokens_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.oauth_client_tokens_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: oauth_client_tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.oauth_client_tokens_id_seq OWNED BY public.oauth_client_tokens.id;


--
-- Name: oauth_clients; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.oauth_clients (
    id bigint NOT NULL,
    client_id character varying NOT NULL,
    client_secret character varying NOT NULL,
    integration_type character varying NOT NULL,
    integration_id bigint NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- Name: oauth_clients_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.oauth_clients_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: oauth_clients_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.oauth_clients_id_seq OWNED BY public.oauth_clients.id;


--
-- Name: oidc_user_session_links; Type: TABLE; Schema: public; Owner: -
--

CREATE UNLOGGED TABLE public.oidc_user_session_links (
    id bigint NOT NULL,
    oidc_session character varying NOT NULL,
    session_id bigint,
    created_at timestamp(6) with time zone NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL
);


--
-- Name: oidc_user_session_links_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.oidc_user_session_links_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: oidc_user_session_links_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.oidc_user_session_links_id_seq OWNED BY public.oidc_user_session_links.id;


--
-- Name: ordered_work_packages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ordered_work_packages (
    id bigint NOT NULL,
    "position" integer NOT NULL,
    query_id bigint,
    work_package_id bigint
);


--
-- Name: ordered_work_packages_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ordered_work_packages_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ordered_work_packages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.ordered_work_packages_id_seq OWNED BY public.ordered_work_packages.id;


--
-- Name: paper_trail_audits; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.paper_trail_audits (
    id bigint NOT NULL,
    item_type character varying NOT NULL,
    item_id bigint NOT NULL,
    event character varying NOT NULL,
    whodunnit character varying,
    stack text,
    object jsonb,
    object_changes jsonb,
    created_at timestamp(6) with time zone
);


--
-- Name: paper_trail_audits_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.paper_trail_audits_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: paper_trail_audits_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.paper_trail_audits_id_seq OWNED BY public.paper_trail_audits.id;


--
-- Name: project_journals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.project_journals (
    id bigint NOT NULL,
    name character varying NOT NULL,
    description text,
    public boolean NOT NULL,
    parent_id bigint,
    identifier character varying NOT NULL,
    active boolean NOT NULL,
    templated boolean NOT NULL,
    status_code integer,
    status_explanation text
);


--
-- Name: project_journals_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.project_journals_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: project_journals_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.project_journals_id_seq OWNED BY public.project_journals.id;


--
-- Name: projects; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.projects (
    id bigint NOT NULL,
    name character varying DEFAULT ''::character varying NOT NULL,
    description text,
    public boolean DEFAULT true NOT NULL,
    parent_id bigint,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    identifier character varying NOT NULL,
    lft integer,
    rgt integer,
    active boolean DEFAULT true NOT NULL,
    templated boolean DEFAULT false NOT NULL,
    status_code integer,
    status_explanation text
);


--
-- Name: projects_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.projects_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: projects_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.projects_id_seq OWNED BY public.projects.id;


--
-- Name: projects_storages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.projects_storages (
    id bigint NOT NULL,
    project_id bigint NOT NULL,
    storage_id bigint NOT NULL,
    creator_id bigint NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    project_folder_id character varying,
    project_folder_mode public.project_folder_modes DEFAULT 'inactive'::public.project_folder_modes NOT NULL
);


--
-- Name: projects_storages_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.projects_storages_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: projects_storages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.projects_storages_id_seq OWNED BY public.projects_storages.id;


--
-- Name: projects_types; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.projects_types (
    project_id bigint NOT NULL,
    type_id bigint NOT NULL
);


--
-- Name: queries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.queries (
    id bigint NOT NULL,
    project_id bigint,
    name character varying NOT NULL,
    filters text,
    user_id bigint NOT NULL,
    public boolean DEFAULT false NOT NULL,
    column_names text,
    sort_criteria text,
    group_by character varying,
    display_sums boolean DEFAULT false NOT NULL,
    timeline_visible boolean DEFAULT false,
    show_hierarchies boolean DEFAULT false,
    timeline_zoom_level integer DEFAULT 5,
    timeline_labels text,
    highlighting_mode text,
    highlighted_attributes text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    display_representation text,
    starred boolean DEFAULT false,
    include_subprojects boolean NOT NULL,
    timestamps character varying
);


--
-- Name: queries_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.queries_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: queries_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.queries_id_seq OWNED BY public.queries.id;


--
-- Name: rates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.rates (
    id bigint NOT NULL,
    valid_from date NOT NULL,
    rate numeric(15,4) NOT NULL,
    type character varying NOT NULL,
    project_id bigint,
    user_id bigint,
    cost_type_id bigint
);


--
-- Name: rates_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.rates_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: rates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.rates_id_seq OWNED BY public.rates.id;


--
-- Name: recaptcha_entries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.recaptcha_entries (
    id integer NOT NULL,
    user_id bigint,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    version integer NOT NULL
);


--
-- Name: recaptcha_entries_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.recaptcha_entries_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: recaptcha_entries_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.recaptcha_entries_id_seq OWNED BY public.recaptcha_entries.id;


--
-- Name: relations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.relations (
    id bigint NOT NULL,
    from_id integer NOT NULL,
    to_id integer NOT NULL,
    delay integer,
    description text,
    relation_type character varying
);


--
-- Name: relations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.relations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: relations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.relations_id_seq OWNED BY public.relations.id;


--
-- Name: repositories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.repositories (
    id bigint NOT NULL,
    project_id bigint NOT NULL,
    url character varying DEFAULT ''::character varying NOT NULL,
    login character varying(60) DEFAULT ''::character varying,
    password character varying DEFAULT ''::character varying,
    root_url character varying DEFAULT ''::character varying,
    type character varying,
    path_encoding character varying(64),
    log_encoding character varying(64),
    scm_type character varying NOT NULL,
    required_storage_bytes bigint DEFAULT 0 NOT NULL,
    storage_updated_at timestamp with time zone
);


--
-- Name: repositories_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.repositories_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: repositories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.repositories_id_seq OWNED BY public.repositories.id;


--
-- Name: role_permissions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.role_permissions (
    id bigint NOT NULL,
    permission character varying,
    role_id bigint,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- Name: role_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.role_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: role_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.role_permissions_id_seq OWNED BY public.role_permissions.id;


--
-- Name: roles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.roles (
    id bigint NOT NULL,
    name character varying(30) DEFAULT ''::character varying NOT NULL,
    "position" integer DEFAULT 1,
    builtin integer DEFAULT 0 NOT NULL,
    type character varying(30) DEFAULT 'Role'::character varying,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: roles_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.roles_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: roles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.roles_id_seq OWNED BY public.roles.id;


--
-- Name: schema_migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.schema_migrations (
    version character varying NOT NULL
);


--
-- Name: sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE UNLOGGED TABLE public.sessions (
    id bigint NOT NULL,
    session_id character varying NOT NULL,
    data text,
    updated_at timestamp with time zone,
    user_id bigint
);


--
-- Name: sessions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.sessions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: sessions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.sessions_id_seq OWNED BY public.sessions.id;


--
-- Name: settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.settings (
    id bigint NOT NULL,
    name character varying DEFAULT ''::character varying NOT NULL,
    value text,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: settings_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.settings_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.settings_id_seq OWNED BY public.settings.id;


--
-- Name: statuses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.statuses (
    id bigint NOT NULL,
    name character varying(30) DEFAULT ''::character varying NOT NULL,
    is_closed boolean DEFAULT false NOT NULL,
    is_default boolean DEFAULT false NOT NULL,
    "position" integer DEFAULT 1,
    default_done_ratio integer,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    color_id bigint,
    is_readonly boolean DEFAULT false
);


--
-- Name: statuses_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.statuses_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: statuses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.statuses_id_seq OWNED BY public.statuses.id;


--
-- Name: storages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.storages (
    id bigint NOT NULL,
    provider_type character varying NOT NULL,
    name character varying NOT NULL,
    host character varying NOT NULL,
    creator_id bigint NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    provider_fields jsonb DEFAULT '{}'::jsonb NOT NULL
);


--
-- Name: storages_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.storages_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: storages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.storages_id_seq OWNED BY public.storages.id;


--
-- Name: time_entries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.time_entries (
    id bigint NOT NULL,
    project_id bigint NOT NULL,
    user_id bigint NOT NULL,
    work_package_id bigint,
    hours double precision NOT NULL,
    comments character varying,
    activity_id bigint NOT NULL,
    spent_on date NOT NULL,
    tyear integer NOT NULL,
    tmonth integer NOT NULL,
    tweek integer NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    overridden_costs numeric(15,4),
    costs numeric(15,4),
    rate_id bigint,
    logged_by_id bigint NOT NULL
);


--
-- Name: time_entries_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.time_entries_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: time_entries_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.time_entries_id_seq OWNED BY public.time_entries.id;


--
-- Name: time_entry_activities_projects; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.time_entry_activities_projects (
    id bigint NOT NULL,
    activity_id bigint NOT NULL,
    project_id bigint NOT NULL,
    active boolean DEFAULT true
);


--
-- Name: time_entry_activities_projects_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.time_entry_activities_projects_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: time_entry_activities_projects_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.time_entry_activities_projects_id_seq OWNED BY public.time_entry_activities_projects.id;


--
-- Name: time_entry_journals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.time_entry_journals (
    id bigint NOT NULL,
    project_id bigint NOT NULL,
    user_id bigint NOT NULL,
    work_package_id bigint,
    hours double precision NOT NULL,
    comments character varying,
    activity_id bigint NOT NULL,
    spent_on date NOT NULL,
    tyear integer NOT NULL,
    tmonth integer NOT NULL,
    tweek integer NOT NULL,
    overridden_costs numeric(15,2),
    costs numeric(15,2),
    rate_id bigint,
    logged_by_id bigint NOT NULL
);


--
-- Name: time_entry_journals_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.time_entry_journals_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: time_entry_journals_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.time_entry_journals_id_seq OWNED BY public.time_entry_journals.id;


--
-- Name: tokens; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tokens (
    id bigint NOT NULL,
    user_id bigint,
    type character varying,
    value character varying(128) DEFAULT ''::character varying NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    expires_on timestamp with time zone
);


--
-- Name: tokens_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.tokens_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.tokens_id_seq OWNED BY public.tokens.id;


--
-- Name: two_factor_authentication_devices; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.two_factor_authentication_devices (
    id bigint NOT NULL,
    type character varying,
    "default" boolean DEFAULT false NOT NULL,
    active boolean DEFAULT false NOT NULL,
    channel character varying NOT NULL,
    phone_number character varying,
    identifier character varying NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    last_used_at integer,
    otp_secret text,
    user_id bigint
);


--
-- Name: two_factor_authentication_devices_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.two_factor_authentication_devices_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: two_factor_authentication_devices_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.two_factor_authentication_devices_id_seq OWNED BY public.two_factor_authentication_devices.id;


--
-- Name: types; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.types (
    id bigint NOT NULL,
    name character varying DEFAULT ''::character varying NOT NULL,
    "position" integer DEFAULT 1,
    is_in_roadmap boolean DEFAULT true NOT NULL,
    is_milestone boolean DEFAULT false NOT NULL,
    is_default boolean DEFAULT false NOT NULL,
    color_id bigint,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    is_standard boolean DEFAULT false NOT NULL,
    attribute_groups text,
    description text
);


--
-- Name: types_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.types_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: types_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.types_id_seq OWNED BY public.types.id;


--
-- Name: user_passwords; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_passwords (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    hashed_password character varying(128) NOT NULL,
    salt character varying(64),
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    type character varying NOT NULL
);


--
-- Name: user_passwords_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.user_passwords_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: user_passwords_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.user_passwords_id_seq OWNED BY public.user_passwords.id;


--
-- Name: user_preferences; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_preferences (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    settings jsonb DEFAULT '{}'::jsonb
);


--
-- Name: user_preferences_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.user_preferences_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: user_preferences_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.user_preferences_id_seq OWNED BY public.user_preferences.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id bigint NOT NULL,
    login character varying(256) DEFAULT ''::character varying NOT NULL,
    firstname character varying DEFAULT ''::character varying NOT NULL,
    lastname character varying DEFAULT ''::character varying NOT NULL,
    mail character varying DEFAULT ''::character varying NOT NULL,
    admin boolean DEFAULT false NOT NULL,
    status integer DEFAULT 1 NOT NULL,
    last_login_on timestamp with time zone,
    language character varying(5) DEFAULT ''::character varying,
    auth_source_id bigint,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    type character varying,
    identity_url character varying,
    first_login boolean DEFAULT true NOT NULL,
    force_password_change boolean DEFAULT false,
    failed_login_count integer DEFAULT 0,
    last_failed_login_on timestamp with time zone,
    consented_at timestamp with time zone
);


--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: version_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.version_settings (
    id bigint NOT NULL,
    project_id bigint,
    version_id bigint,
    display integer,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- Name: version_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.version_settings_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: version_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.version_settings_id_seq OWNED BY public.version_settings.id;


--
-- Name: versions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.versions (
    id bigint NOT NULL,
    project_id bigint NOT NULL,
    name character varying DEFAULT ''::character varying NOT NULL,
    description character varying DEFAULT ''::character varying,
    effective_date date,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    wiki_page_title character varying,
    status character varying DEFAULT 'open'::character varying,
    sharing character varying DEFAULT 'none'::character varying NOT NULL,
    start_date date
);


--
-- Name: versions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.versions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: versions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.versions_id_seq OWNED BY public.versions.id;


--
-- Name: views; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.views (
    id bigint NOT NULL,
    query_id bigint NOT NULL,
    options jsonb DEFAULT '{}'::jsonb NOT NULL,
    type character varying NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- Name: views_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.views_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: views_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.views_id_seq OWNED BY public.views.id;


--
-- Name: watchers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.watchers (
    id bigint NOT NULL,
    watchable_type character varying DEFAULT ''::character varying NOT NULL,
    watchable_id bigint NOT NULL,
    user_id bigint
);


--
-- Name: watchers_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.watchers_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: watchers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.watchers_id_seq OWNED BY public.watchers.id;


--
-- Name: webhooks_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.webhooks_events (
    id bigint NOT NULL,
    name character varying,
    webhooks_webhook_id bigint
);


--
-- Name: webhooks_events_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.webhooks_events_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: webhooks_events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.webhooks_events_id_seq OWNED BY public.webhooks_events.id;


--
-- Name: webhooks_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.webhooks_logs (
    id bigint NOT NULL,
    webhooks_webhook_id bigint,
    event_name character varying,
    url character varying,
    request_headers text,
    request_body text,
    response_code integer,
    response_headers text,
    response_body text,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- Name: webhooks_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.webhooks_logs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: webhooks_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.webhooks_logs_id_seq OWNED BY public.webhooks_logs.id;


--
-- Name: webhooks_projects; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.webhooks_projects (
    id bigint NOT NULL,
    project_id bigint,
    webhooks_webhook_id bigint
);


--
-- Name: webhooks_projects_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.webhooks_projects_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: webhooks_projects_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.webhooks_projects_id_seq OWNED BY public.webhooks_projects.id;


--
-- Name: webhooks_webhooks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.webhooks_webhooks (
    id bigint NOT NULL,
    name character varying,
    url text,
    description text NOT NULL,
    secret character varying,
    enabled boolean NOT NULL,
    all_projects boolean NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- Name: webhooks_webhooks_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.webhooks_webhooks_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: webhooks_webhooks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.webhooks_webhooks_id_seq OWNED BY public.webhooks_webhooks.id;


--
-- Name: wiki_page_journals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.wiki_page_journals (
    id bigint NOT NULL,
    author_id bigint,
    text text
);


--
-- Name: wiki_page_journals_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.wiki_page_journals_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: wiki_page_journals_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.wiki_page_journals_id_seq OWNED BY public.wiki_page_journals.id;


--
-- Name: wiki_pages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.wiki_pages (
    id bigint NOT NULL,
    wiki_id bigint NOT NULL,
    title character varying NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    protected boolean DEFAULT false NOT NULL,
    parent_id bigint,
    slug character varying NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    author_id bigint NOT NULL,
    text text,
    lock_version integer NOT NULL
);


--
-- Name: wiki_pages_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.wiki_pages_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: wiki_pages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.wiki_pages_id_seq OWNED BY public.wiki_pages.id;


--
-- Name: wiki_redirects; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.wiki_redirects (
    id bigint NOT NULL,
    wiki_id bigint NOT NULL,
    title character varying,
    redirects_to character varying,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: wiki_redirects_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.wiki_redirects_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: wiki_redirects_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.wiki_redirects_id_seq OWNED BY public.wiki_redirects.id;


--
-- Name: wikis; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.wikis (
    id bigint NOT NULL,
    project_id bigint NOT NULL,
    start_page character varying NOT NULL,
    status integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- Name: wikis_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.wikis_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: wikis_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.wikis_id_seq OWNED BY public.wikis.id;


--
-- Name: work_package_hierarchies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.work_package_hierarchies (
    ancestor_id integer NOT NULL,
    descendant_id integer NOT NULL,
    generations integer NOT NULL
);


--
-- Name: work_package_journals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.work_package_journals (
    id bigint NOT NULL,
    type_id bigint NOT NULL,
    project_id bigint NOT NULL,
    subject character varying NOT NULL,
    description text,
    due_date date,
    category_id bigint,
    status_id bigint NOT NULL,
    assigned_to_id bigint,
    priority_id bigint NOT NULL,
    version_id bigint,
    author_id bigint NOT NULL,
    done_ratio integer NOT NULL,
    estimated_hours double precision,
    start_date date,
    parent_id bigint,
    responsible_id bigint,
    budget_id bigint,
    story_points integer,
    remaining_hours double precision,
    derived_estimated_hours double precision,
    schedule_manually boolean,
    duration integer,
    ignore_non_working_days boolean NOT NULL
);


--
-- Name: work_package_journals_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.work_package_journals_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: work_package_journals_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.work_package_journals_id_seq OWNED BY public.work_package_journals.id;


--
-- Name: work_packages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.work_packages (
    id bigint NOT NULL,
    type_id bigint NOT NULL,
    project_id bigint NOT NULL,
    subject character varying DEFAULT ''::character varying NOT NULL,
    description text,
    due_date date,
    category_id bigint,
    status_id bigint NOT NULL,
    assigned_to_id bigint,
    priority_id bigint,
    version_id bigint,
    author_id bigint NOT NULL,
    lock_version integer DEFAULT 0 NOT NULL,
    done_ratio integer DEFAULT 0 NOT NULL,
    estimated_hours double precision,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    start_date date,
    responsible_id bigint,
    budget_id bigint,
    "position" integer,
    story_points integer,
    remaining_hours double precision,
    derived_estimated_hours double precision,
    schedule_manually boolean DEFAULT false,
    parent_id bigint,
    duration integer,
    ignore_non_working_days boolean DEFAULT false NOT NULL,
    CONSTRAINT work_packages_due_larger_start_date CHECK ((due_date >= start_date))
);


--
-- Name: work_packages_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.work_packages_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: work_packages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.work_packages_id_seq OWNED BY public.work_packages.id;


--
-- Name: workflows; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.workflows (
    id bigint NOT NULL,
    type_id bigint NOT NULL,
    old_status_id bigint NOT NULL,
    new_status_id bigint NOT NULL,
    role_id bigint NOT NULL,
    assignee boolean DEFAULT false NOT NULL,
    author boolean DEFAULT false NOT NULL
);


--
-- Name: workflows_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.workflows_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: workflows_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.workflows_id_seq OWNED BY public.workflows.id;


--
-- Name: announcements id; Type: DEFAULT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.announcements ALTER COLUMN id SET DEFAULT nextval('backup_preview_5.announcements_id_seq'::regclass);


--
-- Name: attachable_journals id; Type: DEFAULT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.attachable_journals ALTER COLUMN id SET DEFAULT nextval('backup_preview_5.attachable_journals_id_seq'::regclass);


--
-- Name: attachment_journals id; Type: DEFAULT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.attachment_journals ALTER COLUMN id SET DEFAULT nextval('backup_preview_5.attachment_journals_id_seq'::regclass);


--
-- Name: attachments id; Type: DEFAULT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.attachments ALTER COLUMN id SET DEFAULT nextval('backup_preview_5.attachments_id_seq'::regclass);


--
-- Name: attribute_help_texts id; Type: DEFAULT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.attribute_help_texts ALTER COLUMN id SET DEFAULT nextval('backup_preview_5.attribute_help_texts_id_seq'::regclass);


--
-- Name: auth_sources id; Type: DEFAULT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.auth_sources ALTER COLUMN id SET DEFAULT nextval('backup_preview_5.auth_sources_id_seq'::regclass);


--
-- Name: backups id; Type: DEFAULT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.backups ALTER COLUMN id SET DEFAULT nextval('backup_preview_5.backups_id_seq'::regclass);


--
-- Name: bcf_comments id; Type: DEFAULT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.bcf_comments ALTER COLUMN id SET DEFAULT nextval('backup_preview_5.bcf_comments_id_seq'::regclass);


--
-- Name: bcf_issues id; Type: DEFAULT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.bcf_issues ALTER COLUMN id SET DEFAULT nextval('backup_preview_5.bcf_issues_id_seq'::regclass);


--
-- Name: bcf_viewpoints id; Type: DEFAULT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.bcf_viewpoints ALTER COLUMN id SET DEFAULT nextval('backup_preview_5.bcf_viewpoints_id_seq'::regclass);


--
-- Name: budget_journals id; Type: DEFAULT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.budget_journals ALTER COLUMN id SET DEFAULT nextval('backup_preview_5.budget_journals_id_seq'::regclass);


--
-- Name: budgets id; Type: DEFAULT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.budgets ALTER COLUMN id SET DEFAULT nextval('backup_preview_5.budgets_id_seq'::regclass);


--
-- Name: categories id; Type: DEFAULT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.categories ALTER COLUMN id SET DEFAULT nextval('backup_preview_5.categories_id_seq'::regclass);


--
-- Name: changes id; Type: DEFAULT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.changes ALTER COLUMN id SET DEFAULT nextval('backup_preview_5.changes_id_seq'::regclass);


--
-- Name: changeset_journals id; Type: DEFAULT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.changeset_journals ALTER COLUMN id SET DEFAULT nextval('backup_preview_5.changeset_journals_id_seq'::regclass);


--
-- Name: changesets id; Type: DEFAULT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.changesets ALTER COLUMN id SET DEFAULT nextval('backup_preview_5.changesets_id_seq'::regclass);


--
-- Name: colors id; Type: DEFAULT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.colors ALTER COLUMN id SET DEFAULT nextval('backup_preview_5.colors_id_seq'::regclass);


--
-- Name: comments id; Type: DEFAULT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.comments ALTER COLUMN id SET DEFAULT nextval('backup_preview_5.comments_id_seq'::regclass);


--
-- Name: cost_entries id; Type: DEFAULT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.cost_entries ALTER COLUMN id SET DEFAULT nextval('backup_preview_5.cost_entries_id_seq'::regclass);


--
-- Name: cost_queries id; Type: DEFAULT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.cost_queries ALTER COLUMN id SET DEFAULT nextval('backup_preview_5.cost_queries_id_seq'::regclass);


--
-- Name: cost_types id; Type: DEFAULT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.cost_types ALTER COLUMN id SET DEFAULT nextval('backup_preview_5.cost_types_id_seq'::regclass);


--
-- Name: custom_actions id; Type: DEFAULT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.custom_actions ALTER COLUMN id SET DEFAULT nextval('backup_preview_5.custom_actions_id_seq'::regclass);


--
-- Name: custom_actions_projects id; Type: DEFAULT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.custom_actions_projects ALTER COLUMN id SET DEFAULT nextval('backup_preview_5.custom_actions_projects_id_seq'::regclass);


--
-- Name: custom_actions_roles id; Type: DEFAULT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.custom_actions_roles ALTER COLUMN id SET DEFAULT nextval('backup_preview_5.custom_actions_roles_id_seq'::regclass);


--
-- Name: custom_actions_statuses id; Type: DEFAULT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.custom_actions_statuses ALTER COLUMN id SET DEFAULT nextval('backup_preview_5.custom_actions_statuses_id_seq'::regclass);


--
-- Name: custom_actions_types id; Type: DEFAULT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.custom_actions_types ALTER COLUMN id SET DEFAULT nextval('backup_preview_5.custom_actions_types_id_seq'::regclass);


--
-- Name: custom_fields id; Type: DEFAULT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.custom_fields ALTER COLUMN id SET DEFAULT nextval('backup_preview_5.custom_fields_id_seq'::regclass);


--
-- Name: custom_options id; Type: DEFAULT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.custom_options ALTER COLUMN id SET DEFAULT nextval('backup_preview_5.custom_options_id_seq'::regclass);


--
-- Name: custom_styles id; Type: DEFAULT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.custom_styles ALTER COLUMN id SET DEFAULT nextval('backup_preview_5.custom_styles_id_seq'::regclass);


--
-- Name: custom_values id; Type: DEFAULT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.custom_values ALTER COLUMN id SET DEFAULT nextval('backup_preview_5.custom_values_id_seq'::regclass);


--
-- Name: customizable_journals id; Type: DEFAULT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.customizable_journals ALTER COLUMN id SET DEFAULT nextval('backup_preview_5.customizable_journals_id_seq'::regclass);


--
-- Name: delayed_job_statuses id; Type: DEFAULT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.delayed_job_statuses ALTER COLUMN id SET DEFAULT nextval('backup_preview_5.delayed_job_statuses_id_seq'::regclass);


--
-- Name: delayed_jobs id; Type: DEFAULT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.delayed_jobs ALTER COLUMN id SET DEFAULT nextval('backup_preview_5.delayed_jobs_id_seq'::regclass);


--
-- Name: design_colors id; Type: DEFAULT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.design_colors ALTER COLUMN id SET DEFAULT nextval('backup_preview_5.design_colors_id_seq'::regclass);


--
-- Name: document_journals id; Type: DEFAULT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.document_journals ALTER COLUMN id SET DEFAULT nextval('backup_preview_5.document_journals_id_seq'::regclass);


--
-- Name: documents id; Type: DEFAULT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.documents ALTER COLUMN id SET DEFAULT nextval('backup_preview_5.documents_id_seq'::regclass);


--
-- Name: enabled_modules id; Type: DEFAULT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.enabled_modules ALTER COLUMN id SET DEFAULT nextval('backup_preview_5.enabled_modules_id_seq'::regclass);


--
-- Name: enterprise_tokens id; Type: DEFAULT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.enterprise_tokens ALTER COLUMN id SET DEFAULT nextval('backup_preview_5.enterprise_tokens_id_seq'::regclass);


--
-- Name: enumerations id; Type: DEFAULT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.enumerations ALTER COLUMN id SET DEFAULT nextval('backup_preview_5.enumerations_id_seq'::regclass);


--
-- Name: export_card_configurations id; Type: DEFAULT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.export_card_configurations ALTER COLUMN id SET DEFAULT nextval('backup_preview_5.export_card_configurations_id_seq'::regclass);


--
-- Name: exports id; Type: DEFAULT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.exports ALTER COLUMN id SET DEFAULT nextval('backup_preview_5.exports_id_seq'::regclass);


--
-- Name: file_links id; Type: DEFAULT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.file_links ALTER COLUMN id SET DEFAULT nextval('backup_preview_5.file_links_id_seq'::regclass);


--
-- Name: forums id; Type: DEFAULT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.forums ALTER COLUMN id SET DEFAULT nextval('backup_preview_5.forums_id_seq'::regclass);


--
-- Name: github_check_runs id; Type: DEFAULT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.github_check_runs ALTER COLUMN id SET DEFAULT nextval('backup_preview_5.github_check_runs_id_seq'::regclass);


--
-- Name: github_pull_requests id; Type: DEFAULT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.github_pull_requests ALTER COLUMN id SET DEFAULT nextval('backup_preview_5.github_pull_requests_id_seq'::regclass);


--
-- Name: github_users id; Type: DEFAULT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.github_users ALTER COLUMN id SET DEFAULT nextval('backup_preview_5.github_users_id_seq'::regclass);


--
-- Name: grid_widgets id; Type: DEFAULT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.grid_widgets ALTER COLUMN id SET DEFAULT nextval('backup_preview_5.grid_widgets_id_seq'::regclass);


--
-- Name: grids id; Type: DEFAULT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.grids ALTER COLUMN id SET DEFAULT nextval('backup_preview_5.grids_id_seq'::regclass);


--
-- Name: group_users id; Type: DEFAULT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.group_users ALTER COLUMN id SET DEFAULT nextval('backup_preview_5.group_users_id_seq'::regclass);


--
-- Name: ical_token_query_assignments id; Type: DEFAULT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.ical_token_query_assignments ALTER COLUMN id SET DEFAULT nextval('backup_preview_5.ical_token_query_assignments_id_seq'::regclass);


--
-- Name: ifc_models id; Type: DEFAULT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.ifc_models ALTER COLUMN id SET DEFAULT nextval('backup_preview_5.ifc_models_id_seq'::regclass);


--
-- Name: journals id; Type: DEFAULT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.journals ALTER COLUMN id SET DEFAULT nextval('backup_preview_5.journals_id_seq'::regclass);


--
-- Name: labor_budget_items id; Type: DEFAULT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.labor_budget_items ALTER COLUMN id SET DEFAULT nextval('backup_preview_5.labor_budget_items_id_seq'::regclass);


--
-- Name: last_project_folders id; Type: DEFAULT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.last_project_folders ALTER COLUMN id SET DEFAULT nextval('backup_preview_5.last_project_folders_id_seq'::regclass);


--
-- Name: ldap_groups_memberships id; Type: DEFAULT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.ldap_groups_memberships ALTER COLUMN id SET DEFAULT nextval('backup_preview_5.ldap_groups_memberships_id_seq'::regclass);


--
-- Name: ldap_groups_synchronized_filters id; Type: DEFAULT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.ldap_groups_synchronized_filters ALTER COLUMN id SET DEFAULT nextval('backup_preview_5.ldap_groups_synchronized_filters_id_seq'::regclass);


--
-- Name: ldap_groups_synchronized_groups id; Type: DEFAULT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.ldap_groups_synchronized_groups ALTER COLUMN id SET DEFAULT nextval('backup_preview_5.ldap_groups_synchronized_groups_id_seq'::regclass);


--
-- Name: material_budget_items id; Type: DEFAULT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.material_budget_items ALTER COLUMN id SET DEFAULT nextval('backup_preview_5.material_budget_items_id_seq'::regclass);


--
-- Name: meeting_content_journals id; Type: DEFAULT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.meeting_content_journals ALTER COLUMN id SET DEFAULT nextval('backup_preview_5.meeting_content_journals_id_seq'::regclass);


--
-- Name: meeting_contents id; Type: DEFAULT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.meeting_contents ALTER COLUMN id SET DEFAULT nextval('backup_preview_5.meeting_contents_id_seq'::regclass);


--
-- Name: meeting_journals id; Type: DEFAULT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.meeting_journals ALTER COLUMN id SET DEFAULT nextval('backup_preview_5.meeting_journals_id_seq'::regclass);


--
-- Name: meeting_participants id; Type: DEFAULT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.meeting_participants ALTER COLUMN id SET DEFAULT nextval('backup_preview_5.meeting_participants_id_seq'::regclass);


--
-- Name: meetings id; Type: DEFAULT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.meetings ALTER COLUMN id SET DEFAULT nextval('backup_preview_5.meetings_id_seq'::regclass);


--
-- Name: member_roles id; Type: DEFAULT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.member_roles ALTER COLUMN id SET DEFAULT nextval('backup_preview_5.member_roles_id_seq'::regclass);


--
-- Name: members id; Type: DEFAULT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.members ALTER COLUMN id SET DEFAULT nextval('backup_preview_5.members_id_seq'::regclass);


--
-- Name: menu_items id; Type: DEFAULT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.menu_items ALTER COLUMN id SET DEFAULT nextval('backup_preview_5.menu_items_id_seq'::regclass);


--
-- Name: message_journals id; Type: DEFAULT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.message_journals ALTER COLUMN id SET DEFAULT nextval('backup_preview_5.message_journals_id_seq'::regclass);


--
-- Name: messages id; Type: DEFAULT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.messages ALTER COLUMN id SET DEFAULT nextval('backup_preview_5.messages_id_seq'::regclass);


--
-- Name: news id; Type: DEFAULT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.news ALTER COLUMN id SET DEFAULT nextval('backup_preview_5.news_id_seq'::regclass);


--
-- Name: news_journals id; Type: DEFAULT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.news_journals ALTER COLUMN id SET DEFAULT nextval('backup_preview_5.news_journals_id_seq'::regclass);


--
-- Name: non_working_days id; Type: DEFAULT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.non_working_days ALTER COLUMN id SET DEFAULT nextval('backup_preview_5.non_working_days_id_seq'::regclass);


--
-- Name: notification_settings id; Type: DEFAULT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.notification_settings ALTER COLUMN id SET DEFAULT nextval('backup_preview_5.notification_settings_id_seq'::regclass);


--
-- Name: notifications id; Type: DEFAULT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.notifications ALTER COLUMN id SET DEFAULT nextval('backup_preview_5.notifications_id_seq'::regclass);


--
-- Name: oauth_access_grants id; Type: DEFAULT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.oauth_access_grants ALTER COLUMN id SET DEFAULT nextval('backup_preview_5.oauth_access_grants_id_seq'::regclass);


--
-- Name: oauth_access_tokens id; Type: DEFAULT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.oauth_access_tokens ALTER COLUMN id SET DEFAULT nextval('backup_preview_5.oauth_access_tokens_id_seq'::regclass);


--
-- Name: oauth_applications id; Type: DEFAULT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.oauth_applications ALTER COLUMN id SET DEFAULT nextval('backup_preview_5.oauth_applications_id_seq'::regclass);


--
-- Name: oauth_client_tokens id; Type: DEFAULT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.oauth_client_tokens ALTER COLUMN id SET DEFAULT nextval('backup_preview_5.oauth_client_tokens_id_seq'::regclass);


--
-- Name: oauth_clients id; Type: DEFAULT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.oauth_clients ALTER COLUMN id SET DEFAULT nextval('backup_preview_5.oauth_clients_id_seq'::regclass);


--
-- Name: oidc_user_session_links id; Type: DEFAULT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.oidc_user_session_links ALTER COLUMN id SET DEFAULT nextval('backup_preview_5.oidc_user_session_links_id_seq'::regclass);


--
-- Name: ordered_work_packages id; Type: DEFAULT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.ordered_work_packages ALTER COLUMN id SET DEFAULT nextval('backup_preview_5.ordered_work_packages_id_seq'::regclass);


--
-- Name: paper_trail_audits id; Type: DEFAULT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.paper_trail_audits ALTER COLUMN id SET DEFAULT nextval('backup_preview_5.paper_trail_audits_id_seq'::regclass);


--
-- Name: project_journals id; Type: DEFAULT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.project_journals ALTER COLUMN id SET DEFAULT nextval('backup_preview_5.project_journals_id_seq'::regclass);


--
-- Name: projects id; Type: DEFAULT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.projects ALTER COLUMN id SET DEFAULT nextval('backup_preview_5.projects_id_seq'::regclass);


--
-- Name: projects_storages id; Type: DEFAULT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.projects_storages ALTER COLUMN id SET DEFAULT nextval('backup_preview_5.projects_storages_id_seq'::regclass);


--
-- Name: queries id; Type: DEFAULT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.queries ALTER COLUMN id SET DEFAULT nextval('backup_preview_5.queries_id_seq'::regclass);


--
-- Name: rates id; Type: DEFAULT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.rates ALTER COLUMN id SET DEFAULT nextval('backup_preview_5.rates_id_seq'::regclass);


--
-- Name: recaptcha_entries id; Type: DEFAULT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.recaptcha_entries ALTER COLUMN id SET DEFAULT nextval('backup_preview_5.recaptcha_entries_id_seq'::regclass);


--
-- Name: relations id; Type: DEFAULT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.relations ALTER COLUMN id SET DEFAULT nextval('backup_preview_5.relations_id_seq'::regclass);


--
-- Name: repositories id; Type: DEFAULT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.repositories ALTER COLUMN id SET DEFAULT nextval('backup_preview_5.repositories_id_seq'::regclass);


--
-- Name: role_permissions id; Type: DEFAULT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.role_permissions ALTER COLUMN id SET DEFAULT nextval('backup_preview_5.role_permissions_id_seq'::regclass);


--
-- Name: roles id; Type: DEFAULT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.roles ALTER COLUMN id SET DEFAULT nextval('backup_preview_5.roles_id_seq'::regclass);


--
-- Name: sessions id; Type: DEFAULT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.sessions ALTER COLUMN id SET DEFAULT nextval('backup_preview_5.sessions_id_seq'::regclass);


--
-- Name: settings id; Type: DEFAULT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.settings ALTER COLUMN id SET DEFAULT nextval('backup_preview_5.settings_id_seq'::regclass);


--
-- Name: statuses id; Type: DEFAULT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.statuses ALTER COLUMN id SET DEFAULT nextval('backup_preview_5.statuses_id_seq'::regclass);


--
-- Name: storages id; Type: DEFAULT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.storages ALTER COLUMN id SET DEFAULT nextval('backup_preview_5.storages_id_seq'::regclass);


--
-- Name: time_entries id; Type: DEFAULT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.time_entries ALTER COLUMN id SET DEFAULT nextval('backup_preview_5.time_entries_id_seq'::regclass);


--
-- Name: time_entry_activities_projects id; Type: DEFAULT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.time_entry_activities_projects ALTER COLUMN id SET DEFAULT nextval('backup_preview_5.time_entry_activities_projects_id_seq'::regclass);


--
-- Name: time_entry_journals id; Type: DEFAULT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.time_entry_journals ALTER COLUMN id SET DEFAULT nextval('backup_preview_5.time_entry_journals_id_seq'::regclass);


--
-- Name: tokens id; Type: DEFAULT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.tokens ALTER COLUMN id SET DEFAULT nextval('backup_preview_5.tokens_id_seq'::regclass);


--
-- Name: two_factor_authentication_devices id; Type: DEFAULT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.two_factor_authentication_devices ALTER COLUMN id SET DEFAULT nextval('backup_preview_5.two_factor_authentication_devices_id_seq'::regclass);


--
-- Name: types id; Type: DEFAULT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.types ALTER COLUMN id SET DEFAULT nextval('backup_preview_5.types_id_seq'::regclass);


--
-- Name: user_passwords id; Type: DEFAULT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.user_passwords ALTER COLUMN id SET DEFAULT nextval('backup_preview_5.user_passwords_id_seq'::regclass);


--
-- Name: user_preferences id; Type: DEFAULT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.user_preferences ALTER COLUMN id SET DEFAULT nextval('backup_preview_5.user_preferences_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.users ALTER COLUMN id SET DEFAULT nextval('backup_preview_5.users_id_seq'::regclass);


--
-- Name: version_settings id; Type: DEFAULT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.version_settings ALTER COLUMN id SET DEFAULT nextval('backup_preview_5.version_settings_id_seq'::regclass);


--
-- Name: versions id; Type: DEFAULT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.versions ALTER COLUMN id SET DEFAULT nextval('backup_preview_5.versions_id_seq'::regclass);


--
-- Name: views id; Type: DEFAULT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.views ALTER COLUMN id SET DEFAULT nextval('backup_preview_5.views_id_seq'::regclass);


--
-- Name: watchers id; Type: DEFAULT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.watchers ALTER COLUMN id SET DEFAULT nextval('backup_preview_5.watchers_id_seq'::regclass);


--
-- Name: webhooks_events id; Type: DEFAULT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.webhooks_events ALTER COLUMN id SET DEFAULT nextval('backup_preview_5.webhooks_events_id_seq'::regclass);


--
-- Name: webhooks_logs id; Type: DEFAULT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.webhooks_logs ALTER COLUMN id SET DEFAULT nextval('backup_preview_5.webhooks_logs_id_seq'::regclass);


--
-- Name: webhooks_projects id; Type: DEFAULT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.webhooks_projects ALTER COLUMN id SET DEFAULT nextval('backup_preview_5.webhooks_projects_id_seq'::regclass);


--
-- Name: webhooks_webhooks id; Type: DEFAULT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.webhooks_webhooks ALTER COLUMN id SET DEFAULT nextval('backup_preview_5.webhooks_webhooks_id_seq'::regclass);


--
-- Name: wiki_page_journals id; Type: DEFAULT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.wiki_page_journals ALTER COLUMN id SET DEFAULT nextval('backup_preview_5.wiki_page_journals_id_seq'::regclass);


--
-- Name: wiki_pages id; Type: DEFAULT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.wiki_pages ALTER COLUMN id SET DEFAULT nextval('backup_preview_5.wiki_pages_id_seq'::regclass);


--
-- Name: wiki_redirects id; Type: DEFAULT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.wiki_redirects ALTER COLUMN id SET DEFAULT nextval('backup_preview_5.wiki_redirects_id_seq'::regclass);


--
-- Name: wikis id; Type: DEFAULT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.wikis ALTER COLUMN id SET DEFAULT nextval('backup_preview_5.wikis_id_seq'::regclass);


--
-- Name: work_package_journals id; Type: DEFAULT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.work_package_journals ALTER COLUMN id SET DEFAULT nextval('backup_preview_5.work_package_journals_id_seq'::regclass);


--
-- Name: work_packages id; Type: DEFAULT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.work_packages ALTER COLUMN id SET DEFAULT nextval('backup_preview_5.work_packages_id_seq'::regclass);


--
-- Name: workflows id; Type: DEFAULT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.workflows ALTER COLUMN id SET DEFAULT nextval('backup_preview_5.workflows_id_seq'::regclass);


--
-- Name: announcements id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.announcements ALTER COLUMN id SET DEFAULT nextval('public.announcements_id_seq'::regclass);


--
-- Name: attachable_journals id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attachable_journals ALTER COLUMN id SET DEFAULT nextval('public.attachable_journals_id_seq'::regclass);


--
-- Name: attachment_journals id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attachment_journals ALTER COLUMN id SET DEFAULT nextval('public.attachment_journals_id_seq'::regclass);


--
-- Name: attachments id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attachments ALTER COLUMN id SET DEFAULT nextval('public.attachments_id_seq'::regclass);


--
-- Name: attribute_help_texts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attribute_help_texts ALTER COLUMN id SET DEFAULT nextval('public.attribute_help_texts_id_seq'::regclass);


--
-- Name: auth_sources id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_sources ALTER COLUMN id SET DEFAULT nextval('public.auth_sources_id_seq'::regclass);


--
-- Name: backups id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.backups ALTER COLUMN id SET DEFAULT nextval('public.backups_id_seq'::regclass);


--
-- Name: bcf_comments id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bcf_comments ALTER COLUMN id SET DEFAULT nextval('public.bcf_comments_id_seq'::regclass);


--
-- Name: bcf_issues id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bcf_issues ALTER COLUMN id SET DEFAULT nextval('public.bcf_issues_id_seq'::regclass);


--
-- Name: bcf_viewpoints id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bcf_viewpoints ALTER COLUMN id SET DEFAULT nextval('public.bcf_viewpoints_id_seq'::regclass);


--
-- Name: budget_journals id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.budget_journals ALTER COLUMN id SET DEFAULT nextval('public.budget_journals_id_seq'::regclass);


--
-- Name: budgets id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.budgets ALTER COLUMN id SET DEFAULT nextval('public.budgets_id_seq'::regclass);


--
-- Name: categories id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categories ALTER COLUMN id SET DEFAULT nextval('public.categories_id_seq'::regclass);


--
-- Name: changes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.changes ALTER COLUMN id SET DEFAULT nextval('public.changes_id_seq'::regclass);


--
-- Name: changeset_journals id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.changeset_journals ALTER COLUMN id SET DEFAULT nextval('public.changeset_journals_id_seq'::regclass);


--
-- Name: changesets id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.changesets ALTER COLUMN id SET DEFAULT nextval('public.changesets_id_seq'::regclass);


--
-- Name: colors id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.colors ALTER COLUMN id SET DEFAULT nextval('public.colors_id_seq'::regclass);


--
-- Name: comments id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.comments ALTER COLUMN id SET DEFAULT nextval('public.comments_id_seq'::regclass);


--
-- Name: cost_entries id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cost_entries ALTER COLUMN id SET DEFAULT nextval('public.cost_entries_id_seq'::regclass);


--
-- Name: cost_queries id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cost_queries ALTER COLUMN id SET DEFAULT nextval('public.cost_queries_id_seq'::regclass);


--
-- Name: cost_types id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cost_types ALTER COLUMN id SET DEFAULT nextval('public.cost_types_id_seq'::regclass);


--
-- Name: custom_actions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.custom_actions ALTER COLUMN id SET DEFAULT nextval('public.custom_actions_id_seq'::regclass);


--
-- Name: custom_actions_projects id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.custom_actions_projects ALTER COLUMN id SET DEFAULT nextval('public.custom_actions_projects_id_seq'::regclass);


--
-- Name: custom_actions_roles id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.custom_actions_roles ALTER COLUMN id SET DEFAULT nextval('public.custom_actions_roles_id_seq'::regclass);


--
-- Name: custom_actions_statuses id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.custom_actions_statuses ALTER COLUMN id SET DEFAULT nextval('public.custom_actions_statuses_id_seq'::regclass);


--
-- Name: custom_actions_types id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.custom_actions_types ALTER COLUMN id SET DEFAULT nextval('public.custom_actions_types_id_seq'::regclass);


--
-- Name: custom_fields id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.custom_fields ALTER COLUMN id SET DEFAULT nextval('public.custom_fields_id_seq'::regclass);


--
-- Name: custom_options id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.custom_options ALTER COLUMN id SET DEFAULT nextval('public.custom_options_id_seq'::regclass);


--
-- Name: custom_styles id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.custom_styles ALTER COLUMN id SET DEFAULT nextval('public.custom_styles_id_seq'::regclass);


--
-- Name: custom_values id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.custom_values ALTER COLUMN id SET DEFAULT nextval('public.custom_values_id_seq'::regclass);


--
-- Name: customizable_journals id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customizable_journals ALTER COLUMN id SET DEFAULT nextval('public.customizable_journals_id_seq'::regclass);


--
-- Name: delayed_job_statuses id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.delayed_job_statuses ALTER COLUMN id SET DEFAULT nextval('public.delayed_job_statuses_id_seq'::regclass);


--
-- Name: delayed_jobs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.delayed_jobs ALTER COLUMN id SET DEFAULT nextval('public.delayed_jobs_id_seq'::regclass);


--
-- Name: design_colors id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.design_colors ALTER COLUMN id SET DEFAULT nextval('public.design_colors_id_seq'::regclass);


--
-- Name: document_journals id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_journals ALTER COLUMN id SET DEFAULT nextval('public.document_journals_id_seq'::regclass);


--
-- Name: documents id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documents ALTER COLUMN id SET DEFAULT nextval('public.documents_id_seq'::regclass);


--
-- Name: enabled_modules id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.enabled_modules ALTER COLUMN id SET DEFAULT nextval('public.enabled_modules_id_seq'::regclass);


--
-- Name: enterprise_tokens id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.enterprise_tokens ALTER COLUMN id SET DEFAULT nextval('public.enterprise_tokens_id_seq'::regclass);


--
-- Name: enumerations id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.enumerations ALTER COLUMN id SET DEFAULT nextval('public.enumerations_id_seq'::regclass);


--
-- Name: export_card_configurations id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.export_card_configurations ALTER COLUMN id SET DEFAULT nextval('public.export_card_configurations_id_seq'::regclass);


--
-- Name: exports id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.exports ALTER COLUMN id SET DEFAULT nextval('public.exports_id_seq'::regclass);


--
-- Name: file_links id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.file_links ALTER COLUMN id SET DEFAULT nextval('public.file_links_id_seq'::regclass);


--
-- Name: forums id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.forums ALTER COLUMN id SET DEFAULT nextval('public.forums_id_seq'::regclass);


--
-- Name: github_check_runs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.github_check_runs ALTER COLUMN id SET DEFAULT nextval('public.github_check_runs_id_seq'::regclass);


--
-- Name: github_pull_requests id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.github_pull_requests ALTER COLUMN id SET DEFAULT nextval('public.github_pull_requests_id_seq'::regclass);


--
-- Name: github_users id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.github_users ALTER COLUMN id SET DEFAULT nextval('public.github_users_id_seq'::regclass);


--
-- Name: grid_widgets id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.grid_widgets ALTER COLUMN id SET DEFAULT nextval('public.grid_widgets_id_seq'::regclass);


--
-- Name: grids id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.grids ALTER COLUMN id SET DEFAULT nextval('public.grids_id_seq'::regclass);


--
-- Name: group_users id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.group_users ALTER COLUMN id SET DEFAULT nextval('public.group_users_id_seq'::regclass);


--
-- Name: ical_token_query_assignments id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ical_token_query_assignments ALTER COLUMN id SET DEFAULT nextval('public.ical_token_query_assignments_id_seq'::regclass);


--
-- Name: ifc_models id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ifc_models ALTER COLUMN id SET DEFAULT nextval('public.ifc_models_id_seq'::regclass);


--
-- Name: journals id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.journals ALTER COLUMN id SET DEFAULT nextval('public.journals_id_seq'::regclass);


--
-- Name: labor_budget_items id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.labor_budget_items ALTER COLUMN id SET DEFAULT nextval('public.labor_budget_items_id_seq'::regclass);


--
-- Name: last_project_folders id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.last_project_folders ALTER COLUMN id SET DEFAULT nextval('public.last_project_folders_id_seq'::regclass);


--
-- Name: ldap_groups_memberships id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ldap_groups_memberships ALTER COLUMN id SET DEFAULT nextval('public.ldap_groups_memberships_id_seq'::regclass);


--
-- Name: ldap_groups_synchronized_filters id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ldap_groups_synchronized_filters ALTER COLUMN id SET DEFAULT nextval('public.ldap_groups_synchronized_filters_id_seq'::regclass);


--
-- Name: ldap_groups_synchronized_groups id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ldap_groups_synchronized_groups ALTER COLUMN id SET DEFAULT nextval('public.ldap_groups_synchronized_groups_id_seq'::regclass);


--
-- Name: material_budget_items id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.material_budget_items ALTER COLUMN id SET DEFAULT nextval('public.material_budget_items_id_seq'::regclass);


--
-- Name: meeting_content_journals id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.meeting_content_journals ALTER COLUMN id SET DEFAULT nextval('public.meeting_content_journals_id_seq'::regclass);


--
-- Name: meeting_contents id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.meeting_contents ALTER COLUMN id SET DEFAULT nextval('public.meeting_contents_id_seq'::regclass);


--
-- Name: meeting_journals id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.meeting_journals ALTER COLUMN id SET DEFAULT nextval('public.meeting_journals_id_seq'::regclass);


--
-- Name: meeting_participants id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.meeting_participants ALTER COLUMN id SET DEFAULT nextval('public.meeting_participants_id_seq'::regclass);


--
-- Name: meetings id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.meetings ALTER COLUMN id SET DEFAULT nextval('public.meetings_id_seq'::regclass);


--
-- Name: member_roles id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_roles ALTER COLUMN id SET DEFAULT nextval('public.member_roles_id_seq'::regclass);


--
-- Name: members id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.members ALTER COLUMN id SET DEFAULT nextval('public.members_id_seq'::regclass);


--
-- Name: menu_items id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.menu_items ALTER COLUMN id SET DEFAULT nextval('public.menu_items_id_seq'::regclass);


--
-- Name: message_journals id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.message_journals ALTER COLUMN id SET DEFAULT nextval('public.message_journals_id_seq'::regclass);


--
-- Name: messages id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.messages ALTER COLUMN id SET DEFAULT nextval('public.messages_id_seq'::regclass);


--
-- Name: news id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.news ALTER COLUMN id SET DEFAULT nextval('public.news_id_seq'::regclass);


--
-- Name: news_journals id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.news_journals ALTER COLUMN id SET DEFAULT nextval('public.news_journals_id_seq'::regclass);


--
-- Name: non_working_days id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.non_working_days ALTER COLUMN id SET DEFAULT nextval('public.non_working_days_id_seq'::regclass);


--
-- Name: notification_settings id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_settings ALTER COLUMN id SET DEFAULT nextval('public.notification_settings_id_seq'::regclass);


--
-- Name: notifications id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications ALTER COLUMN id SET DEFAULT nextval('public.notifications_id_seq'::regclass);


--
-- Name: oauth_access_grants id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth_access_grants ALTER COLUMN id SET DEFAULT nextval('public.oauth_access_grants_id_seq'::regclass);


--
-- Name: oauth_access_tokens id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth_access_tokens ALTER COLUMN id SET DEFAULT nextval('public.oauth_access_tokens_id_seq'::regclass);


--
-- Name: oauth_applications id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth_applications ALTER COLUMN id SET DEFAULT nextval('public.oauth_applications_id_seq'::regclass);


--
-- Name: oauth_client_tokens id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth_client_tokens ALTER COLUMN id SET DEFAULT nextval('public.oauth_client_tokens_id_seq'::regclass);


--
-- Name: oauth_clients id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth_clients ALTER COLUMN id SET DEFAULT nextval('public.oauth_clients_id_seq'::regclass);


--
-- Name: oidc_user_session_links id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oidc_user_session_links ALTER COLUMN id SET DEFAULT nextval('public.oidc_user_session_links_id_seq'::regclass);


--
-- Name: ordered_work_packages id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ordered_work_packages ALTER COLUMN id SET DEFAULT nextval('public.ordered_work_packages_id_seq'::regclass);


--
-- Name: paper_trail_audits id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.paper_trail_audits ALTER COLUMN id SET DEFAULT nextval('public.paper_trail_audits_id_seq'::regclass);


--
-- Name: project_journals id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_journals ALTER COLUMN id SET DEFAULT nextval('public.project_journals_id_seq'::regclass);


--
-- Name: projects id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.projects ALTER COLUMN id SET DEFAULT nextval('public.projects_id_seq'::regclass);


--
-- Name: projects_storages id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.projects_storages ALTER COLUMN id SET DEFAULT nextval('public.projects_storages_id_seq'::regclass);


--
-- Name: queries id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.queries ALTER COLUMN id SET DEFAULT nextval('public.queries_id_seq'::regclass);


--
-- Name: rates id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rates ALTER COLUMN id SET DEFAULT nextval('public.rates_id_seq'::regclass);


--
-- Name: recaptcha_entries id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recaptcha_entries ALTER COLUMN id SET DEFAULT nextval('public.recaptcha_entries_id_seq'::regclass);


--
-- Name: relations id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.relations ALTER COLUMN id SET DEFAULT nextval('public.relations_id_seq'::regclass);


--
-- Name: repositories id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.repositories ALTER COLUMN id SET DEFAULT nextval('public.repositories_id_seq'::regclass);


--
-- Name: role_permissions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role_permissions ALTER COLUMN id SET DEFAULT nextval('public.role_permissions_id_seq'::regclass);


--
-- Name: roles id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.roles ALTER COLUMN id SET DEFAULT nextval('public.roles_id_seq'::regclass);


--
-- Name: sessions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sessions ALTER COLUMN id SET DEFAULT nextval('public.sessions_id_seq'::regclass);


--
-- Name: settings id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.settings ALTER COLUMN id SET DEFAULT nextval('public.settings_id_seq'::regclass);


--
-- Name: statuses id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.statuses ALTER COLUMN id SET DEFAULT nextval('public.statuses_id_seq'::regclass);


--
-- Name: storages id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.storages ALTER COLUMN id SET DEFAULT nextval('public.storages_id_seq'::regclass);


--
-- Name: time_entries id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.time_entries ALTER COLUMN id SET DEFAULT nextval('public.time_entries_id_seq'::regclass);


--
-- Name: time_entry_activities_projects id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.time_entry_activities_projects ALTER COLUMN id SET DEFAULT nextval('public.time_entry_activities_projects_id_seq'::regclass);


--
-- Name: time_entry_journals id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.time_entry_journals ALTER COLUMN id SET DEFAULT nextval('public.time_entry_journals_id_seq'::regclass);


--
-- Name: tokens id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tokens ALTER COLUMN id SET DEFAULT nextval('public.tokens_id_seq'::regclass);


--
-- Name: two_factor_authentication_devices id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.two_factor_authentication_devices ALTER COLUMN id SET DEFAULT nextval('public.two_factor_authentication_devices_id_seq'::regclass);


--
-- Name: types id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.types ALTER COLUMN id SET DEFAULT nextval('public.types_id_seq'::regclass);


--
-- Name: user_passwords id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_passwords ALTER COLUMN id SET DEFAULT nextval('public.user_passwords_id_seq'::regclass);


--
-- Name: user_preferences id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_preferences ALTER COLUMN id SET DEFAULT nextval('public.user_preferences_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Name: version_settings id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.version_settings ALTER COLUMN id SET DEFAULT nextval('public.version_settings_id_seq'::regclass);


--
-- Name: versions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.versions ALTER COLUMN id SET DEFAULT nextval('public.versions_id_seq'::regclass);


--
-- Name: views id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.views ALTER COLUMN id SET DEFAULT nextval('public.views_id_seq'::regclass);


--
-- Name: watchers id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.watchers ALTER COLUMN id SET DEFAULT nextval('public.watchers_id_seq'::regclass);


--
-- Name: webhooks_events id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.webhooks_events ALTER COLUMN id SET DEFAULT nextval('public.webhooks_events_id_seq'::regclass);


--
-- Name: webhooks_logs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.webhooks_logs ALTER COLUMN id SET DEFAULT nextval('public.webhooks_logs_id_seq'::regclass);


--
-- Name: webhooks_projects id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.webhooks_projects ALTER COLUMN id SET DEFAULT nextval('public.webhooks_projects_id_seq'::regclass);


--
-- Name: webhooks_webhooks id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.webhooks_webhooks ALTER COLUMN id SET DEFAULT nextval('public.webhooks_webhooks_id_seq'::regclass);


--
-- Name: wiki_page_journals id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wiki_page_journals ALTER COLUMN id SET DEFAULT nextval('public.wiki_page_journals_id_seq'::regclass);


--
-- Name: wiki_pages id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wiki_pages ALTER COLUMN id SET DEFAULT nextval('public.wiki_pages_id_seq'::regclass);


--
-- Name: wiki_redirects id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wiki_redirects ALTER COLUMN id SET DEFAULT nextval('public.wiki_redirects_id_seq'::regclass);


--
-- Name: wikis id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wikis ALTER COLUMN id SET DEFAULT nextval('public.wikis_id_seq'::regclass);


--
-- Name: work_package_journals id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_package_journals ALTER COLUMN id SET DEFAULT nextval('public.work_package_journals_id_seq'::regclass);


--
-- Name: work_packages id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_packages ALTER COLUMN id SET DEFAULT nextval('public.work_packages_id_seq'::regclass);


--
-- Name: workflows id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workflows ALTER COLUMN id SET DEFAULT nextval('public.workflows_id_seq'::regclass);


--
-- Data for Name: announcements; Type: TABLE DATA; Schema: backup_preview_5; Owner: -
--

COPY backup_preview_5.announcements (id, text, show_until, active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: ar_internal_metadata; Type: TABLE DATA; Schema: backup_preview_5; Owner: -
--

COPY backup_preview_5.ar_internal_metadata (key, value, created_at, updated_at) FROM stdin;
environment	development	2023-07-26 09:21:51.140625+01	2023-07-26 09:21:51.140625+01
\.


--
-- Data for Name: attachable_journals; Type: TABLE DATA; Schema: backup_preview_5; Owner: -
--

COPY backup_preview_5.attachable_journals (id, journal_id, attachment_id, filename) FROM stdin;
1	52	5	Pop-Ich-klein_400x400.png
\.


--
-- Data for Name: attachment_journals; Type: TABLE DATA; Schema: backup_preview_5; Owner: -
--

COPY backup_preview_5.attachment_journals (id, container_id, container_type, filename, disk_filename, filesize, content_type, digest, downloads, author_id, description) FROM stdin;
1	6	Grids::Grid			455768	image/png	2a53ddc815206499a480d08e38272b8a	0	4	\N
2	7	Grids::Grid			442579	image/png	7b7d591a8dfdaf2900ceecdb9755f39f	0	4	\N
4	1	Export	Demo project - All open.pdf		62182	application/pdf	89e31e139dbb7785615335a8ab2be094	0	4	
5	2	WorkPackage	Pop-Ich-klein_400x400.png		389264	image/png	032fc98977f330f0be42533647ff4b4a	0	4	\N
\.


--
-- Data for Name: attachments; Type: TABLE DATA; Schema: backup_preview_5; Owner: -
--

COPY backup_preview_5.attachments (id, container_id, container_type, filename, disk_filename, filesize, content_type, digest, downloads, author_id, created_at, description, file, fulltext, fulltext_tsv, file_tsv, updated_at) FROM stdin;
1	6	Grids::Grid			455768	image/png	2a53ddc815206499a480d08e38272b8a	0	4	2023-07-26 09:22:09.932178+01	\N	demo_project_teaser.png	\N	\N	\N	2023-07-26 09:22:09.932178+01
2	7	Grids::Grid			442579	image/png	7b7d591a8dfdaf2900ceecdb9755f39f	0	4	2023-07-26 09:22:09.966339+01	\N	scrum_project_teaser.png	\N	\N	\N	2023-07-26 09:22:09.966339+01
4	1	Export	Demo project - All open.pdf		62182	application/pdf	89e31e139dbb7785615335a8ab2be094	0	4	2023-07-28 13:26:07.402459+01		Demo_project_-_All_open.pdf	\N	\N	\N	2023-07-28 13:26:07.402459+01
5	2	WorkPackage	Pop-Ich-klein_400x400.png		389264	image/png	032fc98977f330f0be42533647ff4b4a	0	4	2023-07-30 22:45:37.883264+01	\N	Pop-Ich-klein_400x400.png	\N	\N	\N	2023-07-30 22:45:37.883264+01
\.


--
-- Data for Name: attribute_help_texts; Type: TABLE DATA; Schema: backup_preview_5; Owner: -
--

COPY backup_preview_5.attribute_help_texts (id, help_text, type, attribute_name, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: auth_sources; Type: TABLE DATA; Schema: backup_preview_5; Owner: -
--

COPY backup_preview_5.auth_sources (id, type, name, host, port, account, account_password, base_dn, attr_login, attr_firstname, attr_lastname, attr_mail, onthefly_register, attr_admin, created_at, updated_at, tls_mode, filter_string, verify_peer, tls_certificate_string) FROM stdin;
\.


--
-- Data for Name: backups; Type: TABLE DATA; Schema: backup_preview_5; Owner: -
--

COPY backup_preview_5.backups (id, comment, size_in_mb, creator_id, created_at, updated_at) FROM stdin;
5	initial state	\N	4	2023-07-30 22:46:06.231847+01	2023-07-30 22:46:06.231847+01
\.


--
-- Data for Name: bcf_comments; Type: TABLE DATA; Schema: backup_preview_5; Owner: -
--

COPY backup_preview_5.bcf_comments (id, uuid, journal_id, issue_id, viewpoint_id, reply_to) FROM stdin;
\.


--
-- Data for Name: bcf_issues; Type: TABLE DATA; Schema: backup_preview_5; Owner: -
--

COPY backup_preview_5.bcf_issues (id, uuid, markup, work_package_id, stage, index, labels, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: bcf_viewpoints; Type: TABLE DATA; Schema: backup_preview_5; Owner: -
--

COPY backup_preview_5.bcf_viewpoints (id, uuid, viewpoint_name, issue_id, json_viewpoint, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: budget_journals; Type: TABLE DATA; Schema: backup_preview_5; Owner: -
--

COPY backup_preview_5.budget_journals (id, project_id, author_id, subject, description, fixed_date) FROM stdin;
\.


--
-- Data for Name: budgets; Type: TABLE DATA; Schema: backup_preview_5; Owner: -
--

COPY backup_preview_5.budgets (id, project_id, author_id, subject, description, fixed_date, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: categories; Type: TABLE DATA; Schema: backup_preview_5; Owner: -
--

COPY backup_preview_5.categories (id, project_id, name, assigned_to_id, created_at, updated_at) FROM stdin;
1	1	Category 1 (to be changed in Project settings)	\N	2023-07-26 09:22:07.759089+01	2023-07-26 09:22:07.759089+01
2	2	Category 1 (to be changed in Project settings)	\N	2023-07-26 09:22:08.767274+01	2023-07-26 09:22:08.767274+01
\.


--
-- Data for Name: changes; Type: TABLE DATA; Schema: backup_preview_5; Owner: -
--

COPY backup_preview_5.changes (id, changeset_id, action, path, from_path, from_revision, revision, branch) FROM stdin;
\.


--
-- Data for Name: changeset_journals; Type: TABLE DATA; Schema: backup_preview_5; Owner: -
--

COPY backup_preview_5.changeset_journals (id, repository_id, revision, committer, committed_on, comments, commit_date, scmid, user_id) FROM stdin;
\.


--
-- Data for Name: changesets; Type: TABLE DATA; Schema: backup_preview_5; Owner: -
--

COPY backup_preview_5.changesets (id, repository_id, revision, committer, committed_on, comments, commit_date, scmid, user_id) FROM stdin;
\.


--
-- Data for Name: changesets_work_packages; Type: TABLE DATA; Schema: backup_preview_5; Owner: -
--

COPY backup_preview_5.changesets_work_packages (changeset_id, work_package_id) FROM stdin;
\.


--
-- Data for Name: colors; Type: TABLE DATA; Schema: backup_preview_5; Owner: -
--

COPY backup_preview_5.colors (id, name, hexcode, created_at, updated_at) FROM stdin;
1	Blue (dark)	#175A8E	2023-07-26 09:22:05.749136+01	2023-07-26 09:22:05.749136+01
2	Blue	#1A67A3	2023-07-26 09:22:05.749968+01	2023-07-26 09:22:05.749968+01
3	Blue (light)	#00B0F0	2023-07-26 09:22:05.750611+01	2023-07-26 09:22:05.750611+01
4	Green (light)	#35C53F	2023-07-26 09:22:05.751423+01	2023-07-26 09:22:05.751423+01
5	Green (dark)	#339933	2023-07-26 09:22:05.752072+01	2023-07-26 09:22:05.752072+01
6	Yellow	#FFFF00	2023-07-26 09:22:05.752679+01	2023-07-26 09:22:05.752679+01
7	Orange	#FFCC00	2023-07-26 09:22:05.753213+01	2023-07-26 09:22:05.753213+01
8	Red	#FF3300	2023-07-26 09:22:05.753786+01	2023-07-26 09:22:05.753786+01
9	Magenta	#E20074	2023-07-26 09:22:05.75443+01	2023-07-26 09:22:05.75443+01
10	White	#FFFFFF	2023-07-26 09:22:05.755011+01	2023-07-26 09:22:05.755011+01
11	Grey (light)	#F8F8F8	2023-07-26 09:22:05.755545+01	2023-07-26 09:22:05.755545+01
12	Grey	#EAEAEA	2023-07-26 09:22:05.75631+01	2023-07-26 09:22:05.75631+01
13	Grey (dark)	#878787	2023-07-26 09:22:05.756961+01	2023-07-26 09:22:05.756961+01
14	Black	#000000	2023-07-26 09:22:05.757689+01	2023-07-26 09:22:05.757689+01
15	gray-0	#F8F9FA	2023-07-26 09:22:05.759206+01	2023-07-26 09:22:05.759206+01
16	gray-1	#F1F3F5	2023-07-26 09:22:05.75992+01	2023-07-26 09:22:05.75992+01
17	gray-2	#E9ECEF	2023-07-26 09:22:05.760569+01	2023-07-26 09:22:05.760569+01
18	gray-3	#DEE2E6	2023-07-26 09:22:05.761356+01	2023-07-26 09:22:05.761356+01
19	gray-4	#CED4DA	2023-07-26 09:22:05.762046+01	2023-07-26 09:22:05.762046+01
20	gray-5	#ADB5BD	2023-07-26 09:22:05.762624+01	2023-07-26 09:22:05.762624+01
21	gray-6	#868E96	2023-07-26 09:22:05.763347+01	2023-07-26 09:22:05.763347+01
22	gray-7	#495057	2023-07-26 09:22:05.763928+01	2023-07-26 09:22:05.763928+01
23	gray-8	#343A40	2023-07-26 09:22:05.764646+01	2023-07-26 09:22:05.764646+01
24	gray-9	#212529	2023-07-26 09:22:05.765199+01	2023-07-26 09:22:05.765199+01
25	red-0	#FFF5F5	2023-07-26 09:22:05.765738+01	2023-07-26 09:22:05.765738+01
26	red-1	#FFE3E3	2023-07-26 09:22:05.766353+01	2023-07-26 09:22:05.766353+01
27	red-2	#FFC9C9	2023-07-26 09:22:05.766931+01	2023-07-26 09:22:05.766931+01
28	red-3	#FFA8A8	2023-07-26 09:22:05.767656+01	2023-07-26 09:22:05.767656+01
29	red-4	#FF8787	2023-07-26 09:22:05.768231+01	2023-07-26 09:22:05.768231+01
30	red-5	#FF6B6B	2023-07-26 09:22:05.768888+01	2023-07-26 09:22:05.768888+01
31	red-6	#FA5252	2023-07-26 09:22:05.769499+01	2023-07-26 09:22:05.769499+01
32	red-7	#F03E3E	2023-07-26 09:22:05.770068+01	2023-07-26 09:22:05.770068+01
33	red-8	#E03131	2023-07-26 09:22:05.770781+01	2023-07-26 09:22:05.770781+01
34	red-9	#C92A2A	2023-07-26 09:22:05.771314+01	2023-07-26 09:22:05.771314+01
35	pink-0	#FFF0F6	2023-07-26 09:22:05.771855+01	2023-07-26 09:22:05.771855+01
36	pink-1	#FFDEEB	2023-07-26 09:22:05.772362+01	2023-07-26 09:22:05.772362+01
37	pink-2	#FCC2D7	2023-07-26 09:22:05.773033+01	2023-07-26 09:22:05.773033+01
38	pink-3	#FAA2C1	2023-07-26 09:22:05.773622+01	2023-07-26 09:22:05.773622+01
39	pink-4	#F783AC	2023-07-26 09:22:05.774163+01	2023-07-26 09:22:05.774163+01
40	pink-5	#F06595	2023-07-26 09:22:05.774711+01	2023-07-26 09:22:05.774711+01
41	pink-6	#E64980	2023-07-26 09:22:05.77525+01	2023-07-26 09:22:05.77525+01
42	pink-7	#D6336C	2023-07-26 09:22:05.776407+01	2023-07-26 09:22:05.776407+01
43	pink-8	#C2255C	2023-07-26 09:22:05.781696+01	2023-07-26 09:22:05.781696+01
44	pink-9	#A61E4D	2023-07-26 09:22:05.782366+01	2023-07-26 09:22:05.782366+01
45	grape-0	#F8F0FC	2023-07-26 09:22:05.782931+01	2023-07-26 09:22:05.782931+01
46	grape-1	#F3D9FA	2023-07-26 09:22:05.783459+01	2023-07-26 09:22:05.783459+01
47	grape-2	#EEBEFA	2023-07-26 09:22:05.784096+01	2023-07-26 09:22:05.784096+01
48	grape-3	#E599F7	2023-07-26 09:22:05.784708+01	2023-07-26 09:22:05.784708+01
49	grape-4	#DA77F2	2023-07-26 09:22:05.78529+01	2023-07-26 09:22:05.78529+01
50	grape-5	#CC5DE8	2023-07-26 09:22:05.785929+01	2023-07-26 09:22:05.785929+01
51	grape-6	#BE4BDB	2023-07-26 09:22:05.786695+01	2023-07-26 09:22:05.786695+01
52	grape-7	#AE3EC9	2023-07-26 09:22:05.78745+01	2023-07-26 09:22:05.78745+01
53	grape-8	#9C36B5	2023-07-26 09:22:05.78807+01	2023-07-26 09:22:05.78807+01
54	grape-9	#862E9C	2023-07-26 09:22:05.788601+01	2023-07-26 09:22:05.788601+01
55	violet-0	#F3F0FF	2023-07-26 09:22:05.789128+01	2023-07-26 09:22:05.789128+01
56	violet-1	#E5DBFF	2023-07-26 09:22:05.789652+01	2023-07-26 09:22:05.789652+01
57	violet-2	#D0BFFF	2023-07-26 09:22:05.790376+01	2023-07-26 09:22:05.790376+01
58	violet-3	#B197FC	2023-07-26 09:22:05.790919+01	2023-07-26 09:22:05.790919+01
59	violet-4	#9775FA	2023-07-26 09:22:05.791444+01	2023-07-26 09:22:05.791444+01
60	violet-5	#845EF7	2023-07-26 09:22:05.792078+01	2023-07-26 09:22:05.792078+01
61	violet-6	#7950F2	2023-07-26 09:22:05.792926+01	2023-07-26 09:22:05.792926+01
62	violet-7	#7048E8	2023-07-26 09:22:05.793569+01	2023-07-26 09:22:05.793569+01
63	violet-8	#6741D9	2023-07-26 09:22:05.794146+01	2023-07-26 09:22:05.794146+01
64	violet-9	#5F3DC4	2023-07-26 09:22:05.794733+01	2023-07-26 09:22:05.794733+01
65	indigo-0	#EDF2FF	2023-07-26 09:22:05.795323+01	2023-07-26 09:22:05.795323+01
66	indigo-1	#DBE4FF	2023-07-26 09:22:05.796126+01	2023-07-26 09:22:05.796126+01
67	indigo-2	#BAC8FF	2023-07-26 09:22:05.796683+01	2023-07-26 09:22:05.796683+01
68	indigo-3	#91A7FF	2023-07-26 09:22:05.797219+01	2023-07-26 09:22:05.797219+01
69	indigo-4	#748FFC	2023-07-26 09:22:05.797757+01	2023-07-26 09:22:05.797757+01
70	indigo-5	#5C7CFA	2023-07-26 09:22:05.79827+01	2023-07-26 09:22:05.79827+01
71	indigo-6	#4C6EF5	2023-07-26 09:22:05.799023+01	2023-07-26 09:22:05.799023+01
72	indigo-7	#4263EB	2023-07-26 09:22:05.799626+01	2023-07-26 09:22:05.799626+01
73	indigo-8	#3B5BDB	2023-07-26 09:22:05.800306+01	2023-07-26 09:22:05.800306+01
74	indigo-9	#364FC7	2023-07-26 09:22:05.800908+01	2023-07-26 09:22:05.800908+01
75	blue-0	#E7F5FF	2023-07-26 09:22:05.80158+01	2023-07-26 09:22:05.80158+01
76	blue-1	#D0EBFF	2023-07-26 09:22:05.802312+01	2023-07-26 09:22:05.802312+01
77	blue-2	#A5D8FF	2023-07-26 09:22:05.80297+01	2023-07-26 09:22:05.80297+01
78	blue-3	#74C0FC	2023-07-26 09:22:05.803547+01	2023-07-26 09:22:05.803547+01
79	blue-4	#4DABF7	2023-07-26 09:22:05.80411+01	2023-07-26 09:22:05.80411+01
80	blue-5	#339AF0	2023-07-26 09:22:05.80477+01	2023-07-26 09:22:05.80477+01
81	blue-6	#228BE6	2023-07-26 09:22:05.805339+01	2023-07-26 09:22:05.805339+01
82	blue-7	#1C7ED6	2023-07-26 09:22:05.805898+01	2023-07-26 09:22:05.805898+01
83	blue-8	#1971C2	2023-07-26 09:22:05.806439+01	2023-07-26 09:22:05.806439+01
84	blue-9	#1864AB	2023-07-26 09:22:05.806978+01	2023-07-26 09:22:05.806978+01
85	cyan-0	#E3FAFC	2023-07-26 09:22:05.807512+01	2023-07-26 09:22:05.807512+01
86	cyan-1	#C5F6FA	2023-07-26 09:22:05.808079+01	2023-07-26 09:22:05.808079+01
87	cyan-2	#99E9F2	2023-07-26 09:22:05.808585+01	2023-07-26 09:22:05.808585+01
88	cyan-3	#66D9E8	2023-07-26 09:22:05.809257+01	2023-07-26 09:22:05.809257+01
89	cyan-4	#3BC9DB	2023-07-26 09:22:05.809974+01	2023-07-26 09:22:05.809974+01
90	cyan-5	#22B8CF	2023-07-26 09:22:05.810561+01	2023-07-26 09:22:05.810561+01
91	cyan-6	#15AABF	2023-07-26 09:22:05.811154+01	2023-07-26 09:22:05.811154+01
92	cyan-7	#1098AD	2023-07-26 09:22:05.811702+01	2023-07-26 09:22:05.811702+01
93	cyan-8	#0C8599	2023-07-26 09:22:05.812239+01	2023-07-26 09:22:05.812239+01
94	cyan-9	#0B7285	2023-07-26 09:22:05.812778+01	2023-07-26 09:22:05.812778+01
95	teal-0	#E6FCF5	2023-07-26 09:22:05.813321+01	2023-07-26 09:22:05.813321+01
96	teal-1	#C3FAE8	2023-07-26 09:22:05.813848+01	2023-07-26 09:22:05.813848+01
97	teal-2	#96F2D7	2023-07-26 09:22:05.81455+01	2023-07-26 09:22:05.81455+01
98	teal-3	#63E6BE	2023-07-26 09:22:05.815212+01	2023-07-26 09:22:05.815212+01
99	teal-4	#38D9A9	2023-07-26 09:22:05.815913+01	2023-07-26 09:22:05.815913+01
100	teal-5	#20C997	2023-07-26 09:22:05.81652+01	2023-07-26 09:22:05.81652+01
101	teal-6	#12B886	2023-07-26 09:22:05.817106+01	2023-07-26 09:22:05.817106+01
102	teal-7	#0CA678	2023-07-26 09:22:05.817823+01	2023-07-26 09:22:05.817823+01
103	teal-8	#099268	2023-07-26 09:22:05.81855+01	2023-07-26 09:22:05.81855+01
104	teal-9	#087F5B	2023-07-26 09:22:05.819176+01	2023-07-26 09:22:05.819176+01
105	green-0	#EBFBEE	2023-07-26 09:22:05.819773+01	2023-07-26 09:22:05.819773+01
106	green-1	#D3F9D8	2023-07-26 09:22:05.820299+01	2023-07-26 09:22:05.820299+01
107	green-2	#B2F2BB	2023-07-26 09:22:05.820926+01	2023-07-26 09:22:05.820926+01
108	green-3	#8CE99A	2023-07-26 09:22:05.8215+01	2023-07-26 09:22:05.8215+01
109	green-4	#69DB7C	2023-07-26 09:22:05.822042+01	2023-07-26 09:22:05.822042+01
110	green-5	#51CF66	2023-07-26 09:22:05.822574+01	2023-07-26 09:22:05.822574+01
111	green-6	#40C057	2023-07-26 09:22:05.823096+01	2023-07-26 09:22:05.823096+01
112	green-7	#37B24D	2023-07-26 09:22:05.823739+01	2023-07-26 09:22:05.823739+01
113	green-8	#2F9E44	2023-07-26 09:22:05.824373+01	2023-07-26 09:22:05.824373+01
114	green-9	#2B8A3E	2023-07-26 09:22:05.824928+01	2023-07-26 09:22:05.824928+01
115	lime-0	#F4FCE3	2023-07-26 09:22:05.825599+01	2023-07-26 09:22:05.825599+01
116	lime-1	#E9FAC8	2023-07-26 09:22:05.826322+01	2023-07-26 09:22:05.826322+01
117	lime-2	#D8F5A2	2023-07-26 09:22:05.827026+01	2023-07-26 09:22:05.827026+01
118	lime-3	#C0EB75	2023-07-26 09:22:05.827704+01	2023-07-26 09:22:05.827704+01
119	lime-4	#A9E34B	2023-07-26 09:22:05.828533+01	2023-07-26 09:22:05.828533+01
120	lime-5	#94D82D	2023-07-26 09:22:05.829119+01	2023-07-26 09:22:05.829119+01
121	lime-6	#82C91E	2023-07-26 09:22:05.829673+01	2023-07-26 09:22:05.829673+01
122	lime-7	#74B816	2023-07-26 09:22:05.830212+01	2023-07-26 09:22:05.830212+01
123	lime-8	#66A80F	2023-07-26 09:22:05.83074+01	2023-07-26 09:22:05.83074+01
124	lime-9	#5C940D	2023-07-26 09:22:05.831259+01	2023-07-26 09:22:05.831259+01
125	yellow-0	#FFF9DB	2023-07-26 09:22:05.831912+01	2023-07-26 09:22:05.831912+01
126	yellow-1	#FFF3BF	2023-07-26 09:22:05.832537+01	2023-07-26 09:22:05.832537+01
127	yellow-2	#FFEC99	2023-07-26 09:22:05.833126+01	2023-07-26 09:22:05.833126+01
128	yellow-3	#FFE066	2023-07-26 09:22:05.83377+01	2023-07-26 09:22:05.83377+01
129	yellow-4	#FFD43B	2023-07-26 09:22:05.834457+01	2023-07-26 09:22:05.834457+01
130	yellow-5	#FCC419	2023-07-26 09:22:05.835017+01	2023-07-26 09:22:05.835017+01
131	yellow-6	#FAB005	2023-07-26 09:22:05.835561+01	2023-07-26 09:22:05.835561+01
132	yellow-7	#F59F00	2023-07-26 09:22:05.83612+01	2023-07-26 09:22:05.83612+01
133	yellow-8	#F08C00	2023-07-26 09:22:05.837226+01	2023-07-26 09:22:05.837226+01
134	yellow-9	#E67700	2023-07-26 09:22:05.838003+01	2023-07-26 09:22:05.838003+01
135	orange-0	#FFF4E6	2023-07-26 09:22:05.838591+01	2023-07-26 09:22:05.838591+01
136	orange-1	#FFE8CC	2023-07-26 09:22:05.839146+01	2023-07-26 09:22:05.839146+01
137	orange-2	#FFD8A8	2023-07-26 09:22:05.839719+01	2023-07-26 09:22:05.839719+01
138	orange-3	#FFC078	2023-07-26 09:22:05.840282+01	2023-07-26 09:22:05.840282+01
139	orange-4	#FFA94D	2023-07-26 09:22:05.840849+01	2023-07-26 09:22:05.840849+01
140	orange-5	#FF922B	2023-07-26 09:22:05.841389+01	2023-07-26 09:22:05.841389+01
141	orange-6	#FD7E14	2023-07-26 09:22:05.842062+01	2023-07-26 09:22:05.842062+01
142	orange-7	#F76707	2023-07-26 09:22:05.842862+01	2023-07-26 09:22:05.842862+01
143	orange-8	#E8590C	2023-07-26 09:22:05.843495+01	2023-07-26 09:22:05.843495+01
144	orange-9	#D9480F	2023-07-26 09:22:05.844135+01	2023-07-26 09:22:05.844135+01
\.


--
-- Data for Name: comments; Type: TABLE DATA; Schema: backup_preview_5; Owner: -
--

COPY backup_preview_5.comments (id, commented_type, commented_id, author_id, comments, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: cost_entries; Type: TABLE DATA; Schema: backup_preview_5; Owner: -
--

COPY backup_preview_5.cost_entries (id, user_id, project_id, work_package_id, cost_type_id, units, spent_on, created_at, updated_at, comments, blocked, overridden_costs, costs, rate_id, tyear, tmonth, tweek, logged_by_id) FROM stdin;
\.


--
-- Data for Name: cost_queries; Type: TABLE DATA; Schema: backup_preview_5; Owner: -
--

COPY backup_preview_5.cost_queries (id, user_id, project_id, name, is_public, created_at, updated_at, serialized) FROM stdin;
\.


--
-- Data for Name: cost_types; Type: TABLE DATA; Schema: backup_preview_5; Owner: -
--

COPY backup_preview_5.cost_types (id, name, unit, unit_plural, "default", deleted_at) FROM stdin;
\.


--
-- Data for Name: custom_actions; Type: TABLE DATA; Schema: backup_preview_5; Owner: -
--

COPY backup_preview_5.custom_actions (id, name, actions, description, "position") FROM stdin;
\.


--
-- Data for Name: custom_actions_projects; Type: TABLE DATA; Schema: backup_preview_5; Owner: -
--

COPY backup_preview_5.custom_actions_projects (id, project_id, custom_action_id) FROM stdin;
\.


--
-- Data for Name: custom_actions_roles; Type: TABLE DATA; Schema: backup_preview_5; Owner: -
--

COPY backup_preview_5.custom_actions_roles (id, role_id, custom_action_id) FROM stdin;
\.


--
-- Data for Name: custom_actions_statuses; Type: TABLE DATA; Schema: backup_preview_5; Owner: -
--

COPY backup_preview_5.custom_actions_statuses (id, status_id, custom_action_id) FROM stdin;
\.


--
-- Data for Name: custom_actions_types; Type: TABLE DATA; Schema: backup_preview_5; Owner: -
--

COPY backup_preview_5.custom_actions_types (id, type_id, custom_action_id) FROM stdin;
\.


--
-- Data for Name: custom_fields; Type: TABLE DATA; Schema: backup_preview_5; Owner: -
--

COPY backup_preview_5.custom_fields (id, type, field_format, regexp, min_length, max_length, is_required, is_for_all, is_filter, "position", searchable, editable, visible, multi_value, default_value, name, created_at, updated_at, content_right_to_left) FROM stdin;
1	WorkPackageCustomField	string		0	0	f	f	f	1	f	t	t	f	\N	CF DEV string	2023-07-26 09:22:10.715062+01	2023-07-26 09:22:10.715062+01	f
2	WorkPackageCustomField	text		0	0	f	f	f	2	f	t	t	f	\N	CF DEV text	2023-07-26 09:22:10.718617+01	2023-07-26 09:22:10.718617+01	f
3	WorkPackageCustomField	date		0	0	f	f	f	3	f	t	t	f	\N	CF DEV date	2023-07-26 09:22:10.721528+01	2023-07-26 09:22:10.721528+01	f
4	WorkPackageCustomField	int		0	0	f	f	f	4	f	t	t	f	\N	CF DEV int	2023-07-26 09:22:10.724451+01	2023-07-26 09:22:10.724451+01	f
5	WorkPackageCustomField	float		0	0	f	f	f	5	f	t	t	f	\N	CF DEV float	2023-07-26 09:22:10.728268+01	2023-07-26 09:22:10.728268+01	f
6	WorkPackageCustomField	user		0	0	f	f	f	6	f	t	t	f	\N	CF DEV user	2023-07-26 09:22:10.731323+01	2023-07-26 09:22:10.731323+01	f
7	WorkPackageCustomField	version		0	0	f	f	f	7	f	t	t	f	\N	CF DEV version	2023-07-26 09:22:10.733695+01	2023-07-26 09:22:10.733695+01	f
10	WorkPackageCustomField	text		0	0	t	f	f	10	f	t	t	f	\N	CF DEV required text	2023-07-26 09:22:10.754883+01	2023-07-26 09:22:10.754883+01	f
11	WorkPackageCustomField	int		2	5	f	f	f	11	f	t	t	f	\N	CF DEV intrange	2023-07-26 09:22:10.757584+01	2023-07-26 09:22:10.757584+01	f
8	WorkPackageCustomField	list		0	0	f	f	f	8	f	t	t	f	\N	CF DEV list	2023-07-26 09:22:10.74255+01	2023-07-26 09:22:10.747597+01	f
9	WorkPackageCustomField	list		0	0	f	f	f	9	f	t	t	t	\N	CF DEV multilist	2023-07-26 09:22:10.749018+01	2023-07-26 09:22:10.75352+01	f
\.


--
-- Data for Name: custom_fields_projects; Type: TABLE DATA; Schema: backup_preview_5; Owner: -
--

COPY backup_preview_5.custom_fields_projects (custom_field_id, project_id) FROM stdin;
1	6
2	6
3	6
4	6
5	6
6	6
7	6
8	6
9	6
10	6
11	6
\.


--
-- Data for Name: custom_fields_types; Type: TABLE DATA; Schema: backup_preview_5; Owner: -
--

COPY backup_preview_5.custom_fields_types (custom_field_id, type_id) FROM stdin;
\.


--
-- Data for Name: custom_options; Type: TABLE DATA; Schema: backup_preview_5; Owner: -
--

COPY backup_preview_5.custom_options (id, custom_field_id, "position", default_value, value, created_at, updated_at) FROM stdin;
1	8	1	\N	A	2023-07-26 09:22:10.744712+01	2023-07-26 09:22:10.744712+01
2	8	2	\N	B	2023-07-26 09:22:10.74573+01	2023-07-26 09:22:10.74573+01
3	8	3	\N	C	2023-07-26 09:22:10.746598+01	2023-07-26 09:22:10.746598+01
4	9	1	\N	Foo	2023-07-26 09:22:10.750854+01	2023-07-26 09:22:10.750854+01
5	9	2	\N	Bar	2023-07-26 09:22:10.751789+01	2023-07-26 09:22:10.751789+01
6	9	3	\N	Bla	2023-07-26 09:22:10.752651+01	2023-07-26 09:22:10.752651+01
\.


--
-- Data for Name: custom_styles; Type: TABLE DATA; Schema: backup_preview_5; Owner: -
--

COPY backup_preview_5.custom_styles (id, logo, created_at, updated_at, favicon, touch_icon, theme, theme_logo) FROM stdin;
1	ff-cactus.jpg	2023-07-26 11:38:39.345674+01	2023-07-30 22:36:57.399025+01	\N	\N	OpenProject Light	logo_openproject.png
\.


--
-- Data for Name: custom_values; Type: TABLE DATA; Schema: backup_preview_5; Owner: -
--

COPY backup_preview_5.custom_values (id, customized_type, customized_id, custom_field_id, value) FROM stdin;
\.


--
-- Data for Name: customizable_journals; Type: TABLE DATA; Schema: backup_preview_5; Owner: -
--

COPY backup_preview_5.customizable_journals (id, journal_id, custom_field_id, value) FROM stdin;
\.


--
-- Data for Name: delayed_job_statuses; Type: TABLE DATA; Schema: backup_preview_5; Owner: -
--

COPY backup_preview_5.delayed_job_statuses (id, reference_type, reference_id, message, created_at, updated_at, status, user_id, job_id, payload) FROM stdin;
3	\N	\N	Backup failed: undefined method `migrate' for Apartment::Tenant:Module	2023-07-26 11:39:24.765773+01	2023-07-26 11:39:24.765773+01	failure	3	63aa75fc-c959-411c-91e8-881d0d140ea0	\N
4	\N	\N	The export has completed successfully.	2023-07-26 11:46:58.5703+01	2023-07-26 11:46:58.5703+01	success	3	c7b1615c-d55a-4d68-a31e-a3bf052981b2	\N
5	\N	\N	The export has completed successfully.	2023-07-26 11:56:13.714539+01	2023-07-26 11:56:13.714539+01	success	3	d8477345-dc02-4438-bf1d-ad71f3ea97b1	\N
6	\N	\N	The export has completed successfully.	2023-07-27 13:21:01.246296+01	2023-07-27 13:21:01.246296+01	success	3	4a81d30d-f7bf-4ab6-8d9a-c8598fb85143	\N
7	\N	\N	The export has completed successfully.	2023-07-27 13:23:00.071077+01	2023-07-27 13:23:00.071077+01	success	3	19307339-a9dc-4865-a0d1-578a78193586	\N
8	\N	\N	The export has completed successfully.	2023-07-27 13:38:30.026973+01	2023-07-27 13:38:30.026973+01	success	3	d44ebeed-c50e-4591-af63-91dbfb55726a	\N
9	\N	\N	The export has completed successfully.	2023-07-27 14:18:03.066371+01	2023-07-27 14:18:03.066371+01	success	3	e478ee94-1489-4e56-8554-ef689aed4c7d	\N
12	Export	1	The export has completed successfully.	2023-07-28 13:26:03.477345+01	2023-07-28 13:26:07.462538+01	success	4	d926ded8-969b-402e-90c2-37ccdd145bb9	{"title": "Your work packages export", "download": "/api/v3/attachments/4/content"}
13	Backup	5	\N	2023-07-30 22:46:06.252835+01	2023-07-30 22:46:21.837989+01	in_process	4	2f4347d7-cf9c-46d5-bb6f-f1d5ce07c755	\N
\.


--
-- Data for Name: delayed_jobs; Type: TABLE DATA; Schema: backup_preview_5; Owner: -
--

COPY backup_preview_5.delayed_jobs (id, priority, attempts, handler, last_error, run_at, locked_at, failed_at, locked_by, created_at, updated_at, queue, cron) FROM stdin;
5	10	0	--- !ruby/object:ActiveJob::QueueAdapters::DelayedJobAdapter::JobWrapper\njob_data:\n  job_class: CleanupWebhookLogsJob\n  job_id: 58385d75-a6bd-47e9-893e-fad0c521d37c\n  provider_job_id: \n  queue_name: default\n  priority: \n  arguments: []\n  executions: 0\n  exception_executions: {}\n  locale: en\n  timezone: UTC\n  enqueued_at: '2023-07-26T10:10:11Z'\n	\N	2023-07-30 06:28:00+01	\N	\N	\N	2023-07-26 11:10:11.937845+01	2023-07-26 11:10:11.937845+01	default	28 5 * * 7
6	10	0	--- !ruby/object:ActiveJob::QueueAdapters::DelayedJobAdapter::JobWrapper\njob_data:\n  job_class: Cron::ClearOldPullRequestsJob\n  job_id: 1bd7f2ab-d1b1-470e-8341-426d77e912ed\n  provider_job_id: \n  queue_name: default\n  priority: \n  arguments: []\n  executions: 0\n  exception_executions: {}\n  locale: en\n  timezone: UTC\n  enqueued_at: '2023-07-26T10:10:11Z'\n	\N	2023-07-27 02:25:00+01	\N	\N	\N	2023-07-26 11:10:11.956+01	2023-07-26 11:10:11.956+01	default	25 1 * * *
8	10	0	--- !ruby/object:ActiveJob::QueueAdapters::DelayedJobAdapter::JobWrapper\njob_data:\n  job_class: JobStatus::Cron::ClearOldJobStatusJob\n  job_id: 357f1e82-bcd0-4348-aba1-867a1cbbfebc\n  provider_job_id: \n  queue_name: default\n  priority: \n  arguments: []\n  executions: 0\n  exception_executions: {}\n  locale: en\n  timezone: UTC\n  enqueued_at: '2023-07-26T10:10:11Z'\n	\N	2023-07-27 05:15:00+01	\N	\N	\N	2023-07-26 11:10:11.971507+01	2023-07-26 11:10:11.971507+01	default	15 4 * * *
9	20	0	--- !ruby/object:ActiveJob::QueueAdapters::DelayedJobAdapter::JobWrapper\njob_data:\n  job_class: CleanupUncontaineredFileLinksJob\n  job_id: 4ab0c5b9-a549-48ee-bdce-8c0138e29d06\n  provider_job_id: \n  queue_name: default\n  priority: 20\n  arguments: []\n  executions: 0\n  exception_executions: {}\n  locale: en\n  timezone: UTC\n  enqueued_at: '2023-07-26T10:10:11Z'\n	\N	2023-07-26 23:06:00+01	\N	\N	\N	2023-07-26 11:10:11.981744+01	2023-07-26 11:10:11.981744+01	default	06 22 * * *
11	10	0	--- !ruby/object:ActiveJob::QueueAdapters::DelayedJobAdapter::JobWrapper\njob_data:\n  job_class: Cron::ClearOldSessionsJob\n  job_id: 5b0fb06f-4ac9-47b0-9d92-6f51f80ee80c\n  provider_job_id: \n  queue_name: default\n  priority: \n  arguments: []\n  executions: 0\n  exception_executions: {}\n  locale: en\n  timezone: UTC\n  enqueued_at: '2023-07-26T10:10:11Z'\n	\N	2023-07-27 02:15:00+01	\N	\N	\N	2023-07-26 11:10:12.000939+01	2023-07-26 11:10:12.000939+01	default	15 1 * * *
12	10	0	--- !ruby/object:ActiveJob::QueueAdapters::DelayedJobAdapter::JobWrapper\njob_data:\n  job_class: Cron::ClearTmpCacheJob\n  job_id: 128a4641-cbde-48d5-b843-bc6019151f7c\n  provider_job_id: \n  queue_name: default\n  priority: \n  arguments: []\n  executions: 0\n  exception_executions: {}\n  locale: en\n  timezone: UTC\n  enqueued_at: '2023-07-26T10:10:12Z'\n	\N	2023-07-30 03:45:00+01	\N	\N	\N	2023-07-26 11:10:12.010873+01	2023-07-26 11:10:12.010873+01	default	45 2 * * 7
13	10	0	--- !ruby/object:ActiveJob::QueueAdapters::DelayedJobAdapter::JobWrapper\njob_data:\n  job_class: Cron::ClearUploadedFilesJob\n  job_id: e242e35f-e8b1-428d-a0a8-6db111d2dade\n  provider_job_id: \n  queue_name: default\n  priority: \n  arguments: []\n  executions: 0\n  exception_executions: {}\n  locale: en\n  timezone: UTC\n  enqueued_at: '2023-07-26T10:10:12Z'\n	\N	2023-07-29 00:00:00+01	\N	\N	\N	2023-07-26 11:10:12.017242+01	2023-07-26 11:10:12.017242+01	default	0 23 * * 5
14	20	0	--- !ruby/object:ActiveJob::QueueAdapters::DelayedJobAdapter::JobWrapper\njob_data:\n  job_class: OAuth::CleanupJob\n  job_id: 37a74399-8902-4394-8d12-79332c27bbce\n  provider_job_id: \n  queue_name: default\n  priority: 20\n  arguments: []\n  executions: 0\n  exception_executions: {}\n  locale: en\n  timezone: UTC\n  enqueued_at: '2023-07-26T10:10:12Z'\n	\N	2023-07-27 02:52:00+01	\N	\N	\N	2023-07-26 11:10:12.024856+01	2023-07-26 11:10:12.024856+01	default	52 1 * * *
15	10	0	--- !ruby/object:ActiveJob::QueueAdapters::DelayedJobAdapter::JobWrapper\njob_data:\n  job_class: PaperTrailAudits::CleanupJob\n  job_id: '0388601f-a53a-4cb3-9076-8f9e66c8e390'\n  provider_job_id: \n  queue_name: default\n  priority: \n  arguments: []\n  executions: 0\n  exception_executions: {}\n  locale: en\n  timezone: UTC\n  enqueued_at: '2023-07-26T10:10:12Z'\n	\N	2023-07-29 05:03:00+01	\N	\N	\N	2023-07-26 11:10:12.031899+01	2023-07-26 11:10:12.031899+01	default	3 4 * * 6
16	20	0	--- !ruby/object:ActiveJob::QueueAdapters::DelayedJobAdapter::JobWrapper\njob_data:\n  job_class: Attachments::CleanupUncontaineredJob\n  job_id: 733343db-7f82-4dd8-ac34-62191a525b29\n  provider_job_id: \n  queue_name: default\n  priority: 20\n  arguments: []\n  executions: 0\n  exception_executions: {}\n  locale: en\n  timezone: UTC\n  enqueued_at: '2023-07-26T10:10:12Z'\n	\N	2023-07-26 23:03:00+01	\N	\N	\N	2023-07-26 11:10:12.039882+01	2023-07-26 11:10:12.039882+01	default	03 22 * * *
7	10	1	--- !ruby/object:ActiveJob::QueueAdapters::DelayedJobAdapter::JobWrapper\njob_data:\n  job_class: LdapGroups::SynchronizationJob\n  job_id: 7e9f32a0-aa63-425b-a103-9eaa167e1224\n  provider_job_id: \n  queue_name: default\n  priority: \n  arguments: []\n  executions: 0\n  exception_executions: {}\n  locale: en\n  timezone: UTC\n  enqueued_at: '2023-07-26T10:10:11Z'\n	\N	2023-07-26 12:00:00+01	\N	\N	\N	2023-07-26 11:10:11.963273+01	2023-07-26 11:30:00.351569+01	default	*/30 * * * *
10	20	8	--- !ruby/object:ActiveJob::QueueAdapters::DelayedJobAdapter::JobWrapper\njob_data:\n  job_class: ManageNextcloudIntegrationJob\n  job_id: 0073f736-4025-4d59-94ea-bd26a75b067c\n  provider_job_id: \n  queue_name: default\n  priority: 20\n  arguments: []\n  executions: 0\n  exception_executions: {}\n  locale: en\n  timezone: UTC\n  enqueued_at: '2023-07-26T10:10:11Z'\n	\N	2023-07-26 11:55:00+01	\N	\N	\N	2023-07-26 11:10:11.98918+01	2023-07-26 11:50:04.350887+01	default	*/5 * * * *
17	10	3	--- !ruby/object:ActiveJob::QueueAdapters::DelayedJobAdapter::JobWrapper\njob_data:\n  job_class: Notifications::ScheduleDateAlertsNotificationsJob\n  job_id: 3d9ce2dc-936b-4c8f-a13a-cc1ef5ea9945\n  provider_job_id: \n  queue_name: default\n  priority: \n  arguments: []\n  executions: 0\n  exception_executions: {}\n  locale: en\n  timezone: UTC\n  enqueued_at: '2023-07-26T10:10:12Z'\n	\N	2023-07-26 12:00:00+01	\N	\N	\N	2023-07-26 11:10:12.046661+01	2023-07-26 11:45:00.9597+01	default	*/15 * * * *
19	10	0	--- !ruby/object:ActiveJob::QueueAdapters::DelayedJobAdapter::JobWrapper\njob_data:\n  job_class: Ldap::SynchronizationJob\n  job_id: '09290bfa-c7a0-48ea-86c0-6dc935c1b796'\n  provider_job_id: \n  queue_name: default\n  priority: \n  arguments: []\n  executions: 0\n  exception_executions: {}\n  locale: en\n  timezone: UTC\n  enqueued_at: '2023-07-26T10:10:12Z'\n	\N	2023-07-27 00:30:00+01	\N	\N	\N	2023-07-26 11:10:12.061992+01	2023-07-26 11:10:12.061992+01	default	30 23 * * *
18	10	3	--- !ruby/object:ActiveJob::QueueAdapters::DelayedJobAdapter::JobWrapper\njob_data:\n  job_class: Notifications::ScheduleReminderMailsJob\n  job_id: a245370d-75c0-4eb8-b9b0-5ffaea375d2a\n  provider_job_id: \n  queue_name: default\n  priority: \n  arguments: []\n  executions: 0\n  exception_executions: {}\n  locale: en\n  timezone: UTC\n  enqueued_at: '2023-07-26T10:10:12Z'\n	\N	2023-07-26 12:00:00+01	\N	\N	\N	2023-07-26 11:10:12.055932+01	2023-07-26 11:45:00.990226+01	default	*/15 * * * *
43	0	0	--- !ruby/object:ActiveJob::QueueAdapters::DelayedJobAdapter::JobWrapper\njob_data:\n  job_class: CloseBackupPreviewJob\n  job_id: af29d023-ff80-49b7-89af-e8a2792b4765\n  provider_job_id: \n  queue_name: default\n  priority: 0\n  arguments:\n  - 2\n  executions: 0\n  exception_executions: {}\n  locale: en\n  timezone: UTC\n  enqueued_at: '2023-07-28T14:38:00Z'\n	\N	2023-07-28 15:38:00.051892+01	\N	\N	\N	2023-07-28 15:38:00.051943+01	2023-07-28 15:38:00.051943+01	default	\N
44	0	0	--- !ruby/object:ActiveJob::QueueAdapters::DelayedJobAdapter::JobWrapper\njob_data:\n  job_class: RestoreBackupJob\n  job_id: add9789a-1b87-48dd-964e-aa3eb4f16d1f\n  provider_job_id: \n  queue_name: default\n  priority: 0\n  arguments:\n  - backup:\n      _aj_globalid: gid://open-project/Backup/2\n    user:\n      _aj_globalid: gid://open-project/User/4\n    preview: true\n    _aj_ruby2_keywords:\n    - backup\n    - user\n    - preview\n  executions: 0\n  exception_executions: {}\n  locale: en\n  timezone: UTC\n  enqueued_at: '2023-07-28T14:42:16Z'\n	\N	2023-07-28 15:42:16.889541+01	\N	\N	\N	2023-07-28 15:42:16.889589+01	2023-07-28 15:42:16.889589+01	default	\N
45	0	0	--- !ruby/object:ActiveJob::QueueAdapters::DelayedJobAdapter::JobWrapper\njob_data:\n  job_class: CloseBackupPreviewJob\n  job_id: a6e359ee-546f-44ec-92b0-128e3c2a9a93\n  provider_job_id: \n  queue_name: default\n  priority: 0\n  arguments:\n  - 2\n  executions: 0\n  exception_executions: {}\n  locale: en\n  timezone: UTC\n  enqueued_at: '2023-07-28T14:42:57Z'\n	\N	2023-07-28 15:42:57.317079+01	\N	\N	\N	2023-07-28 15:42:57.317121+01	2023-07-28 15:42:57.317121+01	default	\N
46	0	0	--- !ruby/object:ActiveJob::QueueAdapters::DelayedJobAdapter::JobWrapper\njob_data:\n  job_class: RestoreBackupJob\n  job_id: 13aee48f-b50a-4f38-9434-c9fac2fb0322\n  provider_job_id: \n  queue_name: default\n  priority: 0\n  arguments:\n  - backup:\n      _aj_globalid: gid://open-project/Backup/2\n    user:\n      _aj_globalid: gid://open-project/User/4\n    preview: true\n    _aj_ruby2_keywords:\n    - backup\n    - user\n    - preview\n  executions: 0\n  exception_executions: {}\n  locale: en\n  timezone: UTC\n  enqueued_at: '2023-07-28T14:45:35Z'\n	\N	2023-07-28 15:45:35.697304+01	\N	\N	\N	2023-07-28 15:45:35.697359+01	2023-07-28 15:45:35.697359+01	default	\N
47	0	0	--- !ruby/object:ActiveJob::QueueAdapters::DelayedJobAdapter::JobWrapper\njob_data:\n  job_class: CloseBackupPreviewJob\n  job_id: 34dd686f-59c7-445e-9b12-b6a8160b3585\n  provider_job_id: \n  queue_name: default\n  priority: 0\n  arguments:\n  - 2\n  executions: 0\n  exception_executions: {}\n  locale: en\n  timezone: UTC\n  enqueued_at: '2023-07-28T14:52:20Z'\n	\N	2023-07-28 15:52:20.899311+01	\N	\N	\N	2023-07-28 15:52:20.899396+01	2023-07-28 15:52:20.899396+01	default	\N
48	0	0	--- !ruby/object:ActiveJob::QueueAdapters::DelayedJobAdapter::JobWrapper\njob_data:\n  job_class: RestoreBackupJob\n  job_id: f2b60c3d-6a54-4c53-92ae-bbeecd316154\n  provider_job_id: \n  queue_name: default\n  priority: 0\n  arguments:\n  - backup:\n      _aj_globalid: gid://open-project/Backup/2\n    user:\n      _aj_globalid: gid://open-project/User/4\n    preview: true\n    _aj_ruby2_keywords:\n    - backup\n    - user\n    - preview\n  executions: 0\n  exception_executions: {}\n  locale: en\n  timezone: UTC\n  enqueued_at: '2023-07-28T14:53:02Z'\n	\N	2023-07-28 15:53:02.649076+01	\N	\N	\N	2023-07-28 15:53:02.649127+01	2023-07-28 15:53:02.649127+01	default	\N
49	0	0	--- !ruby/object:ActiveJob::QueueAdapters::DelayedJobAdapter::JobWrapper\njob_data:\n  job_class: RestoreBackupJob\n  job_id: 0115426c-d3fc-4e9f-82a3-2beab6fa4e9d\n  provider_job_id: \n  queue_name: default\n  priority: 0\n  arguments:\n  - backup:\n      _aj_globalid: gid://open-project/Backup/2\n    user:\n      _aj_globalid: gid://open-project/User/4\n    preview: false\n    _aj_ruby2_keywords:\n    - backup\n    - user\n    - preview\n  executions: 0\n  exception_executions: {}\n  locale: en\n  timezone: UTC\n  enqueued_at: '2023-07-29T18:35:30Z'\n	\N	2023-07-29 19:35:30.054067+01	\N	\N	\N	2023-07-29 19:35:30.054116+01	2023-07-29 19:35:30.054116+01	default	\N
50	5	0	--- !ruby/object:ActiveJob::QueueAdapters::DelayedJobAdapter::JobWrapper\njob_data:\n  job_class: Notifications::WorkflowJob\n  job_id: 3b30a7a9-3173-4135-a2d6-5ead497a41b0\n  provider_job_id: \n  queue_name: default\n  priority: 5\n  arguments:\n  - _aj_serialized: ActiveJob::Serializers::SymbolSerializer\n    value: create_notifications\n  - _aj_globalid: gid://open-project/Journal/51\n  - true\n  executions: 0\n  exception_executions: {}\n  locale: en\n  timezone: UTC\n  enqueued_at: '2023-07-30T21:45:37Z'\n	\N	2023-07-30 22:45:37.904644+01	\N	\N	\N	2023-07-30 22:45:37.904709+01	2023-07-30 22:45:37.904709+01	default	\N
51	5	0	--- !ruby/object:ActiveJob::QueueAdapters::DelayedJobAdapter::JobWrapper\njob_data:\n  job_class: Notifications::WorkflowJob\n  job_id: d7844dae-1c6e-4e2e-af92-097fa6614a2b\n  provider_job_id: \n  queue_name: default\n  priority: 5\n  arguments:\n  - _aj_serialized: ActiveJob::Serializers::SymbolSerializer\n    value: create_notifications\n  - _aj_globalid: gid://open-project/Journal/52\n  - true\n  executions: 0\n  exception_executions: {}\n  locale: en\n  timezone: UTC\n  enqueued_at: '2023-07-30T21:45:37Z'\n	\N	2023-07-30 22:45:37.918986+01	\N	\N	\N	2023-07-30 22:45:37.919023+01	2023-07-30 22:45:37.919023+01	default	\N
52	5	0	--- !ruby/object:ActiveJob::QueueAdapters::DelayedJobAdapter::JobWrapper\njob_data:\n  job_class: Journals::CompletedJob\n  job_id: 45b42a73-75e0-496c-bcc1-bff42a9f3936\n  provider_job_id: \n  queue_name: default\n  priority: 5\n  arguments:\n  - 52\n  - _aj_serialized: ActiveJob::Serializers::TimeWithZoneSerializer\n    value: '2023-07-30T21:45:37.910753000Z'\n  - true\n  executions: 0\n  exception_executions: {}\n  locale: en\n  timezone: UTC\n  enqueued_at: '2023-07-30T21:45:37Z'\n	\N	2023-07-30 22:50:37.920379+01	\N	\N	\N	2023-07-30 22:45:37.92313+01	2023-07-30 22:45:37.92313+01	default	\N
53	20	0	--- !ruby/object:ActiveJob::QueueAdapters::DelayedJobAdapter::JobWrapper\njob_data:\n  job_class: ExtractFulltextJob\n  job_id: d07e5103-97af-4e89-b5d8-c3d96f0a1dcd\n  provider_job_id: \n  queue_name: default\n  priority: 20\n  arguments:\n  - 5\n  executions: 0\n  exception_executions: {}\n  locale: en\n  timezone: UTC\n  enqueued_at: '2023-07-30T21:45:37Z'\n	\N	2023-07-30 22:45:37.938834+01	\N	\N	\N	2023-07-30 22:45:37.938863+01	2023-07-30 22:45:37.938863+01	default	\N
54	7	0	--- !ruby/object:ActiveJob::QueueAdapters::DelayedJobAdapter::JobWrapper\njob_data:\n  job_class: BackupJob\n  job_id: 2f4347d7-cf9c-46d5-bb6f-f1d5ce07c755\n  provider_job_id: \n  queue_name: default\n  priority: 7\n  arguments:\n  - backup:\n      _aj_globalid: gid://open-project/Backup/5\n    user:\n      _aj_globalid: gid://open-project/User/4\n    include_attachments: true\n    _aj_ruby2_keywords:\n    - backup\n    - user\n    - include_attachments\n  executions: 0\n  exception_executions: {}\n  locale: en\n  timezone: UTC\n  enqueued_at: '2023-07-30T21:46:06Z'\n	\N	2023-07-30 22:46:06.244802+01	\N	\N	\N	2023-07-30 22:46:06.244857+01	2023-07-30 22:46:06.244857+01	default	\N
\.


--
-- Data for Name: design_colors; Type: TABLE DATA; Schema: backup_preview_5; Owner: -
--

COPY backup_preview_5.design_colors (id, variable, hexcode, created_at, updated_at) FROM stdin;
1	primary-color	#1A67A3	2023-07-26 11:38:39.348803+01	2023-07-26 11:38:39.348803+01
2	primary-color-dark	#175A8E	2023-07-26 11:38:39.350312+01	2023-07-26 11:38:39.350312+01
3	alternative-color	#138E1B	2023-07-26 11:38:39.351992+01	2023-07-26 11:38:39.351992+01
4	content-link-color	#175A8E	2023-07-26 11:38:39.354386+01	2023-07-26 11:38:39.354386+01
5	header-bg-color	#FAFAFA	2023-07-26 11:38:39.357035+01	2023-07-26 11:38:39.357035+01
6	header-item-bg-hover-color	#E1E1E1	2023-07-26 11:38:39.358996+01	2023-07-26 11:38:39.358996+01
7	header-item-font-color	#313131	2023-07-26 11:38:39.360813+01	2023-07-26 11:38:39.360813+01
8	header-item-font-hover-color	#313131	2023-07-26 11:38:39.362389+01	2023-07-26 11:38:39.362389+01
9	header-border-bottom-color	#E1E1E1	2023-07-26 11:38:39.364036+01	2023-07-26 11:38:39.364036+01
10	main-menu-bg-color	#ECECEC	2023-07-26 11:38:39.365957+01	2023-07-26 11:38:39.365957+01
11	main-menu-bg-selected-background	#A9A9A9	2023-07-26 11:38:39.368203+01	2023-07-26 11:38:39.368203+01
12	main-menu-bg-hover-background	#FFFFFF	2023-07-26 11:38:39.369889+01	2023-07-26 11:38:39.369889+01
13	main-menu-font-color	#000000	2023-07-26 11:38:39.37202+01	2023-07-26 11:38:39.37202+01
14	main-menu-hover-font-color	#000000	2023-07-26 11:38:39.373821+01	2023-07-26 11:38:39.373821+01
15	main-menu-selected-font-color	#000000	2023-07-26 11:38:39.375438+01	2023-07-26 11:38:39.375438+01
16	main-menu-border-color	#EAEAEA	2023-07-26 11:38:39.377084+01	2023-07-26 11:38:39.377084+01
\.


--
-- Data for Name: document_journals; Type: TABLE DATA; Schema: backup_preview_5; Owner: -
--

COPY backup_preview_5.document_journals (id, project_id, category_id, title, description) FROM stdin;
\.


--
-- Data for Name: documents; Type: TABLE DATA; Schema: backup_preview_5; Owner: -
--

COPY backup_preview_5.documents (id, project_id, category_id, title, description, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: done_statuses_for_project; Type: TABLE DATA; Schema: backup_preview_5; Owner: -
--

COPY backup_preview_5.done_statuses_for_project (project_id, status_id) FROM stdin;
\.


--
-- Data for Name: enabled_modules; Type: TABLE DATA; Schema: backup_preview_5; Owner: -
--

COPY backup_preview_5.enabled_modules (id, project_id, name) FROM stdin;
1	1	work_package_tracking
2	1	news
3	1	wiki
4	1	board_view
5	1	team_planner_view
6	2	backlogs
7	2	news
8	2	wiki
9	2	work_package_tracking
10	2	board_view
11	3	board_view
12	3	work_package_tracking
13	3	costs
14	3	reporting_module
15	3	backlogs
16	4	board_view
17	4	work_package_tracking
18	4	costs
19	4	reporting_module
20	4	backlogs
21	5	board_view
22	5	work_package_tracking
23	5	costs
24	5	reporting_module
25	5	backlogs
26	6	board_view
27	6	work_package_tracking
28	6	costs
29	6	reporting_module
30	6	backlogs
\.


--
-- Data for Name: enterprise_tokens; Type: TABLE DATA; Schema: backup_preview_5; Owner: -
--

COPY backup_preview_5.enterprise_tokens (id, encoded_token, created_at, updated_at) FROM stdin;
1	-----BEGIN OPENPROJECT-EE TOKEN-----\r\neyJkYXRhIjoiNERwcXNXeG1wNzV4RXpqYUZRTkk1RmlPL0NrQVh0cG5NQW9R\r\nVUMrcUFZQ09ZM1lTbllTTERlUWNCZFpHXG5EbHducTFLRG1hcWVDTVV0RTBB\r\nY1dmMGx0UHFVdDUweG1wOHdHNFVLSzRVK2RKWGVJbUdaSUsxV1hQU2tcbjRE\r\nZnZ6VEN2akNNTmJyVDBNVnNOQzZRek9sU2Z4U2cvTXQ0RTFLNkxDMzNGdDl3\r\nZExGT3ZiOUNpZjArSFxuN1I3Um1JOHh6ZjBsNGVoQnE5Nk9ESTlOSkcxdVRR\r\naGdZK0ZmTnlMN3l6QnJMWERmb29ONjVWVThPNXFIXG5kQlZHT09aa1BLVWNt\r\nMmVnMWJDTk9HVnlsb1I1dHhzR21GZmdWZz09XG4iLCJrZXkiOiJSb2tIdmZo\r\nSkwyRW9OSVhMT3BmdE5sMHlxZk4yd3JWOXFwWm9ja203ajE0eVZWR1FZRTBp\r\nZjM4SCtkMVJcblNaS09UVHFDZ1NadmtML3NxS0czd2Ntd2xBUDArcG1BNnFQ\r\nK3dGMDc5RXU2YVNDL2JKTFh6Skw3ZUVMK1xuMEpRYjhNemVUMmg0TGlKR2ts\r\nZFg4VXlLbmxhSkIvZXpydEZpeWlTMkl0RUsyWGZQRzlRd1JLTnVEZU05XG5m\r\nREM0RFpOb29IOFBvcnpjci9kbXdtTDBtaHlUWlY4ME5PeUlLczl2Q3FjbHBl\r\nT2FmVW9jZXN2R1BFcHlcbi9wSk5jR2JiU0psZnI5S3BkVHJ1NmpEbnM3UXdt\r\nTHBHZEJpY0pJSjlvcURucFkyajJURXI2YTFJbmNwZFxubnlxZld1WCsvOG9N\r\nNm5FdllIcHRqa281V09ITmxpVFQ2YW5OY2pkVDdYOVV6Y2thT3RoRGtlK1hG\r\nU0NEXG5JZEExZTRHalZWL0lFdjZrQzR3ekJSdnpaelV2TEdpbDRwcVBRRklq\r\nTFdSWjNTb0lGeENwS3o3WDRFWGhcbmhVVXFoMHhmU2F6TVMwTFM2S2NnYmVZ\r\neTRrZi9CRm5TRmVQdHltNUJPaE12a0NiL29BeEpZdCs4d1R2blxuQU16RzYy\r\nejc3VzIzM0cxUjFPWkdZUXFMcGEyYUVlYWI2S3V4cGxqMFE4WnRnRGhaM05L\r\nNU5yaFl5WW8zXG5GTGxmcGJoN2JQNjB0UUR5RXJtU2JJcGdCa0FJNWFzOXM1\r\nZUNOaWRIRHhVc3JlcC9ZV1pXZnE1aGU3enZcbmpUdERGUEsvV2Z2VWsvVTFD\r\nck1xaFd0TVloVkdDUFk3M0JLdGpYSHpzM24rL3YyNlU1WCsxbEVYTU1QeVxu\r\nNEpXWUx1dUN1UmhNTXlXNkhRS0dvalhSbTJ6TkNWb3lWd21tZmo4cmNyVEdV\r\nUWhDMStrWS9TK2E0di91XG5lK0Foby9STXZOSFdHY3lPMzFVT1hUUmZ2ai90\r\nYW5TTmRXOGRMQ08vL2FXSzdBL1BjTkUyWG5jcks2WkNcbnBxL05IenJ3QW05\r\nVmZIN3BZOEdCVFZVYVhZT1pIbWtUWSt4RVVLZHZpdnIvTzY3ZE5HK3dKWUNj\r\nY2lrZ1xuMVg3OTJ5aDB2Z2ZwOGl5cmx6cEVuTjlDbkZLRFRDTW95ZGc1bjdS\r\nTExteXpwWTRpUjgyVFVUanYrNDBEXG5YcnZ0c2EzWm5lWUQ2TU9aUTB5a0Ez\r\nU1ExNmR3S3E5UFREQmpXTVRvMU9OUmNWOWl0SXhVTzArRjhsQ3Bcbklxc09X\r\nRHYwcWhyK0lob013YXMyVWsxcXFhZ25EUHQrNWtEOFNwOXE2QWhmNnB4VklW\r\nbEEyNjlLTmtlcFxuTi83eW9Dc3dqaGN2T0ZYeG01MXJDU2x6RlVYYzlQN3dE\r\nV01MMFQwSVBSMGRxcDIxRGp3bTduZ0oxNFZnXG4xUmFScFg5Nkw1S0hQaWJD\r\nZGJKYXJBcFluWi85dzFzQVBJVS9ZRC9SaXNFMXVLQXdpSU56ZVdQNkVlZExc\r\nblFYNW9UcFI2WlFUVjBCTVhZQysxbmJXUEtadU81bTgzZ0JTZDdPTU9ybTFn\r\nTDVESGwrT05hbTVyWnkzVFxuYkk1by83ektPZk5ESmJGNDEvQWFKZUg4Zzkx\r\nL2c0cExaWnNZQTM2cmg2ZXQxVHhkMjFGUGRXajc1aHlXXG5EYVpDSUxjQzNS\r\ndkV4ODQyMjFMZC9mWjhkL01HdUdQQXZBMkdMV2ZWR2Z5SzQvSEFUaHprM25q\r\naUl1UHRcbmpPWGk3SnNGMC9weVNhODRlVW1hckQ0VzdtQ29jQT09XG4iLCJp\r\ndiI6IitYUVNvaXVSQXJPbERyL0VnK0tkeEE9PVxuIn0=\r\n-----END OPENPROJECT-EE TOKEN-----\r\n	2023-07-26 11:08:19.357435+01	2023-07-26 11:08:19.357435+01
\.


--
-- Data for Name: enumerations; Type: TABLE DATA; Schema: backup_preview_5; Owner: -
--

COPY backup_preview_5.enumerations (id, name, "position", is_default, type, active, project_id, parent_id, created_at, updated_at, color_id) FROM stdin;
1	Management	1	t	TimeEntryActivity	t	\N	\N	2023-07-26 09:22:05.723064+01	2023-07-26 09:22:05.723064+01	\N
2	Specification	2	f	TimeEntryActivity	t	\N	\N	2023-07-26 09:22:05.726455+01	2023-07-26 09:22:05.726455+01	\N
3	Development	3	f	TimeEntryActivity	t	\N	\N	2023-07-26 09:22:05.730651+01	2023-07-26 09:22:05.730651+01	\N
4	Testing	4	f	TimeEntryActivity	t	\N	\N	2023-07-26 09:22:05.734165+01	2023-07-26 09:22:05.734165+01	\N
5	Support	5	f	TimeEntryActivity	t	\N	\N	2023-07-26 09:22:05.737361+01	2023-07-26 09:22:05.737361+01	\N
6	Other	6	f	TimeEntryActivity	t	\N	\N	2023-07-26 09:22:05.740964+01	2023-07-26 09:22:05.740964+01	\N
7	Low	1	f	IssuePriority	t	\N	\N	2023-07-26 09:22:06.810486+01	2023-07-26 09:22:06.810486+01	86
8	Normal	2	t	IssuePriority	t	\N	\N	2023-07-26 09:22:06.816294+01	2023-07-26 09:22:06.816294+01	78
9	High	3	f	IssuePriority	t	\N	\N	2023-07-26 09:22:06.819827+01	2023-07-26 09:22:06.819827+01	132
10	Immediate	4	f	IssuePriority	t	\N	\N	2023-07-26 09:22:06.822973+01	2023-07-26 09:22:06.822973+01	50
11	Documentation	1	f	DocumentCategory	t	\N	\N	2023-07-26 09:22:07.320959+01	2023-07-26 09:22:07.320959+01	\N
12	Specification	2	f	DocumentCategory	t	\N	\N	2023-07-26 09:22:07.326671+01	2023-07-26 09:22:07.326671+01	\N
13	Other	3	f	DocumentCategory	t	\N	\N	2023-07-26 09:22:07.329521+01	2023-07-26 09:22:07.329521+01	\N
\.


--
-- Data for Name: export_card_configurations; Type: TABLE DATA; Schema: backup_preview_5; Owner: -
--

COPY backup_preview_5.export_card_configurations (id, name, per_page, page_size, orientation, rows, active, description) FROM stdin;
\.


--
-- Data for Name: exports; Type: TABLE DATA; Schema: backup_preview_5; Owner: -
--

COPY backup_preview_5.exports (id, created_at, updated_at, type) FROM stdin;
1	2023-07-28 13:26:03.448696+01	2023-07-28 13:26:07.44397+01	WorkPackages::Export
\.


--
-- Data for Name: file_links; Type: TABLE DATA; Schema: backup_preview_5; Owner: -
--

COPY backup_preview_5.file_links (id, storage_id, creator_id, container_id, container_type, origin_id, origin_name, origin_created_by_name, origin_last_modified_by_name, origin_mime_type, origin_created_at, origin_updated_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: forums; Type: TABLE DATA; Schema: backup_preview_5; Owner: -
--

COPY backup_preview_5.forums (id, project_id, name, description, "position", topics_count, messages_count, last_message_id) FROM stdin;
\.


--
-- Data for Name: github_check_runs; Type: TABLE DATA; Schema: backup_preview_5; Owner: -
--

COPY backup_preview_5.github_check_runs (id, github_pull_request_id, github_id, github_html_url, app_id, github_app_owner_avatar_url, status, name, conclusion, output_title, output_summary, details_url, started_at, completed_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: github_pull_requests; Type: TABLE DATA; Schema: backup_preview_5; Owner: -
--

COPY backup_preview_5.github_pull_requests (id, github_user_id, merged_by_id, github_id, number, github_html_url, state, repository, github_updated_at, title, body, draft, merged, merged_at, comments_count, review_comments_count, additions_count, deletions_count, changed_files_count, labels, created_at, updated_at, repository_html_url) FROM stdin;
\.


--
-- Data for Name: github_pull_requests_work_packages; Type: TABLE DATA; Schema: backup_preview_5; Owner: -
--

COPY backup_preview_5.github_pull_requests_work_packages (github_pull_request_id, work_package_id) FROM stdin;
\.


--
-- Data for Name: github_users; Type: TABLE DATA; Schema: backup_preview_5; Owner: -
--

COPY backup_preview_5.github_users (id, github_id, github_login, github_html_url, github_avatar_url, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: grid_widgets; Type: TABLE DATA; Schema: backup_preview_5; Owner: -
--

COPY backup_preview_5.grid_widgets (id, start_row, end_row, start_column, end_column, identifier, options, grid_id) FROM stdin;
1	1	2	1	2	work_package_query	---\n:query_id: 5\n:filters:\n- :status:\n    :operator: "="\n    :values:\n    - '1'\n	1
2	1	2	2	3	work_package_query	---\n:query_id: 6\n:filters:\n- :status:\n    :operator: "="\n    :values:\n    - '7'\n	1
3	1	2	3	4	work_package_query	---\n:query_id: 7\n:filters:\n- :status:\n    :operator: "="\n    :values:\n    - '12'\n	1
4	1	2	4	5	work_package_query	---\n:query_id: 8\n:filters:\n- :status:\n    :operator: "="\n    :values:\n    - '14'\n	1
5	1	2	1	2	work_package_query	---\n:query_id: 9\n:filters:\n- :manualSort:\n    :operator: ow\n    :values: []\n	2
6	1	2	2	3	work_package_query	---\n:query_id: 10\n:filters:\n- :manualSort:\n    :operator: ow\n    :values: []\n	2
7	1	2	3	4	work_package_query	---\n:query_id: 11\n:filters:\n- :manualSort:\n    :operator: ow\n    :values: []\n	2
8	1	2	4	5	work_package_query	---\n:query_id: 12\n:filters:\n- :manualSort:\n    :operator: ow\n    :values: []\n	2
9	1	2	1	2	work_package_query	---\n:query_id: 13\n:filters:\n- :parent:\n    :operator: "="\n    :values:\n    - '2'\n	3
10	1	2	2	3	work_package_query	---\n:query_id: 14\n:filters:\n- :parent:\n    :operator: "="\n    :values:\n    - '10'\n	3
11	1	2	1	2	work_package_query	---\n:query_id: 19\n:filters:\n- :status:\n    :operator: "="\n    :values:\n    - '1'\n	4
12	1	2	2	3	work_package_query	---\n:query_id: 20\n:filters:\n- :status:\n    :operator: "="\n    :values:\n    - '7'\n	4
13	1	2	3	4	work_package_query	---\n:query_id: 21\n:filters:\n- :status:\n    :operator: "="\n    :values:\n    - '12'\n	4
14	1	2	4	5	work_package_query	---\n:query_id: 22\n:filters:\n- :status:\n    :operator: "="\n    :values:\n    - '14'\n	4
15	1	2	1	2	work_package_query	---\n:query_id: 23\n:filters:\n- :manualSort:\n    :operator: ow\n    :values: []\n	5
16	1	2	2	3	work_package_query	---\n:query_id: 24\n:filters:\n- :manualSort:\n    :operator: ow\n    :values: []\n	5
17	1	2	3	4	work_package_query	---\n:query_id: 25\n:filters:\n- :manualSort:\n    :operator: ow\n    :values: []\n	5
18	1	2	4	5	work_package_query	---\n:query_id: 26\n:filters:\n- :manualSort:\n    :operator: ow\n    :values: []\n	5
19	1	2	1	3	custom_text	---\ntext: "![Teaser](/api/v3/attachments/1/content)"\nname: Welcome\n	6
20	2	5	1	2	custom_text	---\nname: Getting started\ntext: |\n  We are glad you joined! We suggest to try a few things to get started in OpenProject.\n\n  Discover the most important features with our [Guided Tour]({{opSetting:base_url}}/projects/demo-project/work_packages/?start_onboarding_tour=true).\n\n  _Try the following steps:_\n\n  1. *Invite new members to your project*: &rightarrow; Go to [Members]({{opSetting:base_url}}/projects/demo-project/members) in the project navigation.\n  2. *View the work in your project*: &rightarrow; Go to [Work packages]({{opSetting:base_url}}/projects/demo-project/work_packages) in the project navigation.\n  3. *Create a new work package*: &rightarrow; Go to [Work packages &rightarrow; Create]({{opSetting:base_url}}/projects/demo-project/work_packages/new).\n  4. *Create and update a project plan*: &rightarrow; Go to [Project plan]({{opSetting:base_url}}/projects/demo-project/work_packages?query_id=1) in the project navigation.\n  5. *Activate further modules*: &rightarrow; Go to [Project settings &rightarrow; Modules]({{opSetting:base_url}}/projects/demo-project/settings/modules).\n  6. *Complete your tasks in the project*: &rightarrow; Go to [Work packages &rightarrow; Tasks]({{opSetting:base_url}}/projects/demo-project/work_packages/details/3/overview?query_id=3).\n\n  Here you will find our [User Guides](https://www.openproject.org/docs/user-guide/).\n  Please let us know if you have any questions or need support. Contact us: [support[at]openproject.com](mailto:support@openproject.com).\n	6
21	2	3	2	3	project_status	\N	6
22	3	4	2	3	project_description	\N	6
23	4	5	2	3	members	---\nname: Members\n	6
24	5	6	1	3	work_packages_overview	---\nname: Work packages\n	6
25	6	7	1	3	work_packages_table	---\nqueryId: '2'\nname: Milestones\n	6
26	1	2	1	3	custom_text	---\ntext: "![Teaser](/api/v3/attachments/2/content)"\nname: Welcome\n	7
27	2	5	1	2	custom_text	---\nname: Getting started\ntext: |\n  We are glad you joined! We suggest to try a few things to get started in OpenProject.\n\n  Discover the most important features with our [Guided Tour]({{opSetting:base_url}}/projects/your-scrum-project/backlogs?start_scrum_onboarding_tour=true).\n\n  _Try the following steps:_\n\n  1. *Invite new members to your project*: &rightarrow; Go to [Members]({{opSetting:base_url}}/projects/your-scrum-project/members) in the project navigation.\n  2. *View your Product backlog and Sprint backlogs*: &rightarrow; Go to [Backlogs]({{opSetting:base_url}}/projects/your-scrum-project/backlogs) in the project navigation.\n  3. *View your Task board*: &rightarrow; Go to [Backlogs]({{opSetting:base_url}}/projects/your-scrum-project/backlogs) &rightarrow; Click on right arrow on Sprint &rightarrow; Select [Task Board](/projects/your-scrum-project/sprints/3/taskboard).\n  4. *Create a new work package*: &rightarrow; Go to [Work packages &rightarrow; Create]({{opSetting:base_url}}/projects/your-scrum-project/work_packages/new).\n  5. *Create and update a project plan*: &rightarrow; Go to [Project plan](/projects/your-scrum-project/work_packages?query_id=15) in the project navigation.\n  6. *Create a Sprint wiki*: &rightarrow; Go to [Backlogs]({{opSetting:base_url}}/projects/your-scrum-project/backlogs) and open the sprint wiki from the right drop down menu in a sprint. You can edit the [wiki template]({{opSetting:base_url}}/projects/your-scrum-project/wiki/) based on your needs.\n  7. *Activate further modules*: &rightarrow; Go to [Project settings &rightarrow; Modules]({{opSetting:base_url}}/projects/your-scrum-project/settings/modules).\n\n  Here you will find our [User Guides](https://www.openproject.org/docs/user-guide/).\n  Please let us know if you have any questions or need support. Contact us: [support[at]openproject.com](mailto:support@openproject.com).\n	7
28	2	3	2	3	project_status	\N	7
29	3	4	2	3	project_description	\N	7
30	4	5	2	3	members	---\nname: Members\n	7
31	5	6	1	3	work_packages_overview	---\nname: Work packages\n	7
32	6	7	1	3	work_packages_table	---\nqueryId: '15'\nname: Project plan\n	7
\.


--
-- Data for Name: grids; Type: TABLE DATA; Schema: backup_preview_5; Owner: -
--

COPY backup_preview_5.grids (id, row_count, column_count, type, user_id, created_at, updated_at, project_id, name, options) FROM stdin;
1	1	4	Boards::Grid	\N	2023-07-26 09:22:08.603512+01	2023-07-26 09:22:08.603512+01	1	Kanban board	---\ntype: action\nattribute: status\nhighlightingMode: priority\n:filters:\n- :type:\n    :operator: "="\n    :values:\n    - '1'\n
2	1	4	Boards::Grid	\N	2023-07-26 09:22:08.640498+01	2023-07-26 09:22:08.640498+01	1	Basic board	---\nhighlightingMode: priority\n
3	1	2	Boards::Grid	\N	2023-07-26 09:22:08.665656+01	2023-07-26 09:22:08.665656+01	1	Work breakdown structure	---\ntype: action\nattribute: subtasks\n
4	1	4	Boards::Grid	\N	2023-07-26 09:22:09.870852+01	2023-07-26 09:22:09.870852+01	2	Kanban board	---\ntype: action\nattribute: status\nhighlightingMode: priority\n
5	1	4	Boards::Grid	\N	2023-07-26 09:22:09.90046+01	2023-07-26 09:22:09.90046+01	2	Task board	---\nhighlightingMode: priority\n
6	6	2	Grids::Overview	\N	2023-07-26 09:22:09.912139+01	2023-07-26 09:22:09.912139+01	1	\N	\N
7	6	2	Grids::Overview	\N	2023-07-26 09:22:09.961127+01	2023-07-26 09:22:09.961127+01	2	\N	\N
\.


--
-- Data for Name: group_users; Type: TABLE DATA; Schema: backup_preview_5; Owner: -
--

COPY backup_preview_5.group_users (group_id, user_id, id) FROM stdin;
\.


--
-- Data for Name: ical_token_query_assignments; Type: TABLE DATA; Schema: backup_preview_5; Owner: -
--

COPY backup_preview_5.ical_token_query_assignments (id, ical_token_id, query_id, created_at, updated_at, name) FROM stdin;
\.


--
-- Data for Name: ifc_models; Type: TABLE DATA; Schema: backup_preview_5; Owner: -
--

COPY backup_preview_5.ifc_models (id, title, created_at, updated_at, project_id, uploader_id, is_default, conversion_status, conversion_error_message) FROM stdin;
\.


--
-- Data for Name: journals; Type: TABLE DATA; Schema: backup_preview_5; Owner: -
--

COPY backup_preview_5.journals (id, journable_type, journable_id, user_id, notes, created_at, version, updated_at, data_type, data_id) FROM stdin;
1	Project	1	3		2023-07-26 09:22:07.602264+01	1	2023-07-26 09:22:07.602264+01	Journal::ProjectJournal	1
2	News	1	3		2023-07-26 09:22:07.720793+01	1	2023-07-26 09:22:07.720793+01	Journal::NewsJournal	1
3	WorkPackage	1	3		2023-07-26 09:22:07.861971+01	1	2023-07-26 09:22:07.861971+01	Journal::WorkPackageJournal	1
6	WorkPackage	4	3		2023-07-26 09:22:07.98944+01	1	2023-07-26 09:22:08.033761+01	Journal::WorkPackageJournal	5
7	WorkPackage	5	3		2023-07-26 09:22:08.04898+01	1	2023-07-26 09:22:08.085407+01	Journal::WorkPackageJournal	7
8	WorkPackage	6	3		2023-07-26 09:22:08.099198+01	1	2023-07-26 09:22:08.14419+01	Journal::WorkPackageJournal	9
5	WorkPackage	3	3		2023-07-26 09:22:07.963258+01	1	2023-07-26 09:22:08.196132+01	Journal::WorkPackageJournal	11
9	WorkPackage	7	3		2023-07-26 09:22:08.211407+01	1	2023-07-26 09:22:08.254661+01	Journal::WorkPackageJournal	13
10	WorkPackage	8	3		2023-07-26 09:22:08.271391+01	1	2023-07-26 09:22:08.309413+01	Journal::WorkPackageJournal	15
4	WorkPackage	2	3		2023-07-26 09:22:07.933492+01	1	2023-07-26 09:22:08.329748+01	Journal::WorkPackageJournal	16
11	WorkPackage	9	3		2023-07-26 09:22:08.34986+01	1	2023-07-26 09:22:08.34986+01	Journal::WorkPackageJournal	17
13	WorkPackage	11	3		2023-07-26 09:22:08.40803+01	1	2023-07-26 09:22:08.456445+01	Journal::WorkPackageJournal	20
14	WorkPackage	12	3		2023-07-26 09:22:08.473451+01	1	2023-07-26 09:22:08.510069+01	Journal::WorkPackageJournal	22
12	WorkPackage	10	3		2023-07-26 09:22:08.382407+01	1	2023-07-26 09:22:08.523806+01	Journal::WorkPackageJournal	23
15	WorkPackage	13	3		2023-07-26 09:22:08.536543+01	1	2023-07-26 09:22:08.536543+01	Journal::WorkPackageJournal	24
16	Project	2	3		2023-07-26 09:22:08.69182+01	1	2023-07-26 09:22:08.69182+01	Journal::ProjectJournal	2
17	News	2	3		2023-07-26 09:22:08.741165+01	1	2023-07-26 09:22:08.741165+01	Journal::NewsJournal	2
18	WikiPage	1	3		2023-07-26 09:22:08.797831+01	1	2023-07-26 09:22:08.797831+01	Journal::WikiPageJournal	1
19	WikiPage	2	3		2023-07-26 09:22:08.887046+01	1	2023-07-26 09:22:08.887046+01	Journal::WikiPageJournal	2
20	WorkPackage	14	3		2023-07-26 09:22:08.914479+01	1	2023-07-26 09:22:08.914479+01	Journal::WorkPackageJournal	25
21	WorkPackage	15	3		2023-07-26 09:22:08.953453+01	1	2023-07-26 09:22:08.953453+01	Journal::WorkPackageJournal	26
23	WorkPackage	17	3		2023-07-26 09:22:09.00801+01	1	2023-07-26 09:22:09.056722+01	Journal::WorkPackageJournal	29
24	WorkPackage	18	3		2023-07-26 09:22:09.074143+01	1	2023-07-26 09:22:09.116664+01	Journal::WorkPackageJournal	31
26	WorkPackage	20	3		2023-07-26 09:22:09.163901+01	1	2023-07-26 09:22:09.20149+01	Journal::WorkPackageJournal	34
25	WorkPackage	19	3		2023-07-26 09:22:09.133711+01	1	2023-07-26 09:22:09.25017+01	Journal::WorkPackageJournal	36
22	WorkPackage	16	3		2023-07-26 09:22:08.985574+01	1	2023-07-26 09:22:09.268069+01	Journal::WorkPackageJournal	37
27	WorkPackage	21	3		2023-07-26 09:22:09.28385+01	1	2023-07-26 09:22:09.28385+01	Journal::WorkPackageJournal	38
29	WorkPackage	23	3		2023-07-26 09:22:09.346099+01	1	2023-07-26 09:22:09.387285+01	Journal::WorkPackageJournal	41
28	WorkPackage	22	3		2023-07-26 09:22:09.315148+01	1	2023-07-26 09:22:09.403846+01	Journal::WorkPackageJournal	42
30	WorkPackage	24	3		2023-07-26 09:22:09.419672+01	1	2023-07-26 09:22:09.419672+01	Journal::WorkPackageJournal	43
31	WorkPackage	25	3		2023-07-26 09:22:09.451078+01	1	2023-07-26 09:22:09.451078+01	Journal::WorkPackageJournal	44
32	WorkPackage	26	3		2023-07-26 09:22:09.489023+01	1	2023-07-26 09:22:09.489023+01	Journal::WorkPackageJournal	45
33	WorkPackage	27	3		2023-07-26 09:22:09.525581+01	1	2023-07-26 09:22:09.525581+01	Journal::WorkPackageJournal	46
35	WorkPackage	29	3		2023-07-26 09:22:09.588829+01	1	2023-07-26 09:22:09.627076+01	Journal::WorkPackageJournal	49
34	WorkPackage	28	3		2023-07-26 09:22:09.560194+01	1	2023-07-26 09:22:09.641843+01	Journal::WorkPackageJournal	50
36	WorkPackage	30	3		2023-07-26 09:22:09.655628+01	1	2023-07-26 09:22:09.655628+01	Journal::WorkPackageJournal	51
37	WorkPackage	31	3		2023-07-26 09:22:09.685346+01	1	2023-07-26 09:22:09.685346+01	Journal::WorkPackageJournal	52
38	WorkPackage	32	3		2023-07-26 09:22:09.712085+01	1	2023-07-26 09:22:09.712085+01	Journal::WorkPackageJournal	53
39	WorkPackage	33	3		2023-07-26 09:22:09.744906+01	1	2023-07-26 09:22:09.744906+01	Journal::WorkPackageJournal	54
40	WorkPackage	34	3		2023-07-26 09:22:09.771828+01	1	2023-07-26 09:22:09.771828+01	Journal::WorkPackageJournal	55
41	WorkPackage	35	3		2023-07-26 09:22:09.799192+01	1	2023-07-26 09:22:09.799192+01	Journal::WorkPackageJournal	56
42	WorkPackage	36	3		2023-07-26 09:22:09.828692+01	1	2023-07-26 09:22:09.828692+01	Journal::WorkPackageJournal	57
43	Attachment	1	3		2023-07-26 09:22:09.932178+01	1	2023-07-26 09:22:09.932178+01	Journal::AttachmentJournal	1
44	Attachment	2	3		2023-07-26 09:22:09.966339+01	1	2023-07-26 09:22:09.966339+01	Journal::AttachmentJournal	2
45	Project	3	3		2023-07-26 09:22:10.822769+01	1	2023-07-26 09:22:10.822769+01	Journal::ProjectJournal	3
46	Project	4	3		2023-07-26 09:22:10.871751+01	1	2023-07-26 09:22:10.871751+01	Journal::ProjectJournal	4
47	Project	5	3		2023-07-26 09:22:10.918119+01	1	2023-07-26 09:22:10.918119+01	Journal::ProjectJournal	5
48	Project	6	3		2023-07-26 09:22:10.977801+01	1	2023-07-26 09:22:11.104739+01	Journal::ProjectJournal	7
50	Attachment	4	4		2023-07-28 13:26:07.402459+01	1	2023-07-28 13:26:07.402459+01	Journal::AttachmentJournal	4
51	Attachment	5	4		2023-07-30 22:45:37.883264+01	1	2023-07-30 22:45:37.883264+01	Journal::AttachmentJournal	5
52	WorkPackage	2	4		2023-07-30 22:45:37.910753+01	2	2023-07-30 22:45:37.910753+01	Journal::WorkPackageJournal	58
\.


--
-- Data for Name: labor_budget_items; Type: TABLE DATA; Schema: backup_preview_5; Owner: -
--

COPY backup_preview_5.labor_budget_items (id, budget_id, hours, user_id, comments, amount) FROM stdin;
\.


--
-- Data for Name: last_project_folders; Type: TABLE DATA; Schema: backup_preview_5; Owner: -
--

COPY backup_preview_5.last_project_folders (id, projects_storage_id, origin_folder_id, mode, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: ldap_groups_memberships; Type: TABLE DATA; Schema: backup_preview_5; Owner: -
--

COPY backup_preview_5.ldap_groups_memberships (id, user_id, group_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: ldap_groups_synchronized_filters; Type: TABLE DATA; Schema: backup_preview_5; Owner: -
--

COPY backup_preview_5.ldap_groups_synchronized_filters (id, name, group_name_attribute, filter_string, auth_source_id, created_at, updated_at, base_dn, sync_users) FROM stdin;
\.


--
-- Data for Name: ldap_groups_synchronized_groups; Type: TABLE DATA; Schema: backup_preview_5; Owner: -
--

COPY backup_preview_5.ldap_groups_synchronized_groups (id, group_id, auth_source_id, created_at, updated_at, dn, users_count, filter_id, sync_users) FROM stdin;
\.


--
-- Data for Name: material_budget_items; Type: TABLE DATA; Schema: backup_preview_5; Owner: -
--

COPY backup_preview_5.material_budget_items (id, budget_id, units, cost_type_id, comments, amount) FROM stdin;
\.


--
-- Data for Name: meeting_content_journals; Type: TABLE DATA; Schema: backup_preview_5; Owner: -
--

COPY backup_preview_5.meeting_content_journals (id, meeting_id, author_id, text, locked) FROM stdin;
\.


--
-- Data for Name: meeting_contents; Type: TABLE DATA; Schema: backup_preview_5; Owner: -
--

COPY backup_preview_5.meeting_contents (id, type, meeting_id, author_id, text, lock_version, created_at, updated_at, locked) FROM stdin;
\.


--
-- Data for Name: meeting_journals; Type: TABLE DATA; Schema: backup_preview_5; Owner: -
--

COPY backup_preview_5.meeting_journals (id, title, author_id, project_id, location, start_time, duration) FROM stdin;
\.


--
-- Data for Name: meeting_participants; Type: TABLE DATA; Schema: backup_preview_5; Owner: -
--

COPY backup_preview_5.meeting_participants (id, user_id, meeting_id, email, name, invited, attended, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: meetings; Type: TABLE DATA; Schema: backup_preview_5; Owner: -
--

COPY backup_preview_5.meetings (id, title, author_id, project_id, location, start_time, duration, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: member_roles; Type: TABLE DATA; Schema: backup_preview_5; Owner: -
--

COPY backup_preview_5.member_roles (id, member_id, role_id, inherited_from) FROM stdin;
1	1	5	\N
2	2	5	\N
3	3	4	\N
4	4	4	\N
5	5	4	\N
6	6	4	\N
7	7	3	\N
8	8	3	\N
9	9	3	\N
10	10	3	\N
11	11	5	\N
12	12	5	\N
13	13	5	\N
14	14	5	\N
\.


--
-- Data for Name: members; Type: TABLE DATA; Schema: backup_preview_5; Owner: -
--

COPY backup_preview_5.members (id, user_id, project_id, created_at, updated_at) FROM stdin;
1	4	1	2023-07-26 09:22:07.714588+01	2023-07-26 09:22:07.716519+01
2	4	2	2023-07-26 09:22:08.739401+01	2023-07-26 09:22:08.740937+01
3	5	3	2023-07-26 09:22:10.993952+01	2023-07-26 09:22:10.995167+01
4	5	4	2023-07-26 09:22:10.997454+01	2023-07-26 09:22:10.998813+01
5	5	5	2023-07-26 09:22:11.000963+01	2023-07-26 09:22:11.002039+01
6	5	6	2023-07-26 09:22:11.004444+01	2023-07-26 09:22:11.00584+01
7	6	3	2023-07-26 09:22:11.009549+01	2023-07-26 09:22:11.011278+01
8	6	4	2023-07-26 09:22:11.013336+01	2023-07-26 09:22:11.014617+01
9	6	5	2023-07-26 09:22:11.016614+01	2023-07-26 09:22:11.017699+01
10	6	6	2023-07-26 09:22:11.01976+01	2023-07-26 09:22:11.020965+01
11	7	3	2023-07-26 09:22:11.02357+01	2023-07-26 09:22:11.025031+01
12	7	4	2023-07-26 09:22:11.027436+01	2023-07-26 09:22:11.02873+01
13	7	5	2023-07-26 09:22:11.031272+01	2023-07-26 09:22:11.032614+01
14	7	6	2023-07-26 09:22:11.034502+01	2023-07-26 09:22:11.035896+01
\.


--
-- Data for Name: menu_items; Type: TABLE DATA; Schema: backup_preview_5; Owner: -
--

COPY backup_preview_5.menu_items (id, name, title, parent_id, options, navigatable_id, type) FROM stdin;
1	wiki	Wiki	\N	---\n:new_wiki_page: true\n:index_page: true\n	1	MenuItems::WikiMenuItem
2	wiki	Wiki	\N	---\n:new_wiki_page: true\n:index_page: true\n	2	MenuItems::WikiMenuItem
\.


--
-- Data for Name: message_journals; Type: TABLE DATA; Schema: backup_preview_5; Owner: -
--

COPY backup_preview_5.message_journals (id, forum_id, parent_id, subject, content, author_id, locked, sticky) FROM stdin;
\.


--
-- Data for Name: messages; Type: TABLE DATA; Schema: backup_preview_5; Owner: -
--

COPY backup_preview_5.messages (id, forum_id, parent_id, subject, content, author_id, replies_count, last_reply_id, created_at, updated_at, locked, sticky, sticked_on) FROM stdin;
\.


--
-- Data for Name: news; Type: TABLE DATA; Schema: backup_preview_5; Owner: -
--

COPY backup_preview_5.news (id, project_id, title, summary, description, author_id, created_at, comments_count, updated_at) FROM stdin;
1	1	Welcome to your demo project	We are glad you joined.\nIn this module you can communicate project news to your team members.\n	The actual news	4	2023-07-26 09:22:07.720793+01	0	2023-07-26 09:22:07.720793+01
2	2	Welcome to your Scrum demo project	We are glad you joined.\nIn this module you can communicate project news to your team members.\n	This is the news content.	4	2023-07-26 09:22:08.741165+01	0	2023-07-26 09:22:08.741165+01
\.


--
-- Data for Name: news_journals; Type: TABLE DATA; Schema: backup_preview_5; Owner: -
--

COPY backup_preview_5.news_journals (id, project_id, title, summary, description, author_id, comments_count) FROM stdin;
1	1	Welcome to your demo project	We are glad you joined.\nIn this module you can communicate project news to your team members.\n	The actual news	4	0
2	2	Welcome to your Scrum demo project	We are glad you joined.\nIn this module you can communicate project news to your team members.\n	This is the news content.	4	0
\.


--
-- Data for Name: non_working_days; Type: TABLE DATA; Schema: backup_preview_5; Owner: -
--

COPY backup_preview_5.non_working_days (id, name, date, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: notification_settings; Type: TABLE DATA; Schema: backup_preview_5; Owner: -
--

COPY backup_preview_5.notification_settings (id, project_id, user_id, watched, mentioned, created_at, updated_at, work_package_commented, work_package_created, work_package_processed, work_package_prioritized, work_package_scheduled, news_added, news_commented, document_added, forum_messages, wiki_page_added, wiki_page_updated, membership_added, membership_updated, start_date, due_date, overdue, assignee, responsible) FROM stdin;
1	\N	4	t	t	2023-07-26 09:22:07.346311+01	2023-07-26 09:22:07.346311+01	f	f	f	f	f	f	f	f	f	f	f	f	f	1	1	\N	t	t
2	\N	5	t	t	2023-07-26 09:22:09.99218+01	2023-07-26 09:22:09.99218+01	f	f	f	f	f	f	f	f	f	f	f	f	f	1	1	\N	t	t
3	\N	6	t	t	2023-07-26 09:22:10.170922+01	2023-07-26 09:22:10.170922+01	f	f	f	f	f	f	f	f	f	f	f	f	f	1	1	\N	t	t
4	\N	7	t	t	2023-07-26 09:22:10.376853+01	2023-07-26 09:22:10.376853+01	f	f	f	f	f	f	f	f	f	f	f	f	f	1	1	\N	t	t
5	\N	8	t	t	2023-07-26 09:22:10.543704+01	2023-07-26 09:22:10.543704+01	f	f	f	f	f	f	f	f	f	f	f	f	f	1	1	\N	t	t
\.


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: backup_preview_5; Owner: -
--

COPY backup_preview_5.notifications (id, subject, read_ian, reason, recipient_id, actor_id, resource_type, resource_id, project_id, journal_id, created_at, updated_at, mail_reminder_sent, mail_alert_sent) FROM stdin;
\.


--
-- Data for Name: oauth_access_grants; Type: TABLE DATA; Schema: backup_preview_5; Owner: -
--

COPY backup_preview_5.oauth_access_grants (id, resource_owner_id, application_id, token, expires_in, redirect_uri, created_at, revoked_at, scopes, code_challenge, code_challenge_method) FROM stdin;
\.


--
-- Data for Name: oauth_access_tokens; Type: TABLE DATA; Schema: backup_preview_5; Owner: -
--

COPY backup_preview_5.oauth_access_tokens (id, resource_owner_id, application_id, token, refresh_token, expires_in, revoked_at, created_at, scopes, previous_refresh_token) FROM stdin;
\.


--
-- Data for Name: oauth_applications; Type: TABLE DATA; Schema: backup_preview_5; Owner: -
--

COPY backup_preview_5.oauth_applications (id, name, uid, secret, owner_type, owner_id, client_credentials_user_id, redirect_uri, scopes, confidential, created_at, updated_at, integration_type, integration_id) FROM stdin;
\.


--
-- Data for Name: oauth_client_tokens; Type: TABLE DATA; Schema: backup_preview_5; Owner: -
--

COPY backup_preview_5.oauth_client_tokens (id, oauth_client_id, user_id, access_token, refresh_token, token_type, expires_in, scope, origin_user_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: oauth_clients; Type: TABLE DATA; Schema: backup_preview_5; Owner: -
--

COPY backup_preview_5.oauth_clients (id, client_id, client_secret, integration_type, integration_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: oidc_user_session_links; Type: TABLE DATA; Schema: backup_preview_5; Owner: -
--

COPY backup_preview_5.oidc_user_session_links (id, oidc_session, session_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: ordered_work_packages; Type: TABLE DATA; Schema: backup_preview_5; Owner: -
--

COPY backup_preview_5.ordered_work_packages (id, "position", query_id, work_package_id) FROM stdin;
1	0	9	8
2	1	9	11
3	0	10	7
4	0	11	3
5	0	23	16
6	1	23	25
7	2	23	27
8	0	24	14
9	0	25	26
10	0	26	24
\.


--
-- Data for Name: paper_trail_audits; Type: TABLE DATA; Schema: backup_preview_5; Owner: -
--

COPY backup_preview_5.paper_trail_audits (id, item_type, item_id, event, whodunnit, stack, object, object_changes, created_at) FROM stdin;
1	Attachment	3	destroy	4	app/controllers/admin/backups_controller.rb:199:in `destroy'\nlib/open_project/elevators/backup_preview_elevator.rb:17:in `call'	{"id": 3, "file": "openproject-backup20230726-188669-b4jwvg.zip", "digest": "35fae5b4a0fe36d788aa78db6a3da44f", "filename": "/tmp/openproject-backup20230726-188669-b4jwvg.zip", "filesize": 954034, "author_id": 4, "downloads": 0, "created_at": "07/26/2023/ 10:38 AM", "updated_at": "07/26/2023/ 10:38 AM", "description": "OpenProject backup", "container_id": 2, "content_type": "application/zip", "disk_filename": "", "container_type": "Backup"}	{"id": [3, null], "file": ["openproject-backup20230726-188669-b4jwvg.zip", null], "digest": ["35fae5b4a0fe36d788aa78db6a3da44f", null], "filename": ["/tmp/openproject-backup20230726-188669-b4jwvg.zip", null], "filesize": [954034, null], "author_id": [4, null], "downloads": [0, null], "created_at": ["07/26/2023/ 10:38 AM", null], "updated_at": ["07/26/2023/ 10:38 AM", null], "description": ["OpenProject backup", null], "container_id": [2, null], "content_type": ["application/zip", null], "disk_filename": ["", null], "container_type": ["Backup", null]}	2023-07-30 22:45:51.209553+01
\.


--
-- Data for Name: project_journals; Type: TABLE DATA; Schema: backup_preview_5; Owner: -
--

COPY backup_preview_5.project_journals (id, name, description, public, parent_id, identifier, active, templated, status_code, status_explanation) FROM stdin;
1	Demo project	This is a short summary of the goals of this demo project.	t	\N	demo-project	t	f	0	All tasks are on schedule. The people involved know their tasks. The system is completely set up.
2	Scrum project	This is a short summary of the goals of this demo Scrum project.	t	\N	your-scrum-project	t	f	0	All tasks are on schedule. The people involved know their tasks. The system is completely set up.
3	[dev] Empty		t	\N	dev-empty	t	f	\N	
4	[dev] Large		t	\N	dev-large	t	f	\N	
5	[dev] Large child		t	4	dev-large-child	t	f	\N	
7	[dev] Custom fields		t	\N	dev-custom-fields	t	f	\N	
\.


--
-- Data for Name: projects; Type: TABLE DATA; Schema: backup_preview_5; Owner: -
--

COPY backup_preview_5.projects (id, name, description, public, parent_id, created_at, updated_at, identifier, lft, rgt, active, templated, status_code, status_explanation) FROM stdin;
3	[dev] Empty	\N	t	\N	2023-07-26 09:22:10.796501+01	2023-07-26 09:22:10.977801+01	dev-empty	3	4	t	f	\N	\N
1	Demo project	This is a short summary of the goals of this demo project.	t	\N	2023-07-26 09:22:07.602264+01	2023-07-26 09:22:10.977801+01	demo-project	9	10	t	f	0	All tasks are on schedule. The people involved know their tasks. The system is completely set up.
2	Scrum project	This is a short summary of the goals of this demo Scrum project.	t	\N	2023-07-26 09:22:08.69182+01	2023-07-26 09:22:10.977801+01	your-scrum-project	11	12	t	f	0	All tasks are on schedule. The people involved know their tasks. The system is completely set up.
4	[dev] Large	\N	t	\N	2023-07-26 09:22:10.853021+01	2023-07-26 09:22:10.977801+01	dev-large	5	8	t	f	\N	\N
5	[dev] Large child	\N	t	4	2023-07-26 09:22:10.901254+01	2023-07-26 09:22:10.977801+01	dev-large-child	6	7	t	f	\N	\N
6	[dev] Custom fields	\N	t	\N	2023-07-26 09:22:10.9544+01	2023-07-26 09:22:10.977801+01	dev-custom-fields	1	2	t	f	\N	\N
\.


--
-- Data for Name: projects_storages; Type: TABLE DATA; Schema: backup_preview_5; Owner: -
--

COPY backup_preview_5.projects_storages (id, project_id, storage_id, creator_id, created_at, updated_at, project_folder_id, project_folder_mode) FROM stdin;
\.


--
-- Data for Name: projects_types; Type: TABLE DATA; Schema: backup_preview_5; Owner: -
--

COPY backup_preview_5.projects_types (project_id, type_id) FROM stdin;
1	1
1	2
1	3
2	1
2	2
2	3
2	5
2	6
2	7
3	1
3	9
3	2
3	3
3	4
3	5
3	6
3	7
3	8
4	1
4	9
4	2
4	3
4	4
4	5
4	6
4	7
4	8
5	1
5	9
5	2
5	3
5	4
5	5
5	6
5	7
5	8
6	1
6	9
6	2
6	3
6	4
6	5
6	6
6	7
6	8
\.


--
-- Data for Name: queries; Type: TABLE DATA; Schema: backup_preview_5; Owner: -
--

COPY backup_preview_5.queries (id, project_id, name, filters, user_id, public, column_names, sort_criteria, group_by, display_sums, timeline_visible, show_hierarchies, timeline_zoom_level, timeline_labels, highlighting_mode, highlighted_attributes, created_at, updated_at, display_representation, starred, include_subprojects, timestamps) FROM stdin;
1	1	Project plan	---\nstatus_id:\n  :operator: o\n  :values: []\n	4	t	---\n- :id\n- :type\n- :subject\n- :status\n- :start_date\n- :due_date\n- :duration\n- :assigned_to\n	---\n- - id\n  - asc\n	\N	f	t	t	5	\N	\N	\N	2023-07-26 09:22:07.793566+01	2023-07-26 09:22:07.793566+01	\N	t	t	\N
2	1	Milestones	---\ntype_id:\n  :operator: "="\n  :values:\n  - '2'\n	4	t	---\n- :id\n- :type\n- :subject\n- :status\n- :start_date\n- :due_date\n	---\n- - id\n  - asc\n	\N	f	t	f	5	\N	\N	\N	2023-07-26 09:22:07.811276+01	2023-07-26 09:22:07.811276+01	\N	f	t	\N
3	1	Tasks	---\nstatus_id:\n  :operator: o\n  :values: []\ntype_id:\n  :operator: "="\n  :values:\n  - '1'\n	4	t	---\n- :id\n- :subject\n- :priority\n- :status\n- :assigned_to\n	---\n- - id\n  - asc\n	\N	f	f	t	5	\N	\N	\N	2023-07-26 09:22:07.821196+01	2023-07-26 09:22:07.821196+01	\N	f	t	\N
4	1	Team planner	---\nassigned_to_id:\n  :operator: "="\n  :values:\n  - '4'\n	4	t	\N	\N	\N	f	f	f	5	\N	\N	\N	2023-07-26 09:22:07.831215+01	2023-07-26 09:22:07.831215+01	\N	f	t	\N
5	1	New	---\nstatus_id:\n  :operator: "="\n  :values:\n  - '1'\n	4	t	\N	---\n- - manual_sorting\n  - asc\n	\N	f	f	t	5	\N	\N	\N	2023-07-26 09:22:08.579789+01	2023-07-26 09:22:08.579789+01	\N	f	t	\N
6	1	In progress	---\nstatus_id:\n  :operator: "="\n  :values:\n  - '7'\n	4	t	\N	---\n- - manual_sorting\n  - asc\n	\N	f	f	t	5	\N	\N	\N	2023-07-26 09:22:08.582947+01	2023-07-26 09:22:08.582947+01	\N	f	t	\N
7	1	Closed	---\nstatus_id:\n  :operator: "="\n  :values:\n  - '12'\n	4	t	\N	---\n- - manual_sorting\n  - asc\n	\N	f	f	t	5	\N	\N	\N	2023-07-26 09:22:08.585869+01	2023-07-26 09:22:08.585869+01	\N	f	t	\N
8	1	Rejected	---\nstatus_id:\n  :operator: "="\n  :values:\n  - '14'\n	4	t	\N	---\n- - manual_sorting\n  - asc\n	\N	f	f	t	5	\N	\N	\N	2023-07-26 09:22:08.588586+01	2023-07-26 09:22:08.588586+01	\N	f	t	\N
9	1	Wish list	---\nmanual_sort:\n  :operator: ow\n  :values: []\n	4	t	\N	---\n- - manual_sorting\n  - asc\n	\N	f	f	f	5	\N	\N	\N	2023-07-26 09:22:08.623744+01	2023-07-26 09:22:08.623744+01	\N	f	t	\N
10	1	Short list	---\nmanual_sort:\n  :operator: ow\n  :values: []\n	4	t	\N	---\n- - manual_sorting\n  - asc\n	\N	f	f	f	5	\N	\N	\N	2023-07-26 09:22:08.63021+01	2023-07-26 09:22:08.63021+01	\N	f	t	\N
11	1	Priority list for today	---\nmanual_sort:\n  :operator: ow\n  :values: []\n	4	t	\N	---\n- - manual_sorting\n  - asc\n	\N	f	f	f	5	\N	\N	\N	2023-07-26 09:22:08.635796+01	2023-07-26 09:22:08.635796+01	\N	f	t	\N
12	1	Never	---\nmanual_sort:\n  :operator: ow\n  :values: []\n	4	t	\N	---\n- - manual_sorting\n  - asc\n	\N	f	f	f	5	\N	\N	\N	2023-07-26 09:22:08.639082+01	2023-07-26 09:22:08.639082+01	\N	f	t	\N
13	1	Organize open source conference	---\nstatus_id:\n  :operator: o\n  :values:\n  - ''\nparent:\n  :operator: "="\n  :values:\n  - '2'\n	4	t	\N	---\n- - manual_sorting\n  - asc\n	\N	f	f	t	5	\N	\N	\N	2023-07-26 09:22:08.655479+01	2023-07-26 09:22:08.655479+01	\N	f	t	\N
14	1	Follow-up tasks	---\nstatus_id:\n  :operator: o\n  :values:\n  - ''\nparent:\n  :operator: "="\n  :values:\n  - '10'\n	4	t	\N	---\n- - manual_sorting\n  - asc\n	\N	f	f	t	5	\N	\N	\N	2023-07-26 09:22:08.663668+01	2023-07-26 09:22:08.663668+01	\N	f	t	\N
15	2	Project plan	---\nstatus_id:\n  :operator: o\n  :values: []\ntype_id:\n  :operator: "="\n  :values:\n  - '2'\n  - '3'\n	4	t	\N	---\n- - id\n  - asc\n	\N	f	t	f	5	\N	\N	\N	2023-07-26 09:22:08.848727+01	2023-07-26 09:22:08.848727+01	\N	f	t	\N
16	2	Product backlog	---\nstatus_id:\n  :operator: o\n  :values: []\nversion_id:\n  :operator: "="\n  :values:\n  - '2'\n	4	t	---\n- :id\n- :type\n- :subject\n- :priority\n- :status\n- :assigned_to\n- :story_points\n	---\n- - status\n  - asc\n	status	f	f	f	5	\N	\N	\N	2023-07-26 09:22:08.859243+01	2023-07-26 09:22:08.859243+01	\N	f	t	\N
17	2	Sprint 1	---\nstatus_id:\n  :operator: o\n  :values: []\nversion_id:\n  :operator: "="\n  :values:\n  - '3'\n	4	t	---\n- :id\n- :type\n- :subject\n- :priority\n- :status\n- :assigned_to\n- :done_ratio\n- :story_points\n	\N	\N	f	f	t	5	\N	\N	\N	2023-07-26 09:22:08.869675+01	2023-07-26 09:22:08.869675+01	\N	f	t	\N
18	2	Tasks	---\nstatus_id:\n  :operator: o\n  :values: []\ntype_id:\n  :operator: "="\n  :values:\n  - '1'\n	4	t	\N	\N	\N	f	f	t	5	\N	\N	\N	2023-07-26 09:22:08.880265+01	2023-07-26 09:22:08.880265+01	\N	f	t	\N
19	2	New	---\nstatus_id:\n  :operator: "="\n  :values:\n  - '1'\n	4	t	\N	---\n- - manual_sorting\n  - asc\n	\N	f	f	t	5	\N	\N	\N	2023-07-26 09:22:09.860827+01	2023-07-26 09:22:09.860827+01	\N	f	t	\N
20	2	In progress	---\nstatus_id:\n  :operator: "="\n  :values:\n  - '7'\n	4	t	\N	---\n- - manual_sorting\n  - asc\n	\N	f	f	t	5	\N	\N	\N	2023-07-26 09:22:09.863597+01	2023-07-26 09:22:09.863597+01	\N	f	t	\N
21	2	Closed	---\nstatus_id:\n  :operator: "="\n  :values:\n  - '12'\n	4	t	\N	---\n- - manual_sorting\n  - asc\n	\N	f	f	t	5	\N	\N	\N	2023-07-26 09:22:09.866298+01	2023-07-26 09:22:09.866298+01	\N	f	t	\N
22	2	Rejected	---\nstatus_id:\n  :operator: "="\n  :values:\n  - '14'\n	4	t	\N	---\n- - manual_sorting\n  - asc\n	\N	f	f	t	5	\N	\N	\N	2023-07-26 09:22:09.869227+01	2023-07-26 09:22:09.869227+01	\N	f	t	\N
23	2	Wish list	---\nmanual_sort:\n  :operator: ow\n  :values: []\n	4	t	\N	---\n- - manual_sorting\n  - asc\n	\N	f	f	f	5	\N	\N	\N	2023-07-26 09:22:09.883657+01	2023-07-26 09:22:09.883657+01	\N	f	t	\N
24	2	Short list	---\nmanual_sort:\n  :operator: ow\n  :values: []\n	4	t	\N	---\n- - manual_sorting\n  - asc\n	\N	f	f	f	5	\N	\N	\N	2023-07-26 09:22:09.889069+01	2023-07-26 09:22:09.889069+01	\N	f	t	\N
25	2	Priority list for today	---\nmanual_sort:\n  :operator: ow\n  :values: []\n	4	t	\N	---\n- - manual_sorting\n  - asc\n	\N	f	f	f	5	\N	\N	\N	2023-07-26 09:22:09.894329+01	2023-07-26 09:22:09.894329+01	\N	f	t	\N
26	2	Never	---\nmanual_sort:\n  :operator: ow\n  :values: []\n	4	t	\N	---\n- - manual_sorting\n  - asc\n	\N	f	f	f	5	\N	\N	\N	2023-07-26 09:22:09.898514+01	2023-07-26 09:22:09.898514+01	\N	f	t	\N
\.


--
-- Data for Name: rates; Type: TABLE DATA; Schema: backup_preview_5; Owner: -
--

COPY backup_preview_5.rates (id, valid_from, rate, type, project_id, user_id, cost_type_id) FROM stdin;
\.


--
-- Data for Name: recaptcha_entries; Type: TABLE DATA; Schema: backup_preview_5; Owner: -
--

COPY backup_preview_5.recaptcha_entries (id, user_id, created_at, updated_at, version) FROM stdin;
\.


--
-- Data for Name: relations; Type: TABLE DATA; Schema: backup_preview_5; Owner: -
--

COPY backup_preview_5.relations (id, from_id, to_id, delay, description, relation_type) FROM stdin;
1	13	10	\N	\N	follows
2	9	2	\N	\N	follows
3	8	3	\N	\N	follows
4	7	3	\N	\N	follows
5	36	35	\N	\N	follows
6	34	33	\N	\N	follows
7	32	31	\N	\N	follows
\.


--
-- Data for Name: repositories; Type: TABLE DATA; Schema: backup_preview_5; Owner: -
--

COPY backup_preview_5.repositories (id, project_id, url, login, password, root_url, type, path_encoding, log_encoding, scm_type, required_storage_bytes, storage_updated_at) FROM stdin;
\.


--
-- Data for Name: role_permissions; Type: TABLE DATA; Schema: backup_preview_5; Owner: -
--

COPY backup_preview_5.role_permissions (id, permission, role_id, created_at, updated_at) FROM stdin;
1	view_work_packages	1	2023-07-26 09:22:05.475257+01	2023-07-26 09:22:05.475257+01
2	view_calendar	1	2023-07-26 09:22:05.476355+01	2023-07-26 09:22:05.476355+01
3	comment_news	1	2023-07-26 09:22:05.477625+01	2023-07-26 09:22:05.477625+01
4	browse_repository	1	2023-07-26 09:22:05.478321+01	2023-07-26 09:22:05.478321+01
5	view_changesets	1	2023-07-26 09:22:05.479166+01	2023-07-26 09:22:05.479166+01
6	view_wiki_pages	1	2023-07-26 09:22:05.47982+01	2023-07-26 09:22:05.47982+01
7	show_board_views	1	2023-07-26 09:22:05.480413+01	2023-07-26 09:22:05.480413+01
8	share_calendars	1	2023-07-26 09:22:05.480983+01	2023-07-26 09:22:05.480983+01
9	view_file_links	1	2023-07-26 09:22:05.481647+01	2023-07-26 09:22:05.481647+01
10	view_work_packages	2	2023-07-26 09:22:05.489599+01	2023-07-26 09:22:05.489599+01
11	browse_repository	2	2023-07-26 09:22:05.490363+01	2023-07-26 09:22:05.490363+01
12	view_changesets	2	2023-07-26 09:22:05.49134+01	2023-07-26 09:22:05.49134+01
13	view_wiki_pages	2	2023-07-26 09:22:05.492051+01	2023-07-26 09:22:05.492051+01
14	view_file_links	2	2023-07-26 09:22:05.492967+01	2023-07-26 09:22:05.492967+01
15	view_work_packages	3	2023-07-26 09:22:05.501831+01	2023-07-26 09:22:05.501831+01
16	export_work_packages	3	2023-07-26 09:22:05.502489+01	2023-07-26 09:22:05.502489+01
17	add_work_packages	3	2023-07-26 09:22:05.503186+01	2023-07-26 09:22:05.503186+01
18	move_work_packages	3	2023-07-26 09:22:05.503799+01	2023-07-26 09:22:05.503799+01
19	edit_work_packages	3	2023-07-26 09:22:05.504609+01	2023-07-26 09:22:05.504609+01
20	assign_versions	3	2023-07-26 09:22:05.505475+01	2023-07-26 09:22:05.505475+01
21	work_package_assigned	3	2023-07-26 09:22:05.506767+01	2023-07-26 09:22:05.506767+01
22	add_work_package_notes	3	2023-07-26 09:22:05.507451+01	2023-07-26 09:22:05.507451+01
23	edit_own_work_package_notes	3	2023-07-26 09:22:05.508675+01	2023-07-26 09:22:05.508675+01
24	manage_work_package_relations	3	2023-07-26 09:22:05.509577+01	2023-07-26 09:22:05.509577+01
25	manage_subtasks	3	2023-07-26 09:22:05.510337+01	2023-07-26 09:22:05.510337+01
26	manage_public_queries	3	2023-07-26 09:22:05.511254+01	2023-07-26 09:22:05.511254+01
27	save_queries	3	2023-07-26 09:22:05.511946+01	2023-07-26 09:22:05.511946+01
28	view_work_package_watchers	3	2023-07-26 09:22:05.512595+01	2023-07-26 09:22:05.512595+01
29	add_work_package_watchers	3	2023-07-26 09:22:05.513198+01	2023-07-26 09:22:05.513198+01
30	delete_work_package_watchers	3	2023-07-26 09:22:05.513784+01	2023-07-26 09:22:05.513784+01
31	view_calendar	3	2023-07-26 09:22:05.514441+01	2023-07-26 09:22:05.514441+01
32	comment_news	3	2023-07-26 09:22:05.515167+01	2023-07-26 09:22:05.515167+01
33	manage_news	3	2023-07-26 09:22:05.516238+01	2023-07-26 09:22:05.516238+01
34	log_time	3	2023-07-26 09:22:05.516875+01	2023-07-26 09:22:05.516875+01
35	view_time_entries	3	2023-07-26 09:22:05.517565+01	2023-07-26 09:22:05.517565+01
36	view_own_time_entries	3	2023-07-26 09:22:05.518413+01	2023-07-26 09:22:05.518413+01
37	edit_own_time_entries	3	2023-07-26 09:22:05.519155+01	2023-07-26 09:22:05.519155+01
38	view_timelines	3	2023-07-26 09:22:05.519872+01	2023-07-26 09:22:05.519872+01
39	edit_timelines	3	2023-07-26 09:22:05.520477+01	2023-07-26 09:22:05.520477+01
40	delete_timelines	3	2023-07-26 09:22:05.521135+01	2023-07-26 09:22:05.521135+01
41	view_reportings	3	2023-07-26 09:22:05.521928+01	2023-07-26 09:22:05.521928+01
42	edit_reportings	3	2023-07-26 09:22:05.522637+01	2023-07-26 09:22:05.522637+01
43	delete_reportings	3	2023-07-26 09:22:05.523356+01	2023-07-26 09:22:05.523356+01
44	manage_wiki	3	2023-07-26 09:22:05.523992+01	2023-07-26 09:22:05.523992+01
45	manage_wiki_menu	3	2023-07-26 09:22:05.524607+01	2023-07-26 09:22:05.524607+01
46	rename_wiki_pages	3	2023-07-26 09:22:05.525726+01	2023-07-26 09:22:05.525726+01
47	change_wiki_parent_page	3	2023-07-26 09:22:05.526562+01	2023-07-26 09:22:05.526562+01
48	delete_wiki_pages	3	2023-07-26 09:22:05.527518+01	2023-07-26 09:22:05.527518+01
49	view_wiki_pages	3	2023-07-26 09:22:05.528262+01	2023-07-26 09:22:05.528262+01
50	export_wiki_pages	3	2023-07-26 09:22:05.528914+01	2023-07-26 09:22:05.528914+01
51	view_wiki_edits	3	2023-07-26 09:22:05.529617+01	2023-07-26 09:22:05.529617+01
52	edit_wiki_pages	3	2023-07-26 09:22:05.53032+01	2023-07-26 09:22:05.53032+01
53	delete_wiki_pages_attachments	3	2023-07-26 09:22:05.531078+01	2023-07-26 09:22:05.531078+01
54	protect_wiki_pages	3	2023-07-26 09:22:05.531733+01	2023-07-26 09:22:05.531733+01
55	list_attachments	3	2023-07-26 09:22:05.532312+01	2023-07-26 09:22:05.532312+01
56	add_messages	3	2023-07-26 09:22:05.532989+01	2023-07-26 09:22:05.532989+01
57	edit_own_messages	3	2023-07-26 09:22:05.533645+01	2023-07-26 09:22:05.533645+01
58	delete_own_messages	3	2023-07-26 09:22:05.534327+01	2023-07-26 09:22:05.534327+01
59	browse_repository	3	2023-07-26 09:22:05.535166+01	2023-07-26 09:22:05.535166+01
60	view_changesets	3	2023-07-26 09:22:05.535958+01	2023-07-26 09:22:05.535958+01
61	commit_access	3	2023-07-26 09:22:05.536726+01	2023-07-26 09:22:05.536726+01
62	view_commit_author_statistics	3	2023-07-26 09:22:05.537617+01	2023-07-26 09:22:05.537617+01
63	view_members	3	2023-07-26 09:22:05.538378+01	2023-07-26 09:22:05.538378+01
64	view_team_planner	3	2023-07-26 09:22:05.53909+01	2023-07-26 09:22:05.53909+01
65	view_master_backlog	3	2023-07-26 09:22:05.539817+01	2023-07-26 09:22:05.539817+01
66	view_taskboards	3	2023-07-26 09:22:05.540573+01	2023-07-26 09:22:05.540573+01
67	show_board_views	3	2023-07-26 09:22:05.541233+01	2023-07-26 09:22:05.541233+01
68	manage_board_views	3	2023-07-26 09:22:05.541858+01	2023-07-26 09:22:05.541858+01
69	share_calendars	3	2023-07-26 09:22:05.542848+01	2023-07-26 09:22:05.542848+01
70	view_own_hourly_rate	3	2023-07-26 09:22:05.543793+01	2023-07-26 09:22:05.543793+01
71	view_cost_rates	3	2023-07-26 09:22:05.544775+01	2023-07-26 09:22:05.544775+01
72	log_own_costs	3	2023-07-26 09:22:05.545485+01	2023-07-26 09:22:05.545485+01
73	edit_own_cost_entries	3	2023-07-26 09:22:05.546625+01	2023-07-26 09:22:05.546625+01
74	view_budgets	3	2023-07-26 09:22:05.547827+01	2023-07-26 09:22:05.547827+01
75	view_own_cost_entries	3	2023-07-26 09:22:05.548684+01	2023-07-26 09:22:05.548684+01
76	view_documents	3	2023-07-26 09:22:05.549447+01	2023-07-26 09:22:05.549447+01
77	manage_documents	3	2023-07-26 09:22:05.550309+01	2023-07-26 09:22:05.550309+01
78	create_meetings	3	2023-07-26 09:22:05.551021+01	2023-07-26 09:22:05.551021+01
79	edit_meetings	3	2023-07-26 09:22:05.551648+01	2023-07-26 09:22:05.551648+01
80	delete_meetings	3	2023-07-26 09:22:05.55235+01	2023-07-26 09:22:05.55235+01
81	view_meetings	3	2023-07-26 09:22:05.553097+01	2023-07-26 09:22:05.553097+01
82	create_meeting_agendas	3	2023-07-26 09:22:05.553789+01	2023-07-26 09:22:05.553789+01
83	close_meeting_agendas	3	2023-07-26 09:22:05.555097+01	2023-07-26 09:22:05.555097+01
84	send_meeting_agendas_notification	3	2023-07-26 09:22:05.555711+01	2023-07-26 09:22:05.555711+01
85	send_meeting_agendas_icalendar	3	2023-07-26 09:22:05.556466+01	2023-07-26 09:22:05.556466+01
86	create_meeting_minutes	3	2023-07-26 09:22:05.557126+01	2023-07-26 09:22:05.557126+01
87	send_meeting_minutes_notification	3	2023-07-26 09:22:05.559451+01	2023-07-26 09:22:05.559451+01
88	view_file_links	3	2023-07-26 09:22:05.56015+01	2023-07-26 09:22:05.56015+01
89	manage_file_links	3	2023-07-26 09:22:05.560905+01	2023-07-26 09:22:05.560905+01
90	view_work_packages	4	2023-07-26 09:22:05.566258+01	2023-07-26 09:22:05.566258+01
91	add_work_package_notes	4	2023-07-26 09:22:05.566911+01	2023-07-26 09:22:05.566911+01
92	edit_own_work_package_notes	4	2023-07-26 09:22:05.567619+01	2023-07-26 09:22:05.567619+01
93	save_queries	4	2023-07-26 09:22:05.568281+01	2023-07-26 09:22:05.568281+01
94	view_calendar	4	2023-07-26 09:22:05.568876+01	2023-07-26 09:22:05.568876+01
95	comment_news	4	2023-07-26 09:22:05.569495+01	2023-07-26 09:22:05.569495+01
96	view_timelines	4	2023-07-26 09:22:05.570205+01	2023-07-26 09:22:05.570205+01
97	view_reportings	4	2023-07-26 09:22:05.570853+01	2023-07-26 09:22:05.570853+01
98	view_wiki_pages	4	2023-07-26 09:22:05.571485+01	2023-07-26 09:22:05.571485+01
99	export_wiki_pages	4	2023-07-26 09:22:05.572122+01	2023-07-26 09:22:05.572122+01
100	list_attachments	4	2023-07-26 09:22:05.572771+01	2023-07-26 09:22:05.572771+01
101	add_messages	4	2023-07-26 09:22:05.573366+01	2023-07-26 09:22:05.573366+01
102	edit_own_messages	4	2023-07-26 09:22:05.580445+01	2023-07-26 09:22:05.580445+01
103	delete_own_messages	4	2023-07-26 09:22:05.581403+01	2023-07-26 09:22:05.581403+01
104	browse_repository	4	2023-07-26 09:22:05.582199+01	2023-07-26 09:22:05.582199+01
105	view_changesets	4	2023-07-26 09:22:05.582967+01	2023-07-26 09:22:05.582967+01
106	view_team_planner	4	2023-07-26 09:22:05.583982+01	2023-07-26 09:22:05.583982+01
107	view_master_backlog	4	2023-07-26 09:22:05.584709+01	2023-07-26 09:22:05.584709+01
108	view_taskboards	4	2023-07-26 09:22:05.585443+01	2023-07-26 09:22:05.585443+01
109	show_board_views	4	2023-07-26 09:22:05.586125+01	2023-07-26 09:22:05.586125+01
110	share_calendars	4	2023-07-26 09:22:05.58704+01	2023-07-26 09:22:05.58704+01
111	view_documents	4	2023-07-26 09:22:05.58769+01	2023-07-26 09:22:05.58769+01
112	view_meetings	4	2023-07-26 09:22:05.588353+01	2023-07-26 09:22:05.588353+01
113	view_file_links	4	2023-07-26 09:22:05.589064+01	2023-07-26 09:22:05.589064+01
114	archive_project	5	2023-07-26 09:22:05.601778+01	2023-07-26 09:22:05.601778+01
115	edit_project	5	2023-07-26 09:22:05.602419+01	2023-07-26 09:22:05.602419+01
116	select_project_modules	5	2023-07-26 09:22:05.603217+01	2023-07-26 09:22:05.603217+01
117	manage_members	5	2023-07-26 09:22:05.604108+01	2023-07-26 09:22:05.604108+01
118	view_members	5	2023-07-26 09:22:05.604813+01	2023-07-26 09:22:05.604813+01
119	manage_versions	5	2023-07-26 09:22:05.60552+01	2023-07-26 09:22:05.60552+01
120	manage_types	5	2023-07-26 09:22:05.606383+01	2023-07-26 09:22:05.606383+01
121	select_custom_fields	5	2023-07-26 09:22:05.607106+01	2023-07-26 09:22:05.607106+01
122	add_subprojects	5	2023-07-26 09:22:05.607739+01	2023-07-26 09:22:05.607739+01
123	copy_projects	5	2023-07-26 09:22:05.608375+01	2023-07-26 09:22:05.608375+01
124	view_work_packages	5	2023-07-26 09:22:05.609461+01	2023-07-26 09:22:05.609461+01
125	add_work_packages	5	2023-07-26 09:22:05.610343+01	2023-07-26 09:22:05.610343+01
126	edit_work_packages	5	2023-07-26 09:22:05.611013+01	2023-07-26 09:22:05.611013+01
127	move_work_packages	5	2023-07-26 09:22:05.611823+01	2023-07-26 09:22:05.611823+01
128	add_work_package_notes	5	2023-07-26 09:22:05.612785+01	2023-07-26 09:22:05.612785+01
129	edit_work_package_notes	5	2023-07-26 09:22:05.613595+01	2023-07-26 09:22:05.613595+01
130	edit_own_work_package_notes	5	2023-07-26 09:22:05.614412+01	2023-07-26 09:22:05.614412+01
131	manage_categories	5	2023-07-26 09:22:05.615315+01	2023-07-26 09:22:05.615315+01
132	export_work_packages	5	2023-07-26 09:22:05.616309+01	2023-07-26 09:22:05.616309+01
133	delete_work_packages	5	2023-07-26 09:22:05.617187+01	2023-07-26 09:22:05.617187+01
134	manage_work_package_relations	5	2023-07-26 09:22:05.618071+01	2023-07-26 09:22:05.618071+01
135	manage_subtasks	5	2023-07-26 09:22:05.619122+01	2023-07-26 09:22:05.619122+01
136	manage_public_queries	5	2023-07-26 09:22:05.620083+01	2023-07-26 09:22:05.620083+01
137	save_queries	5	2023-07-26 09:22:05.620997+01	2023-07-26 09:22:05.620997+01
138	view_work_package_watchers	5	2023-07-26 09:22:05.621815+01	2023-07-26 09:22:05.621815+01
139	add_work_package_watchers	5	2023-07-26 09:22:05.622608+01	2023-07-26 09:22:05.622608+01
140	delete_work_package_watchers	5	2023-07-26 09:22:05.62358+01	2023-07-26 09:22:05.62358+01
141	assign_versions	5	2023-07-26 09:22:05.624574+01	2023-07-26 09:22:05.624574+01
142	work_package_assigned	5	2023-07-26 09:22:05.62535+01	2023-07-26 09:22:05.62535+01
143	manage_news	5	2023-07-26 09:22:05.626408+01	2023-07-26 09:22:05.626408+01
144	comment_news	5	2023-07-26 09:22:05.627889+01	2023-07-26 09:22:05.627889+01
145	view_wiki_pages	5	2023-07-26 09:22:05.630399+01	2023-07-26 09:22:05.630399+01
146	list_attachments	5	2023-07-26 09:22:05.631668+01	2023-07-26 09:22:05.631668+01
147	manage_wiki	5	2023-07-26 09:22:05.632663+01	2023-07-26 09:22:05.632663+01
148	manage_wiki_menu	5	2023-07-26 09:22:05.633536+01	2023-07-26 09:22:05.633536+01
149	rename_wiki_pages	5	2023-07-26 09:22:05.634443+01	2023-07-26 09:22:05.634443+01
150	change_wiki_parent_page	5	2023-07-26 09:22:05.63527+01	2023-07-26 09:22:05.63527+01
151	delete_wiki_pages	5	2023-07-26 09:22:05.636085+01	2023-07-26 09:22:05.636085+01
152	export_wiki_pages	5	2023-07-26 09:22:05.636958+01	2023-07-26 09:22:05.636958+01
153	view_wiki_edits	5	2023-07-26 09:22:05.637954+01	2023-07-26 09:22:05.637954+01
154	edit_wiki_pages	5	2023-07-26 09:22:05.638798+01	2023-07-26 09:22:05.638798+01
155	delete_wiki_pages_attachments	5	2023-07-26 09:22:05.639792+01	2023-07-26 09:22:05.639792+01
156	protect_wiki_pages	5	2023-07-26 09:22:05.64086+01	2023-07-26 09:22:05.64086+01
157	browse_repository	5	2023-07-26 09:22:05.641563+01	2023-07-26 09:22:05.641563+01
158	commit_access	5	2023-07-26 09:22:05.642314+01	2023-07-26 09:22:05.642314+01
159	manage_repository	5	2023-07-26 09:22:05.643162+01	2023-07-26 09:22:05.643162+01
160	view_changesets	5	2023-07-26 09:22:05.644035+01	2023-07-26 09:22:05.644035+01
161	view_commit_author_statistics	5	2023-07-26 09:22:05.644903+01	2023-07-26 09:22:05.644903+01
162	manage_forums	5	2023-07-26 09:22:05.645818+01	2023-07-26 09:22:05.645818+01
163	add_messages	5	2023-07-26 09:22:05.646618+01	2023-07-26 09:22:05.646618+01
164	edit_messages	5	2023-07-26 09:22:05.647418+01	2023-07-26 09:22:05.647418+01
165	edit_own_messages	5	2023-07-26 09:22:05.648116+01	2023-07-26 09:22:05.648116+01
166	delete_messages	5	2023-07-26 09:22:05.648776+01	2023-07-26 09:22:05.648776+01
167	delete_own_messages	5	2023-07-26 09:22:05.649526+01	2023-07-26 09:22:05.649526+01
168	view_documents	5	2023-07-26 09:22:05.650205+01	2023-07-26 09:22:05.650205+01
169	manage_documents	5	2023-07-26 09:22:05.650845+01	2023-07-26 09:22:05.650845+01
170	view_time_entries	5	2023-07-26 09:22:05.651497+01	2023-07-26 09:22:05.651497+01
171	view_own_time_entries	5	2023-07-26 09:22:05.652282+01	2023-07-26 09:22:05.652282+01
172	log_own_time	5	2023-07-26 09:22:05.653015+01	2023-07-26 09:22:05.653015+01
173	log_time	5	2023-07-26 09:22:05.65373+01	2023-07-26 09:22:05.65373+01
174	edit_own_time_entries	5	2023-07-26 09:22:05.654744+01	2023-07-26 09:22:05.654744+01
175	edit_time_entries	5	2023-07-26 09:22:05.655712+01	2023-07-26 09:22:05.655712+01
176	manage_project_activities	5	2023-07-26 09:22:05.656575+01	2023-07-26 09:22:05.656575+01
177	view_own_hourly_rate	5	2023-07-26 09:22:05.657252+01	2023-07-26 09:22:05.657252+01
178	view_hourly_rates	5	2023-07-26 09:22:05.657927+01	2023-07-26 09:22:05.657927+01
179	edit_own_hourly_rate	5	2023-07-26 09:22:05.658781+01	2023-07-26 09:22:05.658781+01
180	edit_hourly_rates	5	2023-07-26 09:22:05.661561+01	2023-07-26 09:22:05.661561+01
181	view_cost_rates	5	2023-07-26 09:22:05.662482+01	2023-07-26 09:22:05.662482+01
182	log_own_costs	5	2023-07-26 09:22:05.663452+01	2023-07-26 09:22:05.663452+01
183	log_costs	5	2023-07-26 09:22:05.664283+01	2023-07-26 09:22:05.664283+01
184	edit_own_cost_entries	5	2023-07-26 09:22:05.665168+01	2023-07-26 09:22:05.665168+01
185	edit_cost_entries	5	2023-07-26 09:22:05.665981+01	2023-07-26 09:22:05.665981+01
186	view_cost_entries	5	2023-07-26 09:22:05.666689+01	2023-07-26 09:22:05.666689+01
187	view_own_cost_entries	5	2023-07-26 09:22:05.667467+01	2023-07-26 09:22:05.667467+01
188	view_meetings	5	2023-07-26 09:22:05.668178+01	2023-07-26 09:22:05.668178+01
189	create_meetings	5	2023-07-26 09:22:05.669113+01	2023-07-26 09:22:05.669113+01
190	edit_meetings	5	2023-07-26 09:22:05.669944+01	2023-07-26 09:22:05.669944+01
191	delete_meetings	5	2023-07-26 09:22:05.670682+01	2023-07-26 09:22:05.670682+01
192	meetings_send_invite	5	2023-07-26 09:22:05.671331+01	2023-07-26 09:22:05.671331+01
193	create_meeting_agendas	5	2023-07-26 09:22:05.672083+01	2023-07-26 09:22:05.672083+01
194	close_meeting_agendas	5	2023-07-26 09:22:05.672766+01	2023-07-26 09:22:05.672766+01
195	send_meeting_agendas_notification	5	2023-07-26 09:22:05.673391+01	2023-07-26 09:22:05.673391+01
196	send_meeting_agendas_icalendar	5	2023-07-26 09:22:05.67398+01	2023-07-26 09:22:05.67398+01
197	create_meeting_minutes	5	2023-07-26 09:22:05.674588+01	2023-07-26 09:22:05.674588+01
198	send_meeting_minutes_notification	5	2023-07-26 09:22:05.675335+01	2023-07-26 09:22:05.675335+01
199	view_master_backlog	5	2023-07-26 09:22:05.676074+01	2023-07-26 09:22:05.676074+01
200	view_taskboards	5	2023-07-26 09:22:05.676943+01	2023-07-26 09:22:05.676943+01
201	select_done_statuses	5	2023-07-26 09:22:05.677764+01	2023-07-26 09:22:05.677764+01
202	update_sprints	5	2023-07-26 09:22:05.679089+01	2023-07-26 09:22:05.679089+01
203	show_github_content	5	2023-07-26 09:22:05.679949+01	2023-07-26 09:22:05.679949+01
204	show_board_views	5	2023-07-26 09:22:05.680737+01	2023-07-26 09:22:05.680737+01
205	manage_board_views	5	2023-07-26 09:22:05.681441+01	2023-07-26 09:22:05.681441+01
206	manage_overview	5	2023-07-26 09:22:05.682089+01	2023-07-26 09:22:05.682089+01
207	view_budgets	5	2023-07-26 09:22:05.682809+01	2023-07-26 09:22:05.682809+01
208	edit_budgets	5	2023-07-26 09:22:05.683612+01	2023-07-26 09:22:05.683612+01
209	view_team_planner	5	2023-07-26 09:22:05.684272+01	2023-07-26 09:22:05.684272+01
210	manage_team_planner	5	2023-07-26 09:22:05.686913+01	2023-07-26 09:22:05.686913+01
211	view_calendar	5	2023-07-26 09:22:05.687723+01	2023-07-26 09:22:05.687723+01
212	manage_calendars	5	2023-07-26 09:22:05.688357+01	2023-07-26 09:22:05.688357+01
213	share_calendars	5	2023-07-26 09:22:05.688996+01	2023-07-26 09:22:05.688996+01
214	view_file_links	5	2023-07-26 09:22:05.689614+01	2023-07-26 09:22:05.689614+01
215	manage_file_links	5	2023-07-26 09:22:05.69026+01	2023-07-26 09:22:05.69026+01
216	manage_storages_in_project	5	2023-07-26 09:22:05.690958+01	2023-07-26 09:22:05.690958+01
217	read_files	5	2023-07-26 09:22:05.691595+01	2023-07-26 09:22:05.691595+01
218	write_files	5	2023-07-26 09:22:05.69234+01	2023-07-26 09:22:05.69234+01
219	create_files	5	2023-07-26 09:22:05.693059+01	2023-07-26 09:22:05.693059+01
220	delete_files	5	2023-07-26 09:22:05.697166+01	2023-07-26 09:22:05.697166+01
221	share_files	5	2023-07-26 09:22:05.698198+01	2023-07-26 09:22:05.698198+01
222	view_ifc_models	5	2023-07-26 09:22:05.698968+01	2023-07-26 09:22:05.698968+01
223	manage_ifc_models	5	2023-07-26 09:22:05.699783+01	2023-07-26 09:22:05.699783+01
224	view_linked_issues	5	2023-07-26 09:22:05.700943+01	2023-07-26 09:22:05.700943+01
225	manage_bcf	5	2023-07-26 09:22:05.701666+01	2023-07-26 09:22:05.701666+01
226	delete_bcf	5	2023-07-26 09:22:05.702335+01	2023-07-26 09:22:05.702335+01
227	save_bcf_queries	5	2023-07-26 09:22:05.702967+01	2023-07-26 09:22:05.702967+01
228	manage_public_bcf_queries	5	2023-07-26 09:22:05.703961+01	2023-07-26 09:22:05.703961+01
229	add_project	6	2023-07-26 09:22:05.710255+01	2023-07-26 09:22:05.710255+01
230	manage_user	6	2023-07-26 09:22:05.711192+01	2023-07-26 09:22:05.711192+01
231	manage_placeholder_user	6	2023-07-26 09:22:05.711993+01	2023-07-26 09:22:05.711993+01
232	manage_overview	5	2023-07-26 09:22:09.988065+01	2023-07-26 09:22:09.988065+01
\.


--
-- Data for Name: roles; Type: TABLE DATA; Schema: backup_preview_5; Owner: -
--

COPY backup_preview_5.roles (id, name, "position", builtin, type, created_at, updated_at) FROM stdin;
1	Non member	1	1	Role	2023-07-26 09:22:05.469971+01	2023-07-26 09:22:05.469971+01
2	Anonymous	2	2	Role	2023-07-26 09:22:05.483612+01	2023-07-26 09:22:05.483612+01
3	Member	3	0	Role	2023-07-26 09:22:05.499276+01	2023-07-26 09:22:05.499276+01
4	Reader	4	0	Role	2023-07-26 09:22:05.563939+01	2023-07-26 09:22:05.563939+01
5	Project admin	5	0	Role	2023-07-26 09:22:05.599166+01	2023-07-26 09:22:05.599166+01
6	Staff and projects manager	6	0	GlobalRole	2023-07-26 09:22:05.707411+01	2023-07-26 09:22:05.707411+01
\.


--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: backup_preview_5; Owner: -
--

COPY backup_preview_5.schema_migrations (version) FROM stdin;
10000000000000
20100528100562
20120214103300
20130214130336
20140113132617
20140129103924
20140207134248
20160331190036
20170703075208
20170705134348
20170818063404
20170829095701
20171023190036
20171106074835
20171129145631
20171218205557
20171219145752
20180105130053
20180108132929
20180116065518
20180117065255
20180122135443
20180123092002
20180125082205
20180213155320
20180221151038
20180305130811
20180323130704
20180323133404
20180323135408
20180323140208
20180323151208
20180419061910
20180504144320
20180510184732
20180518130559
20180524084654
20180524113516
20180706150714
20180717102331
20180801072018
20180830120550
20180903110212
20180924141838
20181101132712
20181112125034
20181118193730
20181121174153
20181214103300
20190124081710
20190129083842
20190205090102
20190207155607
20190220080647
20190227163226
20190301122554
20190312083304
20190411122815
20190502102512
20190507132517
20190509071101
20190527095959
20190603060951
20190618115620
20190619143049
20190710132957
20190716071941
20190719123448
20190722082648
20190724093332
20190823090211
20190826083604
20190905130336
20190920102446
20190923111902
20190923123858
20191029155327
20191106132533
20191112111040
20191114090353
20191115141154
20191119144123
20191121140202
20191216135213
20200114091135
20200115090742
20200123163818
20200206101135
20200217061622
20200217090016
20200217155632
20200220171133
20200302100431
20200310092237
20200325101528
20200326102408
20200327074416
20200403105252
20200415131633
20200420122713
20200420133116
20200422105623
20200427082928
20200427121606
20200428105404
20200504085933
20200522131255
20200522140244
20200527130633
20200610083854
20200610124259
20200625133727
20200708065116
20200803081038
20200807083950
20200807083952
20200810152654
20200820140526
20200903064009
20200907090753
20200914092212
20200924085508
20200925084550
20201001184404
20201005120137
20201005184411
20201105154216
20201125121949
20210126112238
20210127134438
20210214205545
20210219092709
20210221230446
20210310101840
20210331085058
20210407110000
20210427065703
20210510193438
20210512121322
20210519141244
20210521080035
20210615150558
20210616145324
20210616191052
20210618125430
20210618132206
20210628185054
20210701073944
20210701082511
20210713081724
20210726065912
20210726070813
20210802114054
20210825183540
20210902201126
20210910092414
20210914065555
20210915154656
20210917190141
20210922123908
20210928133538
20211005080304
20211005135637
20211011204301
20211022143726
20211026061420
20211101152840
20211102161932
20211103120946
20211104151329
20211105142202
20211117195121
20211118203332
20211130161501
20211209092519
20220106145037
20220113144323
20220113144759
20220121090847
20220202140507
20220223095355
20220302123642
20220319211253
20220323083000
20220408080838
20220414085531
20220426132637
20220428071221
20220503093844
20220511124930
20220517113828
20220518154147
20220525154549
20220608213712
20220614132200
20220615213015
20220620132922
20220622151721
20220629061540
20220629073727
20220707192304
20220712132505
20220712165928
20220714145356
20220804112533
20220811061024
20220815072420
20220817154403
20220818074150
20220818074159
20220830074821
20220830092057
20220831073113
20220831081937
20220909153412
20220911182835
20220918165443
20220922200908
20220926124435
20220929114423
20220930133418
20221017073431
20221017184204
20221018160449
20221026132134
20221027151959
20221028070534
20221029194419
20221115082403
20221122072857
20221129074635
20221130150352
20221201140825
20221202130039
20221213092910
20230105073117
20230105134940
20230123092649
20230130134630
20230306083203
20230309104056
20230314093106
20230314165213
20230315103437
20230315183431
20230315184533
20230316080525
20230321194150
20230322135932
20230328154645
20230420063148
20230420071113
20230421154500
20230502094813
20230508150835
20230512153303
20230517075214
20230531093004
20230601082746
20230607101213
20230620160602
\.


--
-- Data for Name: sessions; Type: TABLE DATA; Schema: backup_preview_5; Owner: -
--

COPY backup_preview_5.sessions (id, session_id, data, updated_at, user_id) FROM stdin;
2	2::25bb4031d5738687e6ef44c1c8e11b7f1d7ad7b5ce370837e3b8db844e308b0e	BAh7CkkiDHVzZXJfaWQGOgZFRmkJSSIPdXBkYXRlZF9hdAY7AEZJdToJVGlt\nZQ1K2x6AX+bb4Ao6DW5hbm9fbnVtaQIZAzoNbmFub19kZW5pBjoNc3VibWlj\ncm8iB3kwOgtvZmZzZXRpAhAOOgl6b25lSSIIQlNUBjsARkkiEF9jc3JmX3Rv\na2VuBjsARkkiMW5RK0RYU2VEQzR2bW5QNkp0RWRWSklSTmpxcFA2Q0NjTEpH\nZkx4SzFFV289BjsARkkiF2JhY2t1cHNfaW5kZXhfc29ydAY7AEZJIhRjcmVh\ndGVkX2F0OmRlc2MGOwBGSSIMcHJldmlldwY7AEZ7C0kiB2lkBjsAVGkHSSIM\nY29tbWVudAY7AFRJIhJpbml0aWFsIHN0YXRlBjsAVEkiD3NpemVfaW5fbWIG\nOwBUaQBJIg9jcmVhdG9yX2lkBjsAVGkJSSIPY3JlYXRlZF9hdAY7AFRVOiBB\nY3RpdmVTdXBwb3J0OjpUaW1lV2l0aFpvbmVbCEl1OwYNStsewK3hSpkGOwtJ\nIghVVEMGOwBGSSIIVVRDBjsAVEl1OwYNStsewK3hSpkGOwtAGUkiD3VwZGF0\nZWRfYXQGOwBUVTsMWwhJdTsGDUrbHsDAdXaZBjsLQBlAG0l1OwYNStsewMB1\ndpkGOwtAGQ==\n	2023-07-26 14:45:42.832343+01	4
3	2::2b9b9d0de33080cf4dcf589968b149a4955946492afa10747f4afb92f357eeed	BAh7AA==\n	2023-07-27 12:45:34.565243+01	\N
4	2::91f3bd17487fd783fc5536fd496c2ad239c9e09855de65c99ac0f8e1b2554eac	BAh7AA==\n	2023-07-27 12:48:00.480812+01	\N
5	2::44b059bcd38b52a55a0364654b9a087dde6c2257ca58bc88e873821573121c34	BAh7AA==\n	2023-07-27 12:48:16.105177+01	\N
11	2::708f555e1b7349ab13c5f755e8990068e2d9a32e62e60404269c6235442be045	BAh7CUkiDHVzZXJfaWQGOgZFRmkJSSIPdXBkYXRlZF9hdAY7AEZJdToJVGlt\nZQ1s2x6AYBFtmQo6DW5hbm9fbnVtaQJ2AjoNbmFub19kZW5pBjoNc3VibWlj\ncm8iBmM6C29mZnNldGkCEA46CXpvbmVJIghCU1QGOwBGSSIXYmFja3Vwc19p\nbmRleF9zb3J0BjsARkkiFGNyZWF0ZWRfYXQ6ZGVzYwY7AEZJIhBfY3NyZl90\nb2tlbgY7AEZJIjFSOUJlb0xGWDd4WWpRQW4xWmdiSnloQlhtaXM1VlVNZVpY\nV0JJRlZFSHBRPQY7AEY=\n	2023-07-27 13:38:30.049774+01	4
30	2::31324f1acf415861c30d02a98c0b3db1a6b83cfe92316e6427375ad06e1a74dd	BAh7CUkiDHVzZXJfaWQGOgZFRmkJSSIPdXBkYXRlZF9hdAY7AEZJdToJVGlt\nZQ1t2x6ANSZOjgo6DW5hbm9fbnVtaQHeOg1uYW5vX2RlbmkGOg1zdWJtaWNy\nbyIHIiA6C29mZnNldGkCEA46CXpvbmVJIghCU1QGOwBGSSIXYmFja3Vwc19p\nbmRleF9zb3J0BjsARkkiFGNyZWF0ZWRfYXQ6ZGVzYwY7AEZJIhBfY3NyZl90\nb2tlbgY7AEZJIjE0MmJTOTRLK3FsWGZJLzRCUzAvbEJLanRreGszRjA0WmZT\naCtDTTg4bENJPQY7AEY=\n	2023-07-27 14:35:36.933145+01	4
7	2::1e81447c01a64c6ff44ab460b9ceb7a6a39dc1b93897eb6aa2300d95a5a7540e	BAh7CUkiDHVzZXJfaWQGOgZFRmkJSSIPdXBkYXRlZF9hdAY7AEZJdToJVGlt\nZQ1s2x6Ahno1dQo6DW5hbm9fbnVtaQL4AToNbmFub19kZW5pBjoNc3VibWlj\ncm8iB1BAOgtvZmZzZXRpAhAOOgl6b25lSSIIQlNUBjsARkkiEF9jc3JmX3Rv\na2VuBjsARkkiMTV5bGtGeW1VQVNEcGpmS1hYWkJOUzVicHlMUkNBanF1dStu\nVW9TZU1jRzQ9BjsARkkiF2JhY2t1cHNfaW5kZXhfc29ydAY7AEZJIhRjcmVh\ndGVkX2F0OmRlc2MGOwBG\n	2023-07-27 13:29:19.744639+01	4
24	2::6ba92ae25ba1d51339f95c3e566517f4d0c2cb64fec40079f45a874a8bac105e	BAh7CUkiDHVzZXJfaWQGOgZFRmkJSSIPdXBkYXRlZF9hdAY7AEZJdToJVGlt\nZQ1t2x6AViCSdQo6DW5hbm9fbnVtaWM6DW5hbm9fZGVuaQY6DXN1Ym1pY3Jv\nIgcJQDoLb2Zmc2V0aQIQDjoJem9uZUkiCEJTVAY7AEZJIhdiYWNrdXBzX2lu\nZGV4X3NvcnQGOwBGSSIUY3JlYXRlZF9hdDpkZXNjBjsARkkiEF9jc3JmX3Rv\na2VuBjsARkkiMS9UY2xyMFplcWl5MmdpMHBuTDJoM2VweFVuQU4waDJ4ZFhR\nRVBTNTJjbmc9BjsARg==\n	2023-07-27 14:29:25.146854+01	4
27	2::5159658ee481e94243488057b8018f6b62d31d321b65c9ae4a6d0a34c4da18d1	BAh7CUkiDHVzZXJfaWQGOgZFRmkJSSIPdXBkYXRlZF9hdAY7AEZJdToJVGlt\nZQ1t2x6AOFKbego6DW5hbm9fbnVtaQGYOg1uYW5vX2RlbmkGOg1zdWJtaWNy\nbyIHFSA6C29mZnNldGkCEA46CXpvbmVJIghCU1QGOwBGSSIXYmFja3Vwc19p\nbmRleF9zb3J0BjsARkkiFGNyZWF0ZWRfYXQ6ZGVzYwY7AEZJIhBfY3NyZl90\nb2tlbgY7AEZJIjEvWXoreXBVVVVOWFBwWVFnYTk0VWNtelVONmltRFA2cFJL\nNDZ6bjByT0VRPQY7AEY=\n	2023-07-27 14:30:41.749567+01	4
14	2::69b555f958c9b54837de4782bdcb92ef2de6ce8ffceb8b497f10107728aef10c	BAh7CUkiDHVzZXJfaWQGOgZFRmkJSSIPdXBkYXRlZF9hdAY7AEZJdToJVGlt\nZQ1t2x6AWVaFRwo6DW5hbm9fbnVtaQKVAjoNbmFub19kZW5pBjoNc3VibWlj\ncm8iB2YQOgtvZmZzZXRpAhAOOgl6b25lSSIIQlNUBjsARkkiF2JhY2t1cHNf\naW5kZXhfc29ydAY7AEZJIhRjcmVhdGVkX2F0OmRlc2MGOwBGSSIQX2NzcmZf\ndG9rZW4GOwBGSSIxa3ZTT1RzdGcwYk1VdCtGVUIxeW9ub3RhMnZzYS8yMStB\nWTFiRmR2d2FyRT0GOwBG\n	2023-07-27 14:18:03.081594+01	4
31	2::7c9fda8f866c144c983fccec6f96f8b34b3311d4dc6ff41f5f7b8c721e47bdca	BAh7CkkiDHVzZXJfaWQGOgZFRmkJSSIPdXBkYXRlZF9hdAY7AEZJdToJVGlt\nZQ2J2x6Al9ksLQo6DW5hbm9fbnVtaQHXOg1uYW5vX2RlbmkGOg1zdWJtaWNy\nbyIHIVA6C29mZnNldGkCEA46CXpvbmVJIghCU1QGOwBGSSIXYmFja3Vwc19p\nbmRleF9zb3J0BjsARkkiFGNyZWF0ZWRfYXQ6ZGVzYwY7AEZJIhBfY3NyZl90\nb2tlbgY7AEZJIjF0WHVvZWR5SXJsR1FxQ3BUV1F2RmtXeGZlamVyVU9Pa0ZB\nVk9UTGsvSHlVPQY7AEZJIhV1c2Vyc19pbmRleF9zb3J0BjsARkkiAAY7AEY=\n	2023-07-28 10:40:34.02744+01	4
28	2::2cff5ffabdb4442e3c6fe06354dd6ec0a6e92340b4fc5231157c5ae5efa07256	BAh7CUkiDHVzZXJfaWQGOgZFRmkJSSIPdXBkYXRlZF9hdAY7AEZJdToJVGlt\nZQ1t2x6AiDo0ewo6DW5hbm9fbnVtaQLSAjoNbmFub19kZW5pBjoNc3VibWlj\ncm8iB3IgOgtvZmZzZXRpAhAOOgl6b25lSSIIQlNUBjsARkkiF2JhY2t1cHNf\naW5kZXhfc29ydAY7AEZJIhRjcmVhdGVkX2F0OmRlc2MGOwBGSSIQX2NzcmZf\ndG9rZW4GOwBGSSIxVEkxYzYrd1FRVmhMc0l4S0wyOXgzb21FcFRtUTJPZith\nQlJJUGtSU1pJND0GOwBG\n	2023-07-27 14:30:51.283941+01	4
32	2::1769e98b4e47279a517dd7ac1317485f40faccdcda17a98a3ee3ff2b9e333a25	BAh7AA==\n	2023-07-28 10:42:32.529213+01	\N
33	2::861703ec132def137fb82b2f65dd995b4badd0d2c7659489e137f0f55d04a688	BAh7AA==\n	2023-07-28 10:44:32.497027+01	\N
34	2::8ca4e744444bed4e8b2fdcdab63a158bbf2a9d2d9f67ce86a239ca45490b1a2e	BAh7AA==\n	2023-07-28 10:46:32.491502+01	\N
35	2::488574448df04dfad1e93e7922b171913e15f16af4853cca56184921d15b63d5	BAh7AA==\n	2023-07-28 10:48:32.488376+01	\N
36	2::07485247c6b3121c4911cf91d0b6d037ef31e3288d0657992e53ef656b19b13d	BAh7AA==\n	2023-07-28 10:50:34.709226+01	\N
17	2::b5679e0b0296f0b7c5b28daf1e0232245f3b7d4cb006ce5d9f657712f7a05d79	BAh7CUkiDHVzZXJfaWQGOgZFRmkJSSIPdXBkYXRlZF9hdAY7AEZJdToJVGlt\nZQ1t2x6AzJIETwo6DW5hbm9fbnVtaQJ0AToNbmFub19kZW5pBjoNc3VibWlj\ncm8iBzcgOgtvZmZzZXRpAhAOOgl6b25lSSIIQlNUBjsARkkiF2JhY2t1cHNf\naW5kZXhfc29ydAY7AEZJIhRjcmVhdGVkX2F0OmRlc2MGOwBGSSIQX2NzcmZf\ndG9rZW4GOwBGSSIxZk82WXRaTXAwclBBZHF4LzdnUzhqR1g4VFFBbVdPUk9U\nN3lYUEZKSFNvUT0GOwBG\n	2023-07-27 14:19:48.345226+01	4
37	2::d418c212f3f094d7a70dee685b669c74c907ec26b32d070b94f3e45d16f02c8e	BAh7AA==\n	2023-07-28 10:52:34.94574+01	\N
38	2::6a390d1304e1c5e13683605b5fc16e9725760e76bafefafe53c49af6066c5f17	BAh7AA==\n	2023-07-28 10:54:35.532406+01	\N
39	2::3e75a321a0623b191250f158dcae60078aae05d10f443a843fa0440211ef247a	BAh7AA==\n	2023-07-28 10:56:34.822432+01	\N
40	2::b3d1505988b6e9140b179cb820053780ef0954d49e44e89f872531e08f7584df	BAh7AA==\n	2023-07-28 10:58:32.484078+01	\N
41	2::6bb17c815f18f9fbe378f1935dbe6a82af641d77fc22c1cbb14c420ed6412a66	BAh7AA==\n	2023-07-28 11:00:32.488677+01	\N
29	2::2d70a86e262154eba1d1b516fba3f78e7333c198800ef19d7a520d9e55643c01	BAh7CUkiDHVzZXJfaWQGOgZFRmkJSSIPdXBkYXRlZF9hdAY7AEZJdToJVGlt\nZQ1t2x6A2e/sigo6DW5hbm9fbnVtaQIHAToNbmFub19kZW5pBjoNc3VibWlj\ncm8iByYwOgtvZmZzZXRpAhAOOgl6b25lSSIIQlNUBjsARkkiF2JhY2t1cHNf\naW5kZXhfc29ydAY7AEZJIhRjcmVhdGVkX2F0OmRlc2MGOwBGSSIQX2NzcmZf\ndG9rZW4GOwBGSSIxaE5OUWM1am13UitFeVlwN2Q1Q21aNmNiYTBDTGtIamtu\nM1FOMFl4VHkzbz0GOwBG\n	2023-07-27 14:34:46.855145+01	4
42	2::2a94549360bb4c0439dd4447ad90d6b5d6e242641951ca0611904716a04717bd	BAh7AA==\n	2023-07-28 11:02:32.48696+01	\N
43	2::6b8d255bc8952a0b2b32c4b7d0c3210c8f8045a652fee724266194ab79cd91e6	BAh7AA==\n	2023-07-28 11:04:32.479713+01	\N
20	2::e6da9ffe67b02626605a248942a4a6b82aba6e4a2c8252a2d7742a11a26aca9a	BAh7CUkiDHVzZXJfaWQGOgZFRmkJSSIPdXBkYXRlZF9hdAY7AEZJdToJVGlt\nZQ1t2x6AyJksbwo6DW5hbm9fbnVtaQLfAzoNbmFub19kZW5pBjoNc3VibWlj\ncm8iB5kQOgtvZmZzZXRpAhAOOgl6b25lSSIIQlNUBjsARkkiEF9jc3JmX3Rv\na2VuBjsARkkiMWg0cjZXUEx5cWE1QzFTSzdsYzh2QW5mcHNkK01zcXlISkZF\nZnRsZFRudTA9BjsARkkiF2JhY2t1cHNfaW5kZXhfc29ydAY7AEZJIhRjcmVh\ndGVkX2F0OmRlc2MGOwBG\n	2023-07-27 14:27:50.830324+01	4
21	2::07752404141ed95f8730de50ae78a0519c2715df1e4910f7fb1c08140630ea43	BAh7AA==\n	2023-07-27 14:27:53.570909+01	\N
44	2::6b45545caccc611d7334c9aa2c54d8ee6f117be46502f4f4122dbbf9af54e08f	BAh7AA==\n	2023-07-28 11:06:32.478418+01	\N
45	2::0ad44111fbad87a67985672b40fd7491a5f174a4c804dc67f92901da2f322a24	BAh7AA==\n	2023-07-28 11:08:34.977283+01	\N
46	2::1460be0073b26fd579fc94c88a6c5a41e335d1ed1fd9b9d070f09a33e174c56b	BAh7AA==\n	2023-07-28 11:10:32.495153+01	\N
47	2::cbee9d738e0ee97857341f1ee8744937d03f4dfdef80c7f7cce166404427bf53	BAh7AA==\n	2023-07-28 11:12:34.044033+01	\N
48	2::30e21c397859f165f064ca68871eb3626eecc4d180e7cb85c9f11830d2f587be	BAh7AA==\n	2023-07-28 11:14:36.289565+01	\N
49	2::036f51cea548720bb6cbb62aa34d3c4a645bcf9a5a793d647643b75317c843af	BAh7AA==\n	2023-07-28 11:16:35.094912+01	\N
66	2::7b426be8c903511befca5f77895fa2dbbe3dc216b31c43619e89235f0ca58053	BAh7CUkiDHVzZXJfaWQGOgZFRmkJSSIPdXBkYXRlZF9hdAY7AEZJdToJVGlt\nZQ2M2x6A0OIhgAo6DW5hbm9fbnVtaQJoAzoNbmFub19kZW5pBjoNc3VibWlj\ncm8iB4cgOgtvZmZzZXRpAhAOOgl6b25lSSIIQlNUBjsARkkiF2JhY2t1cHNf\naW5kZXhfc29ydAY7AEZJIhRjcmVhdGVkX2F0OmRlc2MGOwBGSSIQX2NzcmZf\ndG9rZW4GOwBGSSIxSGN5c2VnL1N4VFgyRi9zeXNqRDlLSFRrTHY5S2xtaCtL\nWXhCVnlFaHB3cz0GOwBG\n	2023-07-28 13:32:02.130977+01	4
50	2::81ba15e42085bc9afa258fe07f78d6cabd818c239c7f2491fc37ee9f39b5d8f3	BAh7AA==\n	2023-07-28 11:18:32.273957+01	\N
75	2::a40faf1b42ae9e669c1e718ba4a7ab9326e0276a487dcdb64aca67bd5f9949e1	BAh7CUkiDHVzZXJfaWQGOgZFRmkJSSIPdXBkYXRlZF9hdAY7AEZJdToJVGlt\nZQ2O2x6AgeGJlwo6DW5hbm9fbnVtaQKAAjoNbmFub19kZW5pBjoNc3VibWlj\ncm8iBmQ6C29mZnNldGkCEA46CXpvbmVJIghCU1QGOwBGSSIXYmFja3Vwc19p\nbmRleF9zb3J0BjsARkkiFGNyZWF0ZWRfYXQ6ZGVzYwY7AEZJIhBfY3NyZl90\nb2tlbgY7AEZJIjEwU2x0REFSMDZITE44OUdVQUVyeVVyRkpGNVdhOXFHNlZa\nNkxuVGllVFpvPQY7AEY=\n	2023-07-28 15:37:56.656467+01	4
53	2::a06a6fd79ae8daa29b9d28a9e73ec290efbe376b0c005e82974b28a026ff04e0	BAh7CUkiDHVzZXJfaWQGOgZFRmkJSSIPdXBkYXRlZF9hdAY7AEZJdToJVGlt\nZQ2M2x6AbrKCPwo6DW5hbm9fbnVtaW06DW5hbm9fZGVuaQY6DXN1Ym1pY3Jv\nIgcQQDoLb2Zmc2V0aQIQDjoJem9uZUkiCEJTVAY7AEZJIhdiYWNrdXBzX2lu\nZGV4X3NvcnQGOwBGSSIUY3JlYXRlZF9hdDpkZXNjBjsARkkiEF9jc3JmX3Rv\na2VuBjsARkkiMU0xdnh2U1lSN2dSWVYrVWptZ0FSMEhNZHFzVG9IZWlIaGlV\nT0tOdGpVRTQ9BjsARg==\n	2023-07-28 13:15:56.197771+01	4
54	2::1fe807dc7b9652833c1ccf66d54389d79062175f365a785cda04677c1705c6e8	BAh7BkkiCmZsYXNoBjoGRVR7B0kiDGRpc2NhcmQGOwBUWwBJIgxmbGFzaGVz\nBjsAVHsGSSIKZXJyb3IGOwBGSSIVdGVuYW50IG5vdCBmb3VuZAY7AFQ=\n	2023-07-28 13:16:56.437707+01	\N
57	2::badee8980b0467c4696caaa9e7201af6d82638feef3fcb952ff2d0547f54b5f8	BAh7BkkiCmZsYXNoBjoGRVR7B0kiDGRpc2NhcmQGOwBUWwBJIgxmbGFzaGVz\nBjsAVHsGSSIKZXJyb3IGOwBGSSIVdGVuYW50IG5vdCBmb3VuZAY7AFQ=\n	2023-07-28 13:16:58.027805+01	\N
58	2::674cdc102a3bb03f6631ff48ba8d6f53ebf645439fcd0814cffddd62965fa4a9	BAh7CEkiD3VwZGF0ZWRfYXQGOgZFRkl1OglUaW1lDYzbHoBeq6FDCjoNbmFu\nb19udW1pAYM6DW5hbm9fZGVuaQY6DXN1Ym1pY3JvIgcTEDoLb2Zmc2V0aQIQ\nDjoJem9uZUkiCEJTVAY7AEZJIhBfY3NyZl90b2tlbgY7AEZJIjFjalRZZXEx\nbVd5QzgvMEljNGkzOUdxeXpYRklFUmVMQXh1Z25PSU43L1ZZPQY7AEZJIgpm\nbGFzaAY7AFR7B0kiDGRpc2NhcmQGOwBUWwBJIgxmbGFzaGVzBjsAVHsGSSIK\nZXJyb3IGOwBGSSIVdGVuYW50IG5vdCBmb3VuZAY7AFQ=\n	2023-07-28 13:16:58.175771+01	\N
70	2::a7d65b138c0a4207f6c55b2457c3997fde26152772a86a66321fce4f9c983be4	BAh7CUkiDHVzZXJfaWQGOgZFRmkJSSIPdXBkYXRlZF9hdAY7AEZJdToJVGlt\nZQ2O2x6AoIzYFgo6DW5hbm9fbnVtaUg6DW5hbm9fZGVuaQY6DXN1Ym1pY3Jv\nIgcGcDoLb2Zmc2V0aQIQDjoJem9uZUkiCEJTVAY7AEZJIhdiYWNrdXBzX2lu\nZGV4X3NvcnQGOwBGSSIUY3JlYXRlZF9hdDpkZXNjBjsARkkiEF9jc3JmX3Rv\na2VuBjsARkkiMVhqWnorWnkwdGFMdUlhTzc3N1hObDUrbHBUdlRzaUROR1By\naDh1cUwxTEE9BjsARg==\n	2023-07-28 15:07:00.393568+01	4
68	2::28e5bb7a78fc2dedf0d3cfa407cc191f76b9ee109c2e3331c926471c8342f7c4	BAh7CUkiDHVzZXJfaWQGOgZFRmkJSSIPdXBkYXRlZF9hdAY7AEZJdToJVGlt\nZQ2M2x6A/aHNigo6DW5hbm9fbnVtaQI8AToNbmFub19kZW5pBjoNc3VibWlj\ncm8iBzFgOgtvZmZzZXRpAhAOOgl6b25lSSIIQlNUBjsARkkiEF9jc3JmX3Rv\na2VuBjsARkkiMU5xT1FCVXRVY2NEbWtuL2YxOGxWdSszWGVJTHYzUHBKWTIr\nd3BhUUZSSkU9BjsARkkiF2JhY2t1cHNfaW5kZXhfc29ydAY7AEZJIhRjcmVh\ndGVkX2F0OmRlc2MGOwBG\n	2023-07-28 13:34:44.899336+01	4
71	2::5f8d4039c046957d03e91604cba127b6352db02a78f6e924ce32888a7af9a14b	BAh7B0kiD3VwZGF0ZWRfYXQGOgZFRkl1OglUaW1lDY7bHoC0AhMkCjoNbmFu\nb19udW1pAqkBOg1uYW5vX2RlbmkGOg1zdWJtaWNybyIHQlA6C29mZnNldGkC\nEA46CXpvbmVJIghCU1QGOwBGSSIKZmxhc2gGOwBUewdJIgxkaXNjYXJkBjsA\nVFsASSIMZmxhc2hlcwY7AFR7BkkiCmVycm9yBjsARkkiJk5vdCBjdXJyZW50\nbHkgcHJldmlld2luZyBhbnl0aGluZwY7AFQ=\n	2023-07-28 15:09:31.42557+01	\N
72	2::c41619638d961ede403f1dffe4b4ef900bf2842673a10d7869b33b78d89e9e58	BAh7AA==\n	2023-07-28 15:09:54.108269+01	\N
60	2::4e00463f2f112674a5fb9fce12d60039184bcd58ce012b48a6bc05d325c6504f	BAh7CUkiDHVzZXJfaWQGOgZFRmkJSSIPdXBkYXRlZF9hdAY7AEZJdToJVGlt\nZQ2M2x6ArVDoXQo6DW5hbm9fbnVtaQJIAzoNbmFub19kZW5pBjoNc3VibWlj\ncm8iBoQ6C29mZnNldGkCEA46CXpvbmVJIghCU1QGOwBGSSIQX2NzcmZfdG9r\nZW4GOwBGSSIxbWdidFBPV0svZEhWSVFxNHFXNU9SOHNNZnBYRzNCSlpBbTBu\nZFM2MXp2OD0GOwBGSSIXYmFja3Vwc19pbmRleF9zb3J0BjsARkkiFGNyZWF0\nZWRfYXQ6ZGVzYwY7AEY=\n	2023-07-28 13:23:30.562492+01	4
69	2::73952d2044ec38450f476ae7d2d3d721aa095b7d058f95ec1c578ad7d6ad2b8f	BAh7CUkiDHVzZXJfaWQGOgZFRmkJSSIPdXBkYXRlZF9hdAY7AEZJdToJVGlt\nZQ2M2x6AYvgpjAo6DW5hbm9fbnVtaQGPOg1uYW5vX2RlbmkGOg1zdWJtaWNy\nbyIHFDA6C29mZnNldGkCEA46CXpvbmVJIghCU1QGOwBGSSIXYmFja3Vwc19p\nbmRleF9zb3J0BjsARkkiFGNyZWF0ZWRfYXQ6ZGVzYwY7AEZJIhBfY3NyZl90\nb2tlbgY7AEZJIjFCSFZrSTRaWi9kWjB0eXhXaFJkMXVzMERxVnlBQVRrWkRM\naVVENTZ3Z3RzPQY7AEY=\n	2023-07-28 13:35:02.659092+01	4
76	2::e8406ae7c13b24b2f6455ab469de9793d4d08446bcfd4777ebe6258bbacc8518	BAh7CUkiDHVzZXJfaWQGOgZFRmkJSSIPdXBkYXRlZF9hdAY7AEZJdToJVGlt\nZQ2O2x6AaTuOqgo6DW5hbm9fbnVtaQJ2AjoNbmFub19kZW5pBjoNc3VibWlj\ncm8iBmM6C29mZnNldGkCEA46CXpvbmVJIghCU1QGOwBGSSIXYmFja3Vwc19p\nbmRleF9zb3J0BjsARkkiFGNyZWF0ZWRfYXQ6ZGVzYwY7AEZJIhBfY3NyZl90\nb2tlbgY7AEZJIjF2U0lNcThOMkxhcDJSU2xld0pPUUlueFFwYWNiMFFIc2Fp\nTVZHa1hsNERzPQY7AEY=\n	2023-07-28 15:42:40.940239+01	4
63	2::6ffac3d898ee243354837a7ae80bf7d9cc683dc847e33ad414a316cdb1c16a20	BAh7CUkiDHVzZXJfaWQGOgZFRmkJSSIPdXBkYXRlZF9hdAY7AEZJdToJVGlt\nZQ2M2x6Adk/0dgo6DW5hbm9fbnVtaQGJOg1uYW5vX2RlbmkGOg1zdWJtaWNy\nbyIHE3A6C29mZnNldGkCEA46CXpvbmVJIghCU1QGOwBGSSIXYmFja3Vwc19p\nbmRleF9zb3J0BjsARkkiFGNyZWF0ZWRfYXQ6ZGVzYwY7AEZJIhBfY3NyZl90\nb2tlbgY7AEZJIjFDRWsxUTFSWDlQdUJHekhKNkJITmVFSlVXRHI3dFBYR1hE\nRkp5YUdkS2w4PQY7AEY=\n	2023-07-28 13:29:47.292427+01	4
73	2::3ba1cfcbd96168eeb8aa775d6f6470534254e9f5293c2b86ef36e71a96968f72	BAh7CUkiDHVzZXJfaWQGOgZFRmkJSSIPdXBkYXRlZF9hdAY7AEZJdToJVGlt\nZQ2O2x6A1I5ihAo6DW5hbm9fbnVtaQLgAToNbmFub19kZW5pBjoNc3VibWlj\ncm8iBkg6C29mZnNldGkCEA46CXpvbmVJIghCU1QGOwBGSSIXYmFja3Vwc19p\nbmRleF9zb3J0BjsARkkiFGNyZWF0ZWRfYXQ6ZGVzYwY7AEZJIhBfY3NyZl90\nb2tlbgY7AEZJIjFGRFFzWGZDWURFdzdrRGVuNlFmdkNLbFJUenpwd2FTcll5\nbFpLM1VkSzJBPQY7AEY=\n	2023-07-28 15:33:06.178402+01	4
74	2::33a9a15f36d10e9f1747f7436ca384e4162c2c90e1c51019e5b3fa051bc8a3e0	BAh7CUkiDHVzZXJfaWQGOgZFRmkJSSIPdXBkYXRlZF9hdAY7AEZJdToJVGlt\nZQ2O2x6AAaC6jAo6DW5hbm9fbnVtaQG/Og1uYW5vX2RlbmkGOg1zdWJtaWNy\nbyIHGRA6C29mZnNldGkCEA46CXpvbmVJIghCU1QGOwBGSSIXYmFja3Vwc19p\nbmRleF9zb3J0BjsARkkiFGNyZWF0ZWRfYXQ6ZGVzYwY7AEZJIhBfY3NyZl90\nb2tlbgY7AEZJIjFjTE9sUVI5ZzN5SHNlTm1xdjJQTkRGVitmbEVXODF1eita\nRFZLUU1xUTQ0PQY7AEY=\n	2023-07-28 15:35:23.926426+01	4
77	2::39081c6a843c3321fa18e26563ee0e3aa77565f5a3a985ec841f6f1c6562e1d3	BAh7CUkiDHVzZXJfaWQGOgZFRmkJSSIPdXBkYXRlZF9hdAY7AEZJdToJVGlt\nZQ2O2x6A1Opctwo6DW5hbm9fbnVtaQKnAzoNbmFub19kZW5pBjoNc3VibWlj\ncm8iB5NQOgtvZmZzZXRpAhAOOgl6b25lSSIIQlNUBjsARkkiF2JhY2t1cHNf\naW5kZXhfc29ydAY7AEZJIhRjcmVhdGVkX2F0OmRlc2MGOwBGSSIQX2NzcmZf\ndG9rZW4GOwBGSSIxR2lRM2VYNEhlMGNaRDZVREViTDBZeXdiUmpsd3hOanU5\nemh1ajFKQlY0cz0GOwBG\n	2023-07-28 15:45:53.853916+01	4
80	2::e6f87e50629fe36445e7d21cf7e1ae3df0ef335f4f3ba7ae227956687054881d	BAh7CUkiDHVzZXJfaWQGOgZFRmkJSSIPdXBkYXRlZF9hdAY7AEZJdToJVGlt\nZQ2O2x6AS3/g0Ao6DW5hbm9fbnVtaQLxAToNbmFub19kZW5pBjoNc3VibWlj\ncm8iB0lwOgtvZmZzZXRpAhAOOgl6b25lSSIIQlNUBjsARkkiF2JhY2t1cHNf\naW5kZXhfc29ydAY7AEZJIhRjcmVhdGVkX2F0OmRlc2MGOwBGSSIQX2NzcmZf\ndG9rZW4GOwBGSSIxWUlzVjdBWXFuenc2Ti9UZGdjTHMyVVpucVZPWThVVERt\nT1hsWjNibDdjOD0GOwBG\n	2023-07-28 15:52:14.041336+01	4
81	2::3e8644f83d2f26c831770bcf286d1f75ff2cb7ffb860a2cdaa66d0e1a73e88db	BAh7CUkiDHVzZXJfaWQGOgZFRmkJSSIPdXBkYXRlZF9hdAY7AEZJdToJVGlt\nZQ2y2x6AeQWdjQo6DW5hbm9fbnVtaQJ2AzoNbmFub19kZW5pBjoNc3VibWlj\ncm8iB4hgOgtvZmZzZXRpAhAOOgl6b25lSSIIQlNUBjsARkkiEF9jc3JmX3Rv\na2VuBjsARkkiMXIxaWJUSWJLWE1WVFgyYkowTnNwbjRYQm10USttMFdKeERQ\nb2ZxbkJ0QWs9BjsARkkiF2JhY2t1cHNfaW5kZXhfc29ydAY7AEZJIhRjcmVh\ndGVkX2F0OmRlc2MGOwBG\n	2023-07-29 19:36:06.140077+01	4
84	2::70ffa468a7429bedfe2ee1fe4b7a12b4653be995f63b02904ea5a4d1be246d9f	BAh7CUkiDHVzZXJfaWQGOgZFRmkJSSIPdXBkYXRlZF9hdAY7AEZJdToJVGlt\nZQ2y2x6AFdpH0Qo6DW5hbm9fbnVtaQG6Og1uYW5vX2RlbmkGOg1zdWJtaWNy\nbyIHGGA6C29mZnNldGkCEA46CXpvbmVJIghCU1QGOwBGSSIXYmFja3Vwc19p\nbmRleF9zb3J0BjsARkkiFGNyZWF0ZWRfYXQ6ZGVzYwY7AEZJIhBfY3NyZl90\nb2tlbgY7AEZJIjFvQ1pJZThSUE15enJ4bklXNTEzbzNQUkpQWnRVM2lmcVBj\nT0lrVUVNM3RRPQY7AEY=\n	2023-07-29 19:52:31.007538+01	4
86	2::f12ccde608556fd9e88ee164f19734b2dc9f513825daa6daba159387b7afb5a9	BAh7CUkiDHVzZXJfaWQGOgZFRmkJSSIPdXBkYXRlZF9hdAY7AEZJdToJVGlt\nZQ3n2x6AOAqFRAo6DW5hbm9fbnVtaQKMAToNbmFub19kZW5pBjoNc3VibWlj\ncm8iBzlgOgtvZmZzZXRpAhAOOgl6b25lSSIIQlNUBjsARkkiEF9jc3JmX3Rv\na2VuBjsARkkiMUsrdzBrUi9PazdNczlObFdQS3dSdW9BOEdmR2ZjZG0vTVNT\naHlVNlFnVVk9BjsARkkiF2JhY2t1cHNfaW5kZXhfc29ydAY7AEZJIhRjcmVh\ndGVkX2F0OmRlc2MGOwBG\n	2023-07-31 08:17:08.343456+01	4
\.


--
-- Data for Name: settings; Type: TABLE DATA; Schema: backup_preview_5; Owner: -
--

COPY backup_preview_5.settings (id, name, value, updated_at) FROM stdin;
1	working_days	---\n- 1\n- 2\n- 3\n- 4\n- 5\n	2023-07-26 09:21:42.56482+01
2	fog	{}	2023-07-26 09:22:06.833116+01
3	feature_show_changes_active	true	2023-07-26 09:22:06.840622+01
4	feature_more_global_index_pages_active	true	2023-07-26 09:22:06.845296+01
5	plugin_openproject_auth_saml	---\nproviders: \n	2023-07-26 09:22:06.849422+01
6	plugin_costs	---\ncosts_currency: EUR\ncosts_currency_format: "%n %u"\n	2023-07-26 09:22:06.853528+01
7	cost_reporting_cache_filter_classes	true	2023-07-26 09:22:06.857116+01
9	plugin_openproject_avatars	---\nenable_gravatars: true\nenable_local_avatars: true\n	2023-07-26 09:22:06.865531+01
10	plugin_openproject_two_factor_authentication	---\nactive_strategies:\n- :totp\nenforced: false\nallow_remember_for_days: 0\n	2023-07-26 09:22:06.869156+01
11	plugin_openproject_ldap_groups	{}	2023-07-26 09:22:06.872458+01
12	plugin_openproject_recaptcha	---\nrecaptcha_type: disabled\n	2023-07-26 09:22:06.876547+01
13	recaptcha_via_hcaptcha	f	2023-07-26 09:22:06.880024+01
15	feature_storage_file_picking_select_all_active	true	2023-07-26 09:22:06.886797+01
16	feature_storage_project_folders_active	true	2023-07-26 09:22:06.889881+01
17	feature_managed_project_folders_active	true	2023-07-26 09:22:06.893478+01
18	plugin_openproject_bim	{}	2023-07-26 09:22:06.897136+01
19	available_languages	---\n- de\n- en\n- es\n- fr\n- it\n- ko\n- pt\n- ru\n- zh-CN\n	2023-07-26 09:22:06.900916+01
21	activity_days_default	30	2023-07-26 09:22:06.907361+01
22	apiv3_cors_enabled	f	2023-07-26 09:22:06.912291+01
23	apiv3_cors_origins	[]	2023-07-26 09:22:06.917692+01
24	apiv3_docs_enabled	true	2023-07-26 09:22:06.921125+01
25	apiv3_max_page_size	1000	2023-07-26 09:22:06.925348+01
27	attachment_max_size	5120	2023-07-26 09:22:06.93252+01
28	attachment_whitelist	[]	2023-07-26 09:22:06.9359+01
29	autofetch_changesets	true	2023-07-26 09:22:06.939066+01
30	autologin	0	2023-07-26 09:22:06.942211+01
31	bcc_recipients	true	2023-07-26 09:22:06.945771+01
33	brute_force_block_minutes	30	2023-07-26 09:22:06.955549+01
34	brute_force_block_after_failed_logins	20	2023-07-26 09:22:06.958923+01
36	commit_fix_done_ratio	100	2023-07-26 09:22:06.966303+01
37	commit_fix_keywords	fixes,closes	2023-07-26 09:22:06.969454+01
38	commit_logs_encoding	UTF-8	2023-07-26 09:22:06.972578+01
39	commit_logtime_enabled	f	2023-07-26 09:22:06.979444+01
40	commit_ref_keywords	refs,references,IssueID	2023-07-26 09:22:06.983663+01
41	consent_info	---\nen: |-\n  ## Consent\n\n  You need to agree to the [privacy and security policy](https://www.openproject.org/data-privacy-and-security/) of this OpenProject instance.\n	2023-07-26 09:22:06.98686+01
42	consent_required	f	2023-07-26 09:22:06.99777+01
43	cross_project_work_package_relations	true	2023-07-26 09:22:07.001971+01
44	default_auto_hide_popups	true	2023-07-26 09:22:07.005423+01
45	default_language	en	2023-07-26 09:22:07.009959+01
46	default_projects_modules	---\n- calendar\n- board_view\n- work_package_tracking\n- news\n- costs\n- wiki\n- reporting_module\n- meetings\n- backlogs\n	2023-07-26 09:22:07.015529+01
47	default_projects_public	f	2023-07-26 09:22:07.019156+01
51	diff_max_lines_displayed	1500	2023-07-26 09:22:07.035059+01
52	display_subprojects_work_packages	true	2023-07-26 09:22:07.038446+01
53	emails_footer	---\nen: ''\n	2023-07-26 09:22:07.042071+01
54	emails_header	---\nen: ''\n	2023-07-26 09:22:07.046236+01
55	email_login	f	2023-07-26 09:22:07.049954+01
56	enabled_projects_columns	---\n- project_status\n- public\n- created_at\n- latest_activity_at\n- required_disk_space\n	2023-07-26 09:22:07.053586+01
57	enabled_scm	---\n- subversion\n- git\n	2023-07-26 09:22:07.056899+01
59	feeds_limit	15	2023-07-26 09:22:07.063538+01
60	file_max_size_displayed	512	2023-07-26 09:22:07.066981+01
61	forced_single_page_size	250	2023-07-26 09:22:07.072432+01
62	host_name	localhost:3000	2023-07-26 09:22:07.07593+01
63	invitation_expiration_days	7	2023-07-26 09:22:07.081589+01
64	journal_aggregation_time_minutes	5	2023-07-26 09:22:07.088486+01
65	ldap_tls_options	{}	2023-07-26 09:22:07.092342+01
66	log_requesting_user	f	2023-07-26 09:22:07.096411+01
67	login_required	f	2023-07-26 09:22:07.100376+01
68	lost_password	true	2023-07-26 09:22:07.104751+01
69	mail_from	openproject@example.net	2023-07-26 09:22:07.108595+01
70	mail_handler_body_delimiters		2023-07-26 09:22:07.11249+01
71	mail_handler_body_delimiter_regex		2023-07-26 09:22:07.118772+01
72	mail_handler_ignore_filenames	signature.asc	2023-07-26 09:22:07.122257+01
73	mail_suffix_separators	+	2023-07-26 09:22:07.126293+01
74	oauth_allow_remapping_of_existing_users	true	2023-07-26 09:22:07.131498+01
75	password_active_rules	---\n- lowercase\n- uppercase\n- numeric\n- special\n	2023-07-26 09:22:07.135135+01
76	password_count_former_banned	0	2023-07-26 09:22:07.138384+01
77	password_days_valid	0	2023-07-26 09:22:07.141613+01
78	password_min_length	10	2023-07-26 09:22:07.14606+01
79	password_min_adhered_rules	0	2023-07-26 09:22:07.149538+01
80	per_page_options	20, 100	2023-07-26 09:22:07.153036+01
81	plain_text_mail	f	2023-07-26 09:22:07.159531+01
82	registration_footer	---\nen: ''\n	2023-07-26 09:22:07.163629+01
83	report_incoming_email_errors	true	2023-07-26 09:22:07.168643+01
84	repository_authentication_caching_enabled	true	2023-07-26 09:22:07.172019+01
85	repository_checkout_data	---\ngit:\n  enabled: 0\nsubversion:\n  enabled: 0\n	2023-07-26 09:22:07.177792+01
86	repository_log_display_limit	100	2023-07-26 09:22:07.183405+01
87	repository_storage_cache_minutes	720	2023-07-26 09:22:07.187174+01
88	repository_truncate_at	500	2023-07-26 09:22:07.190814+01
89	rest_api_enabled	true	2023-07-26 09:22:07.195395+01
91	self_registration	2	2023-07-26 09:22:07.203288+01
92	sendmail_location	/usr/sbin/sendmail	2023-07-26 09:22:07.207171+01
93	session_ttl_enabled	f	2023-07-26 09:22:07.21277+01
94	session_ttl	120	2023-07-26 09:22:07.216262+01
95	smtp_authentication	plain	2023-07-26 09:22:07.220129+01
96	smtp_enable_starttls_auto	f	2023-07-26 09:22:07.223571+01
14	ical_enabled	1	2023-07-26 11:09:20.025777+01
35	cache_formatted_text	1	2023-07-26 11:09:20.042083+01
58	feeds_enabled	1	2023-07-26 11:09:20.048501+01
90	security_badge_displayed	1	2023-07-26 11:09:20.08433+01
97	smtp_ssl	f	2023-07-26 09:22:07.229707+01
98	smtp_address		2023-07-26 09:22:07.233718+01
99	smtp_domain	your.domain.com	2023-07-26 09:22:07.237538+01
100	smtp_user_name		2023-07-26 09:22:07.241976+01
101	smtp_port	587	2023-07-26 09:22:07.246758+01
102	smtp_password		2023-07-26 09:22:07.250189+01
103	software_name	OpenProject	2023-07-26 09:22:07.255153+01
26	app_title	OpenProject (current)	2023-07-27 13:21:32.109454+01
104	software_url	https://www.openproject.org/	2023-07-26 09:22:07.259052+01
105	sys_api_enabled	f	2023-07-26 09:22:07.263144+01
106	users_deletable_by_admins	f	2023-07-26 09:22:07.266686+01
107	users_deletable_by_self	f	2023-07-26 09:22:07.27+01
108	user_format	firstname_lastname	2023-07-26 09:22:07.273322+01
110	work_package_done_ratio	field	2023-07-26 09:22:07.281666+01
111	work_packages_projects_export_limit	500	2023-07-26 09:22:07.285133+01
112	work_packages_bulk_request_limit	10	2023-07-26 09:22:07.288562+01
113	work_package_list_default_highlighted_attributes	[]	2023-07-26 09:22:07.29278+01
114	work_package_list_default_columns	---\n- id\n- subject\n- type\n- status\n- assigned_to\n- priority\n	2023-07-26 09:22:07.299164+01
115	work_package_startdate_is_adddate	f	2023-07-26 09:22:07.302536+01
116	new_project_user_role_id	5	2023-07-26 09:22:07.305793+01
117	commit_fix_status_id	12	2023-07-26 09:22:07.310226+01
8	plugin_openproject_backlogs	---\nstory_types:\n- 4\n- 5\n- 6\n- 7\ntask_type: 1\npoints_burn_direction: up\nwiki_template: ''\n	2023-07-26 09:22:07.317015+01
118	welcome_title	Welcome to OpenProject!	2023-07-26 09:22:07.537506+01
109	welcome_on_homescreen	1	2023-07-26 09:22:07.549586+01
49	demo_view_of_type_work_packages_table_seeded	true	2023-07-26 09:22:07.802315+01
50	demo_view_of_type_team_planner_seeded	true	2023-07-26 09:22:07.835062+01
32	boards_demo_data_available	true	2023-07-26 09:22:08.612326+01
48	demo_projects_available	true	2023-07-26 09:22:08.674222+01
120	installation_uuid	59cb2d62-2670-4f39-b385-885e6ac08f55	2023-07-26 09:22:51.145907+01
119	welcome_text	Backup token: **06ac397c0cd55d0cb36c88c79a7d86d5733d8098378846fb21b75f11ec2d748a**	2023-07-26 11:09:20.090017+01
20	_maintenance_mode	---\n:enabled: false\n	2023-07-29 19:34:41.636414+01
\.


--
-- Data for Name: statuses; Type: TABLE DATA; Schema: backup_preview_5; Owner: -
--

COPY backup_preview_5.statuses (id, name, is_closed, is_default, "position", default_done_ratio, created_at, updated_at, color_id, is_readonly) FROM stdin;
1	New	f	t	1	\N	2023-07-26 09:22:05.865881+01	2023-07-26 09:22:05.865881+01	92	f
2	In specification	f	f	2	\N	2023-07-26 09:22:05.869546+01	2023-07-26 09:22:05.869546+01	77	f
3	Specified	f	f	3	\N	2023-07-26 09:22:05.873046+01	2023-07-26 09:22:05.873046+01	77	f
4	Confirmed	f	f	4	\N	2023-07-26 09:22:05.876243+01	2023-07-26 09:22:05.876243+01	57	f
5	To be scheduled	f	f	5	\N	2023-07-26 09:22:05.881483+01	2023-07-26 09:22:05.881483+01	127	f
6	Scheduled	f	f	6	\N	2023-07-26 09:22:05.885731+01	2023-07-26 09:22:05.885731+01	117	f
7	In progress	f	f	7	\N	2023-07-26 09:22:05.890369+01	2023-07-26 09:22:05.890369+01	50	f
8	Developed	f	f	8	\N	2023-07-26 09:22:05.893566+01	2023-07-26 09:22:05.893566+01	108	f
9	In testing	f	f	9	\N	2023-07-26 09:22:05.900638+01	2023-07-26 09:22:05.900638+01	90	f
10	Tested	f	f	10	\N	2023-07-26 09:22:05.903969+01	2023-07-26 09:22:05.903969+01	101	f
11	Test failed	f	f	11	\N	2023-07-26 09:22:05.907152+01	2023-07-26 09:22:05.907152+01	30	f
12	Closed	t	f	12	\N	2023-07-26 09:22:05.910412+01	2023-07-26 09:22:05.910412+01	18	f
13	On hold	f	f	13	\N	2023-07-26 09:22:05.914333+01	2023-07-26 09:22:05.914333+01	138	f
14	Rejected	t	f	14	\N	2023-07-26 09:22:05.917505+01	2023-07-26 09:22:05.917505+01	28	f
\.


--
-- Data for Name: storages; Type: TABLE DATA; Schema: backup_preview_5; Owner: -
--

COPY backup_preview_5.storages (id, provider_type, name, host, creator_id, created_at, updated_at, provider_fields) FROM stdin;
\.


--
-- Data for Name: time_entries; Type: TABLE DATA; Schema: backup_preview_5; Owner: -
--

COPY backup_preview_5.time_entries (id, project_id, user_id, work_package_id, hours, comments, activity_id, spent_on, tyear, tmonth, tweek, created_at, updated_at, overridden_costs, costs, rate_id, logged_by_id) FROM stdin;
\.


--
-- Data for Name: time_entry_activities_projects; Type: TABLE DATA; Schema: backup_preview_5; Owner: -
--

COPY backup_preview_5.time_entry_activities_projects (id, activity_id, project_id, active) FROM stdin;
\.


--
-- Data for Name: time_entry_journals; Type: TABLE DATA; Schema: backup_preview_5; Owner: -
--

COPY backup_preview_5.time_entry_journals (id, project_id, user_id, work_package_id, hours, comments, activity_id, spent_on, tyear, tmonth, tweek, overridden_costs, costs, rate_id, logged_by_id) FROM stdin;
\.


--
-- Data for Name: tokens; Type: TABLE DATA; Schema: backup_preview_5; Owner: -
--

COPY backup_preview_5.tokens (id, user_id, type, value, created_at, expires_on) FROM stdin;
2	4	Token::RSS	cf07df351fc11382e3c0f7639eef8bced79a0bb385b863481105fc07da5826fc	2023-07-26 09:23:53.479535+01	\N
3	4	Token::Backup	bdf333c2551b5762198adf397f6b291eae8063408327734ba6340ad063c8719a	1787-01-04 10:07:38.046577-00:01:15	\N
\.


--
-- Data for Name: two_factor_authentication_devices; Type: TABLE DATA; Schema: backup_preview_5; Owner: -
--

COPY backup_preview_5.two_factor_authentication_devices (id, type, "default", active, channel, phone_number, identifier, created_at, updated_at, last_used_at, otp_secret, user_id) FROM stdin;
\.


--
-- Data for Name: types; Type: TABLE DATA; Schema: backup_preview_5; Owner: -
--

COPY backup_preview_5.types (id, name, "position", is_in_roadmap, is_milestone, is_default, color_id, created_at, updated_at, is_standard, attribute_groups, description) FROM stdin;
1	Task	1	t	f	t	2	2023-07-26 09:22:05.926806+01	2023-07-26 09:22:05.926806+01	f	\N	
2	Milestone	3	f	t	t	4	2023-07-26 09:22:05.929778+01	2023-07-26 09:22:10.776297+01	f	\N	
3	Phase	4	f	f	t	140	2023-07-26 09:22:05.932772+01	2023-07-26 09:22:10.776297+01	f	\N	
4	Feature	5	t	f	f	70	2023-07-26 09:22:05.935667+01	2023-07-26 09:22:10.776297+01	f	\N	
5	Epic	6	t	f	f	60	2023-07-26 09:22:05.93856+01	2023-07-26 09:22:10.776297+01	f	\N	
6	User story	7	t	f	f	3	2023-07-26 09:22:05.941424+01	2023-07-26 09:22:10.776297+01	f	\N	
7	Bug	8	t	f	f	32	2023-07-26 09:22:05.94529+01	2023-07-26 09:22:10.776297+01	f	\N	
8	All CFS	9	t	f	f	\N	2023-07-26 09:22:10.759552+01	2023-07-26 09:22:10.776297+01	f	---\n- - :people\n  - - assignee\n    - responsible\n- - :estimates_and_time\n  - - estimated_time\n    - spent_time\n    - remaining_time\n- - :details\n  - - date\n    - percentage_done\n    - category\n    - version\n    - priority\n- - :costs\n  - - budget\n    - overall_costs\n    - labor_costs\n    - material_costs\n    - costs_by_type\n- - Custom fields\n  - - custom_field_1\n    - custom_field_2\n    - custom_field_3\n    - custom_field_4\n    - custom_field_5\n    - custom_field_6\n    - custom_field_7\n    - custom_field_8\n    - custom_field_9\n    - custom_field_11\n	\N
9	Required CF	2	t	f	f	\N	2023-07-26 09:22:10.772083+01	2023-07-26 09:22:10.772095+01	f	---\n- - :people\n  - - assignee\n    - responsible\n- - :estimates_and_time\n  - - estimated_time\n    - spent_time\n    - remaining_time\n- - :details\n  - - date\n    - percentage_done\n    - category\n    - version\n    - priority\n- - :costs\n  - - budget\n    - overall_costs\n    - labor_costs\n    - material_costs\n    - costs_by_type\n- - Custom fields\n  - - custom_field_10\n	\N
\.


--
-- Data for Name: user_passwords; Type: TABLE DATA; Schema: backup_preview_5; Owner: -
--

COPY backup_preview_5.user_passwords (id, user_id, hashed_password, salt, created_at, updated_at, type) FROM stdin;
1	4	$2a$12$vK/29tEVqXvUaLV248BRYuzN72hwbrk3RgeT4rLiKFrZmIL9aLXka	\N	2023-07-26 09:22:07.35466+01	2023-07-26 09:22:07.35466+01	UserPassword::Bcrypt
2	5	$2a$12$q319iwu0JBU.zU6ANOfy2u/jIxcNpiTTame2Lh61o5OLqHMfh7v4u	\N	2023-07-26 09:22:09.993527+01	2023-07-26 09:22:09.993527+01	UserPassword::Bcrypt
3	6	$2a$12$PcslaMUgtod7r3VN/BbO..HI.Ap1eSc3av7XgBCj4kmrAITGLIoZa	\N	2023-07-26 09:22:10.172556+01	2023-07-26 09:22:10.172556+01	UserPassword::Bcrypt
4	7	$2a$12$SqfKI0CzADDNDtHrCFYMFutpnTM6Q6Wo36AG/pGy7Gjp6oL51BsJq	\N	2023-07-26 09:22:10.378153+01	2023-07-26 09:22:10.378153+01	UserPassword::Bcrypt
5	8	$2a$12$Z6..J1mTZo2K.oNHyqpsy.hxNNTuLzROxua6fDvBrCfZmkGXNBpdq	\N	2023-07-26 09:22:10.544834+01	2023-07-26 09:22:10.544834+01	UserPassword::Bcrypt
\.


--
-- Data for Name: user_preferences; Type: TABLE DATA; Schema: backup_preview_5; Owner: -
--

COPY backup_preview_5.user_preferences (id, user_id, settings) FROM stdin;
1	4	\N
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: backup_preview_5; Owner: -
--

COPY backup_preview_5.users (id, login, firstname, lastname, mail, admin, status, last_login_on, language, auth_source_id, created_at, updated_at, type, identity_url, first_login, force_password_change, failed_login_count, last_failed_login_on, consented_at) FROM stdin;
2					f	3	\N		\N	2023-07-26 09:21:36.583287+01	2023-07-26 09:21:36.583287+01	DeletedUser	\N	t	f	0	\N	\N
1			System		t	1	\N		\N	2023-07-26 09:21:35.573534+01	2023-07-26 09:21:35.573534+01	SystemUser	\N	f	f	0	\N	\N
3			Anonymous		f	1	\N		\N	2023-07-26 09:22:05.445636+01	2023-07-26 09:22:05.445636+01	AnonymousUser	\N	t	f	0	\N	\N
5	reader	Reader	DEV user	reader@example.net	f	1	\N	en	\N	2023-07-26 09:22:09.991117+01	2023-07-26 09:22:09.991117+01	User	\N	t	f	0	\N	\N
6	member	Member	DEV user	member@example.net	f	1	\N	en	\N	2023-07-26 09:22:10.169743+01	2023-07-26 09:22:10.169743+01	User	\N	t	f	0	\N	\N
7	project_admin	Project admin	DEV user	project_admin@example.net	f	1	\N	en	\N	2023-07-26 09:22:10.37577+01	2023-07-26 09:22:10.37577+01	User	\N	t	f	0	\N	\N
8	admin_de	Admin de	DEV user	admin_de@example.net	t	1	\N	de	\N	2023-07-26 09:22:10.542727+01	2023-07-26 09:22:10.542727+01	User	\N	t	f	0	\N	\N
4	admin	OpenProject	Admin	admin@example.net	t	1	2023-07-30 22:36:33.607612+01	en	\N	2023-07-26 09:22:07.345237+01	2023-07-30 22:36:33.610732+01	User	\N	f	f	0	2023-07-28 11:18:39.366254+01	\N
\.


--
-- Data for Name: version_settings; Type: TABLE DATA; Schema: backup_preview_5; Owner: -
--

COPY backup_preview_5.version_settings (id, project_id, version_id, display, created_at, updated_at) FROM stdin;
1	2	1	3	2023-07-26 09:22:08.836034+01	2023-07-26 09:22:08.836034+01
2	2	2	3	2023-07-26 09:22:08.838315+01	2023-07-26 09:22:08.838315+01
3	2	3	2	2023-07-26 09:22:08.839937+01	2023-07-26 09:22:08.839937+01
4	2	4	2	2023-07-26 09:22:08.842358+01	2023-07-26 09:22:08.842358+01
\.


--
-- Data for Name: versions; Type: TABLE DATA; Schema: backup_preview_5; Owner: -
--

COPY backup_preview_5.versions (id, project_id, name, description, effective_date, created_at, updated_at, wiki_page_title, status, sharing, start_date) FROM stdin;
1	2	Bug Backlog		\N	2023-07-26 09:22:08.778842+01	2023-07-26 09:22:08.778842+01	\N	open	none	\N
2	2	Product Backlog		\N	2023-07-26 09:22:08.782362+01	2023-07-26 09:22:08.782362+01	\N	open	none	\N
3	2	Sprint 1		\N	2023-07-26 09:22:08.784687+01	2023-07-26 09:22:08.818188+01	Sprint 1	open	none	\N
4	2	Sprint 2		\N	2023-07-26 09:22:08.82122+01	2023-07-26 09:22:08.82122+01	\N	open	none	\N
5	3	Bug Backlog		\N	2023-07-26 09:22:11.037172+01	2023-07-26 09:22:11.037172+01	\N	open	none	\N
6	3	Product Backlog		\N	2023-07-26 09:22:11.038927+01	2023-07-26 09:22:11.038927+01	\N	open	none	\N
7	3	Sprint 1		\N	2023-07-26 09:22:11.040394+01	2023-07-26 09:22:11.040394+01	\N	open	none	\N
8	3	Sprint 2		\N	2023-07-26 09:22:11.043049+01	2023-07-26 09:22:11.043049+01	\N	open	none	\N
9	4	Bug Backlog		\N	2023-07-26 09:22:11.050323+01	2023-07-26 09:22:11.050323+01	\N	open	none	\N
10	4	Product Backlog		\N	2023-07-26 09:22:11.05445+01	2023-07-26 09:22:11.05445+01	\N	open	none	\N
11	4	Sprint 1		\N	2023-07-26 09:22:11.057423+01	2023-07-26 09:22:11.057423+01	\N	open	none	\N
12	4	Sprint 2		\N	2023-07-26 09:22:11.060407+01	2023-07-26 09:22:11.060407+01	\N	open	none	\N
13	5	Bug Backlog		\N	2023-07-26 09:22:11.062547+01	2023-07-26 09:22:11.062547+01	\N	open	none	\N
14	5	Product Backlog		\N	2023-07-26 09:22:11.065743+01	2023-07-26 09:22:11.065743+01	\N	open	none	\N
15	5	Sprint 1		\N	2023-07-26 09:22:11.068162+01	2023-07-26 09:22:11.068162+01	\N	open	none	\N
16	5	Sprint 2		\N	2023-07-26 09:22:11.069897+01	2023-07-26 09:22:11.069897+01	\N	open	none	\N
17	6	Bug Backlog		\N	2023-07-26 09:22:11.071735+01	2023-07-26 09:22:11.071735+01	\N	open	none	\N
18	6	Product Backlog		\N	2023-07-26 09:22:11.073452+01	2023-07-26 09:22:11.073452+01	\N	open	none	\N
19	6	Sprint 1		\N	2023-07-26 09:22:11.079102+01	2023-07-26 09:22:11.079102+01	\N	open	none	\N
20	6	Sprint 2		\N	2023-07-26 09:22:11.081623+01	2023-07-26 09:22:11.081623+01	\N	open	none	\N
\.


--
-- Data for Name: views; Type: TABLE DATA; Schema: backup_preview_5; Owner: -
--

COPY backup_preview_5.views (id, query_id, options, type, created_at, updated_at) FROM stdin;
1	1	{}	work_packages_table	2023-07-26 09:22:07.799586+01	2023-07-26 09:22:07.799586+01
2	2	{}	work_packages_table	2023-07-26 09:22:07.812586+01	2023-07-26 09:22:07.812586+01
3	3	{}	work_packages_table	2023-07-26 09:22:07.822279+01	2023-07-26 09:22:07.822279+01
4	4	{}	team_planner	2023-07-26 09:22:07.832812+01	2023-07-26 09:22:07.832812+01
5	15	{}	work_packages_table	2023-07-26 09:22:08.850113+01	2023-07-26 09:22:08.850113+01
6	16	{}	work_packages_table	2023-07-26 09:22:08.861049+01	2023-07-26 09:22:08.861049+01
7	17	{}	work_packages_table	2023-07-26 09:22:08.870956+01	2023-07-26 09:22:08.870956+01
8	18	{}	work_packages_table	2023-07-26 09:22:08.88172+01	2023-07-26 09:22:08.88172+01
\.


--
-- Data for Name: watchers; Type: TABLE DATA; Schema: backup_preview_5; Owner: -
--

COPY backup_preview_5.watchers (id, watchable_type, watchable_id, user_id) FROM stdin;
1	News	1	4
2	News	2	4
\.


--
-- Data for Name: webhooks_events; Type: TABLE DATA; Schema: backup_preview_5; Owner: -
--

COPY backup_preview_5.webhooks_events (id, name, webhooks_webhook_id) FROM stdin;
\.


--
-- Data for Name: webhooks_logs; Type: TABLE DATA; Schema: backup_preview_5; Owner: -
--

COPY backup_preview_5.webhooks_logs (id, webhooks_webhook_id, event_name, url, request_headers, request_body, response_code, response_headers, response_body, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: webhooks_projects; Type: TABLE DATA; Schema: backup_preview_5; Owner: -
--

COPY backup_preview_5.webhooks_projects (id, project_id, webhooks_webhook_id) FROM stdin;
\.


--
-- Data for Name: webhooks_webhooks; Type: TABLE DATA; Schema: backup_preview_5; Owner: -
--

COPY backup_preview_5.webhooks_webhooks (id, name, url, description, secret, enabled, all_projects, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: wiki_page_journals; Type: TABLE DATA; Schema: backup_preview_5; Owner: -
--

COPY backup_preview_5.wiki_page_journals (id, author_id, text) FROM stdin;
1	1	### Sprint planning meeting\n\n_Please document here topics to the Sprint planning meeting_\n\n* Time boxed (8 h)\n* Input: Product Backlog\n* Output: Sprint Backlog\n\n* Divided into two additional time boxes of 4 h:\n\n    * The Product Owner presents the [Product Backlog]({{opSetting:base_url}}/projects/your-scrum-project/backlogs) and the priorities to the team and explains the Sprint Goal, to which the team must agree. Together, they prioritize the topics from the Product Backlog which the team will take care of in the next sprint. The team commits to the discussed delivery.\n    * The team plans autonomously (without the Product Owner) in detail and breaks down the tasks from the discussed requirements to consolidate a [Sprint Backlog]({{opSetting:base_url}}/projects/your-scrum-project/backlogs).\n\n\n### Daily Scrum meeting\n\n_Please document here topics to the Daily Scrum meeting_\n\n* Short, daily status meeting of the team.\n* Time boxed (max. 15 min).\n* Stand-up meeting to discuss the following topics from the [Task board](/projects/your-scrum-project/sprints/3/taskboard).\n    * What do I plan to do until the next Daily Scrum?\n    * What has blocked my work (Impediments)?\n* Scrum Master moderates and notes down [Sprint Impediments](/projects/your-scrum-project/sprints/3/taskboard).\n* Product Owner may participate may participate in order to stay informed.\n\n### Sprint Review meeting\n\n_Please document here topics to the Sprint Review meeting_\n\n* Time boxed (4 h).\n* A maximum of one hour of preparation time per person.\n* The team shows the product owner and other interested persons what has been achieved in this sprint.\n* Important: no dummies and no PowerPoint! Just finished product functionality (Increments) should be demonstrated.\n* Feedback from Product Owner, stakeholders and others is desired and will be included in further work.\n* Based on the demonstrated functionalities, the Product Owner decides to go live with this increment or to develop it further. This possibility allows an early ROI.\n\n\n### Sprint Retrospective\n\n_Please document here topics to the Sprint Retrospective meeting_\n\n* Time boxed (3 h).\n* After Sprint Review, will be moderated by Scrum Master.\n* The team discusses the sprint: what went well, what needs to be improved to be more productive for the next sprint or even have more fun.\n
2	4	### Sprint planning meeting\n\n_Please document here topics to the Sprint planning meeting_\n\n* Time boxed (8 h)\n* Input: Product Backlog\n* Output: Sprint Backlog\n\n* Divided into two additional time boxes of 4 h:\n\n    * The Product Owner presents the [Product Backlog]({{opSetting:base_url}}/projects/your-scrum-project/backlogs) and the priorities to the team and explains the Sprint Goal, to which the team must agree. Together, they prioritize the topics from the Product Backlog which the team will take care of in the next sprint. The team commits to the discussed delivery.\n    * The team plans autonomously (without the Product Owner) in detail and breaks down the tasks from the discussed requirements to consolidate a [Sprint Backlog]({{opSetting:base_url}}/projects/your-scrum-project/backlogs).\n\n\n### Daily Scrum meeting\n\n_Please document here topics to the Daily Scrum meeting_\n\n* Short, daily status meeting of the team.\n* Time boxed (max. 15 min).\n* Stand-up meeting to discuss the following topics from the Task board.\n    * What do I plan to do until the next Daily Scrum?\n    * What has blocked my work (Impediments)?\n* Scrum Master moderates and notes down Sprint Impediments.\n* Product Owner may participate may participate in order to stay informed.\n\n### Sprint Review meeting\n\n_Please document here topics to the Sprint Review meeting_\n\n* Time boxed (4 h).\n* A maximum of one hour of preparation time per person.\n* The team shows the product owner and other interested persons what has been achieved in this sprint.\n* Important: no dummies and no PowerPoint! Just finished product functionality (Increments) should be demonstrated.\n* Feedback from Product Owner, stakeholders and others is desired and will be included in further work.\n* Based on the demonstrated functionalities, the Product Owner decides to go live with this increment or to develop it further. This possibility allows an early ROI.\n\n\n### Sprint Retrospective\n\n_Please document here topics to the Sprint Retrospective meeting_\n\n* Time boxed (3 h).\n* After Sprint Review, will be moderated by Scrum Master.\n* The team discusses the sprint: what went well, what needs to be improved to be more productive for the next sprint or even have more fun.\n
\.


--
-- Data for Name: wiki_pages; Type: TABLE DATA; Schema: backup_preview_5; Owner: -
--

COPY backup_preview_5.wiki_pages (id, wiki_id, title, created_at, protected, parent_id, slug, updated_at, author_id, text, lock_version) FROM stdin;
1	2	Sprint 1	2023-07-26 09:22:08.797831+01	f	\N	sprint-1	2023-07-26 09:22:08.797831+01	1	### Sprint planning meeting\n\n_Please document here topics to the Sprint planning meeting_\n\n* Time boxed (8 h)\n* Input: Product Backlog\n* Output: Sprint Backlog\n\n* Divided into two additional time boxes of 4 h:\n\n    * The Product Owner presents the [Product Backlog]({{opSetting:base_url}}/projects/your-scrum-project/backlogs) and the priorities to the team and explains the Sprint Goal, to which the team must agree. Together, they prioritize the topics from the Product Backlog which the team will take care of in the next sprint. The team commits to the discussed delivery.\n    * The team plans autonomously (without the Product Owner) in detail and breaks down the tasks from the discussed requirements to consolidate a [Sprint Backlog]({{opSetting:base_url}}/projects/your-scrum-project/backlogs).\n\n\n### Daily Scrum meeting\n\n_Please document here topics to the Daily Scrum meeting_\n\n* Short, daily status meeting of the team.\n* Time boxed (max. 15 min).\n* Stand-up meeting to discuss the following topics from the [Task board](/projects/your-scrum-project/sprints/3/taskboard).\n    * What do I plan to do until the next Daily Scrum?\n    * What has blocked my work (Impediments)?\n* Scrum Master moderates and notes down [Sprint Impediments](/projects/your-scrum-project/sprints/3/taskboard).\n* Product Owner may participate may participate in order to stay informed.\n\n### Sprint Review meeting\n\n_Please document here topics to the Sprint Review meeting_\n\n* Time boxed (4 h).\n* A maximum of one hour of preparation time per person.\n* The team shows the product owner and other interested persons what has been achieved in this sprint.\n* Important: no dummies and no PowerPoint! Just finished product functionality (Increments) should be demonstrated.\n* Feedback from Product Owner, stakeholders and others is desired and will be included in further work.\n* Based on the demonstrated functionalities, the Product Owner decides to go live with this increment or to develop it further. This possibility allows an early ROI.\n\n\n### Sprint Retrospective\n\n_Please document here topics to the Sprint Retrospective meeting_\n\n* Time boxed (3 h).\n* After Sprint Review, will be moderated by Scrum Master.\n* The team discusses the sprint: what went well, what needs to be improved to be more productive for the next sprint or even have more fun.\n	0
2	2	Wiki	2023-07-26 09:22:08.887046+01	f	\N	wiki	2023-07-26 09:22:08.887046+01	4	### Sprint planning meeting\n\n_Please document here topics to the Sprint planning meeting_\n\n* Time boxed (8 h)\n* Input: Product Backlog\n* Output: Sprint Backlog\n\n* Divided into two additional time boxes of 4 h:\n\n    * The Product Owner presents the [Product Backlog]({{opSetting:base_url}}/projects/your-scrum-project/backlogs) and the priorities to the team and explains the Sprint Goal, to which the team must agree. Together, they prioritize the topics from the Product Backlog which the team will take care of in the next sprint. The team commits to the discussed delivery.\n    * The team plans autonomously (without the Product Owner) in detail and breaks down the tasks from the discussed requirements to consolidate a [Sprint Backlog]({{opSetting:base_url}}/projects/your-scrum-project/backlogs).\n\n\n### Daily Scrum meeting\n\n_Please document here topics to the Daily Scrum meeting_\n\n* Short, daily status meeting of the team.\n* Time boxed (max. 15 min).\n* Stand-up meeting to discuss the following topics from the Task board.\n    * What do I plan to do until the next Daily Scrum?\n    * What has blocked my work (Impediments)?\n* Scrum Master moderates and notes down Sprint Impediments.\n* Product Owner may participate may participate in order to stay informed.\n\n### Sprint Review meeting\n\n_Please document here topics to the Sprint Review meeting_\n\n* Time boxed (4 h).\n* A maximum of one hour of preparation time per person.\n* The team shows the product owner and other interested persons what has been achieved in this sprint.\n* Important: no dummies and no PowerPoint! Just finished product functionality (Increments) should be demonstrated.\n* Feedback from Product Owner, stakeholders and others is desired and will be included in further work.\n* Based on the demonstrated functionalities, the Product Owner decides to go live with this increment or to develop it further. This possibility allows an early ROI.\n\n\n### Sprint Retrospective\n\n_Please document here topics to the Sprint Retrospective meeting_\n\n* Time boxed (3 h).\n* After Sprint Review, will be moderated by Scrum Master.\n* The team discusses the sprint: what went well, what needs to be improved to be more productive for the next sprint or even have more fun.\n	0
\.


--
-- Data for Name: wiki_redirects; Type: TABLE DATA; Schema: backup_preview_5; Owner: -
--

COPY backup_preview_5.wiki_redirects (id, wiki_id, title, redirects_to, created_at) FROM stdin;
\.


--
-- Data for Name: wikis; Type: TABLE DATA; Schema: backup_preview_5; Owner: -
--

COPY backup_preview_5.wikis (id, project_id, start_page, status, created_at, updated_at) FROM stdin;
1	1	Wiki	1	2023-07-26 09:22:07.614753+01	2023-07-26 09:22:07.614753+01
2	2	Wiki	1	2023-07-26 09:22:08.703902+01	2023-07-26 09:22:08.887882+01
\.


--
-- Data for Name: work_package_hierarchies; Type: TABLE DATA; Schema: backup_preview_5; Owner: -
--

COPY backup_preview_5.work_package_hierarchies (ancestor_id, descendant_id, generations) FROM stdin;
1	1	0
2	2	0
3	3	0
2	3	1
4	4	0
3	4	1
2	4	2
5	5	0
3	5	1
2	5	2
6	6	0
3	6	1
2	6	2
7	7	0
2	7	1
8	8	0
2	8	1
9	9	0
10	10	0
11	11	0
10	11	1
12	12	0
10	12	1
13	13	0
14	14	0
15	15	0
16	16	0
17	17	0
16	17	1
18	18	0
16	18	1
19	19	0
16	19	1
20	20	0
19	20	1
16	20	2
21	21	0
22	22	0
23	23	0
22	23	1
24	24	0
25	25	0
26	26	0
27	27	0
28	28	0
29	29	0
28	29	1
30	30	0
31	31	0
32	32	0
33	33	0
34	34	0
35	35	0
36	36	0
\.


--
-- Data for Name: work_package_journals; Type: TABLE DATA; Schema: backup_preview_5; Owner: -
--

COPY backup_preview_5.work_package_journals (id, type_id, project_id, subject, description, due_date, category_id, status_id, assigned_to_id, priority_id, version_id, author_id, done_ratio, estimated_hours, start_date, parent_id, responsible_id, budget_id, story_points, remaining_hours, derived_estimated_hours, schedule_manually, duration, ignore_non_working_days) FROM stdin;
1	2	1	Start of project		2023-07-23	\N	12	4	8	\N	4	0	\N	2023-07-23	\N	\N	\N	\N	\N	\N	f	1	t
5	1	1	Send invitation to speakers		2023-07-24	\N	7	4	8	\N	4	0	\N	2023-07-24	3	\N	\N	\N	\N	\N	f	1	f
7	1	1	Contact sponsoring partners		2023-07-25	\N	1	4	8	\N	4	0	\N	2023-07-24	3	\N	\N	\N	\N	\N	f	2	f
9	1	1	Create sponsorship brochure and hand-outs		2023-07-27	\N	1	4	8	\N	4	0	\N	2023-07-24	3	\N	\N	\N	\N	\N	f	4	f
11	1	1	Set date and location of conference		2023-07-27	\N	7	4	8	\N	4	0	\N	2023-07-24	2	\N	\N	\N	\N	\N	f	4	f
13	1	1	Invite attendees to conference		2023-07-28	\N	1	4	8	\N	4	0	\N	2023-07-28	2	\N	\N	\N	\N	\N	f	1	f
15	1	1	Setup conference website		2023-08-07	\N	1	4	8	\N	4	0	\N	2023-07-28	2	\N	\N	\N	\N	\N	f	7	f
16	3	1	Organize open source conference		2023-08-07	\N	7	4	8	\N	4	0	\N	2023-07-24	\N	\N	\N	\N	\N	\N	f	11	f
17	2	1	Conference		2023-08-08	\N	6	4	8	\N	4	0	\N	2023-08-08	\N	\N	\N	\N	\N	\N	f	1	f
20	1	1	Upload presentations to website		2023-08-23	\N	1	4	8	\N	4	0	\N	2023-08-14	10	\N	\N	\N	\N	\N	f	8	f
22	1	1	Party for conference supporters :-)	*   [ ] Beer\n*   [ ] Snacks\n*   [ ] Music\n*   [ ] Even more beer	2023-08-24	\N	1	4	8	\N	4	0	\N	2023-08-24	10	\N	\N	\N	\N	\N	f	1	f
23	3	1	Follow-up tasks		2023-08-24	\N	5	4	8	\N	4	0	\N	2023-08-14	\N	\N	\N	\N	\N	\N	f	9	f
24	2	1	End of project		2023-08-25	\N	1	4	8	\N	4	0	\N	2023-08-25	\N	\N	\N	\N	\N	\N	f	1	f
25	6	2	New login screen		\N	\N	2	4	8	2	4	0	\N	2023-07-24	\N	\N	\N	\N	\N	\N	f	\N	f
26	7	2	Password reset does not send email		\N	\N	4	4	8	1	4	0	\N	2023-07-24	\N	\N	\N	\N	\N	\N	f	\N	f
29	6	2	Newsletter registration form		\N	\N	7	4	8	2	4	0	\N	2023-07-24	16	\N	\N	\N	\N	\N	f	\N	f
31	6	2	Implement product tour		\N	\N	2	4	8	2	4	0	\N	2023-07-24	16	\N	\N	\N	\N	\N	f	\N	f
34	1	2	Create wireframes for new landing page		2023-08-21	\N	7	4	8	3	4	0	\N	2023-08-21	19	\N	\N	\N	\N	\N	f	1	f
36	6	2	New landing page		2023-08-21	\N	3	4	8	3	4	0	\N	2023-08-21	16	\N	\N	3	\N	\N	f	1	f
37	5	2	New website		2023-08-21	\N	3	4	8	\N	4	0	\N	2023-07-24	\N	\N	\N	\N	\N	\N	f	21	f
38	6	2	Contact form		2023-08-14	\N	3	4	8	3	4	0	\N	2023-08-14	\N	\N	\N	1	\N	\N	f	1	f
41	1	2	Make screenshots for feature tour		\N	\N	12	4	8	3	4	0	\N	2023-07-24	22	\N	\N	\N	\N	\N	f	\N	f
42	6	2	Feature carousel		\N	\N	3	4	8	3	4	0	\N	2023-07-24	\N	\N	\N	5	\N	\N	f	\N	f
43	7	2	Wrong hover color		2023-08-14	\N	14	4	8	3	4	0	\N	2023-08-14	\N	\N	\N	1	\N	\N	f	1	f
44	6	2	SSL certificate		2023-08-15	\N	3	4	8	2	4	0	\N	2023-08-15	\N	\N	\N	\N	\N	\N	f	1	f
45	6	2	Set-up Staging environment		2023-08-16	\N	2	4	8	2	4	0	\N	2023-08-16	\N	\N	\N	\N	\N	\N	f	1	f
46	6	2	Choose a content management system		2023-08-17	\N	3	4	8	2	4	0	\N	2023-08-17	\N	\N	\N	\N	\N	\N	f	1	f
49	1	2	Set up navigation concept for website.		2023-08-18	\N	2	4	8	3	4	0	\N	2023-08-18	28	\N	\N	\N	\N	\N	f	1	f
50	6	2	Website navigation structure		2023-08-18	\N	3	4	8	3	4	0	\N	2023-08-18	\N	\N	\N	3	\N	\N	f	1	f
51	6	2	Internal link structure		2023-08-18	\N	12	4	8	2	4	0	\N	2023-08-18	\N	\N	\N	\N	\N	\N	f	1	f
52	3	2	Develop v1.0		2023-08-09	\N	7	4	8	\N	4	0	\N	2023-08-07	\N	\N	\N	\N	\N	\N	f	3	f
53	2	2	Release v1.0		2023-08-11	\N	1	4	8	\N	4	0	\N	2023-08-11	\N	\N	\N	\N	\N	\N	f	1	f
54	3	2	Develop v1.1		2023-08-16	\N	1	4	8	\N	4	0	\N	2023-08-14	\N	\N	\N	\N	\N	\N	f	3	f
55	2	2	Release v1.1		2023-08-18	\N	1	4	8	\N	4	0	\N	2023-08-18	\N	\N	\N	\N	\N	\N	f	1	f
56	3	2	Develop v2.0		2023-08-23	\N	1	4	8	\N	4	0	\N	2023-08-21	\N	\N	\N	\N	\N	\N	f	3	f
57	2	2	Release v2.0		2023-08-25	\N	1	4	8	\N	4	0	\N	2023-08-25	\N	\N	\N	\N	\N	\N	f	1	f
58	3	1	Organize open source conference		2023-08-07	\N	7	4	8	\N	4	0	\N	2023-07-24	\N	\N	\N	\N	\N	\N	f	11	f
\.


--
-- Data for Name: work_packages; Type: TABLE DATA; Schema: backup_preview_5; Owner: -
--

COPY backup_preview_5.work_packages (id, type_id, project_id, subject, description, due_date, category_id, status_id, assigned_to_id, priority_id, version_id, author_id, lock_version, done_ratio, estimated_hours, created_at, updated_at, start_date, responsible_id, budget_id, "position", story_points, remaining_hours, derived_estimated_hours, schedule_manually, parent_id, duration, ignore_non_working_days) FROM stdin;
1	2	1	Start of project	\N	2023-07-23	\N	12	4	8	\N	4	0	0	\N	2023-07-26 09:22:07.861971+01	2023-07-26 09:22:07.861971+01	2023-07-23	\N	\N	1	\N	\N	\N	f	\N	1	t
4	1	1	Send invitation to speakers		2023-07-24	\N	7	4	8	\N	4	1	0	\N	2023-07-26 09:22:07.98944+01	2023-07-26 09:22:08.022222+01	2023-07-24	\N	\N	1	\N	\N	\N	f	3	1	f
5	1	1	Contact sponsoring partners		2023-07-25	\N	1	4	8	\N	4	1	0	\N	2023-07-26 09:22:08.04898+01	2023-07-26 09:22:08.076017+01	2023-07-24	\N	\N	1	\N	\N	\N	f	3	2	f
6	1	1	Create sponsorship brochure and hand-outs		2023-07-27	\N	1	4	8	\N	4	1	0	\N	2023-07-26 09:22:08.099198+01	2023-07-26 09:22:08.133985+01	2023-07-24	\N	\N	1	\N	\N	\N	f	3	4	f
3	1	1	Set date and location of conference		2023-07-27	\N	7	4	8	\N	4	1	0	\N	2023-07-26 09:22:07.963258+01	2023-07-26 09:22:08.175837+01	2023-07-24	\N	\N	1	\N	\N	\N	f	2	4	f
7	1	1	Invite attendees to conference		2023-07-28	\N	1	4	8	\N	4	1	0	\N	2023-07-26 09:22:08.211407+01	2023-07-26 09:22:08.244611+01	2023-07-28	\N	\N	1	\N	\N	\N	f	2	1	f
8	1	1	Setup conference website		2023-08-07	\N	1	4	8	\N	4	1	0	\N	2023-07-26 09:22:08.271391+01	2023-07-26 09:22:08.299354+01	2023-07-28	\N	\N	1	\N	\N	\N	f	2	7	f
9	2	1	Conference		2023-08-08	\N	6	4	8	\N	4	0	0	\N	2023-07-26 09:22:08.34986+01	2023-07-26 09:22:08.34986+01	2023-08-08	\N	\N	1	\N	\N	\N	f	\N	1	f
10	3	1	Follow-up tasks		2023-08-24	\N	5	4	8	\N	4	0	0	\N	2023-07-26 09:22:08.382407+01	2023-07-26 09:22:08.382407+01	2023-08-14	\N	\N	1	\N	\N	\N	f	\N	9	f
11	1	1	Upload presentations to website		2023-08-23	\N	1	4	8	\N	4	1	0	\N	2023-07-26 09:22:08.40803+01	2023-07-26 09:22:08.440139+01	2023-08-14	\N	\N	1	\N	\N	\N	f	10	8	f
12	1	1	Party for conference supporters :-)	*   [ ] Beer\n*   [ ] Snacks\n*   [ ] Music\n*   [ ] Even more beer	2023-08-24	\N	1	4	8	\N	4	1	0	\N	2023-07-26 09:22:08.473451+01	2023-07-26 09:22:08.500926+01	2023-08-24	\N	\N	1	\N	\N	\N	f	10	1	f
13	2	1	End of project	\N	2023-08-25	\N	1	4	8	\N	4	0	0	\N	2023-07-26 09:22:08.536543+01	2023-07-26 09:22:08.536543+01	2023-08-25	\N	\N	1	\N	\N	\N	f	\N	1	f
15	7	2	Password reset does not send email	\N	\N	\N	4	4	8	1	4	0	0	\N	2023-07-26 09:22:08.953453+01	2023-07-26 09:22:08.953453+01	2023-07-24	\N	\N	1	\N	\N	\N	f	\N	\N	f
16	5	2	New website	\N	2023-08-21	\N	3	4	8	\N	4	0	0	\N	2023-07-26 09:22:08.985574+01	2023-07-26 09:22:08.985574+01	2023-07-24	\N	\N	1	\N	\N	\N	f	\N	21	f
20	1	2	Create wireframes for new landing page	\N	2023-08-21	\N	7	4	8	3	4	1	0	\N	2023-07-26 09:22:09.163901+01	2023-07-26 09:22:09.191765+01	2023-08-21	\N	\N	1	\N	\N	\N	f	19	1	f
19	6	2	New landing page	\N	2023-08-21	\N	3	4	8	3	4	1	0	\N	2023-07-26 09:22:09.133711+01	2023-07-26 09:22:09.232877+01	2023-08-21	\N	\N	2	3	\N	\N	f	16	1	f
22	6	2	Feature carousel	\N	\N	\N	3	4	8	3	4	0	0	\N	2023-07-26 09:22:09.315148+01	2023-07-26 09:22:09.315148+01	2023-07-24	\N	\N	3	5	\N	\N	f	\N	\N	f
23	1	2	Make screenshots for feature tour	\N	\N	\N	12	4	8	3	4	1	0	\N	2023-07-26 09:22:09.346099+01	2023-07-26 09:22:09.376658+01	2023-07-24	\N	\N	1	\N	\N	\N	f	22	\N	f
24	7	2	Wrong hover color	\N	2023-08-14	\N	14	4	8	3	4	0	0	\N	2023-07-26 09:22:09.419672+01	2023-07-26 09:22:09.419672+01	2023-08-14	\N	\N	4	1	\N	\N	f	\N	1	f
25	6	2	SSL certificate	\N	2023-08-15	\N	3	4	8	2	4	0	0	\N	2023-07-26 09:22:09.451078+01	2023-07-26 09:22:09.451078+01	2023-08-15	\N	\N	1	\N	\N	\N	f	\N	1	f
26	6	2	Set-up Staging environment	\N	2023-08-16	\N	2	4	8	2	4	0	0	\N	2023-07-26 09:22:09.489023+01	2023-07-26 09:22:09.489023+01	2023-08-16	\N	\N	2	\N	\N	\N	f	\N	1	f
21	6	2	Contact form	\N	2023-08-14	\N	3	4	8	3	4	0	0	\N	2023-07-26 09:22:09.28385+01	2023-07-26 09:22:09.28385+01	2023-08-14	\N	\N	8	1	\N	\N	f	\N	1	f
28	6	2	Website navigation structure	\N	2023-08-18	\N	3	4	8	3	4	0	0	\N	2023-07-26 09:22:09.560194+01	2023-07-26 09:22:09.560194+01	2023-08-18	\N	\N	7	3	\N	\N	f	\N	1	f
29	1	2	Set up navigation concept for website.	\N	2023-08-18	\N	2	4	8	3	4	1	0	\N	2023-07-26 09:22:09.588829+01	2023-07-26 09:22:09.616727+01	2023-08-18	\N	\N	1	\N	\N	\N	f	28	1	f
14	6	2	New login screen	\N	\N	\N	2	4	8	2	4	0	0	\N	2023-07-26 09:22:08.914479+01	2023-07-26 09:22:08.914479+01	2023-07-24	\N	\N	6	\N	\N	\N	f	\N	\N	f
17	6	2	Newsletter registration form	\N	\N	\N	7	4	8	2	4	1	0	\N	2023-07-26 09:22:09.00801+01	2023-07-26 09:22:09.046689+01	2023-07-24	\N	\N	11	\N	\N	\N	f	16	\N	f
18	6	2	Implement product tour	\N	\N	\N	2	4	8	2	4	1	0	\N	2023-07-26 09:22:09.074143+01	2023-07-26 09:22:09.106608+01	2023-07-24	\N	\N	7	\N	\N	\N	f	16	\N	f
27	6	2	Choose a content management system	\N	2023-08-17	\N	3	4	8	2	4	0	0	\N	2023-07-26 09:22:09.525581+01	2023-07-26 09:22:09.525581+01	2023-08-17	\N	\N	8	\N	\N	\N	f	\N	1	f
30	6	2	Internal link structure	\N	2023-08-18	\N	12	4	8	2	4	0	0	\N	2023-07-26 09:22:09.655628+01	2023-07-26 09:22:09.655628+01	2023-08-18	\N	\N	5	\N	\N	\N	f	\N	1	f
31	3	2	Develop v1.0	\N	2023-08-09	\N	7	4	8	\N	4	0	0	\N	2023-07-26 09:22:09.685346+01	2023-07-26 09:22:09.685346+01	2023-08-07	\N	\N	1	\N	\N	\N	f	\N	3	f
32	2	2	Release v1.0	\N	2023-08-11	\N	1	4	8	\N	4	0	0	\N	2023-07-26 09:22:09.712085+01	2023-07-26 09:22:09.712085+01	2023-08-11	\N	\N	1	\N	\N	\N	f	\N	1	f
33	3	2	Develop v1.1	\N	2023-08-16	\N	1	4	8	\N	4	0	0	\N	2023-07-26 09:22:09.744906+01	2023-07-26 09:22:09.744906+01	2023-08-14	\N	\N	1	\N	\N	\N	f	\N	3	f
34	2	2	Release v1.1	\N	2023-08-18	\N	1	4	8	\N	4	0	0	\N	2023-07-26 09:22:09.771828+01	2023-07-26 09:22:09.771828+01	2023-08-18	\N	\N	1	\N	\N	\N	f	\N	1	f
35	3	2	Develop v2.0	\N	2023-08-23	\N	1	4	8	\N	4	0	0	\N	2023-07-26 09:22:09.799192+01	2023-07-26 09:22:09.799192+01	2023-08-21	\N	\N	1	\N	\N	\N	f	\N	3	f
36	2	2	Release v2.0	\N	2023-08-25	\N	1	4	8	\N	4	0	0	\N	2023-07-26 09:22:09.828692+01	2023-07-26 09:22:09.828692+01	2023-08-25	\N	\N	1	\N	\N	\N	f	\N	1	f
2	3	1	Organize open source conference		2023-08-07	\N	7	4	8	\N	4	0	0	\N	2023-07-26 09:22:07.933492+01	2023-07-30 22:45:37.910753+01	2023-07-24	\N	\N	1	\N	\N	\N	f	\N	11	f
\.


--
-- Data for Name: workflows; Type: TABLE DATA; Schema: backup_preview_5; Owner: -
--

COPY backup_preview_5.workflows (id, type_id, old_status_id, new_status_id, role_id, assignee, author) FROM stdin;
1	1	1	1	3	f	f
2	1	1	1	5	f	f
3	1	1	7	3	f	f
4	1	1	7	5	f	f
5	1	1	13	3	f	f
6	1	1	13	5	f	f
7	1	1	14	3	f	f
8	1	1	14	5	f	f
9	1	1	12	3	f	f
10	1	1	12	5	f	f
11	1	7	1	3	f	f
12	1	7	1	5	f	f
13	1	7	7	3	f	f
14	1	7	7	5	f	f
15	1	7	13	3	f	f
16	1	7	13	5	f	f
17	1	7	14	3	f	f
18	1	7	14	5	f	f
19	1	7	12	3	f	f
20	1	7	12	5	f	f
21	1	13	1	3	f	f
22	1	13	1	5	f	f
23	1	13	7	3	f	f
24	1	13	7	5	f	f
25	1	13	13	3	f	f
26	1	13	13	5	f	f
27	1	13	14	3	f	f
28	1	13	14	5	f	f
29	1	13	12	3	f	f
30	1	13	12	5	f	f
31	1	14	1	3	f	f
32	1	14	1	5	f	f
33	1	14	7	3	f	f
34	1	14	7	5	f	f
35	1	14	13	3	f	f
36	1	14	13	5	f	f
37	1	14	14	3	f	f
38	1	14	14	5	f	f
39	1	14	12	3	f	f
40	1	14	12	5	f	f
41	1	12	1	3	f	f
42	1	12	1	5	f	f
43	1	12	7	3	f	f
44	1	12	7	5	f	f
45	1	12	13	3	f	f
46	1	12	13	5	f	f
47	1	12	14	3	f	f
48	1	12	14	5	f	f
49	1	12	12	3	f	f
50	1	12	12	5	f	f
51	2	1	1	3	f	f
52	2	1	1	5	f	f
53	2	1	5	3	f	f
54	2	1	5	5	f	f
55	2	1	6	3	f	f
56	2	1	6	5	f	f
57	2	1	7	3	f	f
58	2	1	7	5	f	f
59	2	1	13	3	f	f
60	2	1	13	5	f	f
61	2	1	14	3	f	f
62	2	1	14	5	f	f
63	2	1	12	3	f	f
64	2	1	12	5	f	f
65	2	5	1	3	f	f
66	2	5	1	5	f	f
67	2	5	5	3	f	f
68	2	5	5	5	f	f
69	2	5	6	3	f	f
70	2	5	6	5	f	f
71	2	5	7	3	f	f
72	2	5	7	5	f	f
73	2	5	13	3	f	f
74	2	5	13	5	f	f
75	2	5	14	3	f	f
76	2	5	14	5	f	f
77	2	5	12	3	f	f
78	2	5	12	5	f	f
79	2	6	1	3	f	f
80	2	6	1	5	f	f
81	2	6	5	3	f	f
82	2	6	5	5	f	f
83	2	6	6	3	f	f
84	2	6	6	5	f	f
85	2	6	7	3	f	f
86	2	6	7	5	f	f
87	2	6	13	3	f	f
88	2	6	13	5	f	f
89	2	6	14	3	f	f
90	2	6	14	5	f	f
91	2	6	12	3	f	f
92	2	6	12	5	f	f
93	2	7	1	3	f	f
94	2	7	1	5	f	f
95	2	7	5	3	f	f
96	2	7	5	5	f	f
97	2	7	6	3	f	f
98	2	7	6	5	f	f
99	2	7	7	3	f	f
100	2	7	7	5	f	f
101	2	7	13	3	f	f
102	2	7	13	5	f	f
103	2	7	14	3	f	f
104	2	7	14	5	f	f
105	2	7	12	3	f	f
106	2	7	12	5	f	f
107	2	13	1	3	f	f
108	2	13	1	5	f	f
109	2	13	5	3	f	f
110	2	13	5	5	f	f
111	2	13	6	3	f	f
112	2	13	6	5	f	f
113	2	13	7	3	f	f
114	2	13	7	5	f	f
115	2	13	13	3	f	f
116	2	13	13	5	f	f
117	2	13	14	3	f	f
118	2	13	14	5	f	f
119	2	13	12	3	f	f
120	2	13	12	5	f	f
121	2	14	1	3	f	f
122	2	14	1	5	f	f
123	2	14	5	3	f	f
124	2	14	5	5	f	f
125	2	14	6	3	f	f
126	2	14	6	5	f	f
127	2	14	7	3	f	f
128	2	14	7	5	f	f
129	2	14	13	3	f	f
130	2	14	13	5	f	f
131	2	14	14	3	f	f
132	2	14	14	5	f	f
133	2	14	12	3	f	f
134	2	14	12	5	f	f
135	2	12	1	3	f	f
136	2	12	1	5	f	f
137	2	12	5	3	f	f
138	2	12	5	5	f	f
139	2	12	6	3	f	f
140	2	12	6	5	f	f
141	2	12	7	3	f	f
142	2	12	7	5	f	f
143	2	12	13	3	f	f
144	2	12	13	5	f	f
145	2	12	14	3	f	f
146	2	12	14	5	f	f
147	2	12	12	3	f	f
148	2	12	12	5	f	f
149	3	1	1	3	f	f
150	3	1	1	5	f	f
151	3	1	5	3	f	f
152	3	1	5	5	f	f
153	3	1	6	3	f	f
154	3	1	6	5	f	f
155	3	1	7	3	f	f
156	3	1	7	5	f	f
157	3	1	13	3	f	f
158	3	1	13	5	f	f
159	3	1	14	3	f	f
160	3	1	14	5	f	f
161	3	1	12	3	f	f
162	3	1	12	5	f	f
163	3	5	1	3	f	f
164	3	5	1	5	f	f
165	3	5	5	3	f	f
166	3	5	5	5	f	f
167	3	5	6	3	f	f
168	3	5	6	5	f	f
169	3	5	7	3	f	f
170	3	5	7	5	f	f
171	3	5	13	3	f	f
172	3	5	13	5	f	f
173	3	5	14	3	f	f
174	3	5	14	5	f	f
175	3	5	12	3	f	f
176	3	5	12	5	f	f
177	3	6	1	3	f	f
178	3	6	1	5	f	f
179	3	6	5	3	f	f
180	3	6	5	5	f	f
181	3	6	6	3	f	f
182	3	6	6	5	f	f
183	3	6	7	3	f	f
184	3	6	7	5	f	f
185	3	6	13	3	f	f
186	3	6	13	5	f	f
187	3	6	14	3	f	f
188	3	6	14	5	f	f
189	3	6	12	3	f	f
190	3	6	12	5	f	f
191	3	7	1	3	f	f
192	3	7	1	5	f	f
193	3	7	5	3	f	f
194	3	7	5	5	f	f
195	3	7	6	3	f	f
196	3	7	6	5	f	f
197	3	7	7	3	f	f
198	3	7	7	5	f	f
199	3	7	13	3	f	f
200	3	7	13	5	f	f
201	3	7	14	3	f	f
202	3	7	14	5	f	f
203	3	7	12	3	f	f
204	3	7	12	5	f	f
205	3	13	1	3	f	f
206	3	13	1	5	f	f
207	3	13	5	3	f	f
208	3	13	5	5	f	f
209	3	13	6	3	f	f
210	3	13	6	5	f	f
211	3	13	7	3	f	f
212	3	13	7	5	f	f
213	3	13	13	3	f	f
214	3	13	13	5	f	f
215	3	13	14	3	f	f
216	3	13	14	5	f	f
217	3	13	12	3	f	f
218	3	13	12	5	f	f
219	3	14	1	3	f	f
220	3	14	1	5	f	f
221	3	14	5	3	f	f
222	3	14	5	5	f	f
223	3	14	6	3	f	f
224	3	14	6	5	f	f
225	3	14	7	3	f	f
226	3	14	7	5	f	f
227	3	14	13	3	f	f
228	3	14	13	5	f	f
229	3	14	14	3	f	f
230	3	14	14	5	f	f
231	3	14	12	3	f	f
232	3	14	12	5	f	f
233	3	12	1	3	f	f
234	3	12	1	5	f	f
235	3	12	5	3	f	f
236	3	12	5	5	f	f
237	3	12	6	3	f	f
238	3	12	6	5	f	f
239	3	12	7	3	f	f
240	3	12	7	5	f	f
241	3	12	13	3	f	f
242	3	12	13	5	f	f
243	3	12	14	3	f	f
244	3	12	14	5	f	f
245	3	12	12	3	f	f
246	3	12	12	5	f	f
247	4	1	1	3	f	f
248	4	1	1	5	f	f
249	4	1	2	3	f	f
250	4	1	2	5	f	f
251	4	1	3	3	f	f
252	4	1	3	5	f	f
253	4	1	7	3	f	f
254	4	1	7	5	f	f
255	4	1	8	3	f	f
256	4	1	8	5	f	f
257	4	1	9	3	f	f
258	4	1	9	5	f	f
259	4	1	10	3	f	f
260	4	1	10	5	f	f
261	4	1	11	3	f	f
262	4	1	11	5	f	f
263	4	1	13	3	f	f
264	4	1	13	5	f	f
265	4	1	14	3	f	f
266	4	1	14	5	f	f
267	4	1	12	3	f	f
268	4	1	12	5	f	f
269	4	2	1	3	f	f
270	4	2	1	5	f	f
271	4	2	2	3	f	f
272	4	2	2	5	f	f
273	4	2	3	3	f	f
274	4	2	3	5	f	f
275	4	2	7	3	f	f
276	4	2	7	5	f	f
277	4	2	8	3	f	f
278	4	2	8	5	f	f
279	4	2	9	3	f	f
280	4	2	9	5	f	f
281	4	2	10	3	f	f
282	4	2	10	5	f	f
283	4	2	11	3	f	f
284	4	2	11	5	f	f
285	4	2	13	3	f	f
286	4	2	13	5	f	f
287	4	2	14	3	f	f
288	4	2	14	5	f	f
289	4	2	12	3	f	f
290	4	2	12	5	f	f
291	4	3	1	3	f	f
292	4	3	1	5	f	f
293	4	3	2	3	f	f
294	4	3	2	5	f	f
295	4	3	3	3	f	f
296	4	3	3	5	f	f
297	4	3	7	3	f	f
298	4	3	7	5	f	f
299	4	3	8	3	f	f
300	4	3	8	5	f	f
301	4	3	9	3	f	f
302	4	3	9	5	f	f
303	4	3	10	3	f	f
304	4	3	10	5	f	f
305	4	3	11	3	f	f
306	4	3	11	5	f	f
307	4	3	13	3	f	f
308	4	3	13	5	f	f
309	4	3	14	3	f	f
310	4	3	14	5	f	f
311	4	3	12	3	f	f
312	4	3	12	5	f	f
313	4	7	1	3	f	f
314	4	7	1	5	f	f
315	4	7	2	3	f	f
316	4	7	2	5	f	f
317	4	7	3	3	f	f
318	4	7	3	5	f	f
319	4	7	7	3	f	f
320	4	7	7	5	f	f
321	4	7	8	3	f	f
322	4	7	8	5	f	f
323	4	7	9	3	f	f
324	4	7	9	5	f	f
325	4	7	10	3	f	f
326	4	7	10	5	f	f
327	4	7	11	3	f	f
328	4	7	11	5	f	f
329	4	7	13	3	f	f
330	4	7	13	5	f	f
331	4	7	14	3	f	f
332	4	7	14	5	f	f
333	4	7	12	3	f	f
334	4	7	12	5	f	f
335	4	8	1	3	f	f
336	4	8	1	5	f	f
337	4	8	2	3	f	f
338	4	8	2	5	f	f
339	4	8	3	3	f	f
340	4	8	3	5	f	f
341	4	8	7	3	f	f
342	4	8	7	5	f	f
343	4	8	8	3	f	f
344	4	8	8	5	f	f
345	4	8	9	3	f	f
346	4	8	9	5	f	f
347	4	8	10	3	f	f
348	4	8	10	5	f	f
349	4	8	11	3	f	f
350	4	8	11	5	f	f
351	4	8	13	3	f	f
352	4	8	13	5	f	f
353	4	8	14	3	f	f
354	4	8	14	5	f	f
355	4	8	12	3	f	f
356	4	8	12	5	f	f
357	4	9	1	3	f	f
358	4	9	1	5	f	f
359	4	9	2	3	f	f
360	4	9	2	5	f	f
361	4	9	3	3	f	f
362	4	9	3	5	f	f
363	4	9	7	3	f	f
364	4	9	7	5	f	f
365	4	9	8	3	f	f
366	4	9	8	5	f	f
367	4	9	9	3	f	f
368	4	9	9	5	f	f
369	4	9	10	3	f	f
370	4	9	10	5	f	f
371	4	9	11	3	f	f
372	4	9	11	5	f	f
373	4	9	13	3	f	f
374	4	9	13	5	f	f
375	4	9	14	3	f	f
376	4	9	14	5	f	f
377	4	9	12	3	f	f
378	4	9	12	5	f	f
379	4	10	1	3	f	f
380	4	10	1	5	f	f
381	4	10	2	3	f	f
382	4	10	2	5	f	f
383	4	10	3	3	f	f
384	4	10	3	5	f	f
385	4	10	7	3	f	f
386	4	10	7	5	f	f
387	4	10	8	3	f	f
388	4	10	8	5	f	f
389	4	10	9	3	f	f
390	4	10	9	5	f	f
391	4	10	10	3	f	f
392	4	10	10	5	f	f
393	4	10	11	3	f	f
394	4	10	11	5	f	f
395	4	10	13	3	f	f
396	4	10	13	5	f	f
397	4	10	14	3	f	f
398	4	10	14	5	f	f
399	4	10	12	3	f	f
400	4	10	12	5	f	f
401	4	11	1	3	f	f
402	4	11	1	5	f	f
403	4	11	2	3	f	f
404	4	11	2	5	f	f
405	4	11	3	3	f	f
406	4	11	3	5	f	f
407	4	11	7	3	f	f
408	4	11	7	5	f	f
409	4	11	8	3	f	f
410	4	11	8	5	f	f
411	4	11	9	3	f	f
412	4	11	9	5	f	f
413	4	11	10	3	f	f
414	4	11	10	5	f	f
415	4	11	11	3	f	f
416	4	11	11	5	f	f
417	4	11	13	3	f	f
418	4	11	13	5	f	f
419	4	11	14	3	f	f
420	4	11	14	5	f	f
421	4	11	12	3	f	f
422	4	11	12	5	f	f
423	4	13	1	3	f	f
424	4	13	1	5	f	f
425	4	13	2	3	f	f
426	4	13	2	5	f	f
427	4	13	3	3	f	f
428	4	13	3	5	f	f
429	4	13	7	3	f	f
430	4	13	7	5	f	f
431	4	13	8	3	f	f
432	4	13	8	5	f	f
433	4	13	9	3	f	f
434	4	13	9	5	f	f
435	4	13	10	3	f	f
436	4	13	10	5	f	f
437	4	13	11	3	f	f
438	4	13	11	5	f	f
439	4	13	13	3	f	f
440	4	13	13	5	f	f
441	4	13	14	3	f	f
442	4	13	14	5	f	f
443	4	13	12	3	f	f
444	4	13	12	5	f	f
445	4	14	1	3	f	f
446	4	14	1	5	f	f
447	4	14	2	3	f	f
448	4	14	2	5	f	f
449	4	14	3	3	f	f
450	4	14	3	5	f	f
451	4	14	7	3	f	f
452	4	14	7	5	f	f
453	4	14	8	3	f	f
454	4	14	8	5	f	f
455	4	14	9	3	f	f
456	4	14	9	5	f	f
457	4	14	10	3	f	f
458	4	14	10	5	f	f
459	4	14	11	3	f	f
460	4	14	11	5	f	f
461	4	14	13	3	f	f
462	4	14	13	5	f	f
463	4	14	14	3	f	f
464	4	14	14	5	f	f
465	4	14	12	3	f	f
466	4	14	12	5	f	f
467	4	12	1	3	f	f
468	4	12	1	5	f	f
469	4	12	2	3	f	f
470	4	12	2	5	f	f
471	4	12	3	3	f	f
472	4	12	3	5	f	f
473	4	12	7	3	f	f
474	4	12	7	5	f	f
475	4	12	8	3	f	f
476	4	12	8	5	f	f
477	4	12	9	3	f	f
478	4	12	9	5	f	f
479	4	12	10	3	f	f
480	4	12	10	5	f	f
481	4	12	11	3	f	f
482	4	12	11	5	f	f
483	4	12	13	3	f	f
484	4	12	13	5	f	f
485	4	12	14	3	f	f
486	4	12	14	5	f	f
487	4	12	12	3	f	f
488	4	12	12	5	f	f
489	5	1	1	3	f	f
490	5	1	1	5	f	f
491	5	1	2	3	f	f
492	5	1	2	5	f	f
493	5	1	3	3	f	f
494	5	1	3	5	f	f
495	5	1	7	3	f	f
496	5	1	7	5	f	f
497	5	1	8	3	f	f
498	5	1	8	5	f	f
499	5	1	9	3	f	f
500	5	1	9	5	f	f
501	5	1	10	3	f	f
502	5	1	10	5	f	f
503	5	1	11	3	f	f
504	5	1	11	5	f	f
505	5	1	13	3	f	f
506	5	1	13	5	f	f
507	5	1	14	3	f	f
508	5	1	14	5	f	f
509	5	1	12	3	f	f
510	5	1	12	5	f	f
511	5	2	1	3	f	f
512	5	2	1	5	f	f
513	5	2	2	3	f	f
514	5	2	2	5	f	f
515	5	2	3	3	f	f
516	5	2	3	5	f	f
517	5	2	7	3	f	f
518	5	2	7	5	f	f
519	5	2	8	3	f	f
520	5	2	8	5	f	f
521	5	2	9	3	f	f
522	5	2	9	5	f	f
523	5	2	10	3	f	f
524	5	2	10	5	f	f
525	5	2	11	3	f	f
526	5	2	11	5	f	f
527	5	2	13	3	f	f
528	5	2	13	5	f	f
529	5	2	14	3	f	f
530	5	2	14	5	f	f
531	5	2	12	3	f	f
532	5	2	12	5	f	f
533	5	3	1	3	f	f
534	5	3	1	5	f	f
535	5	3	2	3	f	f
536	5	3	2	5	f	f
537	5	3	3	3	f	f
538	5	3	3	5	f	f
539	5	3	7	3	f	f
540	5	3	7	5	f	f
541	5	3	8	3	f	f
542	5	3	8	5	f	f
543	5	3	9	3	f	f
544	5	3	9	5	f	f
545	5	3	10	3	f	f
546	5	3	10	5	f	f
547	5	3	11	3	f	f
548	5	3	11	5	f	f
549	5	3	13	3	f	f
550	5	3	13	5	f	f
551	5	3	14	3	f	f
552	5	3	14	5	f	f
553	5	3	12	3	f	f
554	5	3	12	5	f	f
555	5	7	1	3	f	f
556	5	7	1	5	f	f
557	5	7	2	3	f	f
558	5	7	2	5	f	f
559	5	7	3	3	f	f
560	5	7	3	5	f	f
561	5	7	7	3	f	f
562	5	7	7	5	f	f
563	5	7	8	3	f	f
564	5	7	8	5	f	f
565	5	7	9	3	f	f
566	5	7	9	5	f	f
567	5	7	10	3	f	f
568	5	7	10	5	f	f
569	5	7	11	3	f	f
570	5	7	11	5	f	f
571	5	7	13	3	f	f
572	5	7	13	5	f	f
573	5	7	14	3	f	f
574	5	7	14	5	f	f
575	5	7	12	3	f	f
576	5	7	12	5	f	f
577	5	8	1	3	f	f
578	5	8	1	5	f	f
579	5	8	2	3	f	f
580	5	8	2	5	f	f
581	5	8	3	3	f	f
582	5	8	3	5	f	f
583	5	8	7	3	f	f
584	5	8	7	5	f	f
585	5	8	8	3	f	f
586	5	8	8	5	f	f
587	5	8	9	3	f	f
588	5	8	9	5	f	f
589	5	8	10	3	f	f
590	5	8	10	5	f	f
591	5	8	11	3	f	f
592	5	8	11	5	f	f
593	5	8	13	3	f	f
594	5	8	13	5	f	f
595	5	8	14	3	f	f
596	5	8	14	5	f	f
597	5	8	12	3	f	f
598	5	8	12	5	f	f
599	5	9	1	3	f	f
600	5	9	1	5	f	f
601	5	9	2	3	f	f
602	5	9	2	5	f	f
603	5	9	3	3	f	f
604	5	9	3	5	f	f
605	5	9	7	3	f	f
606	5	9	7	5	f	f
607	5	9	8	3	f	f
608	5	9	8	5	f	f
609	5	9	9	3	f	f
610	5	9	9	5	f	f
611	5	9	10	3	f	f
612	5	9	10	5	f	f
613	5	9	11	3	f	f
614	5	9	11	5	f	f
615	5	9	13	3	f	f
616	5	9	13	5	f	f
617	5	9	14	3	f	f
618	5	9	14	5	f	f
619	5	9	12	3	f	f
620	5	9	12	5	f	f
621	5	10	1	3	f	f
622	5	10	1	5	f	f
623	5	10	2	3	f	f
624	5	10	2	5	f	f
625	5	10	3	3	f	f
626	5	10	3	5	f	f
627	5	10	7	3	f	f
628	5	10	7	5	f	f
629	5	10	8	3	f	f
630	5	10	8	5	f	f
631	5	10	9	3	f	f
632	5	10	9	5	f	f
633	5	10	10	3	f	f
634	5	10	10	5	f	f
635	5	10	11	3	f	f
636	5	10	11	5	f	f
637	5	10	13	3	f	f
638	5	10	13	5	f	f
639	5	10	14	3	f	f
640	5	10	14	5	f	f
641	5	10	12	3	f	f
642	5	10	12	5	f	f
643	5	11	1	3	f	f
644	5	11	1	5	f	f
645	5	11	2	3	f	f
646	5	11	2	5	f	f
647	5	11	3	3	f	f
648	5	11	3	5	f	f
649	5	11	7	3	f	f
650	5	11	7	5	f	f
651	5	11	8	3	f	f
652	5	11	8	5	f	f
653	5	11	9	3	f	f
654	5	11	9	5	f	f
655	5	11	10	3	f	f
656	5	11	10	5	f	f
657	5	11	11	3	f	f
658	5	11	11	5	f	f
659	5	11	13	3	f	f
660	5	11	13	5	f	f
661	5	11	14	3	f	f
662	5	11	14	5	f	f
663	5	11	12	3	f	f
664	5	11	12	5	f	f
665	5	13	1	3	f	f
666	5	13	1	5	f	f
667	5	13	2	3	f	f
668	5	13	2	5	f	f
669	5	13	3	3	f	f
670	5	13	3	5	f	f
671	5	13	7	3	f	f
672	5	13	7	5	f	f
673	5	13	8	3	f	f
674	5	13	8	5	f	f
675	5	13	9	3	f	f
676	5	13	9	5	f	f
677	5	13	10	3	f	f
678	5	13	10	5	f	f
679	5	13	11	3	f	f
680	5	13	11	5	f	f
681	5	13	13	3	f	f
682	5	13	13	5	f	f
683	5	13	14	3	f	f
684	5	13	14	5	f	f
685	5	13	12	3	f	f
686	5	13	12	5	f	f
687	5	14	1	3	f	f
688	5	14	1	5	f	f
689	5	14	2	3	f	f
690	5	14	2	5	f	f
691	5	14	3	3	f	f
692	5	14	3	5	f	f
693	5	14	7	3	f	f
694	5	14	7	5	f	f
695	5	14	8	3	f	f
696	5	14	8	5	f	f
697	5	14	9	3	f	f
698	5	14	9	5	f	f
699	5	14	10	3	f	f
700	5	14	10	5	f	f
701	5	14	11	3	f	f
702	5	14	11	5	f	f
703	5	14	13	3	f	f
704	5	14	13	5	f	f
705	5	14	14	3	f	f
706	5	14	14	5	f	f
707	5	14	12	3	f	f
708	5	14	12	5	f	f
709	5	12	1	3	f	f
710	5	12	1	5	f	f
711	5	12	2	3	f	f
712	5	12	2	5	f	f
713	5	12	3	3	f	f
714	5	12	3	5	f	f
715	5	12	7	3	f	f
716	5	12	7	5	f	f
717	5	12	8	3	f	f
718	5	12	8	5	f	f
719	5	12	9	3	f	f
720	5	12	9	5	f	f
721	5	12	10	3	f	f
722	5	12	10	5	f	f
723	5	12	11	3	f	f
724	5	12	11	5	f	f
725	5	12	13	3	f	f
726	5	12	13	5	f	f
727	5	12	14	3	f	f
728	5	12	14	5	f	f
729	5	12	12	3	f	f
730	5	12	12	5	f	f
731	6	1	1	3	f	f
732	6	1	1	5	f	f
733	6	1	2	3	f	f
734	6	1	2	5	f	f
735	6	1	3	3	f	f
736	6	1	3	5	f	f
737	6	1	7	3	f	f
738	6	1	7	5	f	f
739	6	1	8	3	f	f
740	6	1	8	5	f	f
741	6	1	9	3	f	f
742	6	1	9	5	f	f
743	6	1	10	3	f	f
744	6	1	10	5	f	f
745	6	1	11	3	f	f
746	6	1	11	5	f	f
747	6	1	13	3	f	f
748	6	1	13	5	f	f
749	6	1	14	3	f	f
750	6	1	14	5	f	f
751	6	1	12	3	f	f
752	6	1	12	5	f	f
753	6	2	1	3	f	f
754	6	2	1	5	f	f
755	6	2	2	3	f	f
756	6	2	2	5	f	f
757	6	2	3	3	f	f
758	6	2	3	5	f	f
759	6	2	7	3	f	f
760	6	2	7	5	f	f
761	6	2	8	3	f	f
762	6	2	8	5	f	f
763	6	2	9	3	f	f
764	6	2	9	5	f	f
765	6	2	10	3	f	f
766	6	2	10	5	f	f
767	6	2	11	3	f	f
768	6	2	11	5	f	f
769	6	2	13	3	f	f
770	6	2	13	5	f	f
771	6	2	14	3	f	f
772	6	2	14	5	f	f
773	6	2	12	3	f	f
774	6	2	12	5	f	f
775	6	3	1	3	f	f
776	6	3	1	5	f	f
777	6	3	2	3	f	f
778	6	3	2	5	f	f
779	6	3	3	3	f	f
780	6	3	3	5	f	f
781	6	3	7	3	f	f
782	6	3	7	5	f	f
783	6	3	8	3	f	f
784	6	3	8	5	f	f
785	6	3	9	3	f	f
786	6	3	9	5	f	f
787	6	3	10	3	f	f
788	6	3	10	5	f	f
789	6	3	11	3	f	f
790	6	3	11	5	f	f
791	6	3	13	3	f	f
792	6	3	13	5	f	f
793	6	3	14	3	f	f
794	6	3	14	5	f	f
795	6	3	12	3	f	f
796	6	3	12	5	f	f
797	6	7	1	3	f	f
798	6	7	1	5	f	f
799	6	7	2	3	f	f
800	6	7	2	5	f	f
801	6	7	3	3	f	f
802	6	7	3	5	f	f
803	6	7	7	3	f	f
804	6	7	7	5	f	f
805	6	7	8	3	f	f
806	6	7	8	5	f	f
807	6	7	9	3	f	f
808	6	7	9	5	f	f
809	6	7	10	3	f	f
810	6	7	10	5	f	f
811	6	7	11	3	f	f
812	6	7	11	5	f	f
813	6	7	13	3	f	f
814	6	7	13	5	f	f
815	6	7	14	3	f	f
816	6	7	14	5	f	f
817	6	7	12	3	f	f
818	6	7	12	5	f	f
819	6	8	1	3	f	f
820	6	8	1	5	f	f
821	6	8	2	3	f	f
822	6	8	2	5	f	f
823	6	8	3	3	f	f
824	6	8	3	5	f	f
825	6	8	7	3	f	f
826	6	8	7	5	f	f
827	6	8	8	3	f	f
828	6	8	8	5	f	f
829	6	8	9	3	f	f
830	6	8	9	5	f	f
831	6	8	10	3	f	f
832	6	8	10	5	f	f
833	6	8	11	3	f	f
834	6	8	11	5	f	f
835	6	8	13	3	f	f
836	6	8	13	5	f	f
837	6	8	14	3	f	f
838	6	8	14	5	f	f
839	6	8	12	3	f	f
840	6	8	12	5	f	f
841	6	9	1	3	f	f
842	6	9	1	5	f	f
843	6	9	2	3	f	f
844	6	9	2	5	f	f
845	6	9	3	3	f	f
846	6	9	3	5	f	f
847	6	9	7	3	f	f
848	6	9	7	5	f	f
849	6	9	8	3	f	f
850	6	9	8	5	f	f
851	6	9	9	3	f	f
852	6	9	9	5	f	f
853	6	9	10	3	f	f
854	6	9	10	5	f	f
855	6	9	11	3	f	f
856	6	9	11	5	f	f
857	6	9	13	3	f	f
858	6	9	13	5	f	f
859	6	9	14	3	f	f
860	6	9	14	5	f	f
861	6	9	12	3	f	f
862	6	9	12	5	f	f
863	6	10	1	3	f	f
864	6	10	1	5	f	f
865	6	10	2	3	f	f
866	6	10	2	5	f	f
867	6	10	3	3	f	f
868	6	10	3	5	f	f
869	6	10	7	3	f	f
870	6	10	7	5	f	f
871	6	10	8	3	f	f
872	6	10	8	5	f	f
873	6	10	9	3	f	f
874	6	10	9	5	f	f
875	6	10	10	3	f	f
876	6	10	10	5	f	f
877	6	10	11	3	f	f
878	6	10	11	5	f	f
879	6	10	13	3	f	f
880	6	10	13	5	f	f
881	6	10	14	3	f	f
882	6	10	14	5	f	f
883	6	10	12	3	f	f
884	6	10	12	5	f	f
885	6	11	1	3	f	f
886	6	11	1	5	f	f
887	6	11	2	3	f	f
888	6	11	2	5	f	f
889	6	11	3	3	f	f
890	6	11	3	5	f	f
891	6	11	7	3	f	f
892	6	11	7	5	f	f
893	6	11	8	3	f	f
894	6	11	8	5	f	f
895	6	11	9	3	f	f
896	6	11	9	5	f	f
897	6	11	10	3	f	f
898	6	11	10	5	f	f
899	6	11	11	3	f	f
900	6	11	11	5	f	f
901	6	11	13	3	f	f
902	6	11	13	5	f	f
903	6	11	14	3	f	f
904	6	11	14	5	f	f
905	6	11	12	3	f	f
906	6	11	12	5	f	f
907	6	13	1	3	f	f
908	6	13	1	5	f	f
909	6	13	2	3	f	f
910	6	13	2	5	f	f
911	6	13	3	3	f	f
912	6	13	3	5	f	f
913	6	13	7	3	f	f
914	6	13	7	5	f	f
915	6	13	8	3	f	f
916	6	13	8	5	f	f
917	6	13	9	3	f	f
918	6	13	9	5	f	f
919	6	13	10	3	f	f
920	6	13	10	5	f	f
921	6	13	11	3	f	f
922	6	13	11	5	f	f
923	6	13	13	3	f	f
924	6	13	13	5	f	f
925	6	13	14	3	f	f
926	6	13	14	5	f	f
927	6	13	12	3	f	f
928	6	13	12	5	f	f
929	6	14	1	3	f	f
930	6	14	1	5	f	f
931	6	14	2	3	f	f
932	6	14	2	5	f	f
933	6	14	3	3	f	f
934	6	14	3	5	f	f
935	6	14	7	3	f	f
936	6	14	7	5	f	f
937	6	14	8	3	f	f
938	6	14	8	5	f	f
939	6	14	9	3	f	f
940	6	14	9	5	f	f
941	6	14	10	3	f	f
942	6	14	10	5	f	f
943	6	14	11	3	f	f
944	6	14	11	5	f	f
945	6	14	13	3	f	f
946	6	14	13	5	f	f
947	6	14	14	3	f	f
948	6	14	14	5	f	f
949	6	14	12	3	f	f
950	6	14	12	5	f	f
951	6	12	1	3	f	f
952	6	12	1	5	f	f
953	6	12	2	3	f	f
954	6	12	2	5	f	f
955	6	12	3	3	f	f
956	6	12	3	5	f	f
957	6	12	7	3	f	f
958	6	12	7	5	f	f
959	6	12	8	3	f	f
960	6	12	8	5	f	f
961	6	12	9	3	f	f
962	6	12	9	5	f	f
963	6	12	10	3	f	f
964	6	12	10	5	f	f
965	6	12	11	3	f	f
966	6	12	11	5	f	f
967	6	12	13	3	f	f
968	6	12	13	5	f	f
969	6	12	14	3	f	f
970	6	12	14	5	f	f
971	6	12	12	3	f	f
972	6	12	12	5	f	f
973	7	1	1	3	f	f
974	7	1	1	5	f	f
975	7	1	4	3	f	f
976	7	1	4	5	f	f
977	7	1	7	3	f	f
978	7	1	7	5	f	f
979	7	1	8	3	f	f
980	7	1	8	5	f	f
981	7	1	9	3	f	f
982	7	1	9	5	f	f
983	7	1	10	3	f	f
984	7	1	10	5	f	f
985	7	1	11	3	f	f
986	7	1	11	5	f	f
987	7	1	13	3	f	f
988	7	1	13	5	f	f
989	7	1	14	3	f	f
990	7	1	14	5	f	f
991	7	1	12	3	f	f
992	7	1	12	5	f	f
993	7	4	1	3	f	f
994	7	4	1	5	f	f
995	7	4	4	3	f	f
996	7	4	4	5	f	f
997	7	4	7	3	f	f
998	7	4	7	5	f	f
999	7	4	8	3	f	f
1000	7	4	8	5	f	f
1001	7	4	9	3	f	f
1002	7	4	9	5	f	f
1003	7	4	10	3	f	f
1004	7	4	10	5	f	f
1005	7	4	11	3	f	f
1006	7	4	11	5	f	f
1007	7	4	13	3	f	f
1008	7	4	13	5	f	f
1009	7	4	14	3	f	f
1010	7	4	14	5	f	f
1011	7	4	12	3	f	f
1012	7	4	12	5	f	f
1013	7	7	1	3	f	f
1014	7	7	1	5	f	f
1015	7	7	4	3	f	f
1016	7	7	4	5	f	f
1017	7	7	7	3	f	f
1018	7	7	7	5	f	f
1019	7	7	8	3	f	f
1020	7	7	8	5	f	f
1021	7	7	9	3	f	f
1022	7	7	9	5	f	f
1023	7	7	10	3	f	f
1024	7	7	10	5	f	f
1025	7	7	11	3	f	f
1026	7	7	11	5	f	f
1027	7	7	13	3	f	f
1028	7	7	13	5	f	f
1029	7	7	14	3	f	f
1030	7	7	14	5	f	f
1031	7	7	12	3	f	f
1032	7	7	12	5	f	f
1033	7	8	1	3	f	f
1034	7	8	1	5	f	f
1035	7	8	4	3	f	f
1036	7	8	4	5	f	f
1037	7	8	7	3	f	f
1038	7	8	7	5	f	f
1039	7	8	8	3	f	f
1040	7	8	8	5	f	f
1041	7	8	9	3	f	f
1042	7	8	9	5	f	f
1043	7	8	10	3	f	f
1044	7	8	10	5	f	f
1045	7	8	11	3	f	f
1046	7	8	11	5	f	f
1047	7	8	13	3	f	f
1048	7	8	13	5	f	f
1049	7	8	14	3	f	f
1050	7	8	14	5	f	f
1051	7	8	12	3	f	f
1052	7	8	12	5	f	f
1053	7	9	1	3	f	f
1054	7	9	1	5	f	f
1055	7	9	4	3	f	f
1056	7	9	4	5	f	f
1057	7	9	7	3	f	f
1058	7	9	7	5	f	f
1059	7	9	8	3	f	f
1060	7	9	8	5	f	f
1061	7	9	9	3	f	f
1062	7	9	9	5	f	f
1063	7	9	10	3	f	f
1064	7	9	10	5	f	f
1065	7	9	11	3	f	f
1066	7	9	11	5	f	f
1067	7	9	13	3	f	f
1068	7	9	13	5	f	f
1069	7	9	14	3	f	f
1070	7	9	14	5	f	f
1071	7	9	12	3	f	f
1072	7	9	12	5	f	f
1073	7	10	1	3	f	f
1074	7	10	1	5	f	f
1075	7	10	4	3	f	f
1076	7	10	4	5	f	f
1077	7	10	7	3	f	f
1078	7	10	7	5	f	f
1079	7	10	8	3	f	f
1080	7	10	8	5	f	f
1081	7	10	9	3	f	f
1082	7	10	9	5	f	f
1083	7	10	10	3	f	f
1084	7	10	10	5	f	f
1085	7	10	11	3	f	f
1086	7	10	11	5	f	f
1087	7	10	13	3	f	f
1088	7	10	13	5	f	f
1089	7	10	14	3	f	f
1090	7	10	14	5	f	f
1091	7	10	12	3	f	f
1092	7	10	12	5	f	f
1093	7	11	1	3	f	f
1094	7	11	1	5	f	f
1095	7	11	4	3	f	f
1096	7	11	4	5	f	f
1097	7	11	7	3	f	f
1098	7	11	7	5	f	f
1099	7	11	8	3	f	f
1100	7	11	8	5	f	f
1101	7	11	9	3	f	f
1102	7	11	9	5	f	f
1103	7	11	10	3	f	f
1104	7	11	10	5	f	f
1105	7	11	11	3	f	f
1106	7	11	11	5	f	f
1107	7	11	13	3	f	f
1108	7	11	13	5	f	f
1109	7	11	14	3	f	f
1110	7	11	14	5	f	f
1111	7	11	12	3	f	f
1112	7	11	12	5	f	f
1113	7	13	1	3	f	f
1114	7	13	1	5	f	f
1115	7	13	4	3	f	f
1116	7	13	4	5	f	f
1117	7	13	7	3	f	f
1118	7	13	7	5	f	f
1119	7	13	8	3	f	f
1120	7	13	8	5	f	f
1121	7	13	9	3	f	f
1122	7	13	9	5	f	f
1123	7	13	10	3	f	f
1124	7	13	10	5	f	f
1125	7	13	11	3	f	f
1126	7	13	11	5	f	f
1127	7	13	13	3	f	f
1128	7	13	13	5	f	f
1129	7	13	14	3	f	f
1130	7	13	14	5	f	f
1131	7	13	12	3	f	f
1132	7	13	12	5	f	f
1133	7	14	1	3	f	f
1134	7	14	1	5	f	f
1135	7	14	4	3	f	f
1136	7	14	4	5	f	f
1137	7	14	7	3	f	f
1138	7	14	7	5	f	f
1139	7	14	8	3	f	f
1140	7	14	8	5	f	f
1141	7	14	9	3	f	f
1142	7	14	9	5	f	f
1143	7	14	10	3	f	f
1144	7	14	10	5	f	f
1145	7	14	11	3	f	f
1146	7	14	11	5	f	f
1147	7	14	13	3	f	f
1148	7	14	13	5	f	f
1149	7	14	14	3	f	f
1150	7	14	14	5	f	f
1151	7	14	12	3	f	f
1152	7	14	12	5	f	f
1153	7	12	1	3	f	f
1154	7	12	1	5	f	f
1155	7	12	4	3	f	f
1156	7	12	4	5	f	f
1157	7	12	7	3	f	f
1158	7	12	7	5	f	f
1159	7	12	8	3	f	f
1160	7	12	8	5	f	f
1161	7	12	9	3	f	f
1162	7	12	9	5	f	f
1163	7	12	10	3	f	f
1164	7	12	10	5	f	f
1165	7	12	11	3	f	f
1166	7	12	11	5	f	f
1167	7	12	13	3	f	f
1168	7	12	13	5	f	f
1169	7	12	14	3	f	f
1170	7	12	14	5	f	f
1171	7	12	12	3	f	f
1172	7	12	12	5	f	f
\.


--
-- Data for Name: announcements; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.announcements (id, text, show_until, active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: ar_internal_metadata; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ar_internal_metadata (key, value, created_at, updated_at) FROM stdin;
environment	development	2023-07-26 09:21:51.140625+01	2023-07-26 09:21:51.140625+01
\.


--
-- Data for Name: attachable_journals; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.attachable_journals (id, journal_id, attachment_id, filename) FROM stdin;
4	55	7	ff-cactus.jpg
5	55	8	Pop-Ich-klein_400x400.png
\.


--
-- Data for Name: attachment_journals; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.attachment_journals (id, container_id, container_type, filename, disk_filename, filesize, content_type, digest, downloads, author_id, description) FROM stdin;
1	6	Grids::Grid			455768	image/png	2a53ddc815206499a480d08e38272b8a	0	4	\N
2	7	Grids::Grid			442579	image/png	7b7d591a8dfdaf2900ceecdb9755f39f	0	4	\N
4	1	Export	Demo project - All open.pdf		62182	application/pdf	89e31e139dbb7785615335a8ab2be094	0	4	
7	2	WorkPackage	ff-cactus.jpg		69885	image/jpeg	946a408d1b27ac882ea72b080f7d579a	0	4	\N
8	2	WorkPackage	Pop-Ich-klein_400x400.png		389264	image/png	032fc98977f330f0be42533647ff4b4a	0	4	\N
9	2	Export	Demo project - All open.pdf		62052	application/pdf	da440d5cc2f5514fa2ef7fdd656239f7	0	4	
\.


--
-- Data for Name: attachments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.attachments (id, container_id, container_type, filename, disk_filename, filesize, content_type, digest, downloads, author_id, created_at, description, file, fulltext, fulltext_tsv, file_tsv, updated_at) FROM stdin;
1	6	Grids::Grid			455768	image/png	2a53ddc815206499a480d08e38272b8a	0	4	2023-07-26 09:22:09.932178+01	\N	demo_project_teaser.png	\N	\N	\N	2023-07-26 09:22:09.932178+01
2	7	Grids::Grid			442579	image/png	7b7d591a8dfdaf2900ceecdb9755f39f	0	4	2023-07-26 09:22:09.966339+01	\N	scrum_project_teaser.png	\N	\N	\N	2023-07-26 09:22:09.966339+01
4	1	Export	Demo project - All open.pdf		62182	application/pdf	89e31e139dbb7785615335a8ab2be094	0	4	2023-07-28 13:26:07.402459+01		Demo_project_-_All_open.pdf	\N	\N	\N	2023-07-28 13:26:07.402459+01
7	2	WorkPackage	ff-cactus.jpg		69885	image/jpeg	946a408d1b27ac882ea72b080f7d579a	0	4	2023-07-31 08:17:53.639478+01	\N	ff-cactus.jpg	\N	\N	\N	2023-07-31 08:17:53.639478+01
8	2	WorkPackage	Pop-Ich-klein_400x400.png		389264	image/png	032fc98977f330f0be42533647ff4b4a	0	4	2023-07-31 08:18:14.717365+01	\N	Pop-Ich-klein_400x400.png	\N	\N	\N	2023-07-31 08:18:14.717365+01
9	2	Export	Demo project - All open.pdf		62052	application/pdf	da440d5cc2f5514fa2ef7fdd656239f7	0	4	2023-07-31 08:19:13.689779+01		Demo_project_-_All_open.pdf	\N	\N	\N	2023-07-31 08:19:13.689779+01
\.


--
-- Data for Name: attribute_help_texts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.attribute_help_texts (id, help_text, type, attribute_name, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: auth_sources; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.auth_sources (id, type, name, host, port, account, account_password, base_dn, attr_login, attr_firstname, attr_lastname, attr_mail, onthefly_register, attr_admin, created_at, updated_at, tls_mode, filter_string, verify_peer, tls_certificate_string) FROM stdin;
\.


--
-- Data for Name: backups; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.backups (id, comment, size_in_mb, creator_id, created_at, updated_at) FROM stdin;
7	\N	\N	4	2023-07-31 08:22:23.511127+01	2023-07-31 08:22:23.511127+01
\.


--
-- Data for Name: bcf_comments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.bcf_comments (id, uuid, journal_id, issue_id, viewpoint_id, reply_to) FROM stdin;
\.


--
-- Data for Name: bcf_issues; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.bcf_issues (id, uuid, markup, work_package_id, stage, index, labels, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: bcf_viewpoints; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.bcf_viewpoints (id, uuid, viewpoint_name, issue_id, json_viewpoint, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: budget_journals; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.budget_journals (id, project_id, author_id, subject, description, fixed_date) FROM stdin;
\.


--
-- Data for Name: budgets; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.budgets (id, project_id, author_id, subject, description, fixed_date, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: categories; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.categories (id, project_id, name, assigned_to_id, created_at, updated_at) FROM stdin;
1	1	Category 1 (to be changed in Project settings)	\N	2023-07-26 09:22:07.759089+01	2023-07-26 09:22:07.759089+01
2	2	Category 1 (to be changed in Project settings)	\N	2023-07-26 09:22:08.767274+01	2023-07-26 09:22:08.767274+01
\.


--
-- Data for Name: changes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.changes (id, changeset_id, action, path, from_path, from_revision, revision, branch) FROM stdin;
\.


--
-- Data for Name: changeset_journals; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.changeset_journals (id, repository_id, revision, committer, committed_on, comments, commit_date, scmid, user_id) FROM stdin;
\.


--
-- Data for Name: changesets; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.changesets (id, repository_id, revision, committer, committed_on, comments, commit_date, scmid, user_id) FROM stdin;
\.


--
-- Data for Name: changesets_work_packages; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.changesets_work_packages (changeset_id, work_package_id) FROM stdin;
\.


--
-- Data for Name: colors; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.colors (id, name, hexcode, created_at, updated_at) FROM stdin;
1	Blue (dark)	#175A8E	2023-07-26 09:22:05.749136+01	2023-07-26 09:22:05.749136+01
2	Blue	#1A67A3	2023-07-26 09:22:05.749968+01	2023-07-26 09:22:05.749968+01
3	Blue (light)	#00B0F0	2023-07-26 09:22:05.750611+01	2023-07-26 09:22:05.750611+01
4	Green (light)	#35C53F	2023-07-26 09:22:05.751423+01	2023-07-26 09:22:05.751423+01
5	Green (dark)	#339933	2023-07-26 09:22:05.752072+01	2023-07-26 09:22:05.752072+01
6	Yellow	#FFFF00	2023-07-26 09:22:05.752679+01	2023-07-26 09:22:05.752679+01
7	Orange	#FFCC00	2023-07-26 09:22:05.753213+01	2023-07-26 09:22:05.753213+01
8	Red	#FF3300	2023-07-26 09:22:05.753786+01	2023-07-26 09:22:05.753786+01
9	Magenta	#E20074	2023-07-26 09:22:05.75443+01	2023-07-26 09:22:05.75443+01
10	White	#FFFFFF	2023-07-26 09:22:05.755011+01	2023-07-26 09:22:05.755011+01
11	Grey (light)	#F8F8F8	2023-07-26 09:22:05.755545+01	2023-07-26 09:22:05.755545+01
12	Grey	#EAEAEA	2023-07-26 09:22:05.75631+01	2023-07-26 09:22:05.75631+01
13	Grey (dark)	#878787	2023-07-26 09:22:05.756961+01	2023-07-26 09:22:05.756961+01
14	Black	#000000	2023-07-26 09:22:05.757689+01	2023-07-26 09:22:05.757689+01
15	gray-0	#F8F9FA	2023-07-26 09:22:05.759206+01	2023-07-26 09:22:05.759206+01
16	gray-1	#F1F3F5	2023-07-26 09:22:05.75992+01	2023-07-26 09:22:05.75992+01
17	gray-2	#E9ECEF	2023-07-26 09:22:05.760569+01	2023-07-26 09:22:05.760569+01
18	gray-3	#DEE2E6	2023-07-26 09:22:05.761356+01	2023-07-26 09:22:05.761356+01
19	gray-4	#CED4DA	2023-07-26 09:22:05.762046+01	2023-07-26 09:22:05.762046+01
20	gray-5	#ADB5BD	2023-07-26 09:22:05.762624+01	2023-07-26 09:22:05.762624+01
21	gray-6	#868E96	2023-07-26 09:22:05.763347+01	2023-07-26 09:22:05.763347+01
22	gray-7	#495057	2023-07-26 09:22:05.763928+01	2023-07-26 09:22:05.763928+01
23	gray-8	#343A40	2023-07-26 09:22:05.764646+01	2023-07-26 09:22:05.764646+01
24	gray-9	#212529	2023-07-26 09:22:05.765199+01	2023-07-26 09:22:05.765199+01
25	red-0	#FFF5F5	2023-07-26 09:22:05.765738+01	2023-07-26 09:22:05.765738+01
26	red-1	#FFE3E3	2023-07-26 09:22:05.766353+01	2023-07-26 09:22:05.766353+01
27	red-2	#FFC9C9	2023-07-26 09:22:05.766931+01	2023-07-26 09:22:05.766931+01
28	red-3	#FFA8A8	2023-07-26 09:22:05.767656+01	2023-07-26 09:22:05.767656+01
29	red-4	#FF8787	2023-07-26 09:22:05.768231+01	2023-07-26 09:22:05.768231+01
30	red-5	#FF6B6B	2023-07-26 09:22:05.768888+01	2023-07-26 09:22:05.768888+01
31	red-6	#FA5252	2023-07-26 09:22:05.769499+01	2023-07-26 09:22:05.769499+01
32	red-7	#F03E3E	2023-07-26 09:22:05.770068+01	2023-07-26 09:22:05.770068+01
33	red-8	#E03131	2023-07-26 09:22:05.770781+01	2023-07-26 09:22:05.770781+01
34	red-9	#C92A2A	2023-07-26 09:22:05.771314+01	2023-07-26 09:22:05.771314+01
35	pink-0	#FFF0F6	2023-07-26 09:22:05.771855+01	2023-07-26 09:22:05.771855+01
36	pink-1	#FFDEEB	2023-07-26 09:22:05.772362+01	2023-07-26 09:22:05.772362+01
37	pink-2	#FCC2D7	2023-07-26 09:22:05.773033+01	2023-07-26 09:22:05.773033+01
38	pink-3	#FAA2C1	2023-07-26 09:22:05.773622+01	2023-07-26 09:22:05.773622+01
39	pink-4	#F783AC	2023-07-26 09:22:05.774163+01	2023-07-26 09:22:05.774163+01
40	pink-5	#F06595	2023-07-26 09:22:05.774711+01	2023-07-26 09:22:05.774711+01
41	pink-6	#E64980	2023-07-26 09:22:05.77525+01	2023-07-26 09:22:05.77525+01
42	pink-7	#D6336C	2023-07-26 09:22:05.776407+01	2023-07-26 09:22:05.776407+01
43	pink-8	#C2255C	2023-07-26 09:22:05.781696+01	2023-07-26 09:22:05.781696+01
44	pink-9	#A61E4D	2023-07-26 09:22:05.782366+01	2023-07-26 09:22:05.782366+01
45	grape-0	#F8F0FC	2023-07-26 09:22:05.782931+01	2023-07-26 09:22:05.782931+01
46	grape-1	#F3D9FA	2023-07-26 09:22:05.783459+01	2023-07-26 09:22:05.783459+01
47	grape-2	#EEBEFA	2023-07-26 09:22:05.784096+01	2023-07-26 09:22:05.784096+01
48	grape-3	#E599F7	2023-07-26 09:22:05.784708+01	2023-07-26 09:22:05.784708+01
49	grape-4	#DA77F2	2023-07-26 09:22:05.78529+01	2023-07-26 09:22:05.78529+01
50	grape-5	#CC5DE8	2023-07-26 09:22:05.785929+01	2023-07-26 09:22:05.785929+01
51	grape-6	#BE4BDB	2023-07-26 09:22:05.786695+01	2023-07-26 09:22:05.786695+01
52	grape-7	#AE3EC9	2023-07-26 09:22:05.78745+01	2023-07-26 09:22:05.78745+01
53	grape-8	#9C36B5	2023-07-26 09:22:05.78807+01	2023-07-26 09:22:05.78807+01
54	grape-9	#862E9C	2023-07-26 09:22:05.788601+01	2023-07-26 09:22:05.788601+01
55	violet-0	#F3F0FF	2023-07-26 09:22:05.789128+01	2023-07-26 09:22:05.789128+01
56	violet-1	#E5DBFF	2023-07-26 09:22:05.789652+01	2023-07-26 09:22:05.789652+01
57	violet-2	#D0BFFF	2023-07-26 09:22:05.790376+01	2023-07-26 09:22:05.790376+01
58	violet-3	#B197FC	2023-07-26 09:22:05.790919+01	2023-07-26 09:22:05.790919+01
59	violet-4	#9775FA	2023-07-26 09:22:05.791444+01	2023-07-26 09:22:05.791444+01
60	violet-5	#845EF7	2023-07-26 09:22:05.792078+01	2023-07-26 09:22:05.792078+01
61	violet-6	#7950F2	2023-07-26 09:22:05.792926+01	2023-07-26 09:22:05.792926+01
62	violet-7	#7048E8	2023-07-26 09:22:05.793569+01	2023-07-26 09:22:05.793569+01
63	violet-8	#6741D9	2023-07-26 09:22:05.794146+01	2023-07-26 09:22:05.794146+01
64	violet-9	#5F3DC4	2023-07-26 09:22:05.794733+01	2023-07-26 09:22:05.794733+01
65	indigo-0	#EDF2FF	2023-07-26 09:22:05.795323+01	2023-07-26 09:22:05.795323+01
66	indigo-1	#DBE4FF	2023-07-26 09:22:05.796126+01	2023-07-26 09:22:05.796126+01
67	indigo-2	#BAC8FF	2023-07-26 09:22:05.796683+01	2023-07-26 09:22:05.796683+01
68	indigo-3	#91A7FF	2023-07-26 09:22:05.797219+01	2023-07-26 09:22:05.797219+01
69	indigo-4	#748FFC	2023-07-26 09:22:05.797757+01	2023-07-26 09:22:05.797757+01
70	indigo-5	#5C7CFA	2023-07-26 09:22:05.79827+01	2023-07-26 09:22:05.79827+01
71	indigo-6	#4C6EF5	2023-07-26 09:22:05.799023+01	2023-07-26 09:22:05.799023+01
72	indigo-7	#4263EB	2023-07-26 09:22:05.799626+01	2023-07-26 09:22:05.799626+01
73	indigo-8	#3B5BDB	2023-07-26 09:22:05.800306+01	2023-07-26 09:22:05.800306+01
74	indigo-9	#364FC7	2023-07-26 09:22:05.800908+01	2023-07-26 09:22:05.800908+01
75	blue-0	#E7F5FF	2023-07-26 09:22:05.80158+01	2023-07-26 09:22:05.80158+01
76	blue-1	#D0EBFF	2023-07-26 09:22:05.802312+01	2023-07-26 09:22:05.802312+01
77	blue-2	#A5D8FF	2023-07-26 09:22:05.80297+01	2023-07-26 09:22:05.80297+01
78	blue-3	#74C0FC	2023-07-26 09:22:05.803547+01	2023-07-26 09:22:05.803547+01
79	blue-4	#4DABF7	2023-07-26 09:22:05.80411+01	2023-07-26 09:22:05.80411+01
80	blue-5	#339AF0	2023-07-26 09:22:05.80477+01	2023-07-26 09:22:05.80477+01
81	blue-6	#228BE6	2023-07-26 09:22:05.805339+01	2023-07-26 09:22:05.805339+01
82	blue-7	#1C7ED6	2023-07-26 09:22:05.805898+01	2023-07-26 09:22:05.805898+01
83	blue-8	#1971C2	2023-07-26 09:22:05.806439+01	2023-07-26 09:22:05.806439+01
84	blue-9	#1864AB	2023-07-26 09:22:05.806978+01	2023-07-26 09:22:05.806978+01
85	cyan-0	#E3FAFC	2023-07-26 09:22:05.807512+01	2023-07-26 09:22:05.807512+01
86	cyan-1	#C5F6FA	2023-07-26 09:22:05.808079+01	2023-07-26 09:22:05.808079+01
87	cyan-2	#99E9F2	2023-07-26 09:22:05.808585+01	2023-07-26 09:22:05.808585+01
88	cyan-3	#66D9E8	2023-07-26 09:22:05.809257+01	2023-07-26 09:22:05.809257+01
89	cyan-4	#3BC9DB	2023-07-26 09:22:05.809974+01	2023-07-26 09:22:05.809974+01
90	cyan-5	#22B8CF	2023-07-26 09:22:05.810561+01	2023-07-26 09:22:05.810561+01
91	cyan-6	#15AABF	2023-07-26 09:22:05.811154+01	2023-07-26 09:22:05.811154+01
92	cyan-7	#1098AD	2023-07-26 09:22:05.811702+01	2023-07-26 09:22:05.811702+01
93	cyan-8	#0C8599	2023-07-26 09:22:05.812239+01	2023-07-26 09:22:05.812239+01
94	cyan-9	#0B7285	2023-07-26 09:22:05.812778+01	2023-07-26 09:22:05.812778+01
95	teal-0	#E6FCF5	2023-07-26 09:22:05.813321+01	2023-07-26 09:22:05.813321+01
96	teal-1	#C3FAE8	2023-07-26 09:22:05.813848+01	2023-07-26 09:22:05.813848+01
97	teal-2	#96F2D7	2023-07-26 09:22:05.81455+01	2023-07-26 09:22:05.81455+01
98	teal-3	#63E6BE	2023-07-26 09:22:05.815212+01	2023-07-26 09:22:05.815212+01
99	teal-4	#38D9A9	2023-07-26 09:22:05.815913+01	2023-07-26 09:22:05.815913+01
100	teal-5	#20C997	2023-07-26 09:22:05.81652+01	2023-07-26 09:22:05.81652+01
101	teal-6	#12B886	2023-07-26 09:22:05.817106+01	2023-07-26 09:22:05.817106+01
102	teal-7	#0CA678	2023-07-26 09:22:05.817823+01	2023-07-26 09:22:05.817823+01
103	teal-8	#099268	2023-07-26 09:22:05.81855+01	2023-07-26 09:22:05.81855+01
104	teal-9	#087F5B	2023-07-26 09:22:05.819176+01	2023-07-26 09:22:05.819176+01
105	green-0	#EBFBEE	2023-07-26 09:22:05.819773+01	2023-07-26 09:22:05.819773+01
106	green-1	#D3F9D8	2023-07-26 09:22:05.820299+01	2023-07-26 09:22:05.820299+01
107	green-2	#B2F2BB	2023-07-26 09:22:05.820926+01	2023-07-26 09:22:05.820926+01
108	green-3	#8CE99A	2023-07-26 09:22:05.8215+01	2023-07-26 09:22:05.8215+01
109	green-4	#69DB7C	2023-07-26 09:22:05.822042+01	2023-07-26 09:22:05.822042+01
110	green-5	#51CF66	2023-07-26 09:22:05.822574+01	2023-07-26 09:22:05.822574+01
111	green-6	#40C057	2023-07-26 09:22:05.823096+01	2023-07-26 09:22:05.823096+01
112	green-7	#37B24D	2023-07-26 09:22:05.823739+01	2023-07-26 09:22:05.823739+01
113	green-8	#2F9E44	2023-07-26 09:22:05.824373+01	2023-07-26 09:22:05.824373+01
114	green-9	#2B8A3E	2023-07-26 09:22:05.824928+01	2023-07-26 09:22:05.824928+01
115	lime-0	#F4FCE3	2023-07-26 09:22:05.825599+01	2023-07-26 09:22:05.825599+01
116	lime-1	#E9FAC8	2023-07-26 09:22:05.826322+01	2023-07-26 09:22:05.826322+01
117	lime-2	#D8F5A2	2023-07-26 09:22:05.827026+01	2023-07-26 09:22:05.827026+01
118	lime-3	#C0EB75	2023-07-26 09:22:05.827704+01	2023-07-26 09:22:05.827704+01
119	lime-4	#A9E34B	2023-07-26 09:22:05.828533+01	2023-07-26 09:22:05.828533+01
120	lime-5	#94D82D	2023-07-26 09:22:05.829119+01	2023-07-26 09:22:05.829119+01
121	lime-6	#82C91E	2023-07-26 09:22:05.829673+01	2023-07-26 09:22:05.829673+01
122	lime-7	#74B816	2023-07-26 09:22:05.830212+01	2023-07-26 09:22:05.830212+01
123	lime-8	#66A80F	2023-07-26 09:22:05.83074+01	2023-07-26 09:22:05.83074+01
124	lime-9	#5C940D	2023-07-26 09:22:05.831259+01	2023-07-26 09:22:05.831259+01
125	yellow-0	#FFF9DB	2023-07-26 09:22:05.831912+01	2023-07-26 09:22:05.831912+01
126	yellow-1	#FFF3BF	2023-07-26 09:22:05.832537+01	2023-07-26 09:22:05.832537+01
127	yellow-2	#FFEC99	2023-07-26 09:22:05.833126+01	2023-07-26 09:22:05.833126+01
128	yellow-3	#FFE066	2023-07-26 09:22:05.83377+01	2023-07-26 09:22:05.83377+01
129	yellow-4	#FFD43B	2023-07-26 09:22:05.834457+01	2023-07-26 09:22:05.834457+01
130	yellow-5	#FCC419	2023-07-26 09:22:05.835017+01	2023-07-26 09:22:05.835017+01
131	yellow-6	#FAB005	2023-07-26 09:22:05.835561+01	2023-07-26 09:22:05.835561+01
132	yellow-7	#F59F00	2023-07-26 09:22:05.83612+01	2023-07-26 09:22:05.83612+01
133	yellow-8	#F08C00	2023-07-26 09:22:05.837226+01	2023-07-26 09:22:05.837226+01
134	yellow-9	#E67700	2023-07-26 09:22:05.838003+01	2023-07-26 09:22:05.838003+01
135	orange-0	#FFF4E6	2023-07-26 09:22:05.838591+01	2023-07-26 09:22:05.838591+01
136	orange-1	#FFE8CC	2023-07-26 09:22:05.839146+01	2023-07-26 09:22:05.839146+01
137	orange-2	#FFD8A8	2023-07-26 09:22:05.839719+01	2023-07-26 09:22:05.839719+01
138	orange-3	#FFC078	2023-07-26 09:22:05.840282+01	2023-07-26 09:22:05.840282+01
139	orange-4	#FFA94D	2023-07-26 09:22:05.840849+01	2023-07-26 09:22:05.840849+01
140	orange-5	#FF922B	2023-07-26 09:22:05.841389+01	2023-07-26 09:22:05.841389+01
141	orange-6	#FD7E14	2023-07-26 09:22:05.842062+01	2023-07-26 09:22:05.842062+01
142	orange-7	#F76707	2023-07-26 09:22:05.842862+01	2023-07-26 09:22:05.842862+01
143	orange-8	#E8590C	2023-07-26 09:22:05.843495+01	2023-07-26 09:22:05.843495+01
144	orange-9	#D9480F	2023-07-26 09:22:05.844135+01	2023-07-26 09:22:05.844135+01
\.


--
-- Data for Name: comments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.comments (id, commented_type, commented_id, author_id, comments, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: cost_entries; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cost_entries (id, user_id, project_id, work_package_id, cost_type_id, units, spent_on, created_at, updated_at, comments, blocked, overridden_costs, costs, rate_id, tyear, tmonth, tweek, logged_by_id) FROM stdin;
\.


--
-- Data for Name: cost_queries; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cost_queries (id, user_id, project_id, name, is_public, created_at, updated_at, serialized) FROM stdin;
\.


--
-- Data for Name: cost_types; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cost_types (id, name, unit, unit_plural, "default", deleted_at) FROM stdin;
\.


--
-- Data for Name: custom_actions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.custom_actions (id, name, actions, description, "position") FROM stdin;
\.


--
-- Data for Name: custom_actions_projects; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.custom_actions_projects (id, project_id, custom_action_id) FROM stdin;
\.


--
-- Data for Name: custom_actions_roles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.custom_actions_roles (id, role_id, custom_action_id) FROM stdin;
\.


--
-- Data for Name: custom_actions_statuses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.custom_actions_statuses (id, status_id, custom_action_id) FROM stdin;
\.


--
-- Data for Name: custom_actions_types; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.custom_actions_types (id, type_id, custom_action_id) FROM stdin;
\.


--
-- Data for Name: custom_fields; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.custom_fields (id, type, field_format, regexp, min_length, max_length, is_required, is_for_all, is_filter, "position", searchable, editable, visible, multi_value, default_value, name, created_at, updated_at, content_right_to_left) FROM stdin;
1	WorkPackageCustomField	string		0	0	f	f	f	1	f	t	t	f	\N	CF DEV string	2023-07-26 09:22:10.715062+01	2023-07-26 09:22:10.715062+01	f
2	WorkPackageCustomField	text		0	0	f	f	f	2	f	t	t	f	\N	CF DEV text	2023-07-26 09:22:10.718617+01	2023-07-26 09:22:10.718617+01	f
3	WorkPackageCustomField	date		0	0	f	f	f	3	f	t	t	f	\N	CF DEV date	2023-07-26 09:22:10.721528+01	2023-07-26 09:22:10.721528+01	f
4	WorkPackageCustomField	int		0	0	f	f	f	4	f	t	t	f	\N	CF DEV int	2023-07-26 09:22:10.724451+01	2023-07-26 09:22:10.724451+01	f
5	WorkPackageCustomField	float		0	0	f	f	f	5	f	t	t	f	\N	CF DEV float	2023-07-26 09:22:10.728268+01	2023-07-26 09:22:10.728268+01	f
6	WorkPackageCustomField	user		0	0	f	f	f	6	f	t	t	f	\N	CF DEV user	2023-07-26 09:22:10.731323+01	2023-07-26 09:22:10.731323+01	f
7	WorkPackageCustomField	version		0	0	f	f	f	7	f	t	t	f	\N	CF DEV version	2023-07-26 09:22:10.733695+01	2023-07-26 09:22:10.733695+01	f
10	WorkPackageCustomField	text		0	0	t	f	f	10	f	t	t	f	\N	CF DEV required text	2023-07-26 09:22:10.754883+01	2023-07-26 09:22:10.754883+01	f
11	WorkPackageCustomField	int		2	5	f	f	f	11	f	t	t	f	\N	CF DEV intrange	2023-07-26 09:22:10.757584+01	2023-07-26 09:22:10.757584+01	f
8	WorkPackageCustomField	list		0	0	f	f	f	8	f	t	t	f	\N	CF DEV list	2023-07-26 09:22:10.74255+01	2023-07-26 09:22:10.747597+01	f
9	WorkPackageCustomField	list		0	0	f	f	f	9	f	t	t	t	\N	CF DEV multilist	2023-07-26 09:22:10.749018+01	2023-07-26 09:22:10.75352+01	f
\.


--
-- Data for Name: custom_fields_projects; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.custom_fields_projects (custom_field_id, project_id) FROM stdin;
1	6
2	6
3	6
4	6
5	6
6	6
7	6
8	6
9	6
10	6
11	6
\.


--
-- Data for Name: custom_fields_types; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.custom_fields_types (custom_field_id, type_id) FROM stdin;
\.


--
-- Data for Name: custom_options; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.custom_options (id, custom_field_id, "position", default_value, value, created_at, updated_at) FROM stdin;
1	8	1	\N	A	2023-07-26 09:22:10.744712+01	2023-07-26 09:22:10.744712+01
2	8	2	\N	B	2023-07-26 09:22:10.74573+01	2023-07-26 09:22:10.74573+01
3	8	3	\N	C	2023-07-26 09:22:10.746598+01	2023-07-26 09:22:10.746598+01
4	9	1	\N	Foo	2023-07-26 09:22:10.750854+01	2023-07-26 09:22:10.750854+01
5	9	2	\N	Bar	2023-07-26 09:22:10.751789+01	2023-07-26 09:22:10.751789+01
6	9	3	\N	Bla	2023-07-26 09:22:10.752651+01	2023-07-26 09:22:10.752651+01
\.


--
-- Data for Name: custom_styles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.custom_styles (id, logo, created_at, updated_at, favicon, touch_icon, theme, theme_logo) FROM stdin;
1	\N	2023-07-26 11:38:39.345674+01	2023-07-30 22:47:37.882763+01	\N	\N	OpenProject	\N
\.


--
-- Data for Name: custom_values; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.custom_values (id, customized_type, customized_id, custom_field_id, value) FROM stdin;
\.


--
-- Data for Name: customizable_journals; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.customizable_journals (id, journal_id, custom_field_id, value) FROM stdin;
\.


--
-- Data for Name: delayed_job_statuses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.delayed_job_statuses (id, reference_type, reference_id, message, created_at, updated_at, status, user_id, job_id, payload) FROM stdin;
3	\N	\N	Backup failed: undefined method `migrate' for Apartment::Tenant:Module	2023-07-26 11:39:24.765773+01	2023-07-26 11:39:24.765773+01	failure	3	63aa75fc-c959-411c-91e8-881d0d140ea0	\N
4	\N	\N	The export has completed successfully.	2023-07-26 11:46:58.5703+01	2023-07-26 11:46:58.5703+01	success	3	c7b1615c-d55a-4d68-a31e-a3bf052981b2	\N
5	\N	\N	The export has completed successfully.	2023-07-26 11:56:13.714539+01	2023-07-26 11:56:13.714539+01	success	3	d8477345-dc02-4438-bf1d-ad71f3ea97b1	\N
6	\N	\N	The export has completed successfully.	2023-07-27 13:21:01.246296+01	2023-07-27 13:21:01.246296+01	success	3	4a81d30d-f7bf-4ab6-8d9a-c8598fb85143	\N
7	\N	\N	The export has completed successfully.	2023-07-27 13:23:00.071077+01	2023-07-27 13:23:00.071077+01	success	3	19307339-a9dc-4865-a0d1-578a78193586	\N
8	\N	\N	The export has completed successfully.	2023-07-27 13:38:30.026973+01	2023-07-27 13:38:30.026973+01	success	3	d44ebeed-c50e-4591-af63-91dbfb55726a	\N
9	\N	\N	The export has completed successfully.	2023-07-27 14:18:03.066371+01	2023-07-27 14:18:03.066371+01	success	3	e478ee94-1489-4e56-8554-ef689aed4c7d	\N
12	Export	1	The export has completed successfully.	2023-07-28 13:26:03.477345+01	2023-07-28 13:26:07.462538+01	success	4	d926ded8-969b-402e-90c2-37ccdd145bb9	{"title": "Your work packages export", "download": "/api/v3/attachments/4/content"}
14	Export	2	The export has completed successfully.	2023-07-31 08:18:41.776596+01	2023-07-31 08:19:13.750568+01	success	4	f3089910-5961-4487-929b-465fe6a09cad	{"title": "Your work packages export", "download": "/api/v3/attachments/9/content"}
16	Backup	7	\N	2023-07-31 08:22:23.520783+01	2023-07-31 08:23:32.429763+01	in_process	4	6c39252e-fb83-4841-b150-bbc937f684f9	\N
\.


--
-- Data for Name: delayed_jobs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.delayed_jobs (id, priority, attempts, handler, last_error, run_at, locked_at, failed_at, locked_by, created_at, updated_at, queue, cron) FROM stdin;
5	10	0	--- !ruby/object:ActiveJob::QueueAdapters::DelayedJobAdapter::JobWrapper\njob_data:\n  job_class: CleanupWebhookLogsJob\n  job_id: 58385d75-a6bd-47e9-893e-fad0c521d37c\n  provider_job_id: \n  queue_name: default\n  priority: \n  arguments: []\n  executions: 0\n  exception_executions: {}\n  locale: en\n  timezone: UTC\n  enqueued_at: '2023-07-26T10:10:11Z'\n	\N	2023-07-30 06:28:00+01	\N	\N	\N	2023-07-26 11:10:11.937845+01	2023-07-26 11:10:11.937845+01	default	28 5 * * 7
6	10	0	--- !ruby/object:ActiveJob::QueueAdapters::DelayedJobAdapter::JobWrapper\njob_data:\n  job_class: Cron::ClearOldPullRequestsJob\n  job_id: 1bd7f2ab-d1b1-470e-8341-426d77e912ed\n  provider_job_id: \n  queue_name: default\n  priority: \n  arguments: []\n  executions: 0\n  exception_executions: {}\n  locale: en\n  timezone: UTC\n  enqueued_at: '2023-07-26T10:10:11Z'\n	\N	2023-07-27 02:25:00+01	\N	\N	\N	2023-07-26 11:10:11.956+01	2023-07-26 11:10:11.956+01	default	25 1 * * *
8	10	0	--- !ruby/object:ActiveJob::QueueAdapters::DelayedJobAdapter::JobWrapper\njob_data:\n  job_class: JobStatus::Cron::ClearOldJobStatusJob\n  job_id: 357f1e82-bcd0-4348-aba1-867a1cbbfebc\n  provider_job_id: \n  queue_name: default\n  priority: \n  arguments: []\n  executions: 0\n  exception_executions: {}\n  locale: en\n  timezone: UTC\n  enqueued_at: '2023-07-26T10:10:11Z'\n	\N	2023-07-27 05:15:00+01	\N	\N	\N	2023-07-26 11:10:11.971507+01	2023-07-26 11:10:11.971507+01	default	15 4 * * *
9	20	0	--- !ruby/object:ActiveJob::QueueAdapters::DelayedJobAdapter::JobWrapper\njob_data:\n  job_class: CleanupUncontaineredFileLinksJob\n  job_id: 4ab0c5b9-a549-48ee-bdce-8c0138e29d06\n  provider_job_id: \n  queue_name: default\n  priority: 20\n  arguments: []\n  executions: 0\n  exception_executions: {}\n  locale: en\n  timezone: UTC\n  enqueued_at: '2023-07-26T10:10:11Z'\n	\N	2023-07-26 23:06:00+01	\N	\N	\N	2023-07-26 11:10:11.981744+01	2023-07-26 11:10:11.981744+01	default	06 22 * * *
11	10	0	--- !ruby/object:ActiveJob::QueueAdapters::DelayedJobAdapter::JobWrapper\njob_data:\n  job_class: Cron::ClearOldSessionsJob\n  job_id: 5b0fb06f-4ac9-47b0-9d92-6f51f80ee80c\n  provider_job_id: \n  queue_name: default\n  priority: \n  arguments: []\n  executions: 0\n  exception_executions: {}\n  locale: en\n  timezone: UTC\n  enqueued_at: '2023-07-26T10:10:11Z'\n	\N	2023-07-27 02:15:00+01	\N	\N	\N	2023-07-26 11:10:12.000939+01	2023-07-26 11:10:12.000939+01	default	15 1 * * *
12	10	0	--- !ruby/object:ActiveJob::QueueAdapters::DelayedJobAdapter::JobWrapper\njob_data:\n  job_class: Cron::ClearTmpCacheJob\n  job_id: 128a4641-cbde-48d5-b843-bc6019151f7c\n  provider_job_id: \n  queue_name: default\n  priority: \n  arguments: []\n  executions: 0\n  exception_executions: {}\n  locale: en\n  timezone: UTC\n  enqueued_at: '2023-07-26T10:10:12Z'\n	\N	2023-07-30 03:45:00+01	\N	\N	\N	2023-07-26 11:10:12.010873+01	2023-07-26 11:10:12.010873+01	default	45 2 * * 7
13	10	0	--- !ruby/object:ActiveJob::QueueAdapters::DelayedJobAdapter::JobWrapper\njob_data:\n  job_class: Cron::ClearUploadedFilesJob\n  job_id: e242e35f-e8b1-428d-a0a8-6db111d2dade\n  provider_job_id: \n  queue_name: default\n  priority: \n  arguments: []\n  executions: 0\n  exception_executions: {}\n  locale: en\n  timezone: UTC\n  enqueued_at: '2023-07-26T10:10:12Z'\n	\N	2023-07-29 00:00:00+01	\N	\N	\N	2023-07-26 11:10:12.017242+01	2023-07-26 11:10:12.017242+01	default	0 23 * * 5
14	20	0	--- !ruby/object:ActiveJob::QueueAdapters::DelayedJobAdapter::JobWrapper\njob_data:\n  job_class: OAuth::CleanupJob\n  job_id: 37a74399-8902-4394-8d12-79332c27bbce\n  provider_job_id: \n  queue_name: default\n  priority: 20\n  arguments: []\n  executions: 0\n  exception_executions: {}\n  locale: en\n  timezone: UTC\n  enqueued_at: '2023-07-26T10:10:12Z'\n	\N	2023-07-27 02:52:00+01	\N	\N	\N	2023-07-26 11:10:12.024856+01	2023-07-26 11:10:12.024856+01	default	52 1 * * *
15	10	0	--- !ruby/object:ActiveJob::QueueAdapters::DelayedJobAdapter::JobWrapper\njob_data:\n  job_class: PaperTrailAudits::CleanupJob\n  job_id: '0388601f-a53a-4cb3-9076-8f9e66c8e390'\n  provider_job_id: \n  queue_name: default\n  priority: \n  arguments: []\n  executions: 0\n  exception_executions: {}\n  locale: en\n  timezone: UTC\n  enqueued_at: '2023-07-26T10:10:12Z'\n	\N	2023-07-29 05:03:00+01	\N	\N	\N	2023-07-26 11:10:12.031899+01	2023-07-26 11:10:12.031899+01	default	3 4 * * 6
16	20	0	--- !ruby/object:ActiveJob::QueueAdapters::DelayedJobAdapter::JobWrapper\njob_data:\n  job_class: Attachments::CleanupUncontaineredJob\n  job_id: 733343db-7f82-4dd8-ac34-62191a525b29\n  provider_job_id: \n  queue_name: default\n  priority: 20\n  arguments: []\n  executions: 0\n  exception_executions: {}\n  locale: en\n  timezone: UTC\n  enqueued_at: '2023-07-26T10:10:12Z'\n	\N	2023-07-26 23:03:00+01	\N	\N	\N	2023-07-26 11:10:12.039882+01	2023-07-26 11:10:12.039882+01	default	03 22 * * *
7	10	1	--- !ruby/object:ActiveJob::QueueAdapters::DelayedJobAdapter::JobWrapper\njob_data:\n  job_class: LdapGroups::SynchronizationJob\n  job_id: 7e9f32a0-aa63-425b-a103-9eaa167e1224\n  provider_job_id: \n  queue_name: default\n  priority: \n  arguments: []\n  executions: 0\n  exception_executions: {}\n  locale: en\n  timezone: UTC\n  enqueued_at: '2023-07-26T10:10:11Z'\n	\N	2023-07-26 12:00:00+01	\N	\N	\N	2023-07-26 11:10:11.963273+01	2023-07-26 11:30:00.351569+01	default	*/30 * * * *
10	20	8	--- !ruby/object:ActiveJob::QueueAdapters::DelayedJobAdapter::JobWrapper\njob_data:\n  job_class: ManageNextcloudIntegrationJob\n  job_id: 0073f736-4025-4d59-94ea-bd26a75b067c\n  provider_job_id: \n  queue_name: default\n  priority: 20\n  arguments: []\n  executions: 0\n  exception_executions: {}\n  locale: en\n  timezone: UTC\n  enqueued_at: '2023-07-26T10:10:11Z'\n	\N	2023-07-26 11:55:00+01	\N	\N	\N	2023-07-26 11:10:11.98918+01	2023-07-26 11:50:04.350887+01	default	*/5 * * * *
17	10	3	--- !ruby/object:ActiveJob::QueueAdapters::DelayedJobAdapter::JobWrapper\njob_data:\n  job_class: Notifications::ScheduleDateAlertsNotificationsJob\n  job_id: 3d9ce2dc-936b-4c8f-a13a-cc1ef5ea9945\n  provider_job_id: \n  queue_name: default\n  priority: \n  arguments: []\n  executions: 0\n  exception_executions: {}\n  locale: en\n  timezone: UTC\n  enqueued_at: '2023-07-26T10:10:12Z'\n	\N	2023-07-26 12:00:00+01	\N	\N	\N	2023-07-26 11:10:12.046661+01	2023-07-26 11:45:00.9597+01	default	*/15 * * * *
19	10	0	--- !ruby/object:ActiveJob::QueueAdapters::DelayedJobAdapter::JobWrapper\njob_data:\n  job_class: Ldap::SynchronizationJob\n  job_id: '09290bfa-c7a0-48ea-86c0-6dc935c1b796'\n  provider_job_id: \n  queue_name: default\n  priority: \n  arguments: []\n  executions: 0\n  exception_executions: {}\n  locale: en\n  timezone: UTC\n  enqueued_at: '2023-07-26T10:10:12Z'\n	\N	2023-07-27 00:30:00+01	\N	\N	\N	2023-07-26 11:10:12.061992+01	2023-07-26 11:10:12.061992+01	default	30 23 * * *
18	10	3	--- !ruby/object:ActiveJob::QueueAdapters::DelayedJobAdapter::JobWrapper\njob_data:\n  job_class: Notifications::ScheduleReminderMailsJob\n  job_id: a245370d-75c0-4eb8-b9b0-5ffaea375d2a\n  provider_job_id: \n  queue_name: default\n  priority: \n  arguments: []\n  executions: 0\n  exception_executions: {}\n  locale: en\n  timezone: UTC\n  enqueued_at: '2023-07-26T10:10:12Z'\n	\N	2023-07-26 12:00:00+01	\N	\N	\N	2023-07-26 11:10:12.055932+01	2023-07-26 11:45:00.990226+01	default	*/15 * * * *
75	7	0	--- !ruby/object:ActiveJob::QueueAdapters::DelayedJobAdapter::JobWrapper\njob_data:\n  job_class: BackupJob\n  job_id: 6c39252e-fb83-4841-b150-bbc937f684f9\n  provider_job_id: \n  queue_name: default\n  priority: 7\n  arguments:\n  - backup:\n      _aj_globalid: gid://open-project/Backup/7\n    user:\n      _aj_globalid: gid://open-project/User/4\n    include_attachments: true\n    _aj_ruby2_keywords:\n    - backup\n    - user\n    - include_attachments\n  executions: 0\n  exception_executions: {}\n  locale: en\n  timezone: UTC\n  enqueued_at: '2023-07-31T07:22:23Z'\n	\N	2023-07-31 08:22:23.514934+01	\N	\N	\N	2023-07-31 08:22:23.514973+01	2023-07-31 08:22:23.514973+01	default	\N
\.


--
-- Data for Name: design_colors; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.design_colors (id, variable, hexcode, created_at, updated_at) FROM stdin;
17	primary-color	#1A67A3	2023-07-30 22:47:37.76714+01	2023-07-30 22:47:37.76714+01
18	primary-color-dark	#175A8E	2023-07-30 22:47:37.770067+01	2023-07-30 22:47:37.770067+01
19	alternative-color	#35C53F	2023-07-30 22:47:37.773401+01	2023-07-30 22:47:37.773401+01
20	content-link-color	#175A8E	2023-07-30 22:47:37.776021+01	2023-07-30 22:47:37.776021+01
21	header-bg-color	#1A67A3	2023-07-30 22:47:37.778907+01	2023-07-30 22:47:37.778907+01
22	header-item-bg-hover-color	#175A8E	2023-07-30 22:47:37.781432+01	2023-07-30 22:47:37.781432+01
23	header-item-font-color	#FFFFFF	2023-07-30 22:47:37.784055+01	2023-07-30 22:47:37.784055+01
24	header-item-font-hover-color	#FFFFFF	2023-07-30 22:47:37.786344+01	2023-07-30 22:47:37.786344+01
25	main-menu-bg-color	#333739	2023-07-30 22:47:37.790001+01	2023-07-30 22:47:37.790001+01
26	main-menu-bg-selected-background	#175A8E	2023-07-30 22:47:37.791965+01	2023-07-30 22:47:37.791965+01
27	main-menu-bg-hover-background	#124E7C	2023-07-30 22:47:37.794131+01	2023-07-30 22:47:37.794131+01
28	main-menu-font-color	#FFFFFF	2023-07-30 22:47:37.795924+01	2023-07-30 22:47:37.795924+01
29	main-menu-hover-font-color	#FFFFFF	2023-07-30 22:47:37.79763+01	2023-07-30 22:47:37.79763+01
30	main-menu-selected-font-color	#FFFFFF	2023-07-30 22:47:37.799244+01	2023-07-30 22:47:37.799244+01
31	main-menu-border-color	#EAEAEA	2023-07-30 22:47:37.801031+01	2023-07-30 22:47:37.801031+01
\.


--
-- Data for Name: document_journals; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.document_journals (id, project_id, category_id, title, description) FROM stdin;
\.


--
-- Data for Name: documents; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.documents (id, project_id, category_id, title, description, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: done_statuses_for_project; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.done_statuses_for_project (project_id, status_id) FROM stdin;
\.


--
-- Data for Name: enabled_modules; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.enabled_modules (id, project_id, name) FROM stdin;
1	1	work_package_tracking
2	1	news
3	1	wiki
4	1	board_view
5	1	team_planner_view
6	2	backlogs
7	2	news
8	2	wiki
9	2	work_package_tracking
10	2	board_view
11	3	board_view
12	3	work_package_tracking
13	3	costs
14	3	reporting_module
15	3	backlogs
16	4	board_view
17	4	work_package_tracking
18	4	costs
19	4	reporting_module
20	4	backlogs
21	5	board_view
22	5	work_package_tracking
23	5	costs
24	5	reporting_module
25	5	backlogs
26	6	board_view
27	6	work_package_tracking
28	6	costs
29	6	reporting_module
30	6	backlogs
\.


--
-- Data for Name: enterprise_tokens; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.enterprise_tokens (id, encoded_token, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: enumerations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.enumerations (id, name, "position", is_default, type, active, project_id, parent_id, created_at, updated_at, color_id) FROM stdin;
1	Management	1	t	TimeEntryActivity	t	\N	\N	2023-07-26 09:22:05.723064+01	2023-07-26 09:22:05.723064+01	\N
2	Specification	2	f	TimeEntryActivity	t	\N	\N	2023-07-26 09:22:05.726455+01	2023-07-26 09:22:05.726455+01	\N
3	Development	3	f	TimeEntryActivity	t	\N	\N	2023-07-26 09:22:05.730651+01	2023-07-26 09:22:05.730651+01	\N
4	Testing	4	f	TimeEntryActivity	t	\N	\N	2023-07-26 09:22:05.734165+01	2023-07-26 09:22:05.734165+01	\N
5	Support	5	f	TimeEntryActivity	t	\N	\N	2023-07-26 09:22:05.737361+01	2023-07-26 09:22:05.737361+01	\N
6	Other	6	f	TimeEntryActivity	t	\N	\N	2023-07-26 09:22:05.740964+01	2023-07-26 09:22:05.740964+01	\N
7	Low	1	f	IssuePriority	t	\N	\N	2023-07-26 09:22:06.810486+01	2023-07-26 09:22:06.810486+01	86
8	Normal	2	t	IssuePriority	t	\N	\N	2023-07-26 09:22:06.816294+01	2023-07-26 09:22:06.816294+01	78
9	High	3	f	IssuePriority	t	\N	\N	2023-07-26 09:22:06.819827+01	2023-07-26 09:22:06.819827+01	132
10	Immediate	4	f	IssuePriority	t	\N	\N	2023-07-26 09:22:06.822973+01	2023-07-26 09:22:06.822973+01	50
11	Documentation	1	f	DocumentCategory	t	\N	\N	2023-07-26 09:22:07.320959+01	2023-07-26 09:22:07.320959+01	\N
12	Specification	2	f	DocumentCategory	t	\N	\N	2023-07-26 09:22:07.326671+01	2023-07-26 09:22:07.326671+01	\N
13	Other	3	f	DocumentCategory	t	\N	\N	2023-07-26 09:22:07.329521+01	2023-07-26 09:22:07.329521+01	\N
\.


--
-- Data for Name: export_card_configurations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.export_card_configurations (id, name, per_page, page_size, orientation, rows, active, description) FROM stdin;
\.


--
-- Data for Name: exports; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.exports (id, created_at, updated_at, type) FROM stdin;
1	2023-07-28 13:26:03.448696+01	2023-07-28 13:26:07.44397+01	WorkPackages::Export
2	2023-07-31 08:18:41.757396+01	2023-07-31 08:19:13.733799+01	WorkPackages::Export
\.


--
-- Data for Name: file_links; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.file_links (id, storage_id, creator_id, container_id, container_type, origin_id, origin_name, origin_created_by_name, origin_last_modified_by_name, origin_mime_type, origin_created_at, origin_updated_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: forums; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.forums (id, project_id, name, description, "position", topics_count, messages_count, last_message_id) FROM stdin;
\.


--
-- Data for Name: github_check_runs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.github_check_runs (id, github_pull_request_id, github_id, github_html_url, app_id, github_app_owner_avatar_url, status, name, conclusion, output_title, output_summary, details_url, started_at, completed_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: github_pull_requests; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.github_pull_requests (id, github_user_id, merged_by_id, github_id, number, github_html_url, state, repository, github_updated_at, title, body, draft, merged, merged_at, comments_count, review_comments_count, additions_count, deletions_count, changed_files_count, labels, created_at, updated_at, repository_html_url) FROM stdin;
\.


--
-- Data for Name: github_pull_requests_work_packages; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.github_pull_requests_work_packages (github_pull_request_id, work_package_id) FROM stdin;
\.


--
-- Data for Name: github_users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.github_users (id, github_id, github_login, github_html_url, github_avatar_url, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: grid_widgets; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.grid_widgets (id, start_row, end_row, start_column, end_column, identifier, options, grid_id) FROM stdin;
1	1	2	1	2	work_package_query	---\n:query_id: 5\n:filters:\n- :status:\n    :operator: "="\n    :values:\n    - '1'\n	1
2	1	2	2	3	work_package_query	---\n:query_id: 6\n:filters:\n- :status:\n    :operator: "="\n    :values:\n    - '7'\n	1
3	1	2	3	4	work_package_query	---\n:query_id: 7\n:filters:\n- :status:\n    :operator: "="\n    :values:\n    - '12'\n	1
4	1	2	4	5	work_package_query	---\n:query_id: 8\n:filters:\n- :status:\n    :operator: "="\n    :values:\n    - '14'\n	1
5	1	2	1	2	work_package_query	---\n:query_id: 9\n:filters:\n- :manualSort:\n    :operator: ow\n    :values: []\n	2
6	1	2	2	3	work_package_query	---\n:query_id: 10\n:filters:\n- :manualSort:\n    :operator: ow\n    :values: []\n	2
7	1	2	3	4	work_package_query	---\n:query_id: 11\n:filters:\n- :manualSort:\n    :operator: ow\n    :values: []\n	2
8	1	2	4	5	work_package_query	---\n:query_id: 12\n:filters:\n- :manualSort:\n    :operator: ow\n    :values: []\n	2
9	1	2	1	2	work_package_query	---\n:query_id: 13\n:filters:\n- :parent:\n    :operator: "="\n    :values:\n    - '2'\n	3
10	1	2	2	3	work_package_query	---\n:query_id: 14\n:filters:\n- :parent:\n    :operator: "="\n    :values:\n    - '10'\n	3
11	1	2	1	2	work_package_query	---\n:query_id: 19\n:filters:\n- :status:\n    :operator: "="\n    :values:\n    - '1'\n	4
12	1	2	2	3	work_package_query	---\n:query_id: 20\n:filters:\n- :status:\n    :operator: "="\n    :values:\n    - '7'\n	4
13	1	2	3	4	work_package_query	---\n:query_id: 21\n:filters:\n- :status:\n    :operator: "="\n    :values:\n    - '12'\n	4
14	1	2	4	5	work_package_query	---\n:query_id: 22\n:filters:\n- :status:\n    :operator: "="\n    :values:\n    - '14'\n	4
15	1	2	1	2	work_package_query	---\n:query_id: 23\n:filters:\n- :manualSort:\n    :operator: ow\n    :values: []\n	5
16	1	2	2	3	work_package_query	---\n:query_id: 24\n:filters:\n- :manualSort:\n    :operator: ow\n    :values: []\n	5
17	1	2	3	4	work_package_query	---\n:query_id: 25\n:filters:\n- :manualSort:\n    :operator: ow\n    :values: []\n	5
18	1	2	4	5	work_package_query	---\n:query_id: 26\n:filters:\n- :manualSort:\n    :operator: ow\n    :values: []\n	5
19	1	2	1	3	custom_text	---\ntext: "![Teaser](/api/v3/attachments/1/content)"\nname: Welcome\n	6
20	2	5	1	2	custom_text	---\nname: Getting started\ntext: |\n  We are glad you joined! We suggest to try a few things to get started in OpenProject.\n\n  Discover the most important features with our [Guided Tour]({{opSetting:base_url}}/projects/demo-project/work_packages/?start_onboarding_tour=true).\n\n  _Try the following steps:_\n\n  1. *Invite new members to your project*: &rightarrow; Go to [Members]({{opSetting:base_url}}/projects/demo-project/members) in the project navigation.\n  2. *View the work in your project*: &rightarrow; Go to [Work packages]({{opSetting:base_url}}/projects/demo-project/work_packages) in the project navigation.\n  3. *Create a new work package*: &rightarrow; Go to [Work packages &rightarrow; Create]({{opSetting:base_url}}/projects/demo-project/work_packages/new).\n  4. *Create and update a project plan*: &rightarrow; Go to [Project plan]({{opSetting:base_url}}/projects/demo-project/work_packages?query_id=1) in the project navigation.\n  5. *Activate further modules*: &rightarrow; Go to [Project settings &rightarrow; Modules]({{opSetting:base_url}}/projects/demo-project/settings/modules).\n  6. *Complete your tasks in the project*: &rightarrow; Go to [Work packages &rightarrow; Tasks]({{opSetting:base_url}}/projects/demo-project/work_packages/details/3/overview?query_id=3).\n\n  Here you will find our [User Guides](https://www.openproject.org/docs/user-guide/).\n  Please let us know if you have any questions or need support. Contact us: [support[at]openproject.com](mailto:support@openproject.com).\n	6
21	2	3	2	3	project_status	\N	6
22	3	4	2	3	project_description	\N	6
23	4	5	2	3	members	---\nname: Members\n	6
24	5	6	1	3	work_packages_overview	---\nname: Work packages\n	6
25	6	7	1	3	work_packages_table	---\nqueryId: '2'\nname: Milestones\n	6
26	1	2	1	3	custom_text	---\ntext: "![Teaser](/api/v3/attachments/2/content)"\nname: Welcome\n	7
27	2	5	1	2	custom_text	---\nname: Getting started\ntext: |\n  We are glad you joined! We suggest to try a few things to get started in OpenProject.\n\n  Discover the most important features with our [Guided Tour]({{opSetting:base_url}}/projects/your-scrum-project/backlogs?start_scrum_onboarding_tour=true).\n\n  _Try the following steps:_\n\n  1. *Invite new members to your project*: &rightarrow; Go to [Members]({{opSetting:base_url}}/projects/your-scrum-project/members) in the project navigation.\n  2. *View your Product backlog and Sprint backlogs*: &rightarrow; Go to [Backlogs]({{opSetting:base_url}}/projects/your-scrum-project/backlogs) in the project navigation.\n  3. *View your Task board*: &rightarrow; Go to [Backlogs]({{opSetting:base_url}}/projects/your-scrum-project/backlogs) &rightarrow; Click on right arrow on Sprint &rightarrow; Select [Task Board](/projects/your-scrum-project/sprints/3/taskboard).\n  4. *Create a new work package*: &rightarrow; Go to [Work packages &rightarrow; Create]({{opSetting:base_url}}/projects/your-scrum-project/work_packages/new).\n  5. *Create and update a project plan*: &rightarrow; Go to [Project plan](/projects/your-scrum-project/work_packages?query_id=15) in the project navigation.\n  6. *Create a Sprint wiki*: &rightarrow; Go to [Backlogs]({{opSetting:base_url}}/projects/your-scrum-project/backlogs) and open the sprint wiki from the right drop down menu in a sprint. You can edit the [wiki template]({{opSetting:base_url}}/projects/your-scrum-project/wiki/) based on your needs.\n  7. *Activate further modules*: &rightarrow; Go to [Project settings &rightarrow; Modules]({{opSetting:base_url}}/projects/your-scrum-project/settings/modules).\n\n  Here you will find our [User Guides](https://www.openproject.org/docs/user-guide/).\n  Please let us know if you have any questions or need support. Contact us: [support[at]openproject.com](mailto:support@openproject.com).\n	7
28	2	3	2	3	project_status	\N	7
29	3	4	2	3	project_description	\N	7
30	4	5	2	3	members	---\nname: Members\n	7
31	5	6	1	3	work_packages_overview	---\nname: Work packages\n	7
32	6	7	1	3	work_packages_table	---\nqueryId: '15'\nname: Project plan\n	7
\.


--
-- Data for Name: grids; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.grids (id, row_count, column_count, type, user_id, created_at, updated_at, project_id, name, options) FROM stdin;
1	1	4	Boards::Grid	\N	2023-07-26 09:22:08.603512+01	2023-07-26 09:22:08.603512+01	1	Kanban board	---\ntype: action\nattribute: status\nhighlightingMode: priority\n:filters:\n- :type:\n    :operator: "="\n    :values:\n    - '1'\n
2	1	4	Boards::Grid	\N	2023-07-26 09:22:08.640498+01	2023-07-26 09:22:08.640498+01	1	Basic board	---\nhighlightingMode: priority\n
3	1	2	Boards::Grid	\N	2023-07-26 09:22:08.665656+01	2023-07-26 09:22:08.665656+01	1	Work breakdown structure	---\ntype: action\nattribute: subtasks\n
4	1	4	Boards::Grid	\N	2023-07-26 09:22:09.870852+01	2023-07-26 09:22:09.870852+01	2	Kanban board	---\ntype: action\nattribute: status\nhighlightingMode: priority\n
5	1	4	Boards::Grid	\N	2023-07-26 09:22:09.90046+01	2023-07-26 09:22:09.90046+01	2	Task board	---\nhighlightingMode: priority\n
6	6	2	Grids::Overview	\N	2023-07-26 09:22:09.912139+01	2023-07-26 09:22:09.912139+01	1	\N	\N
7	6	2	Grids::Overview	\N	2023-07-26 09:22:09.961127+01	2023-07-26 09:22:09.961127+01	2	\N	\N
\.


--
-- Data for Name: group_users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.group_users (group_id, user_id, id) FROM stdin;
\.


--
-- Data for Name: ical_token_query_assignments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ical_token_query_assignments (id, ical_token_id, query_id, created_at, updated_at, name) FROM stdin;
\.


--
-- Data for Name: ifc_models; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ifc_models (id, title, created_at, updated_at, project_id, uploader_id, is_default, conversion_status, conversion_error_message) FROM stdin;
\.


--
-- Data for Name: journals; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.journals (id, journable_type, journable_id, user_id, notes, created_at, version, updated_at, data_type, data_id) FROM stdin;
1	Project	1	3		2023-07-26 09:22:07.602264+01	1	2023-07-26 09:22:07.602264+01	Journal::ProjectJournal	1
2	News	1	3		2023-07-26 09:22:07.720793+01	1	2023-07-26 09:22:07.720793+01	Journal::NewsJournal	1
3	WorkPackage	1	3		2023-07-26 09:22:07.861971+01	1	2023-07-26 09:22:07.861971+01	Journal::WorkPackageJournal	1
6	WorkPackage	4	3		2023-07-26 09:22:07.98944+01	1	2023-07-26 09:22:08.033761+01	Journal::WorkPackageJournal	5
7	WorkPackage	5	3		2023-07-26 09:22:08.04898+01	1	2023-07-26 09:22:08.085407+01	Journal::WorkPackageJournal	7
8	WorkPackage	6	3		2023-07-26 09:22:08.099198+01	1	2023-07-26 09:22:08.14419+01	Journal::WorkPackageJournal	9
5	WorkPackage	3	3		2023-07-26 09:22:07.963258+01	1	2023-07-26 09:22:08.196132+01	Journal::WorkPackageJournal	11
9	WorkPackage	7	3		2023-07-26 09:22:08.211407+01	1	2023-07-26 09:22:08.254661+01	Journal::WorkPackageJournal	13
10	WorkPackage	8	3		2023-07-26 09:22:08.271391+01	1	2023-07-26 09:22:08.309413+01	Journal::WorkPackageJournal	15
4	WorkPackage	2	3		2023-07-26 09:22:07.933492+01	1	2023-07-26 09:22:08.329748+01	Journal::WorkPackageJournal	16
11	WorkPackage	9	3		2023-07-26 09:22:08.34986+01	1	2023-07-26 09:22:08.34986+01	Journal::WorkPackageJournal	17
13	WorkPackage	11	3		2023-07-26 09:22:08.40803+01	1	2023-07-26 09:22:08.456445+01	Journal::WorkPackageJournal	20
14	WorkPackage	12	3		2023-07-26 09:22:08.473451+01	1	2023-07-26 09:22:08.510069+01	Journal::WorkPackageJournal	22
12	WorkPackage	10	3		2023-07-26 09:22:08.382407+01	1	2023-07-26 09:22:08.523806+01	Journal::WorkPackageJournal	23
15	WorkPackage	13	3		2023-07-26 09:22:08.536543+01	1	2023-07-26 09:22:08.536543+01	Journal::WorkPackageJournal	24
16	Project	2	3		2023-07-26 09:22:08.69182+01	1	2023-07-26 09:22:08.69182+01	Journal::ProjectJournal	2
17	News	2	3		2023-07-26 09:22:08.741165+01	1	2023-07-26 09:22:08.741165+01	Journal::NewsJournal	2
18	WikiPage	1	3		2023-07-26 09:22:08.797831+01	1	2023-07-26 09:22:08.797831+01	Journal::WikiPageJournal	1
19	WikiPage	2	3		2023-07-26 09:22:08.887046+01	1	2023-07-26 09:22:08.887046+01	Journal::WikiPageJournal	2
20	WorkPackage	14	3		2023-07-26 09:22:08.914479+01	1	2023-07-26 09:22:08.914479+01	Journal::WorkPackageJournal	25
21	WorkPackage	15	3		2023-07-26 09:22:08.953453+01	1	2023-07-26 09:22:08.953453+01	Journal::WorkPackageJournal	26
23	WorkPackage	17	3		2023-07-26 09:22:09.00801+01	1	2023-07-26 09:22:09.056722+01	Journal::WorkPackageJournal	29
24	WorkPackage	18	3		2023-07-26 09:22:09.074143+01	1	2023-07-26 09:22:09.116664+01	Journal::WorkPackageJournal	31
26	WorkPackage	20	3		2023-07-26 09:22:09.163901+01	1	2023-07-26 09:22:09.20149+01	Journal::WorkPackageJournal	34
25	WorkPackage	19	3		2023-07-26 09:22:09.133711+01	1	2023-07-26 09:22:09.25017+01	Journal::WorkPackageJournal	36
22	WorkPackage	16	3		2023-07-26 09:22:08.985574+01	1	2023-07-26 09:22:09.268069+01	Journal::WorkPackageJournal	37
27	WorkPackage	21	3		2023-07-26 09:22:09.28385+01	1	2023-07-26 09:22:09.28385+01	Journal::WorkPackageJournal	38
29	WorkPackage	23	3		2023-07-26 09:22:09.346099+01	1	2023-07-26 09:22:09.387285+01	Journal::WorkPackageJournal	41
28	WorkPackage	22	3		2023-07-26 09:22:09.315148+01	1	2023-07-26 09:22:09.403846+01	Journal::WorkPackageJournal	42
30	WorkPackage	24	3		2023-07-26 09:22:09.419672+01	1	2023-07-26 09:22:09.419672+01	Journal::WorkPackageJournal	43
31	WorkPackage	25	3		2023-07-26 09:22:09.451078+01	1	2023-07-26 09:22:09.451078+01	Journal::WorkPackageJournal	44
32	WorkPackage	26	3		2023-07-26 09:22:09.489023+01	1	2023-07-26 09:22:09.489023+01	Journal::WorkPackageJournal	45
33	WorkPackage	27	3		2023-07-26 09:22:09.525581+01	1	2023-07-26 09:22:09.525581+01	Journal::WorkPackageJournal	46
35	WorkPackage	29	3		2023-07-26 09:22:09.588829+01	1	2023-07-26 09:22:09.627076+01	Journal::WorkPackageJournal	49
34	WorkPackage	28	3		2023-07-26 09:22:09.560194+01	1	2023-07-26 09:22:09.641843+01	Journal::WorkPackageJournal	50
36	WorkPackage	30	3		2023-07-26 09:22:09.655628+01	1	2023-07-26 09:22:09.655628+01	Journal::WorkPackageJournal	51
37	WorkPackage	31	3		2023-07-26 09:22:09.685346+01	1	2023-07-26 09:22:09.685346+01	Journal::WorkPackageJournal	52
38	WorkPackage	32	3		2023-07-26 09:22:09.712085+01	1	2023-07-26 09:22:09.712085+01	Journal::WorkPackageJournal	53
39	WorkPackage	33	3		2023-07-26 09:22:09.744906+01	1	2023-07-26 09:22:09.744906+01	Journal::WorkPackageJournal	54
40	WorkPackage	34	3		2023-07-26 09:22:09.771828+01	1	2023-07-26 09:22:09.771828+01	Journal::WorkPackageJournal	55
41	WorkPackage	35	3		2023-07-26 09:22:09.799192+01	1	2023-07-26 09:22:09.799192+01	Journal::WorkPackageJournal	56
42	WorkPackage	36	3		2023-07-26 09:22:09.828692+01	1	2023-07-26 09:22:09.828692+01	Journal::WorkPackageJournal	57
43	Attachment	1	3		2023-07-26 09:22:09.932178+01	1	2023-07-26 09:22:09.932178+01	Journal::AttachmentJournal	1
44	Attachment	2	3		2023-07-26 09:22:09.966339+01	1	2023-07-26 09:22:09.966339+01	Journal::AttachmentJournal	2
45	Project	3	3		2023-07-26 09:22:10.822769+01	1	2023-07-26 09:22:10.822769+01	Journal::ProjectJournal	3
46	Project	4	3		2023-07-26 09:22:10.871751+01	1	2023-07-26 09:22:10.871751+01	Journal::ProjectJournal	4
47	Project	5	3		2023-07-26 09:22:10.918119+01	1	2023-07-26 09:22:10.918119+01	Journal::ProjectJournal	5
48	Project	6	3		2023-07-26 09:22:10.977801+01	1	2023-07-26 09:22:11.104739+01	Journal::ProjectJournal	7
50	Attachment	4	4		2023-07-28 13:26:07.402459+01	1	2023-07-28 13:26:07.402459+01	Journal::AttachmentJournal	4
52	WorkPackage	2	4		2023-07-30 22:45:37.910753+01	2	2023-07-30 22:47:10.110011+01	Journal::WorkPackageJournal	59
54	Attachment	7	4		2023-07-31 08:17:53.639478+01	1	2023-07-31 08:17:53.639478+01	Journal::AttachmentJournal	7
56	Attachment	8	4		2023-07-31 08:18:14.717365+01	1	2023-07-31 08:18:14.717365+01	Journal::AttachmentJournal	8
55	WorkPackage	2	4		2023-07-31 08:17:53.652717+01	3	2023-07-31 08:18:14.731889+01	Journal::WorkPackageJournal	62
57	Attachment	9	4		2023-07-31 08:19:13.689779+01	1	2023-07-31 08:19:13.689779+01	Journal::AttachmentJournal	9
\.


--
-- Data for Name: labor_budget_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.labor_budget_items (id, budget_id, hours, user_id, comments, amount) FROM stdin;
\.


--
-- Data for Name: last_project_folders; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.last_project_folders (id, projects_storage_id, origin_folder_id, mode, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: ldap_groups_memberships; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ldap_groups_memberships (id, user_id, group_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: ldap_groups_synchronized_filters; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ldap_groups_synchronized_filters (id, name, group_name_attribute, filter_string, auth_source_id, created_at, updated_at, base_dn, sync_users) FROM stdin;
\.


--
-- Data for Name: ldap_groups_synchronized_groups; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ldap_groups_synchronized_groups (id, group_id, auth_source_id, created_at, updated_at, dn, users_count, filter_id, sync_users) FROM stdin;
\.


--
-- Data for Name: material_budget_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.material_budget_items (id, budget_id, units, cost_type_id, comments, amount) FROM stdin;
\.


--
-- Data for Name: meeting_content_journals; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.meeting_content_journals (id, meeting_id, author_id, text, locked) FROM stdin;
\.


--
-- Data for Name: meeting_contents; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.meeting_contents (id, type, meeting_id, author_id, text, lock_version, created_at, updated_at, locked) FROM stdin;
\.


--
-- Data for Name: meeting_journals; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.meeting_journals (id, title, author_id, project_id, location, start_time, duration) FROM stdin;
\.


--
-- Data for Name: meeting_participants; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.meeting_participants (id, user_id, meeting_id, email, name, invited, attended, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: meetings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.meetings (id, title, author_id, project_id, location, start_time, duration, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: member_roles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.member_roles (id, member_id, role_id, inherited_from) FROM stdin;
1	1	5	\N
2	2	5	\N
3	3	4	\N
4	4	4	\N
5	5	4	\N
6	6	4	\N
7	7	3	\N
8	8	3	\N
9	9	3	\N
10	10	3	\N
11	11	5	\N
12	12	5	\N
13	13	5	\N
14	14	5	\N
\.


--
-- Data for Name: members; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.members (id, user_id, project_id, created_at, updated_at) FROM stdin;
1	4	1	2023-07-26 09:22:07.714588+01	2023-07-26 09:22:07.716519+01
2	4	2	2023-07-26 09:22:08.739401+01	2023-07-26 09:22:08.740937+01
3	5	3	2023-07-26 09:22:10.993952+01	2023-07-26 09:22:10.995167+01
4	5	4	2023-07-26 09:22:10.997454+01	2023-07-26 09:22:10.998813+01
5	5	5	2023-07-26 09:22:11.000963+01	2023-07-26 09:22:11.002039+01
6	5	6	2023-07-26 09:22:11.004444+01	2023-07-26 09:22:11.00584+01
7	6	3	2023-07-26 09:22:11.009549+01	2023-07-26 09:22:11.011278+01
8	6	4	2023-07-26 09:22:11.013336+01	2023-07-26 09:22:11.014617+01
9	6	5	2023-07-26 09:22:11.016614+01	2023-07-26 09:22:11.017699+01
10	6	6	2023-07-26 09:22:11.01976+01	2023-07-26 09:22:11.020965+01
11	7	3	2023-07-26 09:22:11.02357+01	2023-07-26 09:22:11.025031+01
12	7	4	2023-07-26 09:22:11.027436+01	2023-07-26 09:22:11.02873+01
13	7	5	2023-07-26 09:22:11.031272+01	2023-07-26 09:22:11.032614+01
14	7	6	2023-07-26 09:22:11.034502+01	2023-07-26 09:22:11.035896+01
\.


--
-- Data for Name: menu_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.menu_items (id, name, title, parent_id, options, navigatable_id, type) FROM stdin;
1	wiki	Wiki	\N	---\n:new_wiki_page: true\n:index_page: true\n	1	MenuItems::WikiMenuItem
2	wiki	Wiki	\N	---\n:new_wiki_page: true\n:index_page: true\n	2	MenuItems::WikiMenuItem
\.


--
-- Data for Name: message_journals; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.message_journals (id, forum_id, parent_id, subject, content, author_id, locked, sticky) FROM stdin;
\.


--
-- Data for Name: messages; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.messages (id, forum_id, parent_id, subject, content, author_id, replies_count, last_reply_id, created_at, updated_at, locked, sticky, sticked_on) FROM stdin;
\.


--
-- Data for Name: news; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.news (id, project_id, title, summary, description, author_id, created_at, comments_count, updated_at) FROM stdin;
1	1	Welcome to your demo project	We are glad you joined.\nIn this module you can communicate project news to your team members.\n	The actual news	4	2023-07-26 09:22:07.720793+01	0	2023-07-26 09:22:07.720793+01
2	2	Welcome to your Scrum demo project	We are glad you joined.\nIn this module you can communicate project news to your team members.\n	This is the news content.	4	2023-07-26 09:22:08.741165+01	0	2023-07-26 09:22:08.741165+01
\.


--
-- Data for Name: news_journals; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.news_journals (id, project_id, title, summary, description, author_id, comments_count) FROM stdin;
1	1	Welcome to your demo project	We are glad you joined.\nIn this module you can communicate project news to your team members.\n	The actual news	4	0
2	2	Welcome to your Scrum demo project	We are glad you joined.\nIn this module you can communicate project news to your team members.\n	This is the news content.	4	0
\.


--
-- Data for Name: non_working_days; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.non_working_days (id, name, date, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: notification_settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.notification_settings (id, project_id, user_id, watched, mentioned, created_at, updated_at, work_package_commented, work_package_created, work_package_processed, work_package_prioritized, work_package_scheduled, news_added, news_commented, document_added, forum_messages, wiki_page_added, wiki_page_updated, membership_added, membership_updated, start_date, due_date, overdue, assignee, responsible) FROM stdin;
1	\N	4	t	t	2023-07-26 09:22:07.346311+01	2023-07-26 09:22:07.346311+01	f	f	f	f	f	f	f	f	f	f	f	f	f	1	1	\N	t	t
2	\N	5	t	t	2023-07-26 09:22:09.99218+01	2023-07-26 09:22:09.99218+01	f	f	f	f	f	f	f	f	f	f	f	f	f	1	1	\N	t	t
3	\N	6	t	t	2023-07-26 09:22:10.170922+01	2023-07-26 09:22:10.170922+01	f	f	f	f	f	f	f	f	f	f	f	f	f	1	1	\N	t	t
4	\N	7	t	t	2023-07-26 09:22:10.376853+01	2023-07-26 09:22:10.376853+01	f	f	f	f	f	f	f	f	f	f	f	f	f	1	1	\N	t	t
5	\N	8	t	t	2023-07-26 09:22:10.543704+01	2023-07-26 09:22:10.543704+01	f	f	f	f	f	f	f	f	f	f	f	f	f	1	1	\N	t	t
\.


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.notifications (id, subject, read_ian, reason, recipient_id, actor_id, resource_type, resource_id, project_id, journal_id, created_at, updated_at, mail_reminder_sent, mail_alert_sent) FROM stdin;
\.


--
-- Data for Name: oauth_access_grants; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.oauth_access_grants (id, resource_owner_id, application_id, token, expires_in, redirect_uri, created_at, revoked_at, scopes, code_challenge, code_challenge_method) FROM stdin;
\.


--
-- Data for Name: oauth_access_tokens; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.oauth_access_tokens (id, resource_owner_id, application_id, token, refresh_token, expires_in, revoked_at, created_at, scopes, previous_refresh_token) FROM stdin;
\.


--
-- Data for Name: oauth_applications; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.oauth_applications (id, name, uid, secret, owner_type, owner_id, client_credentials_user_id, redirect_uri, scopes, confidential, created_at, updated_at, integration_type, integration_id) FROM stdin;
\.


--
-- Data for Name: oauth_client_tokens; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.oauth_client_tokens (id, oauth_client_id, user_id, access_token, refresh_token, token_type, expires_in, scope, origin_user_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: oauth_clients; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.oauth_clients (id, client_id, client_secret, integration_type, integration_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: oidc_user_session_links; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.oidc_user_session_links (id, oidc_session, session_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: ordered_work_packages; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ordered_work_packages (id, "position", query_id, work_package_id) FROM stdin;
1	0	9	8
2	1	9	11
3	0	10	7
4	0	11	3
5	0	23	16
6	1	23	25
7	2	23	27
8	0	24	14
9	0	25	26
10	0	26	24
\.


--
-- Data for Name: paper_trail_audits; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.paper_trail_audits (id, item_type, item_id, event, whodunnit, stack, object, object_changes, created_at) FROM stdin;
1	Attachment	3	destroy	4	app/controllers/admin/backups_controller.rb:199:in `destroy'\nlib/open_project/elevators/backup_preview_elevator.rb:17:in `call'	{"id": 3, "file": "openproject-backup20230726-188669-b4jwvg.zip", "digest": "35fae5b4a0fe36d788aa78db6a3da44f", "filename": "/tmp/openproject-backup20230726-188669-b4jwvg.zip", "filesize": 954034, "author_id": 4, "downloads": 0, "created_at": "07/26/2023/ 10:38 AM", "updated_at": "07/26/2023/ 10:38 AM", "description": "OpenProject backup", "container_id": 2, "content_type": "application/zip", "disk_filename": "", "container_type": "Backup"}	{"id": [3, null], "file": ["openproject-backup20230726-188669-b4jwvg.zip", null], "digest": ["35fae5b4a0fe36d788aa78db6a3da44f", null], "filename": ["/tmp/openproject-backup20230726-188669-b4jwvg.zip", null], "filesize": [954034, null], "author_id": [4, null], "downloads": [0, null], "created_at": ["07/26/2023/ 10:38 AM", null], "updated_at": ["07/26/2023/ 10:38 AM", null], "description": ["OpenProject backup", null], "container_id": [2, null], "content_type": ["application/zip", null], "disk_filename": ["", null], "container_type": ["Backup", null]}	2023-07-30 22:45:51.209553+01
2	Attachment	5	destroy	4	app/services/base_services/delete.rb:48:in `destroy'\napp/services/attachments/delete_service.rb:41:in `destroy'\napp/services/base_services/delete.rb:39:in `persist'\napp/services/base_services/base_contracted.rb:64:in `block in perform'\napp/models/journal/notification_configuration.rb:40:in `with'\napp/services/shared/service_context.rb:67:in `block in without_context_transaction'\nlib/open_project/locale_helper.rb:36:in `with_locale_for'\napp/models/user.rb:526:in `execute_as'\napp/services/shared/service_context.rb:66:in `without_context_transaction'\napp/services/shared/service_context.rb:45:in `block in in_mutex_context'\nlib/open_project/mutex.rb:70:in `block in with_advisory_lock'\nlib/open_project/mutex.rb:68:in `with_advisory_lock'\nlib/open_project/mutex.rb:62:in `block in with_advisory_lock_transaction'\nlib/open_project/mutex.rb:61:in `with_advisory_lock_transaction'\napp/services/shared/service_context.rb:44:in `in_mutex_context'\napp/services/shared/service_context.rb:35:in `in_context'\napp/services/base_services/base_contracted.rb:54:in `service_context'\napp/services/base_services/base_contracted.rb:59:in `perform'\napp/services/attachments/delete_service.rb:34:in `block in call'\napp/models/journal/notification_configuration.rb:40:in `with'\napp/services/shared/service_context.rb:67:in `block in without_context_transaction'\nlib/open_project/locale_helper.rb:36:in `with_locale_for'\napp/models/user.rb:526:in `execute_as'\napp/services/shared/service_context.rb:66:in `without_context_transaction'\napp/services/shared/service_context.rb:45:in `block in in_mutex_context'\nlib/open_project/mutex.rb:70:in `block in with_advisory_lock'\nlib/open_project/mutex.rb:68:in `with_advisory_lock'\nlib/open_project/mutex.rb:62:in `block in with_advisory_lock_transaction'\nlib/open_project/mutex.rb:61:in `with_advisory_lock_transaction'\napp/services/shared/service_context.rb:44:in `in_mutex_context'\napp/services/shared/service_context.rb:35:in `in_context'\napp/services/attachments/delete_service.rb:33:in `call'\nlib/api/utilities/endpoints/delete.rb:69:in `process'\nlib/api/utilities/endpoints/delete.rb:57:in `block in mount'\nlib/open_project/elevators/backup_preview_elevator.rb:17:in `call'	{"id": 5, "file": "Pop-Ich-klein_400x400.png", "digest": "032fc98977f330f0be42533647ff4b4a", "filename": "Pop-Ich-klein_400x400.png", "filesize": 389264, "author_id": 4, "downloads": 0, "created_at": "07/30/2023/ 21:45 PM", "updated_at": "07/30/2023/ 21:45 PM", "description": null, "container_id": 2, "content_type": "image/png", "disk_filename": "", "container_type": "WorkPackage"}	{"id": [5, null], "file": ["Pop-Ich-klein_400x400.png", null], "digest": ["032fc98977f330f0be42533647ff4b4a", null], "filename": ["Pop-Ich-klein_400x400.png", null], "filesize": [389264, null], "author_id": [4, null], "downloads": [0, null], "created_at": ["07/30/2023/ 21:45 PM", null], "updated_at": ["07/30/2023/ 21:45 PM", null], "description": [null, null], "container_id": [2, null], "content_type": ["image/png", null], "disk_filename": ["", null], "container_type": ["WorkPackage", null]}	2023-07-30 22:47:10.088341+01
3	Attachment	6	destroy	4	app/controllers/admin/backups_controller.rb:199:in `destroy'\nlib/open_project/elevators/backup_preview_elevator.rb:17:in `call'	{"id": 6, "file": "openproject-backup20230730-291985-y4h9nu.zip", "digest": "2f9fe2057655d947995f73a95c5d2d9d", "filename": "/tmp/openproject-backup20230730-291985-y4h9nu.zip", "filesize": 1352203, "author_id": 4, "downloads": 0, "created_at": "07/30/2023/ 21:46 PM", "updated_at": "07/30/2023/ 21:46 PM", "description": "OpenProject backup", "container_id": 5, "content_type": "application/zip", "disk_filename": "", "container_type": "Backup"}	{"id": [6, null], "file": ["openproject-backup20230730-291985-y4h9nu.zip", null], "digest": ["2f9fe2057655d947995f73a95c5d2d9d", null], "filename": ["/tmp/openproject-backup20230730-291985-y4h9nu.zip", null], "filesize": [1352203, null], "author_id": [4, null], "downloads": [0, null], "created_at": ["07/30/2023/ 21:46 PM", null], "updated_at": ["07/30/2023/ 21:46 PM", null], "description": ["OpenProject backup", null], "container_id": [5, null], "content_type": ["application/zip", null], "disk_filename": ["", null], "container_type": ["Backup", null]}	2023-07-31 08:17:29.733961+01
\.


--
-- Data for Name: project_journals; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.project_journals (id, name, description, public, parent_id, identifier, active, templated, status_code, status_explanation) FROM stdin;
1	Demo project	This is a short summary of the goals of this demo project.	t	\N	demo-project	t	f	0	All tasks are on schedule. The people involved know their tasks. The system is completely set up.
2	Scrum project	This is a short summary of the goals of this demo Scrum project.	t	\N	your-scrum-project	t	f	0	All tasks are on schedule. The people involved know their tasks. The system is completely set up.
3	[dev] Empty		t	\N	dev-empty	t	f	\N	
4	[dev] Large		t	\N	dev-large	t	f	\N	
5	[dev] Large child		t	4	dev-large-child	t	f	\N	
7	[dev] Custom fields		t	\N	dev-custom-fields	t	f	\N	
\.


--
-- Data for Name: projects; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.projects (id, name, description, public, parent_id, created_at, updated_at, identifier, lft, rgt, active, templated, status_code, status_explanation) FROM stdin;
3	[dev] Empty	\N	t	\N	2023-07-26 09:22:10.796501+01	2023-07-26 09:22:10.977801+01	dev-empty	3	4	t	f	\N	\N
1	Demo project	This is a short summary of the goals of this demo project.	t	\N	2023-07-26 09:22:07.602264+01	2023-07-26 09:22:10.977801+01	demo-project	9	10	t	f	0	All tasks are on schedule. The people involved know their tasks. The system is completely set up.
2	Scrum project	This is a short summary of the goals of this demo Scrum project.	t	\N	2023-07-26 09:22:08.69182+01	2023-07-26 09:22:10.977801+01	your-scrum-project	11	12	t	f	0	All tasks are on schedule. The people involved know their tasks. The system is completely set up.
4	[dev] Large	\N	t	\N	2023-07-26 09:22:10.853021+01	2023-07-26 09:22:10.977801+01	dev-large	5	8	t	f	\N	\N
5	[dev] Large child	\N	t	4	2023-07-26 09:22:10.901254+01	2023-07-26 09:22:10.977801+01	dev-large-child	6	7	t	f	\N	\N
6	[dev] Custom fields	\N	t	\N	2023-07-26 09:22:10.9544+01	2023-07-26 09:22:10.977801+01	dev-custom-fields	1	2	t	f	\N	\N
\.


--
-- Data for Name: projects_storages; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.projects_storages (id, project_id, storage_id, creator_id, created_at, updated_at, project_folder_id, project_folder_mode) FROM stdin;
\.


--
-- Data for Name: projects_types; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.projects_types (project_id, type_id) FROM stdin;
1	1
1	2
1	3
2	1
2	2
2	3
2	5
2	6
2	7
3	1
3	9
3	2
3	3
3	4
3	5
3	6
3	7
3	8
4	1
4	9
4	2
4	3
4	4
4	5
4	6
4	7
4	8
5	1
5	9
5	2
5	3
5	4
5	5
5	6
5	7
5	8
6	1
6	9
6	2
6	3
6	4
6	5
6	6
6	7
6	8
\.


--
-- Data for Name: queries; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.queries (id, project_id, name, filters, user_id, public, column_names, sort_criteria, group_by, display_sums, timeline_visible, show_hierarchies, timeline_zoom_level, timeline_labels, highlighting_mode, highlighted_attributes, created_at, updated_at, display_representation, starred, include_subprojects, timestamps) FROM stdin;
1	1	Project plan	---\nstatus_id:\n  :operator: o\n  :values: []\n	4	t	---\n- :id\n- :type\n- :subject\n- :status\n- :start_date\n- :due_date\n- :duration\n- :assigned_to\n	---\n- - id\n  - asc\n	\N	f	t	t	5	\N	\N	\N	2023-07-26 09:22:07.793566+01	2023-07-26 09:22:07.793566+01	\N	t	t	\N
2	1	Milestones	---\ntype_id:\n  :operator: "="\n  :values:\n  - '2'\n	4	t	---\n- :id\n- :type\n- :subject\n- :status\n- :start_date\n- :due_date\n	---\n- - id\n  - asc\n	\N	f	t	f	5	\N	\N	\N	2023-07-26 09:22:07.811276+01	2023-07-26 09:22:07.811276+01	\N	f	t	\N
3	1	Tasks	---\nstatus_id:\n  :operator: o\n  :values: []\ntype_id:\n  :operator: "="\n  :values:\n  - '1'\n	4	t	---\n- :id\n- :subject\n- :priority\n- :status\n- :assigned_to\n	---\n- - id\n  - asc\n	\N	f	f	t	5	\N	\N	\N	2023-07-26 09:22:07.821196+01	2023-07-26 09:22:07.821196+01	\N	f	t	\N
4	1	Team planner	---\nassigned_to_id:\n  :operator: "="\n  :values:\n  - '4'\n	4	t	\N	\N	\N	f	f	f	5	\N	\N	\N	2023-07-26 09:22:07.831215+01	2023-07-26 09:22:07.831215+01	\N	f	t	\N
5	1	New	---\nstatus_id:\n  :operator: "="\n  :values:\n  - '1'\n	4	t	\N	---\n- - manual_sorting\n  - asc\n	\N	f	f	t	5	\N	\N	\N	2023-07-26 09:22:08.579789+01	2023-07-26 09:22:08.579789+01	\N	f	t	\N
6	1	In progress	---\nstatus_id:\n  :operator: "="\n  :values:\n  - '7'\n	4	t	\N	---\n- - manual_sorting\n  - asc\n	\N	f	f	t	5	\N	\N	\N	2023-07-26 09:22:08.582947+01	2023-07-26 09:22:08.582947+01	\N	f	t	\N
7	1	Closed	---\nstatus_id:\n  :operator: "="\n  :values:\n  - '12'\n	4	t	\N	---\n- - manual_sorting\n  - asc\n	\N	f	f	t	5	\N	\N	\N	2023-07-26 09:22:08.585869+01	2023-07-26 09:22:08.585869+01	\N	f	t	\N
8	1	Rejected	---\nstatus_id:\n  :operator: "="\n  :values:\n  - '14'\n	4	t	\N	---\n- - manual_sorting\n  - asc\n	\N	f	f	t	5	\N	\N	\N	2023-07-26 09:22:08.588586+01	2023-07-26 09:22:08.588586+01	\N	f	t	\N
9	1	Wish list	---\nmanual_sort:\n  :operator: ow\n  :values: []\n	4	t	\N	---\n- - manual_sorting\n  - asc\n	\N	f	f	f	5	\N	\N	\N	2023-07-26 09:22:08.623744+01	2023-07-26 09:22:08.623744+01	\N	f	t	\N
10	1	Short list	---\nmanual_sort:\n  :operator: ow\n  :values: []\n	4	t	\N	---\n- - manual_sorting\n  - asc\n	\N	f	f	f	5	\N	\N	\N	2023-07-26 09:22:08.63021+01	2023-07-26 09:22:08.63021+01	\N	f	t	\N
11	1	Priority list for today	---\nmanual_sort:\n  :operator: ow\n  :values: []\n	4	t	\N	---\n- - manual_sorting\n  - asc\n	\N	f	f	f	5	\N	\N	\N	2023-07-26 09:22:08.635796+01	2023-07-26 09:22:08.635796+01	\N	f	t	\N
12	1	Never	---\nmanual_sort:\n  :operator: ow\n  :values: []\n	4	t	\N	---\n- - manual_sorting\n  - asc\n	\N	f	f	f	5	\N	\N	\N	2023-07-26 09:22:08.639082+01	2023-07-26 09:22:08.639082+01	\N	f	t	\N
13	1	Organize open source conference	---\nstatus_id:\n  :operator: o\n  :values:\n  - ''\nparent:\n  :operator: "="\n  :values:\n  - '2'\n	4	t	\N	---\n- - manual_sorting\n  - asc\n	\N	f	f	t	5	\N	\N	\N	2023-07-26 09:22:08.655479+01	2023-07-26 09:22:08.655479+01	\N	f	t	\N
14	1	Follow-up tasks	---\nstatus_id:\n  :operator: o\n  :values:\n  - ''\nparent:\n  :operator: "="\n  :values:\n  - '10'\n	4	t	\N	---\n- - manual_sorting\n  - asc\n	\N	f	f	t	5	\N	\N	\N	2023-07-26 09:22:08.663668+01	2023-07-26 09:22:08.663668+01	\N	f	t	\N
15	2	Project plan	---\nstatus_id:\n  :operator: o\n  :values: []\ntype_id:\n  :operator: "="\n  :values:\n  - '2'\n  - '3'\n	4	t	\N	---\n- - id\n  - asc\n	\N	f	t	f	5	\N	\N	\N	2023-07-26 09:22:08.848727+01	2023-07-26 09:22:08.848727+01	\N	f	t	\N
16	2	Product backlog	---\nstatus_id:\n  :operator: o\n  :values: []\nversion_id:\n  :operator: "="\n  :values:\n  - '2'\n	4	t	---\n- :id\n- :type\n- :subject\n- :priority\n- :status\n- :assigned_to\n- :story_points\n	---\n- - status\n  - asc\n	status	f	f	f	5	\N	\N	\N	2023-07-26 09:22:08.859243+01	2023-07-26 09:22:08.859243+01	\N	f	t	\N
17	2	Sprint 1	---\nstatus_id:\n  :operator: o\n  :values: []\nversion_id:\n  :operator: "="\n  :values:\n  - '3'\n	4	t	---\n- :id\n- :type\n- :subject\n- :priority\n- :status\n- :assigned_to\n- :done_ratio\n- :story_points\n	\N	\N	f	f	t	5	\N	\N	\N	2023-07-26 09:22:08.869675+01	2023-07-26 09:22:08.869675+01	\N	f	t	\N
18	2	Tasks	---\nstatus_id:\n  :operator: o\n  :values: []\ntype_id:\n  :operator: "="\n  :values:\n  - '1'\n	4	t	\N	\N	\N	f	f	t	5	\N	\N	\N	2023-07-26 09:22:08.880265+01	2023-07-26 09:22:08.880265+01	\N	f	t	\N
19	2	New	---\nstatus_id:\n  :operator: "="\n  :values:\n  - '1'\n	4	t	\N	---\n- - manual_sorting\n  - asc\n	\N	f	f	t	5	\N	\N	\N	2023-07-26 09:22:09.860827+01	2023-07-26 09:22:09.860827+01	\N	f	t	\N
20	2	In progress	---\nstatus_id:\n  :operator: "="\n  :values:\n  - '7'\n	4	t	\N	---\n- - manual_sorting\n  - asc\n	\N	f	f	t	5	\N	\N	\N	2023-07-26 09:22:09.863597+01	2023-07-26 09:22:09.863597+01	\N	f	t	\N
21	2	Closed	---\nstatus_id:\n  :operator: "="\n  :values:\n  - '12'\n	4	t	\N	---\n- - manual_sorting\n  - asc\n	\N	f	f	t	5	\N	\N	\N	2023-07-26 09:22:09.866298+01	2023-07-26 09:22:09.866298+01	\N	f	t	\N
22	2	Rejected	---\nstatus_id:\n  :operator: "="\n  :values:\n  - '14'\n	4	t	\N	---\n- - manual_sorting\n  - asc\n	\N	f	f	t	5	\N	\N	\N	2023-07-26 09:22:09.869227+01	2023-07-26 09:22:09.869227+01	\N	f	t	\N
23	2	Wish list	---\nmanual_sort:\n  :operator: ow\n  :values: []\n	4	t	\N	---\n- - manual_sorting\n  - asc\n	\N	f	f	f	5	\N	\N	\N	2023-07-26 09:22:09.883657+01	2023-07-26 09:22:09.883657+01	\N	f	t	\N
24	2	Short list	---\nmanual_sort:\n  :operator: ow\n  :values: []\n	4	t	\N	---\n- - manual_sorting\n  - asc\n	\N	f	f	f	5	\N	\N	\N	2023-07-26 09:22:09.889069+01	2023-07-26 09:22:09.889069+01	\N	f	t	\N
25	2	Priority list for today	---\nmanual_sort:\n  :operator: ow\n  :values: []\n	4	t	\N	---\n- - manual_sorting\n  - asc\n	\N	f	f	f	5	\N	\N	\N	2023-07-26 09:22:09.894329+01	2023-07-26 09:22:09.894329+01	\N	f	t	\N
26	2	Never	---\nmanual_sort:\n  :operator: ow\n  :values: []\n	4	t	\N	---\n- - manual_sorting\n  - asc\n	\N	f	f	f	5	\N	\N	\N	2023-07-26 09:22:09.898514+01	2023-07-26 09:22:09.898514+01	\N	f	t	\N
\.


--
-- Data for Name: rates; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.rates (id, valid_from, rate, type, project_id, user_id, cost_type_id) FROM stdin;
\.


--
-- Data for Name: recaptcha_entries; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.recaptcha_entries (id, user_id, created_at, updated_at, version) FROM stdin;
\.


--
-- Data for Name: relations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.relations (id, from_id, to_id, delay, description, relation_type) FROM stdin;
1	13	10	\N	\N	follows
2	9	2	\N	\N	follows
3	8	3	\N	\N	follows
4	7	3	\N	\N	follows
5	36	35	\N	\N	follows
6	34	33	\N	\N	follows
7	32	31	\N	\N	follows
\.


--
-- Data for Name: repositories; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.repositories (id, project_id, url, login, password, root_url, type, path_encoding, log_encoding, scm_type, required_storage_bytes, storage_updated_at) FROM stdin;
\.


--
-- Data for Name: role_permissions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.role_permissions (id, permission, role_id, created_at, updated_at) FROM stdin;
1	view_work_packages	1	2023-07-26 09:22:05.475257+01	2023-07-26 09:22:05.475257+01
2	view_calendar	1	2023-07-26 09:22:05.476355+01	2023-07-26 09:22:05.476355+01
3	comment_news	1	2023-07-26 09:22:05.477625+01	2023-07-26 09:22:05.477625+01
4	browse_repository	1	2023-07-26 09:22:05.478321+01	2023-07-26 09:22:05.478321+01
5	view_changesets	1	2023-07-26 09:22:05.479166+01	2023-07-26 09:22:05.479166+01
6	view_wiki_pages	1	2023-07-26 09:22:05.47982+01	2023-07-26 09:22:05.47982+01
7	show_board_views	1	2023-07-26 09:22:05.480413+01	2023-07-26 09:22:05.480413+01
8	share_calendars	1	2023-07-26 09:22:05.480983+01	2023-07-26 09:22:05.480983+01
9	view_file_links	1	2023-07-26 09:22:05.481647+01	2023-07-26 09:22:05.481647+01
10	view_work_packages	2	2023-07-26 09:22:05.489599+01	2023-07-26 09:22:05.489599+01
11	browse_repository	2	2023-07-26 09:22:05.490363+01	2023-07-26 09:22:05.490363+01
12	view_changesets	2	2023-07-26 09:22:05.49134+01	2023-07-26 09:22:05.49134+01
13	view_wiki_pages	2	2023-07-26 09:22:05.492051+01	2023-07-26 09:22:05.492051+01
14	view_file_links	2	2023-07-26 09:22:05.492967+01	2023-07-26 09:22:05.492967+01
15	view_work_packages	3	2023-07-26 09:22:05.501831+01	2023-07-26 09:22:05.501831+01
16	export_work_packages	3	2023-07-26 09:22:05.502489+01	2023-07-26 09:22:05.502489+01
17	add_work_packages	3	2023-07-26 09:22:05.503186+01	2023-07-26 09:22:05.503186+01
18	move_work_packages	3	2023-07-26 09:22:05.503799+01	2023-07-26 09:22:05.503799+01
19	edit_work_packages	3	2023-07-26 09:22:05.504609+01	2023-07-26 09:22:05.504609+01
20	assign_versions	3	2023-07-26 09:22:05.505475+01	2023-07-26 09:22:05.505475+01
21	work_package_assigned	3	2023-07-26 09:22:05.506767+01	2023-07-26 09:22:05.506767+01
22	add_work_package_notes	3	2023-07-26 09:22:05.507451+01	2023-07-26 09:22:05.507451+01
23	edit_own_work_package_notes	3	2023-07-26 09:22:05.508675+01	2023-07-26 09:22:05.508675+01
24	manage_work_package_relations	3	2023-07-26 09:22:05.509577+01	2023-07-26 09:22:05.509577+01
25	manage_subtasks	3	2023-07-26 09:22:05.510337+01	2023-07-26 09:22:05.510337+01
26	manage_public_queries	3	2023-07-26 09:22:05.511254+01	2023-07-26 09:22:05.511254+01
27	save_queries	3	2023-07-26 09:22:05.511946+01	2023-07-26 09:22:05.511946+01
28	view_work_package_watchers	3	2023-07-26 09:22:05.512595+01	2023-07-26 09:22:05.512595+01
29	add_work_package_watchers	3	2023-07-26 09:22:05.513198+01	2023-07-26 09:22:05.513198+01
30	delete_work_package_watchers	3	2023-07-26 09:22:05.513784+01	2023-07-26 09:22:05.513784+01
31	view_calendar	3	2023-07-26 09:22:05.514441+01	2023-07-26 09:22:05.514441+01
32	comment_news	3	2023-07-26 09:22:05.515167+01	2023-07-26 09:22:05.515167+01
33	manage_news	3	2023-07-26 09:22:05.516238+01	2023-07-26 09:22:05.516238+01
34	log_time	3	2023-07-26 09:22:05.516875+01	2023-07-26 09:22:05.516875+01
35	view_time_entries	3	2023-07-26 09:22:05.517565+01	2023-07-26 09:22:05.517565+01
36	view_own_time_entries	3	2023-07-26 09:22:05.518413+01	2023-07-26 09:22:05.518413+01
37	edit_own_time_entries	3	2023-07-26 09:22:05.519155+01	2023-07-26 09:22:05.519155+01
38	view_timelines	3	2023-07-26 09:22:05.519872+01	2023-07-26 09:22:05.519872+01
39	edit_timelines	3	2023-07-26 09:22:05.520477+01	2023-07-26 09:22:05.520477+01
40	delete_timelines	3	2023-07-26 09:22:05.521135+01	2023-07-26 09:22:05.521135+01
41	view_reportings	3	2023-07-26 09:22:05.521928+01	2023-07-26 09:22:05.521928+01
42	edit_reportings	3	2023-07-26 09:22:05.522637+01	2023-07-26 09:22:05.522637+01
43	delete_reportings	3	2023-07-26 09:22:05.523356+01	2023-07-26 09:22:05.523356+01
44	manage_wiki	3	2023-07-26 09:22:05.523992+01	2023-07-26 09:22:05.523992+01
45	manage_wiki_menu	3	2023-07-26 09:22:05.524607+01	2023-07-26 09:22:05.524607+01
46	rename_wiki_pages	3	2023-07-26 09:22:05.525726+01	2023-07-26 09:22:05.525726+01
47	change_wiki_parent_page	3	2023-07-26 09:22:05.526562+01	2023-07-26 09:22:05.526562+01
48	delete_wiki_pages	3	2023-07-26 09:22:05.527518+01	2023-07-26 09:22:05.527518+01
49	view_wiki_pages	3	2023-07-26 09:22:05.528262+01	2023-07-26 09:22:05.528262+01
50	export_wiki_pages	3	2023-07-26 09:22:05.528914+01	2023-07-26 09:22:05.528914+01
51	view_wiki_edits	3	2023-07-26 09:22:05.529617+01	2023-07-26 09:22:05.529617+01
52	edit_wiki_pages	3	2023-07-26 09:22:05.53032+01	2023-07-26 09:22:05.53032+01
53	delete_wiki_pages_attachments	3	2023-07-26 09:22:05.531078+01	2023-07-26 09:22:05.531078+01
54	protect_wiki_pages	3	2023-07-26 09:22:05.531733+01	2023-07-26 09:22:05.531733+01
55	list_attachments	3	2023-07-26 09:22:05.532312+01	2023-07-26 09:22:05.532312+01
56	add_messages	3	2023-07-26 09:22:05.532989+01	2023-07-26 09:22:05.532989+01
57	edit_own_messages	3	2023-07-26 09:22:05.533645+01	2023-07-26 09:22:05.533645+01
58	delete_own_messages	3	2023-07-26 09:22:05.534327+01	2023-07-26 09:22:05.534327+01
59	browse_repository	3	2023-07-26 09:22:05.535166+01	2023-07-26 09:22:05.535166+01
60	view_changesets	3	2023-07-26 09:22:05.535958+01	2023-07-26 09:22:05.535958+01
61	commit_access	3	2023-07-26 09:22:05.536726+01	2023-07-26 09:22:05.536726+01
62	view_commit_author_statistics	3	2023-07-26 09:22:05.537617+01	2023-07-26 09:22:05.537617+01
63	view_members	3	2023-07-26 09:22:05.538378+01	2023-07-26 09:22:05.538378+01
64	view_team_planner	3	2023-07-26 09:22:05.53909+01	2023-07-26 09:22:05.53909+01
65	view_master_backlog	3	2023-07-26 09:22:05.539817+01	2023-07-26 09:22:05.539817+01
66	view_taskboards	3	2023-07-26 09:22:05.540573+01	2023-07-26 09:22:05.540573+01
67	show_board_views	3	2023-07-26 09:22:05.541233+01	2023-07-26 09:22:05.541233+01
68	manage_board_views	3	2023-07-26 09:22:05.541858+01	2023-07-26 09:22:05.541858+01
69	share_calendars	3	2023-07-26 09:22:05.542848+01	2023-07-26 09:22:05.542848+01
70	view_own_hourly_rate	3	2023-07-26 09:22:05.543793+01	2023-07-26 09:22:05.543793+01
71	view_cost_rates	3	2023-07-26 09:22:05.544775+01	2023-07-26 09:22:05.544775+01
72	log_own_costs	3	2023-07-26 09:22:05.545485+01	2023-07-26 09:22:05.545485+01
73	edit_own_cost_entries	3	2023-07-26 09:22:05.546625+01	2023-07-26 09:22:05.546625+01
74	view_budgets	3	2023-07-26 09:22:05.547827+01	2023-07-26 09:22:05.547827+01
75	view_own_cost_entries	3	2023-07-26 09:22:05.548684+01	2023-07-26 09:22:05.548684+01
76	view_documents	3	2023-07-26 09:22:05.549447+01	2023-07-26 09:22:05.549447+01
77	manage_documents	3	2023-07-26 09:22:05.550309+01	2023-07-26 09:22:05.550309+01
78	create_meetings	3	2023-07-26 09:22:05.551021+01	2023-07-26 09:22:05.551021+01
79	edit_meetings	3	2023-07-26 09:22:05.551648+01	2023-07-26 09:22:05.551648+01
80	delete_meetings	3	2023-07-26 09:22:05.55235+01	2023-07-26 09:22:05.55235+01
81	view_meetings	3	2023-07-26 09:22:05.553097+01	2023-07-26 09:22:05.553097+01
82	create_meeting_agendas	3	2023-07-26 09:22:05.553789+01	2023-07-26 09:22:05.553789+01
83	close_meeting_agendas	3	2023-07-26 09:22:05.555097+01	2023-07-26 09:22:05.555097+01
84	send_meeting_agendas_notification	3	2023-07-26 09:22:05.555711+01	2023-07-26 09:22:05.555711+01
85	send_meeting_agendas_icalendar	3	2023-07-26 09:22:05.556466+01	2023-07-26 09:22:05.556466+01
86	create_meeting_minutes	3	2023-07-26 09:22:05.557126+01	2023-07-26 09:22:05.557126+01
87	send_meeting_minutes_notification	3	2023-07-26 09:22:05.559451+01	2023-07-26 09:22:05.559451+01
88	view_file_links	3	2023-07-26 09:22:05.56015+01	2023-07-26 09:22:05.56015+01
89	manage_file_links	3	2023-07-26 09:22:05.560905+01	2023-07-26 09:22:05.560905+01
90	view_work_packages	4	2023-07-26 09:22:05.566258+01	2023-07-26 09:22:05.566258+01
91	add_work_package_notes	4	2023-07-26 09:22:05.566911+01	2023-07-26 09:22:05.566911+01
92	edit_own_work_package_notes	4	2023-07-26 09:22:05.567619+01	2023-07-26 09:22:05.567619+01
93	save_queries	4	2023-07-26 09:22:05.568281+01	2023-07-26 09:22:05.568281+01
94	view_calendar	4	2023-07-26 09:22:05.568876+01	2023-07-26 09:22:05.568876+01
95	comment_news	4	2023-07-26 09:22:05.569495+01	2023-07-26 09:22:05.569495+01
96	view_timelines	4	2023-07-26 09:22:05.570205+01	2023-07-26 09:22:05.570205+01
97	view_reportings	4	2023-07-26 09:22:05.570853+01	2023-07-26 09:22:05.570853+01
98	view_wiki_pages	4	2023-07-26 09:22:05.571485+01	2023-07-26 09:22:05.571485+01
99	export_wiki_pages	4	2023-07-26 09:22:05.572122+01	2023-07-26 09:22:05.572122+01
100	list_attachments	4	2023-07-26 09:22:05.572771+01	2023-07-26 09:22:05.572771+01
101	add_messages	4	2023-07-26 09:22:05.573366+01	2023-07-26 09:22:05.573366+01
102	edit_own_messages	4	2023-07-26 09:22:05.580445+01	2023-07-26 09:22:05.580445+01
103	delete_own_messages	4	2023-07-26 09:22:05.581403+01	2023-07-26 09:22:05.581403+01
104	browse_repository	4	2023-07-26 09:22:05.582199+01	2023-07-26 09:22:05.582199+01
105	view_changesets	4	2023-07-26 09:22:05.582967+01	2023-07-26 09:22:05.582967+01
106	view_team_planner	4	2023-07-26 09:22:05.583982+01	2023-07-26 09:22:05.583982+01
107	view_master_backlog	4	2023-07-26 09:22:05.584709+01	2023-07-26 09:22:05.584709+01
108	view_taskboards	4	2023-07-26 09:22:05.585443+01	2023-07-26 09:22:05.585443+01
109	show_board_views	4	2023-07-26 09:22:05.586125+01	2023-07-26 09:22:05.586125+01
110	share_calendars	4	2023-07-26 09:22:05.58704+01	2023-07-26 09:22:05.58704+01
111	view_documents	4	2023-07-26 09:22:05.58769+01	2023-07-26 09:22:05.58769+01
112	view_meetings	4	2023-07-26 09:22:05.588353+01	2023-07-26 09:22:05.588353+01
113	view_file_links	4	2023-07-26 09:22:05.589064+01	2023-07-26 09:22:05.589064+01
114	archive_project	5	2023-07-26 09:22:05.601778+01	2023-07-26 09:22:05.601778+01
115	edit_project	5	2023-07-26 09:22:05.602419+01	2023-07-26 09:22:05.602419+01
116	select_project_modules	5	2023-07-26 09:22:05.603217+01	2023-07-26 09:22:05.603217+01
117	manage_members	5	2023-07-26 09:22:05.604108+01	2023-07-26 09:22:05.604108+01
118	view_members	5	2023-07-26 09:22:05.604813+01	2023-07-26 09:22:05.604813+01
119	manage_versions	5	2023-07-26 09:22:05.60552+01	2023-07-26 09:22:05.60552+01
120	manage_types	5	2023-07-26 09:22:05.606383+01	2023-07-26 09:22:05.606383+01
121	select_custom_fields	5	2023-07-26 09:22:05.607106+01	2023-07-26 09:22:05.607106+01
122	add_subprojects	5	2023-07-26 09:22:05.607739+01	2023-07-26 09:22:05.607739+01
123	copy_projects	5	2023-07-26 09:22:05.608375+01	2023-07-26 09:22:05.608375+01
124	view_work_packages	5	2023-07-26 09:22:05.609461+01	2023-07-26 09:22:05.609461+01
125	add_work_packages	5	2023-07-26 09:22:05.610343+01	2023-07-26 09:22:05.610343+01
126	edit_work_packages	5	2023-07-26 09:22:05.611013+01	2023-07-26 09:22:05.611013+01
127	move_work_packages	5	2023-07-26 09:22:05.611823+01	2023-07-26 09:22:05.611823+01
128	add_work_package_notes	5	2023-07-26 09:22:05.612785+01	2023-07-26 09:22:05.612785+01
129	edit_work_package_notes	5	2023-07-26 09:22:05.613595+01	2023-07-26 09:22:05.613595+01
130	edit_own_work_package_notes	5	2023-07-26 09:22:05.614412+01	2023-07-26 09:22:05.614412+01
131	manage_categories	5	2023-07-26 09:22:05.615315+01	2023-07-26 09:22:05.615315+01
132	export_work_packages	5	2023-07-26 09:22:05.616309+01	2023-07-26 09:22:05.616309+01
133	delete_work_packages	5	2023-07-26 09:22:05.617187+01	2023-07-26 09:22:05.617187+01
134	manage_work_package_relations	5	2023-07-26 09:22:05.618071+01	2023-07-26 09:22:05.618071+01
135	manage_subtasks	5	2023-07-26 09:22:05.619122+01	2023-07-26 09:22:05.619122+01
136	manage_public_queries	5	2023-07-26 09:22:05.620083+01	2023-07-26 09:22:05.620083+01
137	save_queries	5	2023-07-26 09:22:05.620997+01	2023-07-26 09:22:05.620997+01
138	view_work_package_watchers	5	2023-07-26 09:22:05.621815+01	2023-07-26 09:22:05.621815+01
139	add_work_package_watchers	5	2023-07-26 09:22:05.622608+01	2023-07-26 09:22:05.622608+01
140	delete_work_package_watchers	5	2023-07-26 09:22:05.62358+01	2023-07-26 09:22:05.62358+01
141	assign_versions	5	2023-07-26 09:22:05.624574+01	2023-07-26 09:22:05.624574+01
142	work_package_assigned	5	2023-07-26 09:22:05.62535+01	2023-07-26 09:22:05.62535+01
143	manage_news	5	2023-07-26 09:22:05.626408+01	2023-07-26 09:22:05.626408+01
144	comment_news	5	2023-07-26 09:22:05.627889+01	2023-07-26 09:22:05.627889+01
145	view_wiki_pages	5	2023-07-26 09:22:05.630399+01	2023-07-26 09:22:05.630399+01
146	list_attachments	5	2023-07-26 09:22:05.631668+01	2023-07-26 09:22:05.631668+01
147	manage_wiki	5	2023-07-26 09:22:05.632663+01	2023-07-26 09:22:05.632663+01
148	manage_wiki_menu	5	2023-07-26 09:22:05.633536+01	2023-07-26 09:22:05.633536+01
149	rename_wiki_pages	5	2023-07-26 09:22:05.634443+01	2023-07-26 09:22:05.634443+01
150	change_wiki_parent_page	5	2023-07-26 09:22:05.63527+01	2023-07-26 09:22:05.63527+01
151	delete_wiki_pages	5	2023-07-26 09:22:05.636085+01	2023-07-26 09:22:05.636085+01
152	export_wiki_pages	5	2023-07-26 09:22:05.636958+01	2023-07-26 09:22:05.636958+01
153	view_wiki_edits	5	2023-07-26 09:22:05.637954+01	2023-07-26 09:22:05.637954+01
154	edit_wiki_pages	5	2023-07-26 09:22:05.638798+01	2023-07-26 09:22:05.638798+01
155	delete_wiki_pages_attachments	5	2023-07-26 09:22:05.639792+01	2023-07-26 09:22:05.639792+01
156	protect_wiki_pages	5	2023-07-26 09:22:05.64086+01	2023-07-26 09:22:05.64086+01
157	browse_repository	5	2023-07-26 09:22:05.641563+01	2023-07-26 09:22:05.641563+01
158	commit_access	5	2023-07-26 09:22:05.642314+01	2023-07-26 09:22:05.642314+01
159	manage_repository	5	2023-07-26 09:22:05.643162+01	2023-07-26 09:22:05.643162+01
160	view_changesets	5	2023-07-26 09:22:05.644035+01	2023-07-26 09:22:05.644035+01
161	view_commit_author_statistics	5	2023-07-26 09:22:05.644903+01	2023-07-26 09:22:05.644903+01
162	manage_forums	5	2023-07-26 09:22:05.645818+01	2023-07-26 09:22:05.645818+01
163	add_messages	5	2023-07-26 09:22:05.646618+01	2023-07-26 09:22:05.646618+01
164	edit_messages	5	2023-07-26 09:22:05.647418+01	2023-07-26 09:22:05.647418+01
165	edit_own_messages	5	2023-07-26 09:22:05.648116+01	2023-07-26 09:22:05.648116+01
166	delete_messages	5	2023-07-26 09:22:05.648776+01	2023-07-26 09:22:05.648776+01
167	delete_own_messages	5	2023-07-26 09:22:05.649526+01	2023-07-26 09:22:05.649526+01
168	view_documents	5	2023-07-26 09:22:05.650205+01	2023-07-26 09:22:05.650205+01
169	manage_documents	5	2023-07-26 09:22:05.650845+01	2023-07-26 09:22:05.650845+01
170	view_time_entries	5	2023-07-26 09:22:05.651497+01	2023-07-26 09:22:05.651497+01
171	view_own_time_entries	5	2023-07-26 09:22:05.652282+01	2023-07-26 09:22:05.652282+01
172	log_own_time	5	2023-07-26 09:22:05.653015+01	2023-07-26 09:22:05.653015+01
173	log_time	5	2023-07-26 09:22:05.65373+01	2023-07-26 09:22:05.65373+01
174	edit_own_time_entries	5	2023-07-26 09:22:05.654744+01	2023-07-26 09:22:05.654744+01
175	edit_time_entries	5	2023-07-26 09:22:05.655712+01	2023-07-26 09:22:05.655712+01
176	manage_project_activities	5	2023-07-26 09:22:05.656575+01	2023-07-26 09:22:05.656575+01
177	view_own_hourly_rate	5	2023-07-26 09:22:05.657252+01	2023-07-26 09:22:05.657252+01
178	view_hourly_rates	5	2023-07-26 09:22:05.657927+01	2023-07-26 09:22:05.657927+01
179	edit_own_hourly_rate	5	2023-07-26 09:22:05.658781+01	2023-07-26 09:22:05.658781+01
180	edit_hourly_rates	5	2023-07-26 09:22:05.661561+01	2023-07-26 09:22:05.661561+01
181	view_cost_rates	5	2023-07-26 09:22:05.662482+01	2023-07-26 09:22:05.662482+01
182	log_own_costs	5	2023-07-26 09:22:05.663452+01	2023-07-26 09:22:05.663452+01
183	log_costs	5	2023-07-26 09:22:05.664283+01	2023-07-26 09:22:05.664283+01
184	edit_own_cost_entries	5	2023-07-26 09:22:05.665168+01	2023-07-26 09:22:05.665168+01
185	edit_cost_entries	5	2023-07-26 09:22:05.665981+01	2023-07-26 09:22:05.665981+01
186	view_cost_entries	5	2023-07-26 09:22:05.666689+01	2023-07-26 09:22:05.666689+01
187	view_own_cost_entries	5	2023-07-26 09:22:05.667467+01	2023-07-26 09:22:05.667467+01
188	view_meetings	5	2023-07-26 09:22:05.668178+01	2023-07-26 09:22:05.668178+01
189	create_meetings	5	2023-07-26 09:22:05.669113+01	2023-07-26 09:22:05.669113+01
190	edit_meetings	5	2023-07-26 09:22:05.669944+01	2023-07-26 09:22:05.669944+01
191	delete_meetings	5	2023-07-26 09:22:05.670682+01	2023-07-26 09:22:05.670682+01
192	meetings_send_invite	5	2023-07-26 09:22:05.671331+01	2023-07-26 09:22:05.671331+01
193	create_meeting_agendas	5	2023-07-26 09:22:05.672083+01	2023-07-26 09:22:05.672083+01
194	close_meeting_agendas	5	2023-07-26 09:22:05.672766+01	2023-07-26 09:22:05.672766+01
195	send_meeting_agendas_notification	5	2023-07-26 09:22:05.673391+01	2023-07-26 09:22:05.673391+01
196	send_meeting_agendas_icalendar	5	2023-07-26 09:22:05.67398+01	2023-07-26 09:22:05.67398+01
197	create_meeting_minutes	5	2023-07-26 09:22:05.674588+01	2023-07-26 09:22:05.674588+01
198	send_meeting_minutes_notification	5	2023-07-26 09:22:05.675335+01	2023-07-26 09:22:05.675335+01
199	view_master_backlog	5	2023-07-26 09:22:05.676074+01	2023-07-26 09:22:05.676074+01
200	view_taskboards	5	2023-07-26 09:22:05.676943+01	2023-07-26 09:22:05.676943+01
201	select_done_statuses	5	2023-07-26 09:22:05.677764+01	2023-07-26 09:22:05.677764+01
202	update_sprints	5	2023-07-26 09:22:05.679089+01	2023-07-26 09:22:05.679089+01
203	show_github_content	5	2023-07-26 09:22:05.679949+01	2023-07-26 09:22:05.679949+01
204	show_board_views	5	2023-07-26 09:22:05.680737+01	2023-07-26 09:22:05.680737+01
205	manage_board_views	5	2023-07-26 09:22:05.681441+01	2023-07-26 09:22:05.681441+01
206	manage_overview	5	2023-07-26 09:22:05.682089+01	2023-07-26 09:22:05.682089+01
207	view_budgets	5	2023-07-26 09:22:05.682809+01	2023-07-26 09:22:05.682809+01
208	edit_budgets	5	2023-07-26 09:22:05.683612+01	2023-07-26 09:22:05.683612+01
209	view_team_planner	5	2023-07-26 09:22:05.684272+01	2023-07-26 09:22:05.684272+01
210	manage_team_planner	5	2023-07-26 09:22:05.686913+01	2023-07-26 09:22:05.686913+01
211	view_calendar	5	2023-07-26 09:22:05.687723+01	2023-07-26 09:22:05.687723+01
212	manage_calendars	5	2023-07-26 09:22:05.688357+01	2023-07-26 09:22:05.688357+01
213	share_calendars	5	2023-07-26 09:22:05.688996+01	2023-07-26 09:22:05.688996+01
214	view_file_links	5	2023-07-26 09:22:05.689614+01	2023-07-26 09:22:05.689614+01
215	manage_file_links	5	2023-07-26 09:22:05.69026+01	2023-07-26 09:22:05.69026+01
216	manage_storages_in_project	5	2023-07-26 09:22:05.690958+01	2023-07-26 09:22:05.690958+01
217	read_files	5	2023-07-26 09:22:05.691595+01	2023-07-26 09:22:05.691595+01
218	write_files	5	2023-07-26 09:22:05.69234+01	2023-07-26 09:22:05.69234+01
219	create_files	5	2023-07-26 09:22:05.693059+01	2023-07-26 09:22:05.693059+01
220	delete_files	5	2023-07-26 09:22:05.697166+01	2023-07-26 09:22:05.697166+01
221	share_files	5	2023-07-26 09:22:05.698198+01	2023-07-26 09:22:05.698198+01
222	view_ifc_models	5	2023-07-26 09:22:05.698968+01	2023-07-26 09:22:05.698968+01
223	manage_ifc_models	5	2023-07-26 09:22:05.699783+01	2023-07-26 09:22:05.699783+01
224	view_linked_issues	5	2023-07-26 09:22:05.700943+01	2023-07-26 09:22:05.700943+01
225	manage_bcf	5	2023-07-26 09:22:05.701666+01	2023-07-26 09:22:05.701666+01
226	delete_bcf	5	2023-07-26 09:22:05.702335+01	2023-07-26 09:22:05.702335+01
227	save_bcf_queries	5	2023-07-26 09:22:05.702967+01	2023-07-26 09:22:05.702967+01
228	manage_public_bcf_queries	5	2023-07-26 09:22:05.703961+01	2023-07-26 09:22:05.703961+01
229	add_project	6	2023-07-26 09:22:05.710255+01	2023-07-26 09:22:05.710255+01
230	manage_user	6	2023-07-26 09:22:05.711192+01	2023-07-26 09:22:05.711192+01
231	manage_placeholder_user	6	2023-07-26 09:22:05.711993+01	2023-07-26 09:22:05.711993+01
232	manage_overview	5	2023-07-26 09:22:09.988065+01	2023-07-26 09:22:09.988065+01
\.


--
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.roles (id, name, "position", builtin, type, created_at, updated_at) FROM stdin;
1	Non member	1	1	Role	2023-07-26 09:22:05.469971+01	2023-07-26 09:22:05.469971+01
2	Anonymous	2	2	Role	2023-07-26 09:22:05.483612+01	2023-07-26 09:22:05.483612+01
3	Member	3	0	Role	2023-07-26 09:22:05.499276+01	2023-07-26 09:22:05.499276+01
4	Reader	4	0	Role	2023-07-26 09:22:05.563939+01	2023-07-26 09:22:05.563939+01
5	Project admin	5	0	Role	2023-07-26 09:22:05.599166+01	2023-07-26 09:22:05.599166+01
6	Staff and projects manager	6	0	GlobalRole	2023-07-26 09:22:05.707411+01	2023-07-26 09:22:05.707411+01
\.


--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.schema_migrations (version) FROM stdin;
10000000000000
20100528100562
20120214103300
20130214130336
20140113132617
20140129103924
20140207134248
20160331190036
20170703075208
20170705134348
20170818063404
20170829095701
20171023190036
20171106074835
20171129145631
20171218205557
20171219145752
20180105130053
20180108132929
20180116065518
20180117065255
20180122135443
20180123092002
20180125082205
20180213155320
20180221151038
20180305130811
20180323130704
20180323133404
20180323135408
20180323140208
20180323151208
20180419061910
20180504144320
20180510184732
20180518130559
20180524084654
20180524113516
20180706150714
20180717102331
20180801072018
20180830120550
20180903110212
20180924141838
20181101132712
20181112125034
20181118193730
20181121174153
20181214103300
20190124081710
20190129083842
20190205090102
20190207155607
20190220080647
20190227163226
20190301122554
20190312083304
20190411122815
20190502102512
20190507132517
20190509071101
20190527095959
20190603060951
20190618115620
20190619143049
20190710132957
20190716071941
20190719123448
20190722082648
20190724093332
20190823090211
20190826083604
20190905130336
20190920102446
20190923111902
20190923123858
20191029155327
20191106132533
20191112111040
20191114090353
20191115141154
20191119144123
20191121140202
20191216135213
20200114091135
20200115090742
20200123163818
20200206101135
20200217061622
20200217090016
20200217155632
20200220171133
20200302100431
20200310092237
20200325101528
20200326102408
20200327074416
20200403105252
20200415131633
20200420122713
20200420133116
20200422105623
20200427082928
20200427121606
20200428105404
20200504085933
20200522131255
20200522140244
20200527130633
20200610083854
20200610124259
20200625133727
20200708065116
20200803081038
20200807083950
20200807083952
20200810152654
20200820140526
20200903064009
20200907090753
20200914092212
20200924085508
20200925084550
20201001184404
20201005120137
20201005184411
20201105154216
20201125121949
20210126112238
20210127134438
20210214205545
20210219092709
20210221230446
20210310101840
20210331085058
20210407110000
20210427065703
20210510193438
20210512121322
20210519141244
20210521080035
20210615150558
20210616145324
20210616191052
20210618125430
20210618132206
20210628185054
20210701073944
20210701082511
20210713081724
20210726065912
20210726070813
20210802114054
20210825183540
20210902201126
20210910092414
20210914065555
20210915154656
20210917190141
20210922123908
20210928133538
20211005080304
20211005135637
20211011204301
20211022143726
20211026061420
20211101152840
20211102161932
20211103120946
20211104151329
20211105142202
20211117195121
20211118203332
20211130161501
20211209092519
20220106145037
20220113144323
20220113144759
20220121090847
20220202140507
20220223095355
20220302123642
20220319211253
20220323083000
20220408080838
20220414085531
20220426132637
20220428071221
20220503093844
20220511124930
20220517113828
20220518154147
20220525154549
20220608213712
20220614132200
20220615213015
20220620132922
20220622151721
20220629061540
20220629073727
20220707192304
20220712132505
20220712165928
20220714145356
20220804112533
20220811061024
20220815072420
20220817154403
20220818074150
20220818074159
20220830074821
20220830092057
20220831073113
20220831081937
20220909153412
20220911182835
20220918165443
20220922200908
20220926124435
20220929114423
20220930133418
20221017073431
20221017184204
20221018160449
20221026132134
20221027151959
20221028070534
20221029194419
20221115082403
20221122072857
20221129074635
20221130150352
20221201140825
20221202130039
20221213092910
20230105073117
20230105134940
20230123092649
20230130134630
20230306083203
20230309104056
20230314093106
20230314165213
20230315103437
20230315183431
20230315184533
20230316080525
20230321194150
20230322135932
20230328154645
20230420063148
20230420071113
20230421154500
20230502094813
20230508150835
20230512153303
20230517075214
20230531093004
20230601082746
20230607101213
20230620160602
\.


--
-- Data for Name: sessions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sessions (id, session_id, data, updated_at, user_id) FROM stdin;
2	2::25bb4031d5738687e6ef44c1c8e11b7f1d7ad7b5ce370837e3b8db844e308b0e	BAh7CkkiDHVzZXJfaWQGOgZFRmkJSSIPdXBkYXRlZF9hdAY7AEZJdToJVGlt\nZQ1K2x6AX+bb4Ao6DW5hbm9fbnVtaQIZAzoNbmFub19kZW5pBjoNc3VibWlj\ncm8iB3kwOgtvZmZzZXRpAhAOOgl6b25lSSIIQlNUBjsARkkiEF9jc3JmX3Rv\na2VuBjsARkkiMW5RK0RYU2VEQzR2bW5QNkp0RWRWSklSTmpxcFA2Q0NjTEpH\nZkx4SzFFV289BjsARkkiF2JhY2t1cHNfaW5kZXhfc29ydAY7AEZJIhRjcmVh\ndGVkX2F0OmRlc2MGOwBGSSIMcHJldmlldwY7AEZ7C0kiB2lkBjsAVGkHSSIM\nY29tbWVudAY7AFRJIhJpbml0aWFsIHN0YXRlBjsAVEkiD3NpemVfaW5fbWIG\nOwBUaQBJIg9jcmVhdG9yX2lkBjsAVGkJSSIPY3JlYXRlZF9hdAY7AFRVOiBB\nY3RpdmVTdXBwb3J0OjpUaW1lV2l0aFpvbmVbCEl1OwYNStsewK3hSpkGOwtJ\nIghVVEMGOwBGSSIIVVRDBjsAVEl1OwYNStsewK3hSpkGOwtAGUkiD3VwZGF0\nZWRfYXQGOwBUVTsMWwhJdTsGDUrbHsDAdXaZBjsLQBlAG0l1OwYNStsewMB1\ndpkGOwtAGQ==\n	2023-07-26 14:45:42.832343+01	4
3	2::2b9b9d0de33080cf4dcf589968b149a4955946492afa10747f4afb92f357eeed	BAh7AA==\n	2023-07-27 12:45:34.565243+01	\N
4	2::91f3bd17487fd783fc5536fd496c2ad239c9e09855de65c99ac0f8e1b2554eac	BAh7AA==\n	2023-07-27 12:48:00.480812+01	\N
5	2::44b059bcd38b52a55a0364654b9a087dde6c2257ca58bc88e873821573121c34	BAh7AA==\n	2023-07-27 12:48:16.105177+01	\N
11	2::708f555e1b7349ab13c5f755e8990068e2d9a32e62e60404269c6235442be045	BAh7CUkiDHVzZXJfaWQGOgZFRmkJSSIPdXBkYXRlZF9hdAY7AEZJdToJVGlt\nZQ1s2x6AYBFtmQo6DW5hbm9fbnVtaQJ2AjoNbmFub19kZW5pBjoNc3VibWlj\ncm8iBmM6C29mZnNldGkCEA46CXpvbmVJIghCU1QGOwBGSSIXYmFja3Vwc19p\nbmRleF9zb3J0BjsARkkiFGNyZWF0ZWRfYXQ6ZGVzYwY7AEZJIhBfY3NyZl90\nb2tlbgY7AEZJIjFSOUJlb0xGWDd4WWpRQW4xWmdiSnloQlhtaXM1VlVNZVpY\nV0JJRlZFSHBRPQY7AEY=\n	2023-07-27 13:38:30.049774+01	4
30	2::31324f1acf415861c30d02a98c0b3db1a6b83cfe92316e6427375ad06e1a74dd	BAh7CUkiDHVzZXJfaWQGOgZFRmkJSSIPdXBkYXRlZF9hdAY7AEZJdToJVGlt\nZQ1t2x6ANSZOjgo6DW5hbm9fbnVtaQHeOg1uYW5vX2RlbmkGOg1zdWJtaWNy\nbyIHIiA6C29mZnNldGkCEA46CXpvbmVJIghCU1QGOwBGSSIXYmFja3Vwc19p\nbmRleF9zb3J0BjsARkkiFGNyZWF0ZWRfYXQ6ZGVzYwY7AEZJIhBfY3NyZl90\nb2tlbgY7AEZJIjE0MmJTOTRLK3FsWGZJLzRCUzAvbEJLanRreGszRjA0WmZT\naCtDTTg4bENJPQY7AEY=\n	2023-07-27 14:35:36.933145+01	4
7	2::1e81447c01a64c6ff44ab460b9ceb7a6a39dc1b93897eb6aa2300d95a5a7540e	BAh7CUkiDHVzZXJfaWQGOgZFRmkJSSIPdXBkYXRlZF9hdAY7AEZJdToJVGlt\nZQ1s2x6Ahno1dQo6DW5hbm9fbnVtaQL4AToNbmFub19kZW5pBjoNc3VibWlj\ncm8iB1BAOgtvZmZzZXRpAhAOOgl6b25lSSIIQlNUBjsARkkiEF9jc3JmX3Rv\na2VuBjsARkkiMTV5bGtGeW1VQVNEcGpmS1hYWkJOUzVicHlMUkNBanF1dStu\nVW9TZU1jRzQ9BjsARkkiF2JhY2t1cHNfaW5kZXhfc29ydAY7AEZJIhRjcmVh\ndGVkX2F0OmRlc2MGOwBG\n	2023-07-27 13:29:19.744639+01	4
24	2::6ba92ae25ba1d51339f95c3e566517f4d0c2cb64fec40079f45a874a8bac105e	BAh7CUkiDHVzZXJfaWQGOgZFRmkJSSIPdXBkYXRlZF9hdAY7AEZJdToJVGlt\nZQ1t2x6AViCSdQo6DW5hbm9fbnVtaWM6DW5hbm9fZGVuaQY6DXN1Ym1pY3Jv\nIgcJQDoLb2Zmc2V0aQIQDjoJem9uZUkiCEJTVAY7AEZJIhdiYWNrdXBzX2lu\nZGV4X3NvcnQGOwBGSSIUY3JlYXRlZF9hdDpkZXNjBjsARkkiEF9jc3JmX3Rv\na2VuBjsARkkiMS9UY2xyMFplcWl5MmdpMHBuTDJoM2VweFVuQU4waDJ4ZFhR\nRVBTNTJjbmc9BjsARg==\n	2023-07-27 14:29:25.146854+01	4
27	2::5159658ee481e94243488057b8018f6b62d31d321b65c9ae4a6d0a34c4da18d1	BAh7CUkiDHVzZXJfaWQGOgZFRmkJSSIPdXBkYXRlZF9hdAY7AEZJdToJVGlt\nZQ1t2x6AOFKbego6DW5hbm9fbnVtaQGYOg1uYW5vX2RlbmkGOg1zdWJtaWNy\nbyIHFSA6C29mZnNldGkCEA46CXpvbmVJIghCU1QGOwBGSSIXYmFja3Vwc19p\nbmRleF9zb3J0BjsARkkiFGNyZWF0ZWRfYXQ6ZGVzYwY7AEZJIhBfY3NyZl90\nb2tlbgY7AEZJIjEvWXoreXBVVVVOWFBwWVFnYTk0VWNtelVONmltRFA2cFJL\nNDZ6bjByT0VRPQY7AEY=\n	2023-07-27 14:30:41.749567+01	4
14	2::69b555f958c9b54837de4782bdcb92ef2de6ce8ffceb8b497f10107728aef10c	BAh7CUkiDHVzZXJfaWQGOgZFRmkJSSIPdXBkYXRlZF9hdAY7AEZJdToJVGlt\nZQ1t2x6AWVaFRwo6DW5hbm9fbnVtaQKVAjoNbmFub19kZW5pBjoNc3VibWlj\ncm8iB2YQOgtvZmZzZXRpAhAOOgl6b25lSSIIQlNUBjsARkkiF2JhY2t1cHNf\naW5kZXhfc29ydAY7AEZJIhRjcmVhdGVkX2F0OmRlc2MGOwBGSSIQX2NzcmZf\ndG9rZW4GOwBGSSIxa3ZTT1RzdGcwYk1VdCtGVUIxeW9ub3RhMnZzYS8yMStB\nWTFiRmR2d2FyRT0GOwBG\n	2023-07-27 14:18:03.081594+01	4
31	2::7c9fda8f866c144c983fccec6f96f8b34b3311d4dc6ff41f5f7b8c721e47bdca	BAh7CkkiDHVzZXJfaWQGOgZFRmkJSSIPdXBkYXRlZF9hdAY7AEZJdToJVGlt\nZQ2J2x6Al9ksLQo6DW5hbm9fbnVtaQHXOg1uYW5vX2RlbmkGOg1zdWJtaWNy\nbyIHIVA6C29mZnNldGkCEA46CXpvbmVJIghCU1QGOwBGSSIXYmFja3Vwc19p\nbmRleF9zb3J0BjsARkkiFGNyZWF0ZWRfYXQ6ZGVzYwY7AEZJIhBfY3NyZl90\nb2tlbgY7AEZJIjF0WHVvZWR5SXJsR1FxQ3BUV1F2RmtXeGZlamVyVU9Pa0ZB\nVk9UTGsvSHlVPQY7AEZJIhV1c2Vyc19pbmRleF9zb3J0BjsARkkiAAY7AEY=\n	2023-07-28 10:40:34.02744+01	4
28	2::2cff5ffabdb4442e3c6fe06354dd6ec0a6e92340b4fc5231157c5ae5efa07256	BAh7CUkiDHVzZXJfaWQGOgZFRmkJSSIPdXBkYXRlZF9hdAY7AEZJdToJVGlt\nZQ1t2x6AiDo0ewo6DW5hbm9fbnVtaQLSAjoNbmFub19kZW5pBjoNc3VibWlj\ncm8iB3IgOgtvZmZzZXRpAhAOOgl6b25lSSIIQlNUBjsARkkiF2JhY2t1cHNf\naW5kZXhfc29ydAY7AEZJIhRjcmVhdGVkX2F0OmRlc2MGOwBGSSIQX2NzcmZf\ndG9rZW4GOwBGSSIxVEkxYzYrd1FRVmhMc0l4S0wyOXgzb21FcFRtUTJPZith\nQlJJUGtSU1pJND0GOwBG\n	2023-07-27 14:30:51.283941+01	4
32	2::1769e98b4e47279a517dd7ac1317485f40faccdcda17a98a3ee3ff2b9e333a25	BAh7AA==\n	2023-07-28 10:42:32.529213+01	\N
33	2::861703ec132def137fb82b2f65dd995b4badd0d2c7659489e137f0f55d04a688	BAh7AA==\n	2023-07-28 10:44:32.497027+01	\N
34	2::8ca4e744444bed4e8b2fdcdab63a158bbf2a9d2d9f67ce86a239ca45490b1a2e	BAh7AA==\n	2023-07-28 10:46:32.491502+01	\N
35	2::488574448df04dfad1e93e7922b171913e15f16af4853cca56184921d15b63d5	BAh7AA==\n	2023-07-28 10:48:32.488376+01	\N
36	2::07485247c6b3121c4911cf91d0b6d037ef31e3288d0657992e53ef656b19b13d	BAh7AA==\n	2023-07-28 10:50:34.709226+01	\N
17	2::b5679e0b0296f0b7c5b28daf1e0232245f3b7d4cb006ce5d9f657712f7a05d79	BAh7CUkiDHVzZXJfaWQGOgZFRmkJSSIPdXBkYXRlZF9hdAY7AEZJdToJVGlt\nZQ1t2x6AzJIETwo6DW5hbm9fbnVtaQJ0AToNbmFub19kZW5pBjoNc3VibWlj\ncm8iBzcgOgtvZmZzZXRpAhAOOgl6b25lSSIIQlNUBjsARkkiF2JhY2t1cHNf\naW5kZXhfc29ydAY7AEZJIhRjcmVhdGVkX2F0OmRlc2MGOwBGSSIQX2NzcmZf\ndG9rZW4GOwBGSSIxZk82WXRaTXAwclBBZHF4LzdnUzhqR1g4VFFBbVdPUk9U\nN3lYUEZKSFNvUT0GOwBG\n	2023-07-27 14:19:48.345226+01	4
37	2::d418c212f3f094d7a70dee685b669c74c907ec26b32d070b94f3e45d16f02c8e	BAh7AA==\n	2023-07-28 10:52:34.94574+01	\N
38	2::6a390d1304e1c5e13683605b5fc16e9725760e76bafefafe53c49af6066c5f17	BAh7AA==\n	2023-07-28 10:54:35.532406+01	\N
39	2::3e75a321a0623b191250f158dcae60078aae05d10f443a843fa0440211ef247a	BAh7AA==\n	2023-07-28 10:56:34.822432+01	\N
40	2::b3d1505988b6e9140b179cb820053780ef0954d49e44e89f872531e08f7584df	BAh7AA==\n	2023-07-28 10:58:32.484078+01	\N
41	2::6bb17c815f18f9fbe378f1935dbe6a82af641d77fc22c1cbb14c420ed6412a66	BAh7AA==\n	2023-07-28 11:00:32.488677+01	\N
29	2::2d70a86e262154eba1d1b516fba3f78e7333c198800ef19d7a520d9e55643c01	BAh7CUkiDHVzZXJfaWQGOgZFRmkJSSIPdXBkYXRlZF9hdAY7AEZJdToJVGlt\nZQ1t2x6A2e/sigo6DW5hbm9fbnVtaQIHAToNbmFub19kZW5pBjoNc3VibWlj\ncm8iByYwOgtvZmZzZXRpAhAOOgl6b25lSSIIQlNUBjsARkkiF2JhY2t1cHNf\naW5kZXhfc29ydAY7AEZJIhRjcmVhdGVkX2F0OmRlc2MGOwBGSSIQX2NzcmZf\ndG9rZW4GOwBGSSIxaE5OUWM1am13UitFeVlwN2Q1Q21aNmNiYTBDTGtIamtu\nM1FOMFl4VHkzbz0GOwBG\n	2023-07-27 14:34:46.855145+01	4
42	2::2a94549360bb4c0439dd4447ad90d6b5d6e242641951ca0611904716a04717bd	BAh7AA==\n	2023-07-28 11:02:32.48696+01	\N
43	2::6b8d255bc8952a0b2b32c4b7d0c3210c8f8045a652fee724266194ab79cd91e6	BAh7AA==\n	2023-07-28 11:04:32.479713+01	\N
20	2::e6da9ffe67b02626605a248942a4a6b82aba6e4a2c8252a2d7742a11a26aca9a	BAh7CUkiDHVzZXJfaWQGOgZFRmkJSSIPdXBkYXRlZF9hdAY7AEZJdToJVGlt\nZQ1t2x6AyJksbwo6DW5hbm9fbnVtaQLfAzoNbmFub19kZW5pBjoNc3VibWlj\ncm8iB5kQOgtvZmZzZXRpAhAOOgl6b25lSSIIQlNUBjsARkkiEF9jc3JmX3Rv\na2VuBjsARkkiMWg0cjZXUEx5cWE1QzFTSzdsYzh2QW5mcHNkK01zcXlISkZF\nZnRsZFRudTA9BjsARkkiF2JhY2t1cHNfaW5kZXhfc29ydAY7AEZJIhRjcmVh\ndGVkX2F0OmRlc2MGOwBG\n	2023-07-27 14:27:50.830324+01	4
21	2::07752404141ed95f8730de50ae78a0519c2715df1e4910f7fb1c08140630ea43	BAh7AA==\n	2023-07-27 14:27:53.570909+01	\N
44	2::6b45545caccc611d7334c9aa2c54d8ee6f117be46502f4f4122dbbf9af54e08f	BAh7AA==\n	2023-07-28 11:06:32.478418+01	\N
45	2::0ad44111fbad87a67985672b40fd7491a5f174a4c804dc67f92901da2f322a24	BAh7AA==\n	2023-07-28 11:08:34.977283+01	\N
46	2::1460be0073b26fd579fc94c88a6c5a41e335d1ed1fd9b9d070f09a33e174c56b	BAh7AA==\n	2023-07-28 11:10:32.495153+01	\N
47	2::cbee9d738e0ee97857341f1ee8744937d03f4dfdef80c7f7cce166404427bf53	BAh7AA==\n	2023-07-28 11:12:34.044033+01	\N
48	2::30e21c397859f165f064ca68871eb3626eecc4d180e7cb85c9f11830d2f587be	BAh7AA==\n	2023-07-28 11:14:36.289565+01	\N
49	2::036f51cea548720bb6cbb62aa34d3c4a645bcf9a5a793d647643b75317c843af	BAh7AA==\n	2023-07-28 11:16:35.094912+01	\N
66	2::7b426be8c903511befca5f77895fa2dbbe3dc216b31c43619e89235f0ca58053	BAh7CUkiDHVzZXJfaWQGOgZFRmkJSSIPdXBkYXRlZF9hdAY7AEZJdToJVGlt\nZQ2M2x6A0OIhgAo6DW5hbm9fbnVtaQJoAzoNbmFub19kZW5pBjoNc3VibWlj\ncm8iB4cgOgtvZmZzZXRpAhAOOgl6b25lSSIIQlNUBjsARkkiF2JhY2t1cHNf\naW5kZXhfc29ydAY7AEZJIhRjcmVhdGVkX2F0OmRlc2MGOwBGSSIQX2NzcmZf\ndG9rZW4GOwBGSSIxSGN5c2VnL1N4VFgyRi9zeXNqRDlLSFRrTHY5S2xtaCtL\nWXhCVnlFaHB3cz0GOwBG\n	2023-07-28 13:32:02.130977+01	4
50	2::81ba15e42085bc9afa258fe07f78d6cabd818c239c7f2491fc37ee9f39b5d8f3	BAh7AA==\n	2023-07-28 11:18:32.273957+01	\N
75	2::a40faf1b42ae9e669c1e718ba4a7ab9326e0276a487dcdb64aca67bd5f9949e1	BAh7CUkiDHVzZXJfaWQGOgZFRmkJSSIPdXBkYXRlZF9hdAY7AEZJdToJVGlt\nZQ2O2x6AgeGJlwo6DW5hbm9fbnVtaQKAAjoNbmFub19kZW5pBjoNc3VibWlj\ncm8iBmQ6C29mZnNldGkCEA46CXpvbmVJIghCU1QGOwBGSSIXYmFja3Vwc19p\nbmRleF9zb3J0BjsARkkiFGNyZWF0ZWRfYXQ6ZGVzYwY7AEZJIhBfY3NyZl90\nb2tlbgY7AEZJIjEwU2x0REFSMDZITE44OUdVQUVyeVVyRkpGNVdhOXFHNlZa\nNkxuVGllVFpvPQY7AEY=\n	2023-07-28 15:37:56.656467+01	4
53	2::a06a6fd79ae8daa29b9d28a9e73ec290efbe376b0c005e82974b28a026ff04e0	BAh7CUkiDHVzZXJfaWQGOgZFRmkJSSIPdXBkYXRlZF9hdAY7AEZJdToJVGlt\nZQ2M2x6AbrKCPwo6DW5hbm9fbnVtaW06DW5hbm9fZGVuaQY6DXN1Ym1pY3Jv\nIgcQQDoLb2Zmc2V0aQIQDjoJem9uZUkiCEJTVAY7AEZJIhdiYWNrdXBzX2lu\nZGV4X3NvcnQGOwBGSSIUY3JlYXRlZF9hdDpkZXNjBjsARkkiEF9jc3JmX3Rv\na2VuBjsARkkiMU0xdnh2U1lSN2dSWVYrVWptZ0FSMEhNZHFzVG9IZWlIaGlV\nT0tOdGpVRTQ9BjsARg==\n	2023-07-28 13:15:56.197771+01	4
54	2::1fe807dc7b9652833c1ccf66d54389d79062175f365a785cda04677c1705c6e8	BAh7BkkiCmZsYXNoBjoGRVR7B0kiDGRpc2NhcmQGOwBUWwBJIgxmbGFzaGVz\nBjsAVHsGSSIKZXJyb3IGOwBGSSIVdGVuYW50IG5vdCBmb3VuZAY7AFQ=\n	2023-07-28 13:16:56.437707+01	\N
57	2::badee8980b0467c4696caaa9e7201af6d82638feef3fcb952ff2d0547f54b5f8	BAh7BkkiCmZsYXNoBjoGRVR7B0kiDGRpc2NhcmQGOwBUWwBJIgxmbGFzaGVz\nBjsAVHsGSSIKZXJyb3IGOwBGSSIVdGVuYW50IG5vdCBmb3VuZAY7AFQ=\n	2023-07-28 13:16:58.027805+01	\N
58	2::674cdc102a3bb03f6631ff48ba8d6f53ebf645439fcd0814cffddd62965fa4a9	BAh7CEkiD3VwZGF0ZWRfYXQGOgZFRkl1OglUaW1lDYzbHoBeq6FDCjoNbmFu\nb19udW1pAYM6DW5hbm9fZGVuaQY6DXN1Ym1pY3JvIgcTEDoLb2Zmc2V0aQIQ\nDjoJem9uZUkiCEJTVAY7AEZJIhBfY3NyZl90b2tlbgY7AEZJIjFjalRZZXEx\nbVd5QzgvMEljNGkzOUdxeXpYRklFUmVMQXh1Z25PSU43L1ZZPQY7AEZJIgpm\nbGFzaAY7AFR7B0kiDGRpc2NhcmQGOwBUWwBJIgxmbGFzaGVzBjsAVHsGSSIK\nZXJyb3IGOwBGSSIVdGVuYW50IG5vdCBmb3VuZAY7AFQ=\n	2023-07-28 13:16:58.175771+01	\N
70	2::a7d65b138c0a4207f6c55b2457c3997fde26152772a86a66321fce4f9c983be4	BAh7CUkiDHVzZXJfaWQGOgZFRmkJSSIPdXBkYXRlZF9hdAY7AEZJdToJVGlt\nZQ2O2x6AoIzYFgo6DW5hbm9fbnVtaUg6DW5hbm9fZGVuaQY6DXN1Ym1pY3Jv\nIgcGcDoLb2Zmc2V0aQIQDjoJem9uZUkiCEJTVAY7AEZJIhdiYWNrdXBzX2lu\nZGV4X3NvcnQGOwBGSSIUY3JlYXRlZF9hdDpkZXNjBjsARkkiEF9jc3JmX3Rv\na2VuBjsARkkiMVhqWnorWnkwdGFMdUlhTzc3N1hObDUrbHBUdlRzaUROR1By\naDh1cUwxTEE9BjsARg==\n	2023-07-28 15:07:00.393568+01	4
68	2::28e5bb7a78fc2dedf0d3cfa407cc191f76b9ee109c2e3331c926471c8342f7c4	BAh7CUkiDHVzZXJfaWQGOgZFRmkJSSIPdXBkYXRlZF9hdAY7AEZJdToJVGlt\nZQ2M2x6A/aHNigo6DW5hbm9fbnVtaQI8AToNbmFub19kZW5pBjoNc3VibWlj\ncm8iBzFgOgtvZmZzZXRpAhAOOgl6b25lSSIIQlNUBjsARkkiEF9jc3JmX3Rv\na2VuBjsARkkiMU5xT1FCVXRVY2NEbWtuL2YxOGxWdSszWGVJTHYzUHBKWTIr\nd3BhUUZSSkU9BjsARkkiF2JhY2t1cHNfaW5kZXhfc29ydAY7AEZJIhRjcmVh\ndGVkX2F0OmRlc2MGOwBG\n	2023-07-28 13:34:44.899336+01	4
71	2::5f8d4039c046957d03e91604cba127b6352db02a78f6e924ce32888a7af9a14b	BAh7B0kiD3VwZGF0ZWRfYXQGOgZFRkl1OglUaW1lDY7bHoC0AhMkCjoNbmFu\nb19udW1pAqkBOg1uYW5vX2RlbmkGOg1zdWJtaWNybyIHQlA6C29mZnNldGkC\nEA46CXpvbmVJIghCU1QGOwBGSSIKZmxhc2gGOwBUewdJIgxkaXNjYXJkBjsA\nVFsASSIMZmxhc2hlcwY7AFR7BkkiCmVycm9yBjsARkkiJk5vdCBjdXJyZW50\nbHkgcHJldmlld2luZyBhbnl0aGluZwY7AFQ=\n	2023-07-28 15:09:31.42557+01	\N
72	2::c41619638d961ede403f1dffe4b4ef900bf2842673a10d7869b33b78d89e9e58	BAh7AA==\n	2023-07-28 15:09:54.108269+01	\N
60	2::4e00463f2f112674a5fb9fce12d60039184bcd58ce012b48a6bc05d325c6504f	BAh7CUkiDHVzZXJfaWQGOgZFRmkJSSIPdXBkYXRlZF9hdAY7AEZJdToJVGlt\nZQ2M2x6ArVDoXQo6DW5hbm9fbnVtaQJIAzoNbmFub19kZW5pBjoNc3VibWlj\ncm8iBoQ6C29mZnNldGkCEA46CXpvbmVJIghCU1QGOwBGSSIQX2NzcmZfdG9r\nZW4GOwBGSSIxbWdidFBPV0svZEhWSVFxNHFXNU9SOHNNZnBYRzNCSlpBbTBu\nZFM2MXp2OD0GOwBGSSIXYmFja3Vwc19pbmRleF9zb3J0BjsARkkiFGNyZWF0\nZWRfYXQ6ZGVzYwY7AEY=\n	2023-07-28 13:23:30.562492+01	4
69	2::73952d2044ec38450f476ae7d2d3d721aa095b7d058f95ec1c578ad7d6ad2b8f	BAh7CUkiDHVzZXJfaWQGOgZFRmkJSSIPdXBkYXRlZF9hdAY7AEZJdToJVGlt\nZQ2M2x6AYvgpjAo6DW5hbm9fbnVtaQGPOg1uYW5vX2RlbmkGOg1zdWJtaWNy\nbyIHFDA6C29mZnNldGkCEA46CXpvbmVJIghCU1QGOwBGSSIXYmFja3Vwc19p\nbmRleF9zb3J0BjsARkkiFGNyZWF0ZWRfYXQ6ZGVzYwY7AEZJIhBfY3NyZl90\nb2tlbgY7AEZJIjFCSFZrSTRaWi9kWjB0eXhXaFJkMXVzMERxVnlBQVRrWkRM\naVVENTZ3Z3RzPQY7AEY=\n	2023-07-28 13:35:02.659092+01	4
76	2::e8406ae7c13b24b2f6455ab469de9793d4d08446bcfd4777ebe6258bbacc8518	BAh7CUkiDHVzZXJfaWQGOgZFRmkJSSIPdXBkYXRlZF9hdAY7AEZJdToJVGlt\nZQ2O2x6AaTuOqgo6DW5hbm9fbnVtaQJ2AjoNbmFub19kZW5pBjoNc3VibWlj\ncm8iBmM6C29mZnNldGkCEA46CXpvbmVJIghCU1QGOwBGSSIXYmFja3Vwc19p\nbmRleF9zb3J0BjsARkkiFGNyZWF0ZWRfYXQ6ZGVzYwY7AEZJIhBfY3NyZl90\nb2tlbgY7AEZJIjF2U0lNcThOMkxhcDJSU2xld0pPUUlueFFwYWNiMFFIc2Fp\nTVZHa1hsNERzPQY7AEY=\n	2023-07-28 15:42:40.940239+01	4
63	2::6ffac3d898ee243354837a7ae80bf7d9cc683dc847e33ad414a316cdb1c16a20	BAh7CUkiDHVzZXJfaWQGOgZFRmkJSSIPdXBkYXRlZF9hdAY7AEZJdToJVGlt\nZQ2M2x6Adk/0dgo6DW5hbm9fbnVtaQGJOg1uYW5vX2RlbmkGOg1zdWJtaWNy\nbyIHE3A6C29mZnNldGkCEA46CXpvbmVJIghCU1QGOwBGSSIXYmFja3Vwc19p\nbmRleF9zb3J0BjsARkkiFGNyZWF0ZWRfYXQ6ZGVzYwY7AEZJIhBfY3NyZl90\nb2tlbgY7AEZJIjFDRWsxUTFSWDlQdUJHekhKNkJITmVFSlVXRHI3dFBYR1hE\nRkp5YUdkS2w4PQY7AEY=\n	2023-07-28 13:29:47.292427+01	4
73	2::3ba1cfcbd96168eeb8aa775d6f6470534254e9f5293c2b86ef36e71a96968f72	BAh7CUkiDHVzZXJfaWQGOgZFRmkJSSIPdXBkYXRlZF9hdAY7AEZJdToJVGlt\nZQ2O2x6A1I5ihAo6DW5hbm9fbnVtaQLgAToNbmFub19kZW5pBjoNc3VibWlj\ncm8iBkg6C29mZnNldGkCEA46CXpvbmVJIghCU1QGOwBGSSIXYmFja3Vwc19p\nbmRleF9zb3J0BjsARkkiFGNyZWF0ZWRfYXQ6ZGVzYwY7AEZJIhBfY3NyZl90\nb2tlbgY7AEZJIjFGRFFzWGZDWURFdzdrRGVuNlFmdkNLbFJUenpwd2FTcll5\nbFpLM1VkSzJBPQY7AEY=\n	2023-07-28 15:33:06.178402+01	4
74	2::33a9a15f36d10e9f1747f7436ca384e4162c2c90e1c51019e5b3fa051bc8a3e0	BAh7CUkiDHVzZXJfaWQGOgZFRmkJSSIPdXBkYXRlZF9hdAY7AEZJdToJVGlt\nZQ2O2x6AAaC6jAo6DW5hbm9fbnVtaQG/Og1uYW5vX2RlbmkGOg1zdWJtaWNy\nbyIHGRA6C29mZnNldGkCEA46CXpvbmVJIghCU1QGOwBGSSIXYmFja3Vwc19p\nbmRleF9zb3J0BjsARkkiFGNyZWF0ZWRfYXQ6ZGVzYwY7AEZJIhBfY3NyZl90\nb2tlbgY7AEZJIjFjTE9sUVI5ZzN5SHNlTm1xdjJQTkRGVitmbEVXODF1eita\nRFZLUU1xUTQ0PQY7AEY=\n	2023-07-28 15:35:23.926426+01	4
77	2::39081c6a843c3321fa18e26563ee0e3aa77565f5a3a985ec841f6f1c6562e1d3	BAh7CUkiDHVzZXJfaWQGOgZFRmkJSSIPdXBkYXRlZF9hdAY7AEZJdToJVGlt\nZQ2O2x6A1Opctwo6DW5hbm9fbnVtaQKnAzoNbmFub19kZW5pBjoNc3VibWlj\ncm8iB5NQOgtvZmZzZXRpAhAOOgl6b25lSSIIQlNUBjsARkkiF2JhY2t1cHNf\naW5kZXhfc29ydAY7AEZJIhRjcmVhdGVkX2F0OmRlc2MGOwBGSSIQX2NzcmZf\ndG9rZW4GOwBGSSIxR2lRM2VYNEhlMGNaRDZVREViTDBZeXdiUmpsd3hOanU5\nemh1ajFKQlY0cz0GOwBG\n	2023-07-28 15:45:53.853916+01	4
80	2::e6f87e50629fe36445e7d21cf7e1ae3df0ef335f4f3ba7ae227956687054881d	BAh7CUkiDHVzZXJfaWQGOgZFRmkJSSIPdXBkYXRlZF9hdAY7AEZJdToJVGlt\nZQ2O2x6AS3/g0Ao6DW5hbm9fbnVtaQLxAToNbmFub19kZW5pBjoNc3VibWlj\ncm8iB0lwOgtvZmZzZXRpAhAOOgl6b25lSSIIQlNUBjsARkkiF2JhY2t1cHNf\naW5kZXhfc29ydAY7AEZJIhRjcmVhdGVkX2F0OmRlc2MGOwBGSSIQX2NzcmZf\ndG9rZW4GOwBGSSIxWUlzVjdBWXFuenc2Ti9UZGdjTHMyVVpucVZPWThVVERt\nT1hsWjNibDdjOD0GOwBG\n	2023-07-28 15:52:14.041336+01	4
81	2::3e8644f83d2f26c831770bcf286d1f75ff2cb7ffb860a2cdaa66d0e1a73e88db	BAh7CUkiDHVzZXJfaWQGOgZFRmkJSSIPdXBkYXRlZF9hdAY7AEZJdToJVGlt\nZQ2y2x6AeQWdjQo6DW5hbm9fbnVtaQJ2AzoNbmFub19kZW5pBjoNc3VibWlj\ncm8iB4hgOgtvZmZzZXRpAhAOOgl6b25lSSIIQlNUBjsARkkiEF9jc3JmX3Rv\na2VuBjsARkkiMXIxaWJUSWJLWE1WVFgyYkowTnNwbjRYQm10USttMFdKeERQ\nb2ZxbkJ0QWs9BjsARkkiF2JhY2t1cHNfaW5kZXhfc29ydAY7AEZJIhRjcmVh\ndGVkX2F0OmRlc2MGOwBG\n	2023-07-29 19:36:06.140077+01	4
84	2::70ffa468a7429bedfe2ee1fe4b7a12b4653be995f63b02904ea5a4d1be246d9f	BAh7CUkiDHVzZXJfaWQGOgZFRmkJSSIPdXBkYXRlZF9hdAY7AEZJdToJVGlt\nZQ2y2x6AFdpH0Qo6DW5hbm9fbnVtaQG6Og1uYW5vX2RlbmkGOg1zdWJtaWNy\nbyIHGGA6C29mZnNldGkCEA46CXpvbmVJIghCU1QGOwBGSSIXYmFja3Vwc19p\nbmRleF9zb3J0BjsARkkiFGNyZWF0ZWRfYXQ6ZGVzYwY7AEZJIhBfY3NyZl90\nb2tlbgY7AEZJIjFvQ1pJZThSUE15enJ4bklXNTEzbzNQUkpQWnRVM2lmcVBj\nT0lrVUVNM3RRPQY7AEY=\n	2023-07-29 19:52:31.007538+01	4
86	2::f12ccde608556fd9e88ee164f19734b2dc9f513825daa6daba159387b7afb5a9	BAh7CUkiDHVzZXJfaWQGOgZFRmkJSSIPdXBkYXRlZF9hdAY7AEZJdToJVGlt\nZQ3n2x6A25uWVwo6DW5hbm9fbnVtaQGZOg1uYW5vX2RlbmkGOg1zdWJtaWNy\nbyIHFTA6C29mZnNldGkCEA46CXpvbmVJIghCU1QGOwBGSSIQX2NzcmZfdG9r\nZW4GOwBGSSIxSyt3MGtSL09rN01zOU5sV1BLd1J1b0E4R2ZHZmNkbS9NU1No\neVU2UWdVWT0GOwBGSSIXYmFja3Vwc19pbmRleF9zb3J0BjsARkkiFGNyZWF0\nZWRfYXQ6ZGVzYwY7AEY=\n	2023-07-31 08:23:31.614867+01	4
\.


--
-- Data for Name: settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.settings (id, name, value, updated_at) FROM stdin;
1	working_days	---\n- 1\n- 2\n- 3\n- 4\n- 5\n	2023-07-26 09:21:42.56482+01
2	fog	{}	2023-07-26 09:22:06.833116+01
3	feature_show_changes_active	true	2023-07-26 09:22:06.840622+01
4	feature_more_global_index_pages_active	true	2023-07-26 09:22:06.845296+01
5	plugin_openproject_auth_saml	---\nproviders: \n	2023-07-26 09:22:06.849422+01
6	plugin_costs	---\ncosts_currency: EUR\ncosts_currency_format: "%n %u"\n	2023-07-26 09:22:06.853528+01
7	cost_reporting_cache_filter_classes	true	2023-07-26 09:22:06.857116+01
9	plugin_openproject_avatars	---\nenable_gravatars: true\nenable_local_avatars: true\n	2023-07-26 09:22:06.865531+01
10	plugin_openproject_two_factor_authentication	---\nactive_strategies:\n- :totp\nenforced: false\nallow_remember_for_days: 0\n	2023-07-26 09:22:06.869156+01
11	plugin_openproject_ldap_groups	{}	2023-07-26 09:22:06.872458+01
12	plugin_openproject_recaptcha	---\nrecaptcha_type: disabled\n	2023-07-26 09:22:06.876547+01
13	recaptcha_via_hcaptcha	f	2023-07-26 09:22:06.880024+01
15	feature_storage_file_picking_select_all_active	true	2023-07-26 09:22:06.886797+01
16	feature_storage_project_folders_active	true	2023-07-26 09:22:06.889881+01
17	feature_managed_project_folders_active	true	2023-07-26 09:22:06.893478+01
18	plugin_openproject_bim	{}	2023-07-26 09:22:06.897136+01
19	available_languages	---\n- de\n- en\n- es\n- fr\n- it\n- ko\n- pt\n- ru\n- zh-CN\n	2023-07-26 09:22:06.900916+01
21	activity_days_default	30	2023-07-26 09:22:06.907361+01
22	apiv3_cors_enabled	f	2023-07-26 09:22:06.912291+01
23	apiv3_cors_origins	[]	2023-07-26 09:22:06.917692+01
24	apiv3_docs_enabled	true	2023-07-26 09:22:06.921125+01
25	apiv3_max_page_size	1000	2023-07-26 09:22:06.925348+01
27	attachment_max_size	5120	2023-07-26 09:22:06.93252+01
28	attachment_whitelist	[]	2023-07-26 09:22:06.9359+01
29	autofetch_changesets	true	2023-07-26 09:22:06.939066+01
30	autologin	0	2023-07-26 09:22:06.942211+01
31	bcc_recipients	true	2023-07-26 09:22:06.945771+01
33	brute_force_block_minutes	30	2023-07-26 09:22:06.955549+01
34	brute_force_block_after_failed_logins	20	2023-07-26 09:22:06.958923+01
36	commit_fix_done_ratio	100	2023-07-26 09:22:06.966303+01
37	commit_fix_keywords	fixes,closes	2023-07-26 09:22:06.969454+01
38	commit_logs_encoding	UTF-8	2023-07-26 09:22:06.972578+01
39	commit_logtime_enabled	f	2023-07-26 09:22:06.979444+01
40	commit_ref_keywords	refs,references,IssueID	2023-07-26 09:22:06.983663+01
41	consent_info	---\nen: |-\n  ## Consent\n\n  You need to agree to the [privacy and security policy](https://www.openproject.org/data-privacy-and-security/) of this OpenProject instance.\n	2023-07-26 09:22:06.98686+01
42	consent_required	f	2023-07-26 09:22:06.99777+01
43	cross_project_work_package_relations	true	2023-07-26 09:22:07.001971+01
44	default_auto_hide_popups	true	2023-07-26 09:22:07.005423+01
45	default_language	en	2023-07-26 09:22:07.009959+01
46	default_projects_modules	---\n- calendar\n- board_view\n- work_package_tracking\n- news\n- costs\n- wiki\n- reporting_module\n- meetings\n- backlogs\n	2023-07-26 09:22:07.015529+01
47	default_projects_public	f	2023-07-26 09:22:07.019156+01
51	diff_max_lines_displayed	1500	2023-07-26 09:22:07.035059+01
52	display_subprojects_work_packages	true	2023-07-26 09:22:07.038446+01
53	emails_footer	---\nen: ''\n	2023-07-26 09:22:07.042071+01
54	emails_header	---\nen: ''\n	2023-07-26 09:22:07.046236+01
55	email_login	f	2023-07-26 09:22:07.049954+01
56	enabled_projects_columns	---\n- project_status\n- public\n- created_at\n- latest_activity_at\n- required_disk_space\n	2023-07-26 09:22:07.053586+01
57	enabled_scm	---\n- subversion\n- git\n	2023-07-26 09:22:07.056899+01
59	feeds_limit	15	2023-07-26 09:22:07.063538+01
60	file_max_size_displayed	512	2023-07-26 09:22:07.066981+01
61	forced_single_page_size	250	2023-07-26 09:22:07.072432+01
62	host_name	localhost:3000	2023-07-26 09:22:07.07593+01
63	invitation_expiration_days	7	2023-07-26 09:22:07.081589+01
64	journal_aggregation_time_minutes	5	2023-07-26 09:22:07.088486+01
65	ldap_tls_options	{}	2023-07-26 09:22:07.092342+01
66	log_requesting_user	f	2023-07-26 09:22:07.096411+01
67	login_required	f	2023-07-26 09:22:07.100376+01
68	lost_password	true	2023-07-26 09:22:07.104751+01
69	mail_from	openproject@example.net	2023-07-26 09:22:07.108595+01
70	mail_handler_body_delimiters		2023-07-26 09:22:07.11249+01
71	mail_handler_body_delimiter_regex		2023-07-26 09:22:07.118772+01
72	mail_handler_ignore_filenames	signature.asc	2023-07-26 09:22:07.122257+01
73	mail_suffix_separators	+	2023-07-26 09:22:07.126293+01
74	oauth_allow_remapping_of_existing_users	true	2023-07-26 09:22:07.131498+01
75	password_active_rules	---\n- lowercase\n- uppercase\n- numeric\n- special\n	2023-07-26 09:22:07.135135+01
76	password_count_former_banned	0	2023-07-26 09:22:07.138384+01
77	password_days_valid	0	2023-07-26 09:22:07.141613+01
78	password_min_length	10	2023-07-26 09:22:07.14606+01
79	password_min_adhered_rules	0	2023-07-26 09:22:07.149538+01
80	per_page_options	20, 100	2023-07-26 09:22:07.153036+01
81	plain_text_mail	f	2023-07-26 09:22:07.159531+01
82	registration_footer	---\nen: ''\n	2023-07-26 09:22:07.163629+01
83	report_incoming_email_errors	true	2023-07-26 09:22:07.168643+01
84	repository_authentication_caching_enabled	true	2023-07-26 09:22:07.172019+01
85	repository_checkout_data	---\ngit:\n  enabled: 0\nsubversion:\n  enabled: 0\n	2023-07-26 09:22:07.177792+01
86	repository_log_display_limit	100	2023-07-26 09:22:07.183405+01
87	repository_storage_cache_minutes	720	2023-07-26 09:22:07.187174+01
88	repository_truncate_at	500	2023-07-26 09:22:07.190814+01
89	rest_api_enabled	true	2023-07-26 09:22:07.195395+01
91	self_registration	2	2023-07-26 09:22:07.203288+01
92	sendmail_location	/usr/sbin/sendmail	2023-07-26 09:22:07.207171+01
93	session_ttl_enabled	f	2023-07-26 09:22:07.21277+01
94	session_ttl	120	2023-07-26 09:22:07.216262+01
95	smtp_authentication	plain	2023-07-26 09:22:07.220129+01
96	smtp_enable_starttls_auto	f	2023-07-26 09:22:07.223571+01
14	ical_enabled	1	2023-07-26 11:09:20.025777+01
35	cache_formatted_text	1	2023-07-26 11:09:20.042083+01
58	feeds_enabled	1	2023-07-26 11:09:20.048501+01
90	security_badge_displayed	1	2023-07-26 11:09:20.08433+01
97	smtp_ssl	f	2023-07-26 09:22:07.229707+01
98	smtp_address		2023-07-26 09:22:07.233718+01
99	smtp_domain	your.domain.com	2023-07-26 09:22:07.237538+01
100	smtp_user_name		2023-07-26 09:22:07.241976+01
101	smtp_port	587	2023-07-26 09:22:07.246758+01
102	smtp_password		2023-07-26 09:22:07.250189+01
103	software_name	OpenProject	2023-07-26 09:22:07.255153+01
104	software_url	https://www.openproject.org/	2023-07-26 09:22:07.259052+01
105	sys_api_enabled	f	2023-07-26 09:22:07.263144+01
106	users_deletable_by_admins	f	2023-07-26 09:22:07.266686+01
107	users_deletable_by_self	f	2023-07-26 09:22:07.27+01
108	user_format	firstname_lastname	2023-07-26 09:22:07.273322+01
110	work_package_done_ratio	field	2023-07-26 09:22:07.281666+01
111	work_packages_projects_export_limit	500	2023-07-26 09:22:07.285133+01
112	work_packages_bulk_request_limit	10	2023-07-26 09:22:07.288562+01
113	work_package_list_default_highlighted_attributes	[]	2023-07-26 09:22:07.29278+01
114	work_package_list_default_columns	---\n- id\n- subject\n- type\n- status\n- assigned_to\n- priority\n	2023-07-26 09:22:07.299164+01
115	work_package_startdate_is_adddate	f	2023-07-26 09:22:07.302536+01
116	new_project_user_role_id	5	2023-07-26 09:22:07.305793+01
117	commit_fix_status_id	12	2023-07-26 09:22:07.310226+01
8	plugin_openproject_backlogs	---\nstory_types:\n- 4\n- 5\n- 6\n- 7\ntask_type: 1\npoints_burn_direction: up\nwiki_template: ''\n	2023-07-26 09:22:07.317015+01
118	welcome_title	Welcome to OpenProject!	2023-07-26 09:22:07.537506+01
109	welcome_on_homescreen	1	2023-07-26 09:22:07.549586+01
49	demo_view_of_type_work_packages_table_seeded	true	2023-07-26 09:22:07.802315+01
50	demo_view_of_type_team_planner_seeded	true	2023-07-26 09:22:07.835062+01
32	boards_demo_data_available	true	2023-07-26 09:22:08.612326+01
48	demo_projects_available	true	2023-07-26 09:22:08.674222+01
120	installation_uuid	59cb2d62-2670-4f39-b385-885e6ac08f55	2023-07-26 09:22:51.145907+01
119	welcome_text	Backup token: **06ac397c0cd55d0cb36c88c79a7d86d5733d8098378846fb21b75f11ec2d748a**	2023-07-26 11:09:20.090017+01
20	_maintenance_mode	---\n:enabled: false\n	2023-07-29 19:34:41.636414+01
26	app_title	OpenProject (backup)	2023-07-31 08:19:58.145929+01
\.


--
-- Data for Name: statuses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.statuses (id, name, is_closed, is_default, "position", default_done_ratio, created_at, updated_at, color_id, is_readonly) FROM stdin;
1	New	f	t	1	\N	2023-07-26 09:22:05.865881+01	2023-07-26 09:22:05.865881+01	92	f
2	In specification	f	f	2	\N	2023-07-26 09:22:05.869546+01	2023-07-26 09:22:05.869546+01	77	f
3	Specified	f	f	3	\N	2023-07-26 09:22:05.873046+01	2023-07-26 09:22:05.873046+01	77	f
4	Confirmed	f	f	4	\N	2023-07-26 09:22:05.876243+01	2023-07-26 09:22:05.876243+01	57	f
5	To be scheduled	f	f	5	\N	2023-07-26 09:22:05.881483+01	2023-07-26 09:22:05.881483+01	127	f
6	Scheduled	f	f	6	\N	2023-07-26 09:22:05.885731+01	2023-07-26 09:22:05.885731+01	117	f
7	In progress	f	f	7	\N	2023-07-26 09:22:05.890369+01	2023-07-26 09:22:05.890369+01	50	f
8	Developed	f	f	8	\N	2023-07-26 09:22:05.893566+01	2023-07-26 09:22:05.893566+01	108	f
9	In testing	f	f	9	\N	2023-07-26 09:22:05.900638+01	2023-07-26 09:22:05.900638+01	90	f
10	Tested	f	f	10	\N	2023-07-26 09:22:05.903969+01	2023-07-26 09:22:05.903969+01	101	f
11	Test failed	f	f	11	\N	2023-07-26 09:22:05.907152+01	2023-07-26 09:22:05.907152+01	30	f
12	Closed	t	f	12	\N	2023-07-26 09:22:05.910412+01	2023-07-26 09:22:05.910412+01	18	f
13	On hold	f	f	13	\N	2023-07-26 09:22:05.914333+01	2023-07-26 09:22:05.914333+01	138	f
14	Rejected	t	f	14	\N	2023-07-26 09:22:05.917505+01	2023-07-26 09:22:05.917505+01	28	f
\.


--
-- Data for Name: storages; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.storages (id, provider_type, name, host, creator_id, created_at, updated_at, provider_fields) FROM stdin;
\.


--
-- Data for Name: time_entries; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.time_entries (id, project_id, user_id, work_package_id, hours, comments, activity_id, spent_on, tyear, tmonth, tweek, created_at, updated_at, overridden_costs, costs, rate_id, logged_by_id) FROM stdin;
\.


--
-- Data for Name: time_entry_activities_projects; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.time_entry_activities_projects (id, activity_id, project_id, active) FROM stdin;
\.


--
-- Data for Name: time_entry_journals; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.time_entry_journals (id, project_id, user_id, work_package_id, hours, comments, activity_id, spent_on, tyear, tmonth, tweek, overridden_costs, costs, rate_id, logged_by_id) FROM stdin;
\.


--
-- Data for Name: tokens; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tokens (id, user_id, type, value, created_at, expires_on) FROM stdin;
2	4	Token::RSS	cf07df351fc11382e3c0f7639eef8bced79a0bb385b863481105fc07da5826fc	2023-07-26 09:23:53.479535+01	\N
3	4	Token::Backup	bdf333c2551b5762198adf397f6b291eae8063408327734ba6340ad063c8719a	1787-01-04 10:07:38.046577-00:01:15	\N
\.


--
-- Data for Name: two_factor_authentication_devices; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.two_factor_authentication_devices (id, type, "default", active, channel, phone_number, identifier, created_at, updated_at, last_used_at, otp_secret, user_id) FROM stdin;
\.


--
-- Data for Name: types; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.types (id, name, "position", is_in_roadmap, is_milestone, is_default, color_id, created_at, updated_at, is_standard, attribute_groups, description) FROM stdin;
1	Task	1	t	f	t	2	2023-07-26 09:22:05.926806+01	2023-07-26 09:22:05.926806+01	f	\N	
2	Milestone	3	f	t	t	4	2023-07-26 09:22:05.929778+01	2023-07-26 09:22:10.776297+01	f	\N	
3	Phase	4	f	f	t	140	2023-07-26 09:22:05.932772+01	2023-07-26 09:22:10.776297+01	f	\N	
4	Feature	5	t	f	f	70	2023-07-26 09:22:05.935667+01	2023-07-26 09:22:10.776297+01	f	\N	
5	Epic	6	t	f	f	60	2023-07-26 09:22:05.93856+01	2023-07-26 09:22:10.776297+01	f	\N	
6	User story	7	t	f	f	3	2023-07-26 09:22:05.941424+01	2023-07-26 09:22:10.776297+01	f	\N	
7	Bug	8	t	f	f	32	2023-07-26 09:22:05.94529+01	2023-07-26 09:22:10.776297+01	f	\N	
8	All CFS	9	t	f	f	\N	2023-07-26 09:22:10.759552+01	2023-07-26 09:22:10.776297+01	f	---\n- - :people\n  - - assignee\n    - responsible\n- - :estimates_and_time\n  - - estimated_time\n    - spent_time\n    - remaining_time\n- - :details\n  - - date\n    - percentage_done\n    - category\n    - version\n    - priority\n- - :costs\n  - - budget\n    - overall_costs\n    - labor_costs\n    - material_costs\n    - costs_by_type\n- - Custom fields\n  - - custom_field_1\n    - custom_field_2\n    - custom_field_3\n    - custom_field_4\n    - custom_field_5\n    - custom_field_6\n    - custom_field_7\n    - custom_field_8\n    - custom_field_9\n    - custom_field_11\n	\N
9	Required CF	2	t	f	f	\N	2023-07-26 09:22:10.772083+01	2023-07-26 09:22:10.772095+01	f	---\n- - :people\n  - - assignee\n    - responsible\n- - :estimates_and_time\n  - - estimated_time\n    - spent_time\n    - remaining_time\n- - :details\n  - - date\n    - percentage_done\n    - category\n    - version\n    - priority\n- - :costs\n  - - budget\n    - overall_costs\n    - labor_costs\n    - material_costs\n    - costs_by_type\n- - Custom fields\n  - - custom_field_10\n	\N
\.


--
-- Data for Name: user_passwords; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_passwords (id, user_id, hashed_password, salt, created_at, updated_at, type) FROM stdin;
1	4	$2a$12$vK/29tEVqXvUaLV248BRYuzN72hwbrk3RgeT4rLiKFrZmIL9aLXka	\N	2023-07-26 09:22:07.35466+01	2023-07-26 09:22:07.35466+01	UserPassword::Bcrypt
2	5	$2a$12$q319iwu0JBU.zU6ANOfy2u/jIxcNpiTTame2Lh61o5OLqHMfh7v4u	\N	2023-07-26 09:22:09.993527+01	2023-07-26 09:22:09.993527+01	UserPassword::Bcrypt
3	6	$2a$12$PcslaMUgtod7r3VN/BbO..HI.Ap1eSc3av7XgBCj4kmrAITGLIoZa	\N	2023-07-26 09:22:10.172556+01	2023-07-26 09:22:10.172556+01	UserPassword::Bcrypt
4	7	$2a$12$SqfKI0CzADDNDtHrCFYMFutpnTM6Q6Wo36AG/pGy7Gjp6oL51BsJq	\N	2023-07-26 09:22:10.378153+01	2023-07-26 09:22:10.378153+01	UserPassword::Bcrypt
5	8	$2a$12$Z6..J1mTZo2K.oNHyqpsy.hxNNTuLzROxua6fDvBrCfZmkGXNBpdq	\N	2023-07-26 09:22:10.544834+01	2023-07-26 09:22:10.544834+01	UserPassword::Bcrypt
\.


--
-- Data for Name: user_preferences; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_preferences (id, user_id, settings) FROM stdin;
1	4	\N
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, login, firstname, lastname, mail, admin, status, last_login_on, language, auth_source_id, created_at, updated_at, type, identity_url, first_login, force_password_change, failed_login_count, last_failed_login_on, consented_at) FROM stdin;
2					f	3	\N		\N	2023-07-26 09:21:36.583287+01	2023-07-26 09:21:36.583287+01	DeletedUser	\N	t	f	0	\N	\N
1			System		t	1	\N		\N	2023-07-26 09:21:35.573534+01	2023-07-26 09:21:35.573534+01	SystemUser	\N	f	f	0	\N	\N
3			Anonymous		f	1	\N		\N	2023-07-26 09:22:05.445636+01	2023-07-26 09:22:05.445636+01	AnonymousUser	\N	t	f	0	\N	\N
5	reader	Reader	DEV user	reader@example.net	f	1	\N	en	\N	2023-07-26 09:22:09.991117+01	2023-07-26 09:22:09.991117+01	User	\N	t	f	0	\N	\N
6	member	Member	DEV user	member@example.net	f	1	\N	en	\N	2023-07-26 09:22:10.169743+01	2023-07-26 09:22:10.169743+01	User	\N	t	f	0	\N	\N
7	project_admin	Project admin	DEV user	project_admin@example.net	f	1	\N	en	\N	2023-07-26 09:22:10.37577+01	2023-07-26 09:22:10.37577+01	User	\N	t	f	0	\N	\N
8	admin_de	Admin de	DEV user	admin_de@example.net	t	1	\N	de	\N	2023-07-26 09:22:10.542727+01	2023-07-26 09:22:10.542727+01	User	\N	t	f	0	\N	\N
4	admin	OpenProject	Admin	admin@example.net	t	1	2023-07-30 22:36:33.607612+01	en	\N	2023-07-26 09:22:07.345237+01	2023-07-30 22:36:33.610732+01	User	\N	f	f	0	2023-07-28 11:18:39.366254+01	\N
\.


--
-- Data for Name: version_settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.version_settings (id, project_id, version_id, display, created_at, updated_at) FROM stdin;
1	2	1	3	2023-07-26 09:22:08.836034+01	2023-07-26 09:22:08.836034+01
2	2	2	3	2023-07-26 09:22:08.838315+01	2023-07-26 09:22:08.838315+01
3	2	3	2	2023-07-26 09:22:08.839937+01	2023-07-26 09:22:08.839937+01
4	2	4	2	2023-07-26 09:22:08.842358+01	2023-07-26 09:22:08.842358+01
\.


--
-- Data for Name: versions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.versions (id, project_id, name, description, effective_date, created_at, updated_at, wiki_page_title, status, sharing, start_date) FROM stdin;
1	2	Bug Backlog		\N	2023-07-26 09:22:08.778842+01	2023-07-26 09:22:08.778842+01	\N	open	none	\N
2	2	Product Backlog		\N	2023-07-26 09:22:08.782362+01	2023-07-26 09:22:08.782362+01	\N	open	none	\N
3	2	Sprint 1		\N	2023-07-26 09:22:08.784687+01	2023-07-26 09:22:08.818188+01	Sprint 1	open	none	\N
4	2	Sprint 2		\N	2023-07-26 09:22:08.82122+01	2023-07-26 09:22:08.82122+01	\N	open	none	\N
5	3	Bug Backlog		\N	2023-07-26 09:22:11.037172+01	2023-07-26 09:22:11.037172+01	\N	open	none	\N
6	3	Product Backlog		\N	2023-07-26 09:22:11.038927+01	2023-07-26 09:22:11.038927+01	\N	open	none	\N
7	3	Sprint 1		\N	2023-07-26 09:22:11.040394+01	2023-07-26 09:22:11.040394+01	\N	open	none	\N
8	3	Sprint 2		\N	2023-07-26 09:22:11.043049+01	2023-07-26 09:22:11.043049+01	\N	open	none	\N
9	4	Bug Backlog		\N	2023-07-26 09:22:11.050323+01	2023-07-26 09:22:11.050323+01	\N	open	none	\N
10	4	Product Backlog		\N	2023-07-26 09:22:11.05445+01	2023-07-26 09:22:11.05445+01	\N	open	none	\N
11	4	Sprint 1		\N	2023-07-26 09:22:11.057423+01	2023-07-26 09:22:11.057423+01	\N	open	none	\N
12	4	Sprint 2		\N	2023-07-26 09:22:11.060407+01	2023-07-26 09:22:11.060407+01	\N	open	none	\N
13	5	Bug Backlog		\N	2023-07-26 09:22:11.062547+01	2023-07-26 09:22:11.062547+01	\N	open	none	\N
14	5	Product Backlog		\N	2023-07-26 09:22:11.065743+01	2023-07-26 09:22:11.065743+01	\N	open	none	\N
15	5	Sprint 1		\N	2023-07-26 09:22:11.068162+01	2023-07-26 09:22:11.068162+01	\N	open	none	\N
16	5	Sprint 2		\N	2023-07-26 09:22:11.069897+01	2023-07-26 09:22:11.069897+01	\N	open	none	\N
17	6	Bug Backlog		\N	2023-07-26 09:22:11.071735+01	2023-07-26 09:22:11.071735+01	\N	open	none	\N
18	6	Product Backlog		\N	2023-07-26 09:22:11.073452+01	2023-07-26 09:22:11.073452+01	\N	open	none	\N
19	6	Sprint 1		\N	2023-07-26 09:22:11.079102+01	2023-07-26 09:22:11.079102+01	\N	open	none	\N
20	6	Sprint 2		\N	2023-07-26 09:22:11.081623+01	2023-07-26 09:22:11.081623+01	\N	open	none	\N
\.


--
-- Data for Name: views; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.views (id, query_id, options, type, created_at, updated_at) FROM stdin;
1	1	{}	work_packages_table	2023-07-26 09:22:07.799586+01	2023-07-26 09:22:07.799586+01
2	2	{}	work_packages_table	2023-07-26 09:22:07.812586+01	2023-07-26 09:22:07.812586+01
3	3	{}	work_packages_table	2023-07-26 09:22:07.822279+01	2023-07-26 09:22:07.822279+01
4	4	{}	team_planner	2023-07-26 09:22:07.832812+01	2023-07-26 09:22:07.832812+01
5	15	{}	work_packages_table	2023-07-26 09:22:08.850113+01	2023-07-26 09:22:08.850113+01
6	16	{}	work_packages_table	2023-07-26 09:22:08.861049+01	2023-07-26 09:22:08.861049+01
7	17	{}	work_packages_table	2023-07-26 09:22:08.870956+01	2023-07-26 09:22:08.870956+01
8	18	{}	work_packages_table	2023-07-26 09:22:08.88172+01	2023-07-26 09:22:08.88172+01
\.


--
-- Data for Name: watchers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.watchers (id, watchable_type, watchable_id, user_id) FROM stdin;
1	News	1	4
2	News	2	4
\.


--
-- Data for Name: webhooks_events; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.webhooks_events (id, name, webhooks_webhook_id) FROM stdin;
\.


--
-- Data for Name: webhooks_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.webhooks_logs (id, webhooks_webhook_id, event_name, url, request_headers, request_body, response_code, response_headers, response_body, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: webhooks_projects; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.webhooks_projects (id, project_id, webhooks_webhook_id) FROM stdin;
\.


--
-- Data for Name: webhooks_webhooks; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.webhooks_webhooks (id, name, url, description, secret, enabled, all_projects, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: wiki_page_journals; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.wiki_page_journals (id, author_id, text) FROM stdin;
1	1	### Sprint planning meeting\n\n_Please document here topics to the Sprint planning meeting_\n\n* Time boxed (8 h)\n* Input: Product Backlog\n* Output: Sprint Backlog\n\n* Divided into two additional time boxes of 4 h:\n\n    * The Product Owner presents the [Product Backlog]({{opSetting:base_url}}/projects/your-scrum-project/backlogs) and the priorities to the team and explains the Sprint Goal, to which the team must agree. Together, they prioritize the topics from the Product Backlog which the team will take care of in the next sprint. The team commits to the discussed delivery.\n    * The team plans autonomously (without the Product Owner) in detail and breaks down the tasks from the discussed requirements to consolidate a [Sprint Backlog]({{opSetting:base_url}}/projects/your-scrum-project/backlogs).\n\n\n### Daily Scrum meeting\n\n_Please document here topics to the Daily Scrum meeting_\n\n* Short, daily status meeting of the team.\n* Time boxed (max. 15 min).\n* Stand-up meeting to discuss the following topics from the [Task board](/projects/your-scrum-project/sprints/3/taskboard).\n    * What do I plan to do until the next Daily Scrum?\n    * What has blocked my work (Impediments)?\n* Scrum Master moderates and notes down [Sprint Impediments](/projects/your-scrum-project/sprints/3/taskboard).\n* Product Owner may participate may participate in order to stay informed.\n\n### Sprint Review meeting\n\n_Please document here topics to the Sprint Review meeting_\n\n* Time boxed (4 h).\n* A maximum of one hour of preparation time per person.\n* The team shows the product owner and other interested persons what has been achieved in this sprint.\n* Important: no dummies and no PowerPoint! Just finished product functionality (Increments) should be demonstrated.\n* Feedback from Product Owner, stakeholders and others is desired and will be included in further work.\n* Based on the demonstrated functionalities, the Product Owner decides to go live with this increment or to develop it further. This possibility allows an early ROI.\n\n\n### Sprint Retrospective\n\n_Please document here topics to the Sprint Retrospective meeting_\n\n* Time boxed (3 h).\n* After Sprint Review, will be moderated by Scrum Master.\n* The team discusses the sprint: what went well, what needs to be improved to be more productive for the next sprint or even have more fun.\n
2	4	### Sprint planning meeting\n\n_Please document here topics to the Sprint planning meeting_\n\n* Time boxed (8 h)\n* Input: Product Backlog\n* Output: Sprint Backlog\n\n* Divided into two additional time boxes of 4 h:\n\n    * The Product Owner presents the [Product Backlog]({{opSetting:base_url}}/projects/your-scrum-project/backlogs) and the priorities to the team and explains the Sprint Goal, to which the team must agree. Together, they prioritize the topics from the Product Backlog which the team will take care of in the next sprint. The team commits to the discussed delivery.\n    * The team plans autonomously (without the Product Owner) in detail and breaks down the tasks from the discussed requirements to consolidate a [Sprint Backlog]({{opSetting:base_url}}/projects/your-scrum-project/backlogs).\n\n\n### Daily Scrum meeting\n\n_Please document here topics to the Daily Scrum meeting_\n\n* Short, daily status meeting of the team.\n* Time boxed (max. 15 min).\n* Stand-up meeting to discuss the following topics from the Task board.\n    * What do I plan to do until the next Daily Scrum?\n    * What has blocked my work (Impediments)?\n* Scrum Master moderates and notes down Sprint Impediments.\n* Product Owner may participate may participate in order to stay informed.\n\n### Sprint Review meeting\n\n_Please document here topics to the Sprint Review meeting_\n\n* Time boxed (4 h).\n* A maximum of one hour of preparation time per person.\n* The team shows the product owner and other interested persons what has been achieved in this sprint.\n* Important: no dummies and no PowerPoint! Just finished product functionality (Increments) should be demonstrated.\n* Feedback from Product Owner, stakeholders and others is desired and will be included in further work.\n* Based on the demonstrated functionalities, the Product Owner decides to go live with this increment or to develop it further. This possibility allows an early ROI.\n\n\n### Sprint Retrospective\n\n_Please document here topics to the Sprint Retrospective meeting_\n\n* Time boxed (3 h).\n* After Sprint Review, will be moderated by Scrum Master.\n* The team discusses the sprint: what went well, what needs to be improved to be more productive for the next sprint or even have more fun.\n
\.


--
-- Data for Name: wiki_pages; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.wiki_pages (id, wiki_id, title, created_at, protected, parent_id, slug, updated_at, author_id, text, lock_version) FROM stdin;
1	2	Sprint 1	2023-07-26 09:22:08.797831+01	f	\N	sprint-1	2023-07-26 09:22:08.797831+01	1	### Sprint planning meeting\n\n_Please document here topics to the Sprint planning meeting_\n\n* Time boxed (8 h)\n* Input: Product Backlog\n* Output: Sprint Backlog\n\n* Divided into two additional time boxes of 4 h:\n\n    * The Product Owner presents the [Product Backlog]({{opSetting:base_url}}/projects/your-scrum-project/backlogs) and the priorities to the team and explains the Sprint Goal, to which the team must agree. Together, they prioritize the topics from the Product Backlog which the team will take care of in the next sprint. The team commits to the discussed delivery.\n    * The team plans autonomously (without the Product Owner) in detail and breaks down the tasks from the discussed requirements to consolidate a [Sprint Backlog]({{opSetting:base_url}}/projects/your-scrum-project/backlogs).\n\n\n### Daily Scrum meeting\n\n_Please document here topics to the Daily Scrum meeting_\n\n* Short, daily status meeting of the team.\n* Time boxed (max. 15 min).\n* Stand-up meeting to discuss the following topics from the [Task board](/projects/your-scrum-project/sprints/3/taskboard).\n    * What do I plan to do until the next Daily Scrum?\n    * What has blocked my work (Impediments)?\n* Scrum Master moderates and notes down [Sprint Impediments](/projects/your-scrum-project/sprints/3/taskboard).\n* Product Owner may participate may participate in order to stay informed.\n\n### Sprint Review meeting\n\n_Please document here topics to the Sprint Review meeting_\n\n* Time boxed (4 h).\n* A maximum of one hour of preparation time per person.\n* The team shows the product owner and other interested persons what has been achieved in this sprint.\n* Important: no dummies and no PowerPoint! Just finished product functionality (Increments) should be demonstrated.\n* Feedback from Product Owner, stakeholders and others is desired and will be included in further work.\n* Based on the demonstrated functionalities, the Product Owner decides to go live with this increment or to develop it further. This possibility allows an early ROI.\n\n\n### Sprint Retrospective\n\n_Please document here topics to the Sprint Retrospective meeting_\n\n* Time boxed (3 h).\n* After Sprint Review, will be moderated by Scrum Master.\n* The team discusses the sprint: what went well, what needs to be improved to be more productive for the next sprint or even have more fun.\n	0
2	2	Wiki	2023-07-26 09:22:08.887046+01	f	\N	wiki	2023-07-26 09:22:08.887046+01	4	### Sprint planning meeting\n\n_Please document here topics to the Sprint planning meeting_\n\n* Time boxed (8 h)\n* Input: Product Backlog\n* Output: Sprint Backlog\n\n* Divided into two additional time boxes of 4 h:\n\n    * The Product Owner presents the [Product Backlog]({{opSetting:base_url}}/projects/your-scrum-project/backlogs) and the priorities to the team and explains the Sprint Goal, to which the team must agree. Together, they prioritize the topics from the Product Backlog which the team will take care of in the next sprint. The team commits to the discussed delivery.\n    * The team plans autonomously (without the Product Owner) in detail and breaks down the tasks from the discussed requirements to consolidate a [Sprint Backlog]({{opSetting:base_url}}/projects/your-scrum-project/backlogs).\n\n\n### Daily Scrum meeting\n\n_Please document here topics to the Daily Scrum meeting_\n\n* Short, daily status meeting of the team.\n* Time boxed (max. 15 min).\n* Stand-up meeting to discuss the following topics from the Task board.\n    * What do I plan to do until the next Daily Scrum?\n    * What has blocked my work (Impediments)?\n* Scrum Master moderates and notes down Sprint Impediments.\n* Product Owner may participate may participate in order to stay informed.\n\n### Sprint Review meeting\n\n_Please document here topics to the Sprint Review meeting_\n\n* Time boxed (4 h).\n* A maximum of one hour of preparation time per person.\n* The team shows the product owner and other interested persons what has been achieved in this sprint.\n* Important: no dummies and no PowerPoint! Just finished product functionality (Increments) should be demonstrated.\n* Feedback from Product Owner, stakeholders and others is desired and will be included in further work.\n* Based on the demonstrated functionalities, the Product Owner decides to go live with this increment or to develop it further. This possibility allows an early ROI.\n\n\n### Sprint Retrospective\n\n_Please document here topics to the Sprint Retrospective meeting_\n\n* Time boxed (3 h).\n* After Sprint Review, will be moderated by Scrum Master.\n* The team discusses the sprint: what went well, what needs to be improved to be more productive for the next sprint or even have more fun.\n	0
\.


--
-- Data for Name: wiki_redirects; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.wiki_redirects (id, wiki_id, title, redirects_to, created_at) FROM stdin;
\.


--
-- Data for Name: wikis; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.wikis (id, project_id, start_page, status, created_at, updated_at) FROM stdin;
1	1	Wiki	1	2023-07-26 09:22:07.614753+01	2023-07-26 09:22:07.614753+01
2	2	Wiki	1	2023-07-26 09:22:08.703902+01	2023-07-26 09:22:08.887882+01
\.


--
-- Data for Name: work_package_hierarchies; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.work_package_hierarchies (ancestor_id, descendant_id, generations) FROM stdin;
1	1	0
2	2	0
3	3	0
2	3	1
4	4	0
3	4	1
2	4	2
5	5	0
3	5	1
2	5	2
6	6	0
3	6	1
2	6	2
7	7	0
2	7	1
8	8	0
2	8	1
9	9	0
10	10	0
11	11	0
10	11	1
12	12	0
10	12	1
13	13	0
14	14	0
15	15	0
16	16	0
17	17	0
16	17	1
18	18	0
16	18	1
19	19	0
16	19	1
20	20	0
19	20	1
16	20	2
21	21	0
22	22	0
23	23	0
22	23	1
24	24	0
25	25	0
26	26	0
27	27	0
28	28	0
29	29	0
28	29	1
30	30	0
31	31	0
32	32	0
33	33	0
34	34	0
35	35	0
36	36	0
\.


--
-- Data for Name: work_package_journals; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.work_package_journals (id, type_id, project_id, subject, description, due_date, category_id, status_id, assigned_to_id, priority_id, version_id, author_id, done_ratio, estimated_hours, start_date, parent_id, responsible_id, budget_id, story_points, remaining_hours, derived_estimated_hours, schedule_manually, duration, ignore_non_working_days) FROM stdin;
1	2	1	Start of project		2023-07-23	\N	12	4	8	\N	4	0	\N	2023-07-23	\N	\N	\N	\N	\N	\N	f	1	t
5	1	1	Send invitation to speakers		2023-07-24	\N	7	4	8	\N	4	0	\N	2023-07-24	3	\N	\N	\N	\N	\N	f	1	f
7	1	1	Contact sponsoring partners		2023-07-25	\N	1	4	8	\N	4	0	\N	2023-07-24	3	\N	\N	\N	\N	\N	f	2	f
9	1	1	Create sponsorship brochure and hand-outs		2023-07-27	\N	1	4	8	\N	4	0	\N	2023-07-24	3	\N	\N	\N	\N	\N	f	4	f
11	1	1	Set date and location of conference		2023-07-27	\N	7	4	8	\N	4	0	\N	2023-07-24	2	\N	\N	\N	\N	\N	f	4	f
13	1	1	Invite attendees to conference		2023-07-28	\N	1	4	8	\N	4	0	\N	2023-07-28	2	\N	\N	\N	\N	\N	f	1	f
15	1	1	Setup conference website		2023-08-07	\N	1	4	8	\N	4	0	\N	2023-07-28	2	\N	\N	\N	\N	\N	f	7	f
16	3	1	Organize open source conference		2023-08-07	\N	7	4	8	\N	4	0	\N	2023-07-24	\N	\N	\N	\N	\N	\N	f	11	f
17	2	1	Conference		2023-08-08	\N	6	4	8	\N	4	0	\N	2023-08-08	\N	\N	\N	\N	\N	\N	f	1	f
20	1	1	Upload presentations to website		2023-08-23	\N	1	4	8	\N	4	0	\N	2023-08-14	10	\N	\N	\N	\N	\N	f	8	f
22	1	1	Party for conference supporters :-)	*   [ ] Beer\n*   [ ] Snacks\n*   [ ] Music\n*   [ ] Even more beer	2023-08-24	\N	1	4	8	\N	4	0	\N	2023-08-24	10	\N	\N	\N	\N	\N	f	1	f
23	3	1	Follow-up tasks		2023-08-24	\N	5	4	8	\N	4	0	\N	2023-08-14	\N	\N	\N	\N	\N	\N	f	9	f
24	2	1	End of project		2023-08-25	\N	1	4	8	\N	4	0	\N	2023-08-25	\N	\N	\N	\N	\N	\N	f	1	f
25	6	2	New login screen		\N	\N	2	4	8	2	4	0	\N	2023-07-24	\N	\N	\N	\N	\N	\N	f	\N	f
26	7	2	Password reset does not send email		\N	\N	4	4	8	1	4	0	\N	2023-07-24	\N	\N	\N	\N	\N	\N	f	\N	f
29	6	2	Newsletter registration form		\N	\N	7	4	8	2	4	0	\N	2023-07-24	16	\N	\N	\N	\N	\N	f	\N	f
31	6	2	Implement product tour		\N	\N	2	4	8	2	4	0	\N	2023-07-24	16	\N	\N	\N	\N	\N	f	\N	f
34	1	2	Create wireframes for new landing page		2023-08-21	\N	7	4	8	3	4	0	\N	2023-08-21	19	\N	\N	\N	\N	\N	f	1	f
36	6	2	New landing page		2023-08-21	\N	3	4	8	3	4	0	\N	2023-08-21	16	\N	\N	3	\N	\N	f	1	f
37	5	2	New website		2023-08-21	\N	3	4	8	\N	4	0	\N	2023-07-24	\N	\N	\N	\N	\N	\N	f	21	f
38	6	2	Contact form		2023-08-14	\N	3	4	8	3	4	0	\N	2023-08-14	\N	\N	\N	1	\N	\N	f	1	f
41	1	2	Make screenshots for feature tour		\N	\N	12	4	8	3	4	0	\N	2023-07-24	22	\N	\N	\N	\N	\N	f	\N	f
42	6	2	Feature carousel		\N	\N	3	4	8	3	4	0	\N	2023-07-24	\N	\N	\N	5	\N	\N	f	\N	f
43	7	2	Wrong hover color		2023-08-14	\N	14	4	8	3	4	0	\N	2023-08-14	\N	\N	\N	1	\N	\N	f	1	f
44	6	2	SSL certificate		2023-08-15	\N	3	4	8	2	4	0	\N	2023-08-15	\N	\N	\N	\N	\N	\N	f	1	f
45	6	2	Set-up Staging environment		2023-08-16	\N	2	4	8	2	4	0	\N	2023-08-16	\N	\N	\N	\N	\N	\N	f	1	f
46	6	2	Choose a content management system		2023-08-17	\N	3	4	8	2	4	0	\N	2023-08-17	\N	\N	\N	\N	\N	\N	f	1	f
49	1	2	Set up navigation concept for website.		2023-08-18	\N	2	4	8	3	4	0	\N	2023-08-18	28	\N	\N	\N	\N	\N	f	1	f
50	6	2	Website navigation structure		2023-08-18	\N	3	4	8	3	4	0	\N	2023-08-18	\N	\N	\N	3	\N	\N	f	1	f
51	6	2	Internal link structure		2023-08-18	\N	12	4	8	2	4	0	\N	2023-08-18	\N	\N	\N	\N	\N	\N	f	1	f
52	3	2	Develop v1.0		2023-08-09	\N	7	4	8	\N	4	0	\N	2023-08-07	\N	\N	\N	\N	\N	\N	f	3	f
53	2	2	Release v1.0		2023-08-11	\N	1	4	8	\N	4	0	\N	2023-08-11	\N	\N	\N	\N	\N	\N	f	1	f
54	3	2	Develop v1.1		2023-08-16	\N	1	4	8	\N	4	0	\N	2023-08-14	\N	\N	\N	\N	\N	\N	f	3	f
55	2	2	Release v1.1		2023-08-18	\N	1	4	8	\N	4	0	\N	2023-08-18	\N	\N	\N	\N	\N	\N	f	1	f
56	3	2	Develop v2.0		2023-08-23	\N	1	4	8	\N	4	0	\N	2023-08-21	\N	\N	\N	\N	\N	\N	f	3	f
57	2	2	Release v2.0		2023-08-25	\N	1	4	8	\N	4	0	\N	2023-08-25	\N	\N	\N	\N	\N	\N	f	1	f
59	3	1	Organize open source conference		2023-08-07	\N	7	4	8	\N	4	0	\N	2023-07-24	\N	\N	\N	\N	\N	\N	f	11	f
62	3	1	Cactus	<figure class="image op-uc-figure"><div class="op-uc-figure--content"><img class="op-uc-image" src="/attachments/7/ff-cactus.jpg"></div></figure>	2023-08-07	\N	7	4	8	\N	4	0	\N	2023-07-24	\N	\N	\N	\N	\N	\N	f	11	f
\.


--
-- Data for Name: work_packages; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.work_packages (id, type_id, project_id, subject, description, due_date, category_id, status_id, assigned_to_id, priority_id, version_id, author_id, lock_version, done_ratio, estimated_hours, created_at, updated_at, start_date, responsible_id, budget_id, "position", story_points, remaining_hours, derived_estimated_hours, schedule_manually, parent_id, duration, ignore_non_working_days) FROM stdin;
1	2	1	Start of project	\N	2023-07-23	\N	12	4	8	\N	4	0	0	\N	2023-07-26 09:22:07.861971+01	2023-07-26 09:22:07.861971+01	2023-07-23	\N	\N	1	\N	\N	\N	f	\N	1	t
4	1	1	Send invitation to speakers		2023-07-24	\N	7	4	8	\N	4	1	0	\N	2023-07-26 09:22:07.98944+01	2023-07-26 09:22:08.022222+01	2023-07-24	\N	\N	1	\N	\N	\N	f	3	1	f
5	1	1	Contact sponsoring partners		2023-07-25	\N	1	4	8	\N	4	1	0	\N	2023-07-26 09:22:08.04898+01	2023-07-26 09:22:08.076017+01	2023-07-24	\N	\N	1	\N	\N	\N	f	3	2	f
6	1	1	Create sponsorship brochure and hand-outs		2023-07-27	\N	1	4	8	\N	4	1	0	\N	2023-07-26 09:22:08.099198+01	2023-07-26 09:22:08.133985+01	2023-07-24	\N	\N	1	\N	\N	\N	f	3	4	f
3	1	1	Set date and location of conference		2023-07-27	\N	7	4	8	\N	4	1	0	\N	2023-07-26 09:22:07.963258+01	2023-07-26 09:22:08.175837+01	2023-07-24	\N	\N	1	\N	\N	\N	f	2	4	f
7	1	1	Invite attendees to conference		2023-07-28	\N	1	4	8	\N	4	1	0	\N	2023-07-26 09:22:08.211407+01	2023-07-26 09:22:08.244611+01	2023-07-28	\N	\N	1	\N	\N	\N	f	2	1	f
8	1	1	Setup conference website		2023-08-07	\N	1	4	8	\N	4	1	0	\N	2023-07-26 09:22:08.271391+01	2023-07-26 09:22:08.299354+01	2023-07-28	\N	\N	1	\N	\N	\N	f	2	7	f
9	2	1	Conference		2023-08-08	\N	6	4	8	\N	4	0	0	\N	2023-07-26 09:22:08.34986+01	2023-07-26 09:22:08.34986+01	2023-08-08	\N	\N	1	\N	\N	\N	f	\N	1	f
10	3	1	Follow-up tasks		2023-08-24	\N	5	4	8	\N	4	0	0	\N	2023-07-26 09:22:08.382407+01	2023-07-26 09:22:08.382407+01	2023-08-14	\N	\N	1	\N	\N	\N	f	\N	9	f
11	1	1	Upload presentations to website		2023-08-23	\N	1	4	8	\N	4	1	0	\N	2023-07-26 09:22:08.40803+01	2023-07-26 09:22:08.440139+01	2023-08-14	\N	\N	1	\N	\N	\N	f	10	8	f
12	1	1	Party for conference supporters :-)	*   [ ] Beer\n*   [ ] Snacks\n*   [ ] Music\n*   [ ] Even more beer	2023-08-24	\N	1	4	8	\N	4	1	0	\N	2023-07-26 09:22:08.473451+01	2023-07-26 09:22:08.500926+01	2023-08-24	\N	\N	1	\N	\N	\N	f	10	1	f
13	2	1	End of project	\N	2023-08-25	\N	1	4	8	\N	4	0	0	\N	2023-07-26 09:22:08.536543+01	2023-07-26 09:22:08.536543+01	2023-08-25	\N	\N	1	\N	\N	\N	f	\N	1	f
15	7	2	Password reset does not send email	\N	\N	\N	4	4	8	1	4	0	0	\N	2023-07-26 09:22:08.953453+01	2023-07-26 09:22:08.953453+01	2023-07-24	\N	\N	1	\N	\N	\N	f	\N	\N	f
16	5	2	New website	\N	2023-08-21	\N	3	4	8	\N	4	0	0	\N	2023-07-26 09:22:08.985574+01	2023-07-26 09:22:08.985574+01	2023-07-24	\N	\N	1	\N	\N	\N	f	\N	21	f
20	1	2	Create wireframes for new landing page	\N	2023-08-21	\N	7	4	8	3	4	1	0	\N	2023-07-26 09:22:09.163901+01	2023-07-26 09:22:09.191765+01	2023-08-21	\N	\N	1	\N	\N	\N	f	19	1	f
19	6	2	New landing page	\N	2023-08-21	\N	3	4	8	3	4	1	0	\N	2023-07-26 09:22:09.133711+01	2023-07-26 09:22:09.232877+01	2023-08-21	\N	\N	2	3	\N	\N	f	16	1	f
22	6	2	Feature carousel	\N	\N	\N	3	4	8	3	4	0	0	\N	2023-07-26 09:22:09.315148+01	2023-07-26 09:22:09.315148+01	2023-07-24	\N	\N	3	5	\N	\N	f	\N	\N	f
23	1	2	Make screenshots for feature tour	\N	\N	\N	12	4	8	3	4	1	0	\N	2023-07-26 09:22:09.346099+01	2023-07-26 09:22:09.376658+01	2023-07-24	\N	\N	1	\N	\N	\N	f	22	\N	f
24	7	2	Wrong hover color	\N	2023-08-14	\N	14	4	8	3	4	0	0	\N	2023-07-26 09:22:09.419672+01	2023-07-26 09:22:09.419672+01	2023-08-14	\N	\N	4	1	\N	\N	f	\N	1	f
25	6	2	SSL certificate	\N	2023-08-15	\N	3	4	8	2	4	0	0	\N	2023-07-26 09:22:09.451078+01	2023-07-26 09:22:09.451078+01	2023-08-15	\N	\N	1	\N	\N	\N	f	\N	1	f
26	6	2	Set-up Staging environment	\N	2023-08-16	\N	2	4	8	2	4	0	0	\N	2023-07-26 09:22:09.489023+01	2023-07-26 09:22:09.489023+01	2023-08-16	\N	\N	2	\N	\N	\N	f	\N	1	f
21	6	2	Contact form	\N	2023-08-14	\N	3	4	8	3	4	0	0	\N	2023-07-26 09:22:09.28385+01	2023-07-26 09:22:09.28385+01	2023-08-14	\N	\N	8	1	\N	\N	f	\N	1	f
28	6	2	Website navigation structure	\N	2023-08-18	\N	3	4	8	3	4	0	0	\N	2023-07-26 09:22:09.560194+01	2023-07-26 09:22:09.560194+01	2023-08-18	\N	\N	7	3	\N	\N	f	\N	1	f
29	1	2	Set up navigation concept for website.	\N	2023-08-18	\N	2	4	8	3	4	1	0	\N	2023-07-26 09:22:09.588829+01	2023-07-26 09:22:09.616727+01	2023-08-18	\N	\N	1	\N	\N	\N	f	28	1	f
14	6	2	New login screen	\N	\N	\N	2	4	8	2	4	0	0	\N	2023-07-26 09:22:08.914479+01	2023-07-26 09:22:08.914479+01	2023-07-24	\N	\N	6	\N	\N	\N	f	\N	\N	f
17	6	2	Newsletter registration form	\N	\N	\N	7	4	8	2	4	1	0	\N	2023-07-26 09:22:09.00801+01	2023-07-26 09:22:09.046689+01	2023-07-24	\N	\N	11	\N	\N	\N	f	16	\N	f
18	6	2	Implement product tour	\N	\N	\N	2	4	8	2	4	1	0	\N	2023-07-26 09:22:09.074143+01	2023-07-26 09:22:09.106608+01	2023-07-24	\N	\N	7	\N	\N	\N	f	16	\N	f
27	6	2	Choose a content management system	\N	2023-08-17	\N	3	4	8	2	4	0	0	\N	2023-07-26 09:22:09.525581+01	2023-07-26 09:22:09.525581+01	2023-08-17	\N	\N	8	\N	\N	\N	f	\N	1	f
30	6	2	Internal link structure	\N	2023-08-18	\N	12	4	8	2	4	0	0	\N	2023-07-26 09:22:09.655628+01	2023-07-26 09:22:09.655628+01	2023-08-18	\N	\N	5	\N	\N	\N	f	\N	1	f
31	3	2	Develop v1.0	\N	2023-08-09	\N	7	4	8	\N	4	0	0	\N	2023-07-26 09:22:09.685346+01	2023-07-26 09:22:09.685346+01	2023-08-07	\N	\N	1	\N	\N	\N	f	\N	3	f
32	2	2	Release v1.0	\N	2023-08-11	\N	1	4	8	\N	4	0	0	\N	2023-07-26 09:22:09.712085+01	2023-07-26 09:22:09.712085+01	2023-08-11	\N	\N	1	\N	\N	\N	f	\N	1	f
33	3	2	Develop v1.1	\N	2023-08-16	\N	1	4	8	\N	4	0	0	\N	2023-07-26 09:22:09.744906+01	2023-07-26 09:22:09.744906+01	2023-08-14	\N	\N	1	\N	\N	\N	f	\N	3	f
34	2	2	Release v1.1	\N	2023-08-18	\N	1	4	8	\N	4	0	0	\N	2023-07-26 09:22:09.771828+01	2023-07-26 09:22:09.771828+01	2023-08-18	\N	\N	1	\N	\N	\N	f	\N	1	f
35	3	2	Develop v2.0	\N	2023-08-23	\N	1	4	8	\N	4	0	0	\N	2023-07-26 09:22:09.799192+01	2023-07-26 09:22:09.799192+01	2023-08-21	\N	\N	1	\N	\N	\N	f	\N	3	f
36	2	2	Release v2.0	\N	2023-08-25	\N	1	4	8	\N	4	0	0	\N	2023-07-26 09:22:09.828692+01	2023-07-26 09:22:09.828692+01	2023-08-25	\N	\N	1	\N	\N	\N	f	\N	1	f
2	3	1	Cactus	<figure class="image op-uc-figure"><div class="op-uc-figure--content"><img class="op-uc-image" src="/attachments/7/ff-cactus.jpg"></div></figure>	2023-08-07	\N	7	4	8	\N	4	1	0	\N	2023-07-26 09:22:07.933492+01	2023-07-31 08:18:14.729321+01	2023-07-24	\N	\N	1	\N	\N	\N	f	\N	11	f
\.


--
-- Data for Name: workflows; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.workflows (id, type_id, old_status_id, new_status_id, role_id, assignee, author) FROM stdin;
1	1	1	1	3	f	f
2	1	1	1	5	f	f
3	1	1	7	3	f	f
4	1	1	7	5	f	f
5	1	1	13	3	f	f
6	1	1	13	5	f	f
7	1	1	14	3	f	f
8	1	1	14	5	f	f
9	1	1	12	3	f	f
10	1	1	12	5	f	f
11	1	7	1	3	f	f
12	1	7	1	5	f	f
13	1	7	7	3	f	f
14	1	7	7	5	f	f
15	1	7	13	3	f	f
16	1	7	13	5	f	f
17	1	7	14	3	f	f
18	1	7	14	5	f	f
19	1	7	12	3	f	f
20	1	7	12	5	f	f
21	1	13	1	3	f	f
22	1	13	1	5	f	f
23	1	13	7	3	f	f
24	1	13	7	5	f	f
25	1	13	13	3	f	f
26	1	13	13	5	f	f
27	1	13	14	3	f	f
28	1	13	14	5	f	f
29	1	13	12	3	f	f
30	1	13	12	5	f	f
31	1	14	1	3	f	f
32	1	14	1	5	f	f
33	1	14	7	3	f	f
34	1	14	7	5	f	f
35	1	14	13	3	f	f
36	1	14	13	5	f	f
37	1	14	14	3	f	f
38	1	14	14	5	f	f
39	1	14	12	3	f	f
40	1	14	12	5	f	f
41	1	12	1	3	f	f
42	1	12	1	5	f	f
43	1	12	7	3	f	f
44	1	12	7	5	f	f
45	1	12	13	3	f	f
46	1	12	13	5	f	f
47	1	12	14	3	f	f
48	1	12	14	5	f	f
49	1	12	12	3	f	f
50	1	12	12	5	f	f
51	2	1	1	3	f	f
52	2	1	1	5	f	f
53	2	1	5	3	f	f
54	2	1	5	5	f	f
55	2	1	6	3	f	f
56	2	1	6	5	f	f
57	2	1	7	3	f	f
58	2	1	7	5	f	f
59	2	1	13	3	f	f
60	2	1	13	5	f	f
61	2	1	14	3	f	f
62	2	1	14	5	f	f
63	2	1	12	3	f	f
64	2	1	12	5	f	f
65	2	5	1	3	f	f
66	2	5	1	5	f	f
67	2	5	5	3	f	f
68	2	5	5	5	f	f
69	2	5	6	3	f	f
70	2	5	6	5	f	f
71	2	5	7	3	f	f
72	2	5	7	5	f	f
73	2	5	13	3	f	f
74	2	5	13	5	f	f
75	2	5	14	3	f	f
76	2	5	14	5	f	f
77	2	5	12	3	f	f
78	2	5	12	5	f	f
79	2	6	1	3	f	f
80	2	6	1	5	f	f
81	2	6	5	3	f	f
82	2	6	5	5	f	f
83	2	6	6	3	f	f
84	2	6	6	5	f	f
85	2	6	7	3	f	f
86	2	6	7	5	f	f
87	2	6	13	3	f	f
88	2	6	13	5	f	f
89	2	6	14	3	f	f
90	2	6	14	5	f	f
91	2	6	12	3	f	f
92	2	6	12	5	f	f
93	2	7	1	3	f	f
94	2	7	1	5	f	f
95	2	7	5	3	f	f
96	2	7	5	5	f	f
97	2	7	6	3	f	f
98	2	7	6	5	f	f
99	2	7	7	3	f	f
100	2	7	7	5	f	f
101	2	7	13	3	f	f
102	2	7	13	5	f	f
103	2	7	14	3	f	f
104	2	7	14	5	f	f
105	2	7	12	3	f	f
106	2	7	12	5	f	f
107	2	13	1	3	f	f
108	2	13	1	5	f	f
109	2	13	5	3	f	f
110	2	13	5	5	f	f
111	2	13	6	3	f	f
112	2	13	6	5	f	f
113	2	13	7	3	f	f
114	2	13	7	5	f	f
115	2	13	13	3	f	f
116	2	13	13	5	f	f
117	2	13	14	3	f	f
118	2	13	14	5	f	f
119	2	13	12	3	f	f
120	2	13	12	5	f	f
121	2	14	1	3	f	f
122	2	14	1	5	f	f
123	2	14	5	3	f	f
124	2	14	5	5	f	f
125	2	14	6	3	f	f
126	2	14	6	5	f	f
127	2	14	7	3	f	f
128	2	14	7	5	f	f
129	2	14	13	3	f	f
130	2	14	13	5	f	f
131	2	14	14	3	f	f
132	2	14	14	5	f	f
133	2	14	12	3	f	f
134	2	14	12	5	f	f
135	2	12	1	3	f	f
136	2	12	1	5	f	f
137	2	12	5	3	f	f
138	2	12	5	5	f	f
139	2	12	6	3	f	f
140	2	12	6	5	f	f
141	2	12	7	3	f	f
142	2	12	7	5	f	f
143	2	12	13	3	f	f
144	2	12	13	5	f	f
145	2	12	14	3	f	f
146	2	12	14	5	f	f
147	2	12	12	3	f	f
148	2	12	12	5	f	f
149	3	1	1	3	f	f
150	3	1	1	5	f	f
151	3	1	5	3	f	f
152	3	1	5	5	f	f
153	3	1	6	3	f	f
154	3	1	6	5	f	f
155	3	1	7	3	f	f
156	3	1	7	5	f	f
157	3	1	13	3	f	f
158	3	1	13	5	f	f
159	3	1	14	3	f	f
160	3	1	14	5	f	f
161	3	1	12	3	f	f
162	3	1	12	5	f	f
163	3	5	1	3	f	f
164	3	5	1	5	f	f
165	3	5	5	3	f	f
166	3	5	5	5	f	f
167	3	5	6	3	f	f
168	3	5	6	5	f	f
169	3	5	7	3	f	f
170	3	5	7	5	f	f
171	3	5	13	3	f	f
172	3	5	13	5	f	f
173	3	5	14	3	f	f
174	3	5	14	5	f	f
175	3	5	12	3	f	f
176	3	5	12	5	f	f
177	3	6	1	3	f	f
178	3	6	1	5	f	f
179	3	6	5	3	f	f
180	3	6	5	5	f	f
181	3	6	6	3	f	f
182	3	6	6	5	f	f
183	3	6	7	3	f	f
184	3	6	7	5	f	f
185	3	6	13	3	f	f
186	3	6	13	5	f	f
187	3	6	14	3	f	f
188	3	6	14	5	f	f
189	3	6	12	3	f	f
190	3	6	12	5	f	f
191	3	7	1	3	f	f
192	3	7	1	5	f	f
193	3	7	5	3	f	f
194	3	7	5	5	f	f
195	3	7	6	3	f	f
196	3	7	6	5	f	f
197	3	7	7	3	f	f
198	3	7	7	5	f	f
199	3	7	13	3	f	f
200	3	7	13	5	f	f
201	3	7	14	3	f	f
202	3	7	14	5	f	f
203	3	7	12	3	f	f
204	3	7	12	5	f	f
205	3	13	1	3	f	f
206	3	13	1	5	f	f
207	3	13	5	3	f	f
208	3	13	5	5	f	f
209	3	13	6	3	f	f
210	3	13	6	5	f	f
211	3	13	7	3	f	f
212	3	13	7	5	f	f
213	3	13	13	3	f	f
214	3	13	13	5	f	f
215	3	13	14	3	f	f
216	3	13	14	5	f	f
217	3	13	12	3	f	f
218	3	13	12	5	f	f
219	3	14	1	3	f	f
220	3	14	1	5	f	f
221	3	14	5	3	f	f
222	3	14	5	5	f	f
223	3	14	6	3	f	f
224	3	14	6	5	f	f
225	3	14	7	3	f	f
226	3	14	7	5	f	f
227	3	14	13	3	f	f
228	3	14	13	5	f	f
229	3	14	14	3	f	f
230	3	14	14	5	f	f
231	3	14	12	3	f	f
232	3	14	12	5	f	f
233	3	12	1	3	f	f
234	3	12	1	5	f	f
235	3	12	5	3	f	f
236	3	12	5	5	f	f
237	3	12	6	3	f	f
238	3	12	6	5	f	f
239	3	12	7	3	f	f
240	3	12	7	5	f	f
241	3	12	13	3	f	f
242	3	12	13	5	f	f
243	3	12	14	3	f	f
244	3	12	14	5	f	f
245	3	12	12	3	f	f
246	3	12	12	5	f	f
247	4	1	1	3	f	f
248	4	1	1	5	f	f
249	4	1	2	3	f	f
250	4	1	2	5	f	f
251	4	1	3	3	f	f
252	4	1	3	5	f	f
253	4	1	7	3	f	f
254	4	1	7	5	f	f
255	4	1	8	3	f	f
256	4	1	8	5	f	f
257	4	1	9	3	f	f
258	4	1	9	5	f	f
259	4	1	10	3	f	f
260	4	1	10	5	f	f
261	4	1	11	3	f	f
262	4	1	11	5	f	f
263	4	1	13	3	f	f
264	4	1	13	5	f	f
265	4	1	14	3	f	f
266	4	1	14	5	f	f
267	4	1	12	3	f	f
268	4	1	12	5	f	f
269	4	2	1	3	f	f
270	4	2	1	5	f	f
271	4	2	2	3	f	f
272	4	2	2	5	f	f
273	4	2	3	3	f	f
274	4	2	3	5	f	f
275	4	2	7	3	f	f
276	4	2	7	5	f	f
277	4	2	8	3	f	f
278	4	2	8	5	f	f
279	4	2	9	3	f	f
280	4	2	9	5	f	f
281	4	2	10	3	f	f
282	4	2	10	5	f	f
283	4	2	11	3	f	f
284	4	2	11	5	f	f
285	4	2	13	3	f	f
286	4	2	13	5	f	f
287	4	2	14	3	f	f
288	4	2	14	5	f	f
289	4	2	12	3	f	f
290	4	2	12	5	f	f
291	4	3	1	3	f	f
292	4	3	1	5	f	f
293	4	3	2	3	f	f
294	4	3	2	5	f	f
295	4	3	3	3	f	f
296	4	3	3	5	f	f
297	4	3	7	3	f	f
298	4	3	7	5	f	f
299	4	3	8	3	f	f
300	4	3	8	5	f	f
301	4	3	9	3	f	f
302	4	3	9	5	f	f
303	4	3	10	3	f	f
304	4	3	10	5	f	f
305	4	3	11	3	f	f
306	4	3	11	5	f	f
307	4	3	13	3	f	f
308	4	3	13	5	f	f
309	4	3	14	3	f	f
310	4	3	14	5	f	f
311	4	3	12	3	f	f
312	4	3	12	5	f	f
313	4	7	1	3	f	f
314	4	7	1	5	f	f
315	4	7	2	3	f	f
316	4	7	2	5	f	f
317	4	7	3	3	f	f
318	4	7	3	5	f	f
319	4	7	7	3	f	f
320	4	7	7	5	f	f
321	4	7	8	3	f	f
322	4	7	8	5	f	f
323	4	7	9	3	f	f
324	4	7	9	5	f	f
325	4	7	10	3	f	f
326	4	7	10	5	f	f
327	4	7	11	3	f	f
328	4	7	11	5	f	f
329	4	7	13	3	f	f
330	4	7	13	5	f	f
331	4	7	14	3	f	f
332	4	7	14	5	f	f
333	4	7	12	3	f	f
334	4	7	12	5	f	f
335	4	8	1	3	f	f
336	4	8	1	5	f	f
337	4	8	2	3	f	f
338	4	8	2	5	f	f
339	4	8	3	3	f	f
340	4	8	3	5	f	f
341	4	8	7	3	f	f
342	4	8	7	5	f	f
343	4	8	8	3	f	f
344	4	8	8	5	f	f
345	4	8	9	3	f	f
346	4	8	9	5	f	f
347	4	8	10	3	f	f
348	4	8	10	5	f	f
349	4	8	11	3	f	f
350	4	8	11	5	f	f
351	4	8	13	3	f	f
352	4	8	13	5	f	f
353	4	8	14	3	f	f
354	4	8	14	5	f	f
355	4	8	12	3	f	f
356	4	8	12	5	f	f
357	4	9	1	3	f	f
358	4	9	1	5	f	f
359	4	9	2	3	f	f
360	4	9	2	5	f	f
361	4	9	3	3	f	f
362	4	9	3	5	f	f
363	4	9	7	3	f	f
364	4	9	7	5	f	f
365	4	9	8	3	f	f
366	4	9	8	5	f	f
367	4	9	9	3	f	f
368	4	9	9	5	f	f
369	4	9	10	3	f	f
370	4	9	10	5	f	f
371	4	9	11	3	f	f
372	4	9	11	5	f	f
373	4	9	13	3	f	f
374	4	9	13	5	f	f
375	4	9	14	3	f	f
376	4	9	14	5	f	f
377	4	9	12	3	f	f
378	4	9	12	5	f	f
379	4	10	1	3	f	f
380	4	10	1	5	f	f
381	4	10	2	3	f	f
382	4	10	2	5	f	f
383	4	10	3	3	f	f
384	4	10	3	5	f	f
385	4	10	7	3	f	f
386	4	10	7	5	f	f
387	4	10	8	3	f	f
388	4	10	8	5	f	f
389	4	10	9	3	f	f
390	4	10	9	5	f	f
391	4	10	10	3	f	f
392	4	10	10	5	f	f
393	4	10	11	3	f	f
394	4	10	11	5	f	f
395	4	10	13	3	f	f
396	4	10	13	5	f	f
397	4	10	14	3	f	f
398	4	10	14	5	f	f
399	4	10	12	3	f	f
400	4	10	12	5	f	f
401	4	11	1	3	f	f
402	4	11	1	5	f	f
403	4	11	2	3	f	f
404	4	11	2	5	f	f
405	4	11	3	3	f	f
406	4	11	3	5	f	f
407	4	11	7	3	f	f
408	4	11	7	5	f	f
409	4	11	8	3	f	f
410	4	11	8	5	f	f
411	4	11	9	3	f	f
412	4	11	9	5	f	f
413	4	11	10	3	f	f
414	4	11	10	5	f	f
415	4	11	11	3	f	f
416	4	11	11	5	f	f
417	4	11	13	3	f	f
418	4	11	13	5	f	f
419	4	11	14	3	f	f
420	4	11	14	5	f	f
421	4	11	12	3	f	f
422	4	11	12	5	f	f
423	4	13	1	3	f	f
424	4	13	1	5	f	f
425	4	13	2	3	f	f
426	4	13	2	5	f	f
427	4	13	3	3	f	f
428	4	13	3	5	f	f
429	4	13	7	3	f	f
430	4	13	7	5	f	f
431	4	13	8	3	f	f
432	4	13	8	5	f	f
433	4	13	9	3	f	f
434	4	13	9	5	f	f
435	4	13	10	3	f	f
436	4	13	10	5	f	f
437	4	13	11	3	f	f
438	4	13	11	5	f	f
439	4	13	13	3	f	f
440	4	13	13	5	f	f
441	4	13	14	3	f	f
442	4	13	14	5	f	f
443	4	13	12	3	f	f
444	4	13	12	5	f	f
445	4	14	1	3	f	f
446	4	14	1	5	f	f
447	4	14	2	3	f	f
448	4	14	2	5	f	f
449	4	14	3	3	f	f
450	4	14	3	5	f	f
451	4	14	7	3	f	f
452	4	14	7	5	f	f
453	4	14	8	3	f	f
454	4	14	8	5	f	f
455	4	14	9	3	f	f
456	4	14	9	5	f	f
457	4	14	10	3	f	f
458	4	14	10	5	f	f
459	4	14	11	3	f	f
460	4	14	11	5	f	f
461	4	14	13	3	f	f
462	4	14	13	5	f	f
463	4	14	14	3	f	f
464	4	14	14	5	f	f
465	4	14	12	3	f	f
466	4	14	12	5	f	f
467	4	12	1	3	f	f
468	4	12	1	5	f	f
469	4	12	2	3	f	f
470	4	12	2	5	f	f
471	4	12	3	3	f	f
472	4	12	3	5	f	f
473	4	12	7	3	f	f
474	4	12	7	5	f	f
475	4	12	8	3	f	f
476	4	12	8	5	f	f
477	4	12	9	3	f	f
478	4	12	9	5	f	f
479	4	12	10	3	f	f
480	4	12	10	5	f	f
481	4	12	11	3	f	f
482	4	12	11	5	f	f
483	4	12	13	3	f	f
484	4	12	13	5	f	f
485	4	12	14	3	f	f
486	4	12	14	5	f	f
487	4	12	12	3	f	f
488	4	12	12	5	f	f
489	5	1	1	3	f	f
490	5	1	1	5	f	f
491	5	1	2	3	f	f
492	5	1	2	5	f	f
493	5	1	3	3	f	f
494	5	1	3	5	f	f
495	5	1	7	3	f	f
496	5	1	7	5	f	f
497	5	1	8	3	f	f
498	5	1	8	5	f	f
499	5	1	9	3	f	f
500	5	1	9	5	f	f
501	5	1	10	3	f	f
502	5	1	10	5	f	f
503	5	1	11	3	f	f
504	5	1	11	5	f	f
505	5	1	13	3	f	f
506	5	1	13	5	f	f
507	5	1	14	3	f	f
508	5	1	14	5	f	f
509	5	1	12	3	f	f
510	5	1	12	5	f	f
511	5	2	1	3	f	f
512	5	2	1	5	f	f
513	5	2	2	3	f	f
514	5	2	2	5	f	f
515	5	2	3	3	f	f
516	5	2	3	5	f	f
517	5	2	7	3	f	f
518	5	2	7	5	f	f
519	5	2	8	3	f	f
520	5	2	8	5	f	f
521	5	2	9	3	f	f
522	5	2	9	5	f	f
523	5	2	10	3	f	f
524	5	2	10	5	f	f
525	5	2	11	3	f	f
526	5	2	11	5	f	f
527	5	2	13	3	f	f
528	5	2	13	5	f	f
529	5	2	14	3	f	f
530	5	2	14	5	f	f
531	5	2	12	3	f	f
532	5	2	12	5	f	f
533	5	3	1	3	f	f
534	5	3	1	5	f	f
535	5	3	2	3	f	f
536	5	3	2	5	f	f
537	5	3	3	3	f	f
538	5	3	3	5	f	f
539	5	3	7	3	f	f
540	5	3	7	5	f	f
541	5	3	8	3	f	f
542	5	3	8	5	f	f
543	5	3	9	3	f	f
544	5	3	9	5	f	f
545	5	3	10	3	f	f
546	5	3	10	5	f	f
547	5	3	11	3	f	f
548	5	3	11	5	f	f
549	5	3	13	3	f	f
550	5	3	13	5	f	f
551	5	3	14	3	f	f
552	5	3	14	5	f	f
553	5	3	12	3	f	f
554	5	3	12	5	f	f
555	5	7	1	3	f	f
556	5	7	1	5	f	f
557	5	7	2	3	f	f
558	5	7	2	5	f	f
559	5	7	3	3	f	f
560	5	7	3	5	f	f
561	5	7	7	3	f	f
562	5	7	7	5	f	f
563	5	7	8	3	f	f
564	5	7	8	5	f	f
565	5	7	9	3	f	f
566	5	7	9	5	f	f
567	5	7	10	3	f	f
568	5	7	10	5	f	f
569	5	7	11	3	f	f
570	5	7	11	5	f	f
571	5	7	13	3	f	f
572	5	7	13	5	f	f
573	5	7	14	3	f	f
574	5	7	14	5	f	f
575	5	7	12	3	f	f
576	5	7	12	5	f	f
577	5	8	1	3	f	f
578	5	8	1	5	f	f
579	5	8	2	3	f	f
580	5	8	2	5	f	f
581	5	8	3	3	f	f
582	5	8	3	5	f	f
583	5	8	7	3	f	f
584	5	8	7	5	f	f
585	5	8	8	3	f	f
586	5	8	8	5	f	f
587	5	8	9	3	f	f
588	5	8	9	5	f	f
589	5	8	10	3	f	f
590	5	8	10	5	f	f
591	5	8	11	3	f	f
592	5	8	11	5	f	f
593	5	8	13	3	f	f
594	5	8	13	5	f	f
595	5	8	14	3	f	f
596	5	8	14	5	f	f
597	5	8	12	3	f	f
598	5	8	12	5	f	f
599	5	9	1	3	f	f
600	5	9	1	5	f	f
601	5	9	2	3	f	f
602	5	9	2	5	f	f
603	5	9	3	3	f	f
604	5	9	3	5	f	f
605	5	9	7	3	f	f
606	5	9	7	5	f	f
607	5	9	8	3	f	f
608	5	9	8	5	f	f
609	5	9	9	3	f	f
610	5	9	9	5	f	f
611	5	9	10	3	f	f
612	5	9	10	5	f	f
613	5	9	11	3	f	f
614	5	9	11	5	f	f
615	5	9	13	3	f	f
616	5	9	13	5	f	f
617	5	9	14	3	f	f
618	5	9	14	5	f	f
619	5	9	12	3	f	f
620	5	9	12	5	f	f
621	5	10	1	3	f	f
622	5	10	1	5	f	f
623	5	10	2	3	f	f
624	5	10	2	5	f	f
625	5	10	3	3	f	f
626	5	10	3	5	f	f
627	5	10	7	3	f	f
628	5	10	7	5	f	f
629	5	10	8	3	f	f
630	5	10	8	5	f	f
631	5	10	9	3	f	f
632	5	10	9	5	f	f
633	5	10	10	3	f	f
634	5	10	10	5	f	f
635	5	10	11	3	f	f
636	5	10	11	5	f	f
637	5	10	13	3	f	f
638	5	10	13	5	f	f
639	5	10	14	3	f	f
640	5	10	14	5	f	f
641	5	10	12	3	f	f
642	5	10	12	5	f	f
643	5	11	1	3	f	f
644	5	11	1	5	f	f
645	5	11	2	3	f	f
646	5	11	2	5	f	f
647	5	11	3	3	f	f
648	5	11	3	5	f	f
649	5	11	7	3	f	f
650	5	11	7	5	f	f
651	5	11	8	3	f	f
652	5	11	8	5	f	f
653	5	11	9	3	f	f
654	5	11	9	5	f	f
655	5	11	10	3	f	f
656	5	11	10	5	f	f
657	5	11	11	3	f	f
658	5	11	11	5	f	f
659	5	11	13	3	f	f
660	5	11	13	5	f	f
661	5	11	14	3	f	f
662	5	11	14	5	f	f
663	5	11	12	3	f	f
664	5	11	12	5	f	f
665	5	13	1	3	f	f
666	5	13	1	5	f	f
667	5	13	2	3	f	f
668	5	13	2	5	f	f
669	5	13	3	3	f	f
670	5	13	3	5	f	f
671	5	13	7	3	f	f
672	5	13	7	5	f	f
673	5	13	8	3	f	f
674	5	13	8	5	f	f
675	5	13	9	3	f	f
676	5	13	9	5	f	f
677	5	13	10	3	f	f
678	5	13	10	5	f	f
679	5	13	11	3	f	f
680	5	13	11	5	f	f
681	5	13	13	3	f	f
682	5	13	13	5	f	f
683	5	13	14	3	f	f
684	5	13	14	5	f	f
685	5	13	12	3	f	f
686	5	13	12	5	f	f
687	5	14	1	3	f	f
688	5	14	1	5	f	f
689	5	14	2	3	f	f
690	5	14	2	5	f	f
691	5	14	3	3	f	f
692	5	14	3	5	f	f
693	5	14	7	3	f	f
694	5	14	7	5	f	f
695	5	14	8	3	f	f
696	5	14	8	5	f	f
697	5	14	9	3	f	f
698	5	14	9	5	f	f
699	5	14	10	3	f	f
700	5	14	10	5	f	f
701	5	14	11	3	f	f
702	5	14	11	5	f	f
703	5	14	13	3	f	f
704	5	14	13	5	f	f
705	5	14	14	3	f	f
706	5	14	14	5	f	f
707	5	14	12	3	f	f
708	5	14	12	5	f	f
709	5	12	1	3	f	f
710	5	12	1	5	f	f
711	5	12	2	3	f	f
712	5	12	2	5	f	f
713	5	12	3	3	f	f
714	5	12	3	5	f	f
715	5	12	7	3	f	f
716	5	12	7	5	f	f
717	5	12	8	3	f	f
718	5	12	8	5	f	f
719	5	12	9	3	f	f
720	5	12	9	5	f	f
721	5	12	10	3	f	f
722	5	12	10	5	f	f
723	5	12	11	3	f	f
724	5	12	11	5	f	f
725	5	12	13	3	f	f
726	5	12	13	5	f	f
727	5	12	14	3	f	f
728	5	12	14	5	f	f
729	5	12	12	3	f	f
730	5	12	12	5	f	f
731	6	1	1	3	f	f
732	6	1	1	5	f	f
733	6	1	2	3	f	f
734	6	1	2	5	f	f
735	6	1	3	3	f	f
736	6	1	3	5	f	f
737	6	1	7	3	f	f
738	6	1	7	5	f	f
739	6	1	8	3	f	f
740	6	1	8	5	f	f
741	6	1	9	3	f	f
742	6	1	9	5	f	f
743	6	1	10	3	f	f
744	6	1	10	5	f	f
745	6	1	11	3	f	f
746	6	1	11	5	f	f
747	6	1	13	3	f	f
748	6	1	13	5	f	f
749	6	1	14	3	f	f
750	6	1	14	5	f	f
751	6	1	12	3	f	f
752	6	1	12	5	f	f
753	6	2	1	3	f	f
754	6	2	1	5	f	f
755	6	2	2	3	f	f
756	6	2	2	5	f	f
757	6	2	3	3	f	f
758	6	2	3	5	f	f
759	6	2	7	3	f	f
760	6	2	7	5	f	f
761	6	2	8	3	f	f
762	6	2	8	5	f	f
763	6	2	9	3	f	f
764	6	2	9	5	f	f
765	6	2	10	3	f	f
766	6	2	10	5	f	f
767	6	2	11	3	f	f
768	6	2	11	5	f	f
769	6	2	13	3	f	f
770	6	2	13	5	f	f
771	6	2	14	3	f	f
772	6	2	14	5	f	f
773	6	2	12	3	f	f
774	6	2	12	5	f	f
775	6	3	1	3	f	f
776	6	3	1	5	f	f
777	6	3	2	3	f	f
778	6	3	2	5	f	f
779	6	3	3	3	f	f
780	6	3	3	5	f	f
781	6	3	7	3	f	f
782	6	3	7	5	f	f
783	6	3	8	3	f	f
784	6	3	8	5	f	f
785	6	3	9	3	f	f
786	6	3	9	5	f	f
787	6	3	10	3	f	f
788	6	3	10	5	f	f
789	6	3	11	3	f	f
790	6	3	11	5	f	f
791	6	3	13	3	f	f
792	6	3	13	5	f	f
793	6	3	14	3	f	f
794	6	3	14	5	f	f
795	6	3	12	3	f	f
796	6	3	12	5	f	f
797	6	7	1	3	f	f
798	6	7	1	5	f	f
799	6	7	2	3	f	f
800	6	7	2	5	f	f
801	6	7	3	3	f	f
802	6	7	3	5	f	f
803	6	7	7	3	f	f
804	6	7	7	5	f	f
805	6	7	8	3	f	f
806	6	7	8	5	f	f
807	6	7	9	3	f	f
808	6	7	9	5	f	f
809	6	7	10	3	f	f
810	6	7	10	5	f	f
811	6	7	11	3	f	f
812	6	7	11	5	f	f
813	6	7	13	3	f	f
814	6	7	13	5	f	f
815	6	7	14	3	f	f
816	6	7	14	5	f	f
817	6	7	12	3	f	f
818	6	7	12	5	f	f
819	6	8	1	3	f	f
820	6	8	1	5	f	f
821	6	8	2	3	f	f
822	6	8	2	5	f	f
823	6	8	3	3	f	f
824	6	8	3	5	f	f
825	6	8	7	3	f	f
826	6	8	7	5	f	f
827	6	8	8	3	f	f
828	6	8	8	5	f	f
829	6	8	9	3	f	f
830	6	8	9	5	f	f
831	6	8	10	3	f	f
832	6	8	10	5	f	f
833	6	8	11	3	f	f
834	6	8	11	5	f	f
835	6	8	13	3	f	f
836	6	8	13	5	f	f
837	6	8	14	3	f	f
838	6	8	14	5	f	f
839	6	8	12	3	f	f
840	6	8	12	5	f	f
841	6	9	1	3	f	f
842	6	9	1	5	f	f
843	6	9	2	3	f	f
844	6	9	2	5	f	f
845	6	9	3	3	f	f
846	6	9	3	5	f	f
847	6	9	7	3	f	f
848	6	9	7	5	f	f
849	6	9	8	3	f	f
850	6	9	8	5	f	f
851	6	9	9	3	f	f
852	6	9	9	5	f	f
853	6	9	10	3	f	f
854	6	9	10	5	f	f
855	6	9	11	3	f	f
856	6	9	11	5	f	f
857	6	9	13	3	f	f
858	6	9	13	5	f	f
859	6	9	14	3	f	f
860	6	9	14	5	f	f
861	6	9	12	3	f	f
862	6	9	12	5	f	f
863	6	10	1	3	f	f
864	6	10	1	5	f	f
865	6	10	2	3	f	f
866	6	10	2	5	f	f
867	6	10	3	3	f	f
868	6	10	3	5	f	f
869	6	10	7	3	f	f
870	6	10	7	5	f	f
871	6	10	8	3	f	f
872	6	10	8	5	f	f
873	6	10	9	3	f	f
874	6	10	9	5	f	f
875	6	10	10	3	f	f
876	6	10	10	5	f	f
877	6	10	11	3	f	f
878	6	10	11	5	f	f
879	6	10	13	3	f	f
880	6	10	13	5	f	f
881	6	10	14	3	f	f
882	6	10	14	5	f	f
883	6	10	12	3	f	f
884	6	10	12	5	f	f
885	6	11	1	3	f	f
886	6	11	1	5	f	f
887	6	11	2	3	f	f
888	6	11	2	5	f	f
889	6	11	3	3	f	f
890	6	11	3	5	f	f
891	6	11	7	3	f	f
892	6	11	7	5	f	f
893	6	11	8	3	f	f
894	6	11	8	5	f	f
895	6	11	9	3	f	f
896	6	11	9	5	f	f
897	6	11	10	3	f	f
898	6	11	10	5	f	f
899	6	11	11	3	f	f
900	6	11	11	5	f	f
901	6	11	13	3	f	f
902	6	11	13	5	f	f
903	6	11	14	3	f	f
904	6	11	14	5	f	f
905	6	11	12	3	f	f
906	6	11	12	5	f	f
907	6	13	1	3	f	f
908	6	13	1	5	f	f
909	6	13	2	3	f	f
910	6	13	2	5	f	f
911	6	13	3	3	f	f
912	6	13	3	5	f	f
913	6	13	7	3	f	f
914	6	13	7	5	f	f
915	6	13	8	3	f	f
916	6	13	8	5	f	f
917	6	13	9	3	f	f
918	6	13	9	5	f	f
919	6	13	10	3	f	f
920	6	13	10	5	f	f
921	6	13	11	3	f	f
922	6	13	11	5	f	f
923	6	13	13	3	f	f
924	6	13	13	5	f	f
925	6	13	14	3	f	f
926	6	13	14	5	f	f
927	6	13	12	3	f	f
928	6	13	12	5	f	f
929	6	14	1	3	f	f
930	6	14	1	5	f	f
931	6	14	2	3	f	f
932	6	14	2	5	f	f
933	6	14	3	3	f	f
934	6	14	3	5	f	f
935	6	14	7	3	f	f
936	6	14	7	5	f	f
937	6	14	8	3	f	f
938	6	14	8	5	f	f
939	6	14	9	3	f	f
940	6	14	9	5	f	f
941	6	14	10	3	f	f
942	6	14	10	5	f	f
943	6	14	11	3	f	f
944	6	14	11	5	f	f
945	6	14	13	3	f	f
946	6	14	13	5	f	f
947	6	14	14	3	f	f
948	6	14	14	5	f	f
949	6	14	12	3	f	f
950	6	14	12	5	f	f
951	6	12	1	3	f	f
952	6	12	1	5	f	f
953	6	12	2	3	f	f
954	6	12	2	5	f	f
955	6	12	3	3	f	f
956	6	12	3	5	f	f
957	6	12	7	3	f	f
958	6	12	7	5	f	f
959	6	12	8	3	f	f
960	6	12	8	5	f	f
961	6	12	9	3	f	f
962	6	12	9	5	f	f
963	6	12	10	3	f	f
964	6	12	10	5	f	f
965	6	12	11	3	f	f
966	6	12	11	5	f	f
967	6	12	13	3	f	f
968	6	12	13	5	f	f
969	6	12	14	3	f	f
970	6	12	14	5	f	f
971	6	12	12	3	f	f
972	6	12	12	5	f	f
973	7	1	1	3	f	f
974	7	1	1	5	f	f
975	7	1	4	3	f	f
976	7	1	4	5	f	f
977	7	1	7	3	f	f
978	7	1	7	5	f	f
979	7	1	8	3	f	f
980	7	1	8	5	f	f
981	7	1	9	3	f	f
982	7	1	9	5	f	f
983	7	1	10	3	f	f
984	7	1	10	5	f	f
985	7	1	11	3	f	f
986	7	1	11	5	f	f
987	7	1	13	3	f	f
988	7	1	13	5	f	f
989	7	1	14	3	f	f
990	7	1	14	5	f	f
991	7	1	12	3	f	f
992	7	1	12	5	f	f
993	7	4	1	3	f	f
994	7	4	1	5	f	f
995	7	4	4	3	f	f
996	7	4	4	5	f	f
997	7	4	7	3	f	f
998	7	4	7	5	f	f
999	7	4	8	3	f	f
1000	7	4	8	5	f	f
1001	7	4	9	3	f	f
1002	7	4	9	5	f	f
1003	7	4	10	3	f	f
1004	7	4	10	5	f	f
1005	7	4	11	3	f	f
1006	7	4	11	5	f	f
1007	7	4	13	3	f	f
1008	7	4	13	5	f	f
1009	7	4	14	3	f	f
1010	7	4	14	5	f	f
1011	7	4	12	3	f	f
1012	7	4	12	5	f	f
1013	7	7	1	3	f	f
1014	7	7	1	5	f	f
1015	7	7	4	3	f	f
1016	7	7	4	5	f	f
1017	7	7	7	3	f	f
1018	7	7	7	5	f	f
1019	7	7	8	3	f	f
1020	7	7	8	5	f	f
1021	7	7	9	3	f	f
1022	7	7	9	5	f	f
1023	7	7	10	3	f	f
1024	7	7	10	5	f	f
1025	7	7	11	3	f	f
1026	7	7	11	5	f	f
1027	7	7	13	3	f	f
1028	7	7	13	5	f	f
1029	7	7	14	3	f	f
1030	7	7	14	5	f	f
1031	7	7	12	3	f	f
1032	7	7	12	5	f	f
1033	7	8	1	3	f	f
1034	7	8	1	5	f	f
1035	7	8	4	3	f	f
1036	7	8	4	5	f	f
1037	7	8	7	3	f	f
1038	7	8	7	5	f	f
1039	7	8	8	3	f	f
1040	7	8	8	5	f	f
1041	7	8	9	3	f	f
1042	7	8	9	5	f	f
1043	7	8	10	3	f	f
1044	7	8	10	5	f	f
1045	7	8	11	3	f	f
1046	7	8	11	5	f	f
1047	7	8	13	3	f	f
1048	7	8	13	5	f	f
1049	7	8	14	3	f	f
1050	7	8	14	5	f	f
1051	7	8	12	3	f	f
1052	7	8	12	5	f	f
1053	7	9	1	3	f	f
1054	7	9	1	5	f	f
1055	7	9	4	3	f	f
1056	7	9	4	5	f	f
1057	7	9	7	3	f	f
1058	7	9	7	5	f	f
1059	7	9	8	3	f	f
1060	7	9	8	5	f	f
1061	7	9	9	3	f	f
1062	7	9	9	5	f	f
1063	7	9	10	3	f	f
1064	7	9	10	5	f	f
1065	7	9	11	3	f	f
1066	7	9	11	5	f	f
1067	7	9	13	3	f	f
1068	7	9	13	5	f	f
1069	7	9	14	3	f	f
1070	7	9	14	5	f	f
1071	7	9	12	3	f	f
1072	7	9	12	5	f	f
1073	7	10	1	3	f	f
1074	7	10	1	5	f	f
1075	7	10	4	3	f	f
1076	7	10	4	5	f	f
1077	7	10	7	3	f	f
1078	7	10	7	5	f	f
1079	7	10	8	3	f	f
1080	7	10	8	5	f	f
1081	7	10	9	3	f	f
1082	7	10	9	5	f	f
1083	7	10	10	3	f	f
1084	7	10	10	5	f	f
1085	7	10	11	3	f	f
1086	7	10	11	5	f	f
1087	7	10	13	3	f	f
1088	7	10	13	5	f	f
1089	7	10	14	3	f	f
1090	7	10	14	5	f	f
1091	7	10	12	3	f	f
1092	7	10	12	5	f	f
1093	7	11	1	3	f	f
1094	7	11	1	5	f	f
1095	7	11	4	3	f	f
1096	7	11	4	5	f	f
1097	7	11	7	3	f	f
1098	7	11	7	5	f	f
1099	7	11	8	3	f	f
1100	7	11	8	5	f	f
1101	7	11	9	3	f	f
1102	7	11	9	5	f	f
1103	7	11	10	3	f	f
1104	7	11	10	5	f	f
1105	7	11	11	3	f	f
1106	7	11	11	5	f	f
1107	7	11	13	3	f	f
1108	7	11	13	5	f	f
1109	7	11	14	3	f	f
1110	7	11	14	5	f	f
1111	7	11	12	3	f	f
1112	7	11	12	5	f	f
1113	7	13	1	3	f	f
1114	7	13	1	5	f	f
1115	7	13	4	3	f	f
1116	7	13	4	5	f	f
1117	7	13	7	3	f	f
1118	7	13	7	5	f	f
1119	7	13	8	3	f	f
1120	7	13	8	5	f	f
1121	7	13	9	3	f	f
1122	7	13	9	5	f	f
1123	7	13	10	3	f	f
1124	7	13	10	5	f	f
1125	7	13	11	3	f	f
1126	7	13	11	5	f	f
1127	7	13	13	3	f	f
1128	7	13	13	5	f	f
1129	7	13	14	3	f	f
1130	7	13	14	5	f	f
1131	7	13	12	3	f	f
1132	7	13	12	5	f	f
1133	7	14	1	3	f	f
1134	7	14	1	5	f	f
1135	7	14	4	3	f	f
1136	7	14	4	5	f	f
1137	7	14	7	3	f	f
1138	7	14	7	5	f	f
1139	7	14	8	3	f	f
1140	7	14	8	5	f	f
1141	7	14	9	3	f	f
1142	7	14	9	5	f	f
1143	7	14	10	3	f	f
1144	7	14	10	5	f	f
1145	7	14	11	3	f	f
1146	7	14	11	5	f	f
1147	7	14	13	3	f	f
1148	7	14	13	5	f	f
1149	7	14	14	3	f	f
1150	7	14	14	5	f	f
1151	7	14	12	3	f	f
1152	7	14	12	5	f	f
1153	7	12	1	3	f	f
1154	7	12	1	5	f	f
1155	7	12	4	3	f	f
1156	7	12	4	5	f	f
1157	7	12	7	3	f	f
1158	7	12	7	5	f	f
1159	7	12	8	3	f	f
1160	7	12	8	5	f	f
1161	7	12	9	3	f	f
1162	7	12	9	5	f	f
1163	7	12	10	3	f	f
1164	7	12	10	5	f	f
1165	7	12	11	3	f	f
1166	7	12	11	5	f	f
1167	7	12	13	3	f	f
1168	7	12	13	5	f	f
1169	7	12	14	3	f	f
1170	7	12	14	5	f	f
1171	7	12	12	3	f	f
1172	7	12	12	5	f	f
\.


--
-- Name: announcements_id_seq; Type: SEQUENCE SET; Schema: backup_preview_5; Owner: -
--

SELECT pg_catalog.setval('backup_preview_5.announcements_id_seq', 1, false);


--
-- Name: attachable_journals_id_seq; Type: SEQUENCE SET; Schema: backup_preview_5; Owner: -
--

SELECT pg_catalog.setval('backup_preview_5.attachable_journals_id_seq', 1, true);


--
-- Name: attachment_journals_id_seq; Type: SEQUENCE SET; Schema: backup_preview_5; Owner: -
--

SELECT pg_catalog.setval('backup_preview_5.attachment_journals_id_seq', 5, true);


--
-- Name: attachments_id_seq; Type: SEQUENCE SET; Schema: backup_preview_5; Owner: -
--

SELECT pg_catalog.setval('backup_preview_5.attachments_id_seq', 5, true);


--
-- Name: attribute_help_texts_id_seq; Type: SEQUENCE SET; Schema: backup_preview_5; Owner: -
--

SELECT pg_catalog.setval('backup_preview_5.attribute_help_texts_id_seq', 1, false);


--
-- Name: auth_sources_id_seq; Type: SEQUENCE SET; Schema: backup_preview_5; Owner: -
--

SELECT pg_catalog.setval('backup_preview_5.auth_sources_id_seq', 1, false);


--
-- Name: backups_id_seq; Type: SEQUENCE SET; Schema: backup_preview_5; Owner: -
--

SELECT pg_catalog.setval('backup_preview_5.backups_id_seq', 5, true);


--
-- Name: bcf_comments_id_seq; Type: SEQUENCE SET; Schema: backup_preview_5; Owner: -
--

SELECT pg_catalog.setval('backup_preview_5.bcf_comments_id_seq', 1, false);


--
-- Name: bcf_issues_id_seq; Type: SEQUENCE SET; Schema: backup_preview_5; Owner: -
--

SELECT pg_catalog.setval('backup_preview_5.bcf_issues_id_seq', 1, false);


--
-- Name: bcf_viewpoints_id_seq; Type: SEQUENCE SET; Schema: backup_preview_5; Owner: -
--

SELECT pg_catalog.setval('backup_preview_5.bcf_viewpoints_id_seq', 1, false);


--
-- Name: budget_journals_id_seq; Type: SEQUENCE SET; Schema: backup_preview_5; Owner: -
--

SELECT pg_catalog.setval('backup_preview_5.budget_journals_id_seq', 1, false);


--
-- Name: budgets_id_seq; Type: SEQUENCE SET; Schema: backup_preview_5; Owner: -
--

SELECT pg_catalog.setval('backup_preview_5.budgets_id_seq', 1, false);


--
-- Name: categories_id_seq; Type: SEQUENCE SET; Schema: backup_preview_5; Owner: -
--

SELECT pg_catalog.setval('backup_preview_5.categories_id_seq', 2, true);


--
-- Name: changes_id_seq; Type: SEQUENCE SET; Schema: backup_preview_5; Owner: -
--

SELECT pg_catalog.setval('backup_preview_5.changes_id_seq', 1, false);


--
-- Name: changeset_journals_id_seq; Type: SEQUENCE SET; Schema: backup_preview_5; Owner: -
--

SELECT pg_catalog.setval('backup_preview_5.changeset_journals_id_seq', 1, false);


--
-- Name: changesets_id_seq; Type: SEQUENCE SET; Schema: backup_preview_5; Owner: -
--

SELECT pg_catalog.setval('backup_preview_5.changesets_id_seq', 1, false);


--
-- Name: colors_id_seq; Type: SEQUENCE SET; Schema: backup_preview_5; Owner: -
--

SELECT pg_catalog.setval('backup_preview_5.colors_id_seq', 144, true);


--
-- Name: comments_id_seq; Type: SEQUENCE SET; Schema: backup_preview_5; Owner: -
--

SELECT pg_catalog.setval('backup_preview_5.comments_id_seq', 1, false);


--
-- Name: cost_entries_id_seq; Type: SEQUENCE SET; Schema: backup_preview_5; Owner: -
--

SELECT pg_catalog.setval('backup_preview_5.cost_entries_id_seq', 1, false);


--
-- Name: cost_queries_id_seq; Type: SEQUENCE SET; Schema: backup_preview_5; Owner: -
--

SELECT pg_catalog.setval('backup_preview_5.cost_queries_id_seq', 1, false);


--
-- Name: cost_types_id_seq; Type: SEQUENCE SET; Schema: backup_preview_5; Owner: -
--

SELECT pg_catalog.setval('backup_preview_5.cost_types_id_seq', 1, false);


--
-- Name: custom_actions_id_seq; Type: SEQUENCE SET; Schema: backup_preview_5; Owner: -
--

SELECT pg_catalog.setval('backup_preview_5.custom_actions_id_seq', 1, false);


--
-- Name: custom_actions_projects_id_seq; Type: SEQUENCE SET; Schema: backup_preview_5; Owner: -
--

SELECT pg_catalog.setval('backup_preview_5.custom_actions_projects_id_seq', 1, false);


--
-- Name: custom_actions_roles_id_seq; Type: SEQUENCE SET; Schema: backup_preview_5; Owner: -
--

SELECT pg_catalog.setval('backup_preview_5.custom_actions_roles_id_seq', 1, false);


--
-- Name: custom_actions_statuses_id_seq; Type: SEQUENCE SET; Schema: backup_preview_5; Owner: -
--

SELECT pg_catalog.setval('backup_preview_5.custom_actions_statuses_id_seq', 1, false);


--
-- Name: custom_actions_types_id_seq; Type: SEQUENCE SET; Schema: backup_preview_5; Owner: -
--

SELECT pg_catalog.setval('backup_preview_5.custom_actions_types_id_seq', 1, false);


--
-- Name: custom_fields_id_seq; Type: SEQUENCE SET; Schema: backup_preview_5; Owner: -
--

SELECT pg_catalog.setval('backup_preview_5.custom_fields_id_seq', 11, true);


--
-- Name: custom_options_id_seq; Type: SEQUENCE SET; Schema: backup_preview_5; Owner: -
--

SELECT pg_catalog.setval('backup_preview_5.custom_options_id_seq', 6, true);


--
-- Name: custom_styles_id_seq; Type: SEQUENCE SET; Schema: backup_preview_5; Owner: -
--

SELECT pg_catalog.setval('backup_preview_5.custom_styles_id_seq', 1, true);


--
-- Name: custom_values_id_seq; Type: SEQUENCE SET; Schema: backup_preview_5; Owner: -
--

SELECT pg_catalog.setval('backup_preview_5.custom_values_id_seq', 1, false);


--
-- Name: customizable_journals_id_seq; Type: SEQUENCE SET; Schema: backup_preview_5; Owner: -
--

SELECT pg_catalog.setval('backup_preview_5.customizable_journals_id_seq', 1, false);


--
-- Name: delayed_job_statuses_id_seq; Type: SEQUENCE SET; Schema: backup_preview_5; Owner: -
--

SELECT pg_catalog.setval('backup_preview_5.delayed_job_statuses_id_seq', 13, true);


--
-- Name: delayed_jobs_id_seq; Type: SEQUENCE SET; Schema: backup_preview_5; Owner: -
--

SELECT pg_catalog.setval('backup_preview_5.delayed_jobs_id_seq', 54, true);


--
-- Name: design_colors_id_seq; Type: SEQUENCE SET; Schema: backup_preview_5; Owner: -
--

SELECT pg_catalog.setval('backup_preview_5.design_colors_id_seq', 16, true);


--
-- Name: document_journals_id_seq; Type: SEQUENCE SET; Schema: backup_preview_5; Owner: -
--

SELECT pg_catalog.setval('backup_preview_5.document_journals_id_seq', 1, false);


--
-- Name: documents_id_seq; Type: SEQUENCE SET; Schema: backup_preview_5; Owner: -
--

SELECT pg_catalog.setval('backup_preview_5.documents_id_seq', 1, false);


--
-- Name: enabled_modules_id_seq; Type: SEQUENCE SET; Schema: backup_preview_5; Owner: -
--

SELECT pg_catalog.setval('backup_preview_5.enabled_modules_id_seq', 30, true);


--
-- Name: enterprise_tokens_id_seq; Type: SEQUENCE SET; Schema: backup_preview_5; Owner: -
--

SELECT pg_catalog.setval('backup_preview_5.enterprise_tokens_id_seq', 1, true);


--
-- Name: enumerations_id_seq; Type: SEQUENCE SET; Schema: backup_preview_5; Owner: -
--

SELECT pg_catalog.setval('backup_preview_5.enumerations_id_seq', 13, true);


--
-- Name: export_card_configurations_id_seq; Type: SEQUENCE SET; Schema: backup_preview_5; Owner: -
--

SELECT pg_catalog.setval('backup_preview_5.export_card_configurations_id_seq', 1, false);


--
-- Name: exports_id_seq; Type: SEQUENCE SET; Schema: backup_preview_5; Owner: -
--

SELECT pg_catalog.setval('backup_preview_5.exports_id_seq', 1, true);


--
-- Name: file_links_id_seq; Type: SEQUENCE SET; Schema: backup_preview_5; Owner: -
--

SELECT pg_catalog.setval('backup_preview_5.file_links_id_seq', 1, false);


--
-- Name: forums_id_seq; Type: SEQUENCE SET; Schema: backup_preview_5; Owner: -
--

SELECT pg_catalog.setval('backup_preview_5.forums_id_seq', 1, false);


--
-- Name: github_check_runs_id_seq; Type: SEQUENCE SET; Schema: backup_preview_5; Owner: -
--

SELECT pg_catalog.setval('backup_preview_5.github_check_runs_id_seq', 1, false);


--
-- Name: github_pull_requests_id_seq; Type: SEQUENCE SET; Schema: backup_preview_5; Owner: -
--

SELECT pg_catalog.setval('backup_preview_5.github_pull_requests_id_seq', 1, false);


--
-- Name: github_users_id_seq; Type: SEQUENCE SET; Schema: backup_preview_5; Owner: -
--

SELECT pg_catalog.setval('backup_preview_5.github_users_id_seq', 1, false);


--
-- Name: grid_widgets_id_seq; Type: SEQUENCE SET; Schema: backup_preview_5; Owner: -
--

SELECT pg_catalog.setval('backup_preview_5.grid_widgets_id_seq', 32, true);


--
-- Name: grids_id_seq; Type: SEQUENCE SET; Schema: backup_preview_5; Owner: -
--

SELECT pg_catalog.setval('backup_preview_5.grids_id_seq', 7, true);


--
-- Name: group_users_id_seq; Type: SEQUENCE SET; Schema: backup_preview_5; Owner: -
--

SELECT pg_catalog.setval('backup_preview_5.group_users_id_seq', 1, false);


--
-- Name: ical_token_query_assignments_id_seq; Type: SEQUENCE SET; Schema: backup_preview_5; Owner: -
--

SELECT pg_catalog.setval('backup_preview_5.ical_token_query_assignments_id_seq', 1, false);


--
-- Name: ifc_models_id_seq; Type: SEQUENCE SET; Schema: backup_preview_5; Owner: -
--

SELECT pg_catalog.setval('backup_preview_5.ifc_models_id_seq', 1, false);


--
-- Name: journals_id_seq; Type: SEQUENCE SET; Schema: backup_preview_5; Owner: -
--

SELECT pg_catalog.setval('backup_preview_5.journals_id_seq', 52, true);


--
-- Name: labor_budget_items_id_seq; Type: SEQUENCE SET; Schema: backup_preview_5; Owner: -
--

SELECT pg_catalog.setval('backup_preview_5.labor_budget_items_id_seq', 1, false);


--
-- Name: last_project_folders_id_seq; Type: SEQUENCE SET; Schema: backup_preview_5; Owner: -
--

SELECT pg_catalog.setval('backup_preview_5.last_project_folders_id_seq', 1, false);


--
-- Name: ldap_groups_memberships_id_seq; Type: SEQUENCE SET; Schema: backup_preview_5; Owner: -
--

SELECT pg_catalog.setval('backup_preview_5.ldap_groups_memberships_id_seq', 1, false);


--
-- Name: ldap_groups_synchronized_filters_id_seq; Type: SEQUENCE SET; Schema: backup_preview_5; Owner: -
--

SELECT pg_catalog.setval('backup_preview_5.ldap_groups_synchronized_filters_id_seq', 1, false);


--
-- Name: ldap_groups_synchronized_groups_id_seq; Type: SEQUENCE SET; Schema: backup_preview_5; Owner: -
--

SELECT pg_catalog.setval('backup_preview_5.ldap_groups_synchronized_groups_id_seq', 1, false);


--
-- Name: material_budget_items_id_seq; Type: SEQUENCE SET; Schema: backup_preview_5; Owner: -
--

SELECT pg_catalog.setval('backup_preview_5.material_budget_items_id_seq', 1, false);


--
-- Name: meeting_content_journals_id_seq; Type: SEQUENCE SET; Schema: backup_preview_5; Owner: -
--

SELECT pg_catalog.setval('backup_preview_5.meeting_content_journals_id_seq', 1, false);


--
-- Name: meeting_contents_id_seq; Type: SEQUENCE SET; Schema: backup_preview_5; Owner: -
--

SELECT pg_catalog.setval('backup_preview_5.meeting_contents_id_seq', 1, false);


--
-- Name: meeting_journals_id_seq; Type: SEQUENCE SET; Schema: backup_preview_5; Owner: -
--

SELECT pg_catalog.setval('backup_preview_5.meeting_journals_id_seq', 1, false);


--
-- Name: meeting_participants_id_seq; Type: SEQUENCE SET; Schema: backup_preview_5; Owner: -
--

SELECT pg_catalog.setval('backup_preview_5.meeting_participants_id_seq', 1, false);


--
-- Name: meetings_id_seq; Type: SEQUENCE SET; Schema: backup_preview_5; Owner: -
--

SELECT pg_catalog.setval('backup_preview_5.meetings_id_seq', 1, false);


--
-- Name: member_roles_id_seq; Type: SEQUENCE SET; Schema: backup_preview_5; Owner: -
--

SELECT pg_catalog.setval('backup_preview_5.member_roles_id_seq', 14, true);


--
-- Name: members_id_seq; Type: SEQUENCE SET; Schema: backup_preview_5; Owner: -
--

SELECT pg_catalog.setval('backup_preview_5.members_id_seq', 14, true);


--
-- Name: menu_items_id_seq; Type: SEQUENCE SET; Schema: backup_preview_5; Owner: -
--

SELECT pg_catalog.setval('backup_preview_5.menu_items_id_seq', 2, true);


--
-- Name: message_journals_id_seq; Type: SEQUENCE SET; Schema: backup_preview_5; Owner: -
--

SELECT pg_catalog.setval('backup_preview_5.message_journals_id_seq', 1, false);


--
-- Name: messages_id_seq; Type: SEQUENCE SET; Schema: backup_preview_5; Owner: -
--

SELECT pg_catalog.setval('backup_preview_5.messages_id_seq', 1, false);


--
-- Name: news_id_seq; Type: SEQUENCE SET; Schema: backup_preview_5; Owner: -
--

SELECT pg_catalog.setval('backup_preview_5.news_id_seq', 2, true);


--
-- Name: news_journals_id_seq; Type: SEQUENCE SET; Schema: backup_preview_5; Owner: -
--

SELECT pg_catalog.setval('backup_preview_5.news_journals_id_seq', 2, true);


--
-- Name: non_working_days_id_seq; Type: SEQUENCE SET; Schema: backup_preview_5; Owner: -
--

SELECT pg_catalog.setval('backup_preview_5.non_working_days_id_seq', 1, false);


--
-- Name: notification_settings_id_seq; Type: SEQUENCE SET; Schema: backup_preview_5; Owner: -
--

SELECT pg_catalog.setval('backup_preview_5.notification_settings_id_seq', 5, true);


--
-- Name: notifications_id_seq; Type: SEQUENCE SET; Schema: backup_preview_5; Owner: -
--

SELECT pg_catalog.setval('backup_preview_5.notifications_id_seq', 1, false);


--
-- Name: oauth_access_grants_id_seq; Type: SEQUENCE SET; Schema: backup_preview_5; Owner: -
--

SELECT pg_catalog.setval('backup_preview_5.oauth_access_grants_id_seq', 1, false);


--
-- Name: oauth_access_tokens_id_seq; Type: SEQUENCE SET; Schema: backup_preview_5; Owner: -
--

SELECT pg_catalog.setval('backup_preview_5.oauth_access_tokens_id_seq', 1, false);


--
-- Name: oauth_applications_id_seq; Type: SEQUENCE SET; Schema: backup_preview_5; Owner: -
--

SELECT pg_catalog.setval('backup_preview_5.oauth_applications_id_seq', 1, false);


--
-- Name: oauth_client_tokens_id_seq; Type: SEQUENCE SET; Schema: backup_preview_5; Owner: -
--

SELECT pg_catalog.setval('backup_preview_5.oauth_client_tokens_id_seq', 1, false);


--
-- Name: oauth_clients_id_seq; Type: SEQUENCE SET; Schema: backup_preview_5; Owner: -
--

SELECT pg_catalog.setval('backup_preview_5.oauth_clients_id_seq', 1, false);


--
-- Name: oidc_user_session_links_id_seq; Type: SEQUENCE SET; Schema: backup_preview_5; Owner: -
--

SELECT pg_catalog.setval('backup_preview_5.oidc_user_session_links_id_seq', 1, false);


--
-- Name: ordered_work_packages_id_seq; Type: SEQUENCE SET; Schema: backup_preview_5; Owner: -
--

SELECT pg_catalog.setval('backup_preview_5.ordered_work_packages_id_seq', 10, true);


--
-- Name: paper_trail_audits_id_seq; Type: SEQUENCE SET; Schema: backup_preview_5; Owner: -
--

SELECT pg_catalog.setval('backup_preview_5.paper_trail_audits_id_seq', 1, true);


--
-- Name: project_journals_id_seq; Type: SEQUENCE SET; Schema: backup_preview_5; Owner: -
--

SELECT pg_catalog.setval('backup_preview_5.project_journals_id_seq', 7, true);


--
-- Name: projects_id_seq; Type: SEQUENCE SET; Schema: backup_preview_5; Owner: -
--

SELECT pg_catalog.setval('backup_preview_5.projects_id_seq', 6, true);


--
-- Name: projects_storages_id_seq; Type: SEQUENCE SET; Schema: backup_preview_5; Owner: -
--

SELECT pg_catalog.setval('backup_preview_5.projects_storages_id_seq', 1, false);


--
-- Name: queries_id_seq; Type: SEQUENCE SET; Schema: backup_preview_5; Owner: -
--

SELECT pg_catalog.setval('backup_preview_5.queries_id_seq', 26, true);


--
-- Name: rates_id_seq; Type: SEQUENCE SET; Schema: backup_preview_5; Owner: -
--

SELECT pg_catalog.setval('backup_preview_5.rates_id_seq', 1, false);


--
-- Name: recaptcha_entries_id_seq; Type: SEQUENCE SET; Schema: backup_preview_5; Owner: -
--

SELECT pg_catalog.setval('backup_preview_5.recaptcha_entries_id_seq', 1, false);


--
-- Name: relations_id_seq; Type: SEQUENCE SET; Schema: backup_preview_5; Owner: -
--

SELECT pg_catalog.setval('backup_preview_5.relations_id_seq', 7, true);


--
-- Name: repositories_id_seq; Type: SEQUENCE SET; Schema: backup_preview_5; Owner: -
--

SELECT pg_catalog.setval('backup_preview_5.repositories_id_seq', 1, false);


--
-- Name: role_permissions_id_seq; Type: SEQUENCE SET; Schema: backup_preview_5; Owner: -
--

SELECT pg_catalog.setval('backup_preview_5.role_permissions_id_seq', 232, true);


--
-- Name: roles_id_seq; Type: SEQUENCE SET; Schema: backup_preview_5; Owner: -
--

SELECT pg_catalog.setval('backup_preview_5.roles_id_seq', 6, true);


--
-- Name: sessions_id_seq; Type: SEQUENCE SET; Schema: backup_preview_5; Owner: -
--

SELECT pg_catalog.setval('backup_preview_5.sessions_id_seq', 86, true);


--
-- Name: settings_id_seq; Type: SEQUENCE SET; Schema: backup_preview_5; Owner: -
--

SELECT pg_catalog.setval('backup_preview_5.settings_id_seq', 120, true);


--
-- Name: statuses_id_seq; Type: SEQUENCE SET; Schema: backup_preview_5; Owner: -
--

SELECT pg_catalog.setval('backup_preview_5.statuses_id_seq', 14, true);


--
-- Name: storages_id_seq; Type: SEQUENCE SET; Schema: backup_preview_5; Owner: -
--

SELECT pg_catalog.setval('backup_preview_5.storages_id_seq', 1, false);


--
-- Name: time_entries_id_seq; Type: SEQUENCE SET; Schema: backup_preview_5; Owner: -
--

SELECT pg_catalog.setval('backup_preview_5.time_entries_id_seq', 1, false);


--
-- Name: time_entry_activities_projects_id_seq; Type: SEQUENCE SET; Schema: backup_preview_5; Owner: -
--

SELECT pg_catalog.setval('backup_preview_5.time_entry_activities_projects_id_seq', 1, false);


--
-- Name: time_entry_journals_id_seq; Type: SEQUENCE SET; Schema: backup_preview_5; Owner: -
--

SELECT pg_catalog.setval('backup_preview_5.time_entry_journals_id_seq', 1, false);


--
-- Name: tokens_id_seq; Type: SEQUENCE SET; Schema: backup_preview_5; Owner: -
--

SELECT pg_catalog.setval('backup_preview_5.tokens_id_seq', 3, true);


--
-- Name: two_factor_authentication_devices_id_seq; Type: SEQUENCE SET; Schema: backup_preview_5; Owner: -
--

SELECT pg_catalog.setval('backup_preview_5.two_factor_authentication_devices_id_seq', 1, false);


--
-- Name: types_id_seq; Type: SEQUENCE SET; Schema: backup_preview_5; Owner: -
--

SELECT pg_catalog.setval('backup_preview_5.types_id_seq', 9, true);


--
-- Name: user_passwords_id_seq; Type: SEQUENCE SET; Schema: backup_preview_5; Owner: -
--

SELECT pg_catalog.setval('backup_preview_5.user_passwords_id_seq', 5, true);


--
-- Name: user_preferences_id_seq; Type: SEQUENCE SET; Schema: backup_preview_5; Owner: -
--

SELECT pg_catalog.setval('backup_preview_5.user_preferences_id_seq', 1, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: backup_preview_5; Owner: -
--

SELECT pg_catalog.setval('backup_preview_5.users_id_seq', 8, true);


--
-- Name: version_settings_id_seq; Type: SEQUENCE SET; Schema: backup_preview_5; Owner: -
--

SELECT pg_catalog.setval('backup_preview_5.version_settings_id_seq', 4, true);


--
-- Name: versions_id_seq; Type: SEQUENCE SET; Schema: backup_preview_5; Owner: -
--

SELECT pg_catalog.setval('backup_preview_5.versions_id_seq', 20, true);


--
-- Name: views_id_seq; Type: SEQUENCE SET; Schema: backup_preview_5; Owner: -
--

SELECT pg_catalog.setval('backup_preview_5.views_id_seq', 8, true);


--
-- Name: watchers_id_seq; Type: SEQUENCE SET; Schema: backup_preview_5; Owner: -
--

SELECT pg_catalog.setval('backup_preview_5.watchers_id_seq', 2, true);


--
-- Name: webhooks_events_id_seq; Type: SEQUENCE SET; Schema: backup_preview_5; Owner: -
--

SELECT pg_catalog.setval('backup_preview_5.webhooks_events_id_seq', 1, false);


--
-- Name: webhooks_logs_id_seq; Type: SEQUENCE SET; Schema: backup_preview_5; Owner: -
--

SELECT pg_catalog.setval('backup_preview_5.webhooks_logs_id_seq', 1, false);


--
-- Name: webhooks_projects_id_seq; Type: SEQUENCE SET; Schema: backup_preview_5; Owner: -
--

SELECT pg_catalog.setval('backup_preview_5.webhooks_projects_id_seq', 1, false);


--
-- Name: webhooks_webhooks_id_seq; Type: SEQUENCE SET; Schema: backup_preview_5; Owner: -
--

SELECT pg_catalog.setval('backup_preview_5.webhooks_webhooks_id_seq', 1, false);


--
-- Name: wiki_page_journals_id_seq; Type: SEQUENCE SET; Schema: backup_preview_5; Owner: -
--

SELECT pg_catalog.setval('backup_preview_5.wiki_page_journals_id_seq', 2, true);


--
-- Name: wiki_pages_id_seq; Type: SEQUENCE SET; Schema: backup_preview_5; Owner: -
--

SELECT pg_catalog.setval('backup_preview_5.wiki_pages_id_seq', 2, true);


--
-- Name: wiki_redirects_id_seq; Type: SEQUENCE SET; Schema: backup_preview_5; Owner: -
--

SELECT pg_catalog.setval('backup_preview_5.wiki_redirects_id_seq', 1, false);


--
-- Name: wikis_id_seq; Type: SEQUENCE SET; Schema: backup_preview_5; Owner: -
--

SELECT pg_catalog.setval('backup_preview_5.wikis_id_seq', 2, true);


--
-- Name: work_package_journals_id_seq; Type: SEQUENCE SET; Schema: backup_preview_5; Owner: -
--

SELECT pg_catalog.setval('backup_preview_5.work_package_journals_id_seq', 58, true);


--
-- Name: work_packages_id_seq; Type: SEQUENCE SET; Schema: backup_preview_5; Owner: -
--

SELECT pg_catalog.setval('backup_preview_5.work_packages_id_seq', 36, true);


--
-- Name: workflows_id_seq; Type: SEQUENCE SET; Schema: backup_preview_5; Owner: -
--

SELECT pg_catalog.setval('backup_preview_5.workflows_id_seq', 1172, true);


--
-- Name: announcements_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.announcements_id_seq', 1, false);


--
-- Name: attachable_journals_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.attachable_journals_id_seq', 5, true);


--
-- Name: attachment_journals_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.attachment_journals_id_seq', 9, true);


--
-- Name: attachments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.attachments_id_seq', 9, true);


--
-- Name: attribute_help_texts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.attribute_help_texts_id_seq', 1, false);


--
-- Name: auth_sources_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.auth_sources_id_seq', 1, false);


--
-- Name: backups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.backups_id_seq', 7, true);


--
-- Name: bcf_comments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.bcf_comments_id_seq', 1, false);


--
-- Name: bcf_issues_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.bcf_issues_id_seq', 1, false);


--
-- Name: bcf_viewpoints_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.bcf_viewpoints_id_seq', 1, false);


--
-- Name: budget_journals_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.budget_journals_id_seq', 1, false);


--
-- Name: budgets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.budgets_id_seq', 1, false);


--
-- Name: categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.categories_id_seq', 2, true);


--
-- Name: changes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.changes_id_seq', 1, false);


--
-- Name: changeset_journals_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.changeset_journals_id_seq', 1, false);


--
-- Name: changesets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.changesets_id_seq', 1, false);


--
-- Name: colors_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.colors_id_seq', 144, true);


--
-- Name: comments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.comments_id_seq', 1, false);


--
-- Name: cost_entries_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.cost_entries_id_seq', 1, false);


--
-- Name: cost_queries_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.cost_queries_id_seq', 1, false);


--
-- Name: cost_types_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.cost_types_id_seq', 1, false);


--
-- Name: custom_actions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.custom_actions_id_seq', 1, false);


--
-- Name: custom_actions_projects_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.custom_actions_projects_id_seq', 1, false);


--
-- Name: custom_actions_roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.custom_actions_roles_id_seq', 1, false);


--
-- Name: custom_actions_statuses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.custom_actions_statuses_id_seq', 1, false);


--
-- Name: custom_actions_types_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.custom_actions_types_id_seq', 1, false);


--
-- Name: custom_fields_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.custom_fields_id_seq', 11, true);


--
-- Name: custom_options_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.custom_options_id_seq', 6, true);


--
-- Name: custom_styles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.custom_styles_id_seq', 1, true);


--
-- Name: custom_values_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.custom_values_id_seq', 1, false);


--
-- Name: customizable_journals_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.customizable_journals_id_seq', 1, false);


--
-- Name: delayed_job_statuses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.delayed_job_statuses_id_seq', 16, true);


--
-- Name: delayed_jobs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.delayed_jobs_id_seq', 75, true);


--
-- Name: design_colors_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.design_colors_id_seq', 31, true);


--
-- Name: document_journals_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.document_journals_id_seq', 1, false);


--
-- Name: documents_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.documents_id_seq', 1, false);


--
-- Name: enabled_modules_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.enabled_modules_id_seq', 30, true);


--
-- Name: enterprise_tokens_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.enterprise_tokens_id_seq', 1, true);


--
-- Name: enumerations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.enumerations_id_seq', 13, true);


--
-- Name: export_card_configurations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.export_card_configurations_id_seq', 1, false);


--
-- Name: exports_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.exports_id_seq', 2, true);


--
-- Name: file_links_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.file_links_id_seq', 1, false);


--
-- Name: forums_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.forums_id_seq', 1, false);


--
-- Name: github_check_runs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.github_check_runs_id_seq', 1, false);


--
-- Name: github_pull_requests_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.github_pull_requests_id_seq', 1, false);


--
-- Name: github_users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.github_users_id_seq', 1, false);


--
-- Name: grid_widgets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.grid_widgets_id_seq', 32, true);


--
-- Name: grids_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.grids_id_seq', 7, true);


--
-- Name: group_users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.group_users_id_seq', 1, false);


--
-- Name: ical_token_query_assignments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ical_token_query_assignments_id_seq', 1, false);


--
-- Name: ifc_models_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ifc_models_id_seq', 1, false);


--
-- Name: journals_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.journals_id_seq', 57, true);


--
-- Name: labor_budget_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.labor_budget_items_id_seq', 1, false);


--
-- Name: last_project_folders_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.last_project_folders_id_seq', 1, false);


--
-- Name: ldap_groups_memberships_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ldap_groups_memberships_id_seq', 1, false);


--
-- Name: ldap_groups_synchronized_filters_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ldap_groups_synchronized_filters_id_seq', 1, false);


--
-- Name: ldap_groups_synchronized_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ldap_groups_synchronized_groups_id_seq', 1, false);


--
-- Name: material_budget_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.material_budget_items_id_seq', 1, false);


--
-- Name: meeting_content_journals_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.meeting_content_journals_id_seq', 1, false);


--
-- Name: meeting_contents_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.meeting_contents_id_seq', 1, false);


--
-- Name: meeting_journals_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.meeting_journals_id_seq', 1, false);


--
-- Name: meeting_participants_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.meeting_participants_id_seq', 1, false);


--
-- Name: meetings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.meetings_id_seq', 1, false);


--
-- Name: member_roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.member_roles_id_seq', 14, true);


--
-- Name: members_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.members_id_seq', 14, true);


--
-- Name: menu_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.menu_items_id_seq', 2, true);


--
-- Name: message_journals_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.message_journals_id_seq', 1, false);


--
-- Name: messages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.messages_id_seq', 1, false);


--
-- Name: news_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.news_id_seq', 2, true);


--
-- Name: news_journals_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.news_journals_id_seq', 2, true);


--
-- Name: non_working_days_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.non_working_days_id_seq', 1, false);


--
-- Name: notification_settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.notification_settings_id_seq', 5, true);


--
-- Name: notifications_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.notifications_id_seq', 1, false);


--
-- Name: oauth_access_grants_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.oauth_access_grants_id_seq', 1, false);


--
-- Name: oauth_access_tokens_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.oauth_access_tokens_id_seq', 1, false);


--
-- Name: oauth_applications_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.oauth_applications_id_seq', 1, false);


--
-- Name: oauth_client_tokens_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.oauth_client_tokens_id_seq', 1, false);


--
-- Name: oauth_clients_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.oauth_clients_id_seq', 1, false);


--
-- Name: oidc_user_session_links_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.oidc_user_session_links_id_seq', 1, false);


--
-- Name: ordered_work_packages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ordered_work_packages_id_seq', 10, true);


--
-- Name: paper_trail_audits_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.paper_trail_audits_id_seq', 3, true);


--
-- Name: project_journals_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.project_journals_id_seq', 7, true);


--
-- Name: projects_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.projects_id_seq', 6, true);


--
-- Name: projects_storages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.projects_storages_id_seq', 1, false);


--
-- Name: queries_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.queries_id_seq', 26, true);


--
-- Name: rates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.rates_id_seq', 1, false);


--
-- Name: recaptcha_entries_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.recaptcha_entries_id_seq', 1, false);


--
-- Name: relations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.relations_id_seq', 7, true);


--
-- Name: repositories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.repositories_id_seq', 1, false);


--
-- Name: role_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.role_permissions_id_seq', 232, true);


--
-- Name: roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.roles_id_seq', 6, true);


--
-- Name: sessions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.sessions_id_seq', 86, true);


--
-- Name: settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.settings_id_seq', 120, true);


--
-- Name: statuses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.statuses_id_seq', 14, true);


--
-- Name: storages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.storages_id_seq', 1, false);


--
-- Name: time_entries_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.time_entries_id_seq', 1, false);


--
-- Name: time_entry_activities_projects_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.time_entry_activities_projects_id_seq', 1, false);


--
-- Name: time_entry_journals_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.time_entry_journals_id_seq', 1, false);


--
-- Name: tokens_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.tokens_id_seq', 3, true);


--
-- Name: two_factor_authentication_devices_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.two_factor_authentication_devices_id_seq', 1, false);


--
-- Name: types_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.types_id_seq', 9, true);


--
-- Name: user_passwords_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.user_passwords_id_seq', 5, true);


--
-- Name: user_preferences_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.user_preferences_id_seq', 1, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.users_id_seq', 8, true);


--
-- Name: version_settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.version_settings_id_seq', 4, true);


--
-- Name: versions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.versions_id_seq', 20, true);


--
-- Name: views_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.views_id_seq', 8, true);


--
-- Name: watchers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.watchers_id_seq', 2, true);


--
-- Name: webhooks_events_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.webhooks_events_id_seq', 1, false);


--
-- Name: webhooks_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.webhooks_logs_id_seq', 1, false);


--
-- Name: webhooks_projects_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.webhooks_projects_id_seq', 1, false);


--
-- Name: webhooks_webhooks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.webhooks_webhooks_id_seq', 1, false);


--
-- Name: wiki_page_journals_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.wiki_page_journals_id_seq', 2, true);


--
-- Name: wiki_pages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.wiki_pages_id_seq', 2, true);


--
-- Name: wiki_redirects_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.wiki_redirects_id_seq', 1, false);


--
-- Name: wikis_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.wikis_id_seq', 2, true);


--
-- Name: work_package_journals_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.work_package_journals_id_seq', 62, true);


--
-- Name: work_packages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.work_packages_id_seq', 36, true);


--
-- Name: workflows_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.workflows_id_seq', 1172, true);


--
-- Name: announcements announcements_pkey; Type: CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.announcements
    ADD CONSTRAINT announcements_pkey PRIMARY KEY (id);


--
-- Name: ar_internal_metadata ar_internal_metadata_pkey; Type: CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.ar_internal_metadata
    ADD CONSTRAINT ar_internal_metadata_pkey PRIMARY KEY (key);


--
-- Name: attachable_journals attachable_journals_pkey; Type: CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.attachable_journals
    ADD CONSTRAINT attachable_journals_pkey PRIMARY KEY (id);


--
-- Name: attachment_journals attachment_journals_pkey; Type: CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.attachment_journals
    ADD CONSTRAINT attachment_journals_pkey PRIMARY KEY (id);


--
-- Name: attachments attachments_pkey; Type: CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.attachments
    ADD CONSTRAINT attachments_pkey PRIMARY KEY (id);


--
-- Name: attribute_help_texts attribute_help_texts_pkey; Type: CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.attribute_help_texts
    ADD CONSTRAINT attribute_help_texts_pkey PRIMARY KEY (id);


--
-- Name: auth_sources auth_sources_pkey; Type: CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.auth_sources
    ADD CONSTRAINT auth_sources_pkey PRIMARY KEY (id);


--
-- Name: backups backups_pkey; Type: CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.backups
    ADD CONSTRAINT backups_pkey PRIMARY KEY (id);


--
-- Name: bcf_comments bcf_comments_pkey; Type: CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.bcf_comments
    ADD CONSTRAINT bcf_comments_pkey PRIMARY KEY (id);


--
-- Name: bcf_issues bcf_issues_pkey; Type: CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.bcf_issues
    ADD CONSTRAINT bcf_issues_pkey PRIMARY KEY (id);


--
-- Name: bcf_viewpoints bcf_viewpoints_pkey; Type: CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.bcf_viewpoints
    ADD CONSTRAINT bcf_viewpoints_pkey PRIMARY KEY (id);


--
-- Name: budget_journals budget_journals_pkey; Type: CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.budget_journals
    ADD CONSTRAINT budget_journals_pkey PRIMARY KEY (id);


--
-- Name: budgets budgets_pkey; Type: CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.budgets
    ADD CONSTRAINT budgets_pkey PRIMARY KEY (id);


--
-- Name: categories categories_pkey; Type: CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.categories
    ADD CONSTRAINT categories_pkey PRIMARY KEY (id);


--
-- Name: changes changes_pkey; Type: CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.changes
    ADD CONSTRAINT changes_pkey PRIMARY KEY (id);


--
-- Name: changeset_journals changeset_journals_pkey; Type: CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.changeset_journals
    ADD CONSTRAINT changeset_journals_pkey PRIMARY KEY (id);


--
-- Name: changesets changesets_pkey; Type: CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.changesets
    ADD CONSTRAINT changesets_pkey PRIMARY KEY (id);


--
-- Name: colors colors_pkey; Type: CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.colors
    ADD CONSTRAINT colors_pkey PRIMARY KEY (id);


--
-- Name: comments comments_pkey; Type: CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.comments
    ADD CONSTRAINT comments_pkey PRIMARY KEY (id);


--
-- Name: cost_entries cost_entries_pkey; Type: CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.cost_entries
    ADD CONSTRAINT cost_entries_pkey PRIMARY KEY (id);


--
-- Name: cost_queries cost_queries_pkey; Type: CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.cost_queries
    ADD CONSTRAINT cost_queries_pkey PRIMARY KEY (id);


--
-- Name: cost_types cost_types_pkey; Type: CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.cost_types
    ADD CONSTRAINT cost_types_pkey PRIMARY KEY (id);


--
-- Name: custom_actions custom_actions_pkey; Type: CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.custom_actions
    ADD CONSTRAINT custom_actions_pkey PRIMARY KEY (id);


--
-- Name: custom_actions_projects custom_actions_projects_pkey; Type: CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.custom_actions_projects
    ADD CONSTRAINT custom_actions_projects_pkey PRIMARY KEY (id);


--
-- Name: custom_actions_roles custom_actions_roles_pkey; Type: CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.custom_actions_roles
    ADD CONSTRAINT custom_actions_roles_pkey PRIMARY KEY (id);


--
-- Name: custom_actions_statuses custom_actions_statuses_pkey; Type: CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.custom_actions_statuses
    ADD CONSTRAINT custom_actions_statuses_pkey PRIMARY KEY (id);


--
-- Name: custom_actions_types custom_actions_types_pkey; Type: CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.custom_actions_types
    ADD CONSTRAINT custom_actions_types_pkey PRIMARY KEY (id);


--
-- Name: custom_fields custom_fields_pkey; Type: CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.custom_fields
    ADD CONSTRAINT custom_fields_pkey PRIMARY KEY (id);


--
-- Name: custom_options custom_options_pkey; Type: CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.custom_options
    ADD CONSTRAINT custom_options_pkey PRIMARY KEY (id);


--
-- Name: custom_styles custom_styles_pkey; Type: CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.custom_styles
    ADD CONSTRAINT custom_styles_pkey PRIMARY KEY (id);


--
-- Name: custom_values custom_values_pkey; Type: CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.custom_values
    ADD CONSTRAINT custom_values_pkey PRIMARY KEY (id);


--
-- Name: customizable_journals customizable_journals_pkey; Type: CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.customizable_journals
    ADD CONSTRAINT customizable_journals_pkey PRIMARY KEY (id);


--
-- Name: delayed_job_statuses delayed_job_statuses_pkey; Type: CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.delayed_job_statuses
    ADD CONSTRAINT delayed_job_statuses_pkey PRIMARY KEY (id);


--
-- Name: delayed_jobs delayed_jobs_pkey; Type: CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.delayed_jobs
    ADD CONSTRAINT delayed_jobs_pkey PRIMARY KEY (id);


--
-- Name: design_colors design_colors_pkey; Type: CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.design_colors
    ADD CONSTRAINT design_colors_pkey PRIMARY KEY (id);


--
-- Name: document_journals document_journals_pkey; Type: CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.document_journals
    ADD CONSTRAINT document_journals_pkey PRIMARY KEY (id);


--
-- Name: documents documents_pkey; Type: CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.documents
    ADD CONSTRAINT documents_pkey PRIMARY KEY (id);


--
-- Name: enabled_modules enabled_modules_pkey; Type: CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.enabled_modules
    ADD CONSTRAINT enabled_modules_pkey PRIMARY KEY (id);


--
-- Name: enterprise_tokens enterprise_tokens_pkey; Type: CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.enterprise_tokens
    ADD CONSTRAINT enterprise_tokens_pkey PRIMARY KEY (id);


--
-- Name: enumerations enumerations_pkey; Type: CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.enumerations
    ADD CONSTRAINT enumerations_pkey PRIMARY KEY (id);


--
-- Name: export_card_configurations export_card_configurations_pkey; Type: CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.export_card_configurations
    ADD CONSTRAINT export_card_configurations_pkey PRIMARY KEY (id);


--
-- Name: exports exports_pkey; Type: CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.exports
    ADD CONSTRAINT exports_pkey PRIMARY KEY (id);


--
-- Name: file_links file_links_pkey; Type: CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.file_links
    ADD CONSTRAINT file_links_pkey PRIMARY KEY (id);


--
-- Name: forums forums_pkey; Type: CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.forums
    ADD CONSTRAINT forums_pkey PRIMARY KEY (id);


--
-- Name: github_check_runs github_check_runs_pkey; Type: CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.github_check_runs
    ADD CONSTRAINT github_check_runs_pkey PRIMARY KEY (id);


--
-- Name: github_pull_requests github_pull_requests_pkey; Type: CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.github_pull_requests
    ADD CONSTRAINT github_pull_requests_pkey PRIMARY KEY (id);


--
-- Name: github_users github_users_pkey; Type: CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.github_users
    ADD CONSTRAINT github_users_pkey PRIMARY KEY (id);


--
-- Name: grid_widgets grid_widgets_pkey; Type: CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.grid_widgets
    ADD CONSTRAINT grid_widgets_pkey PRIMARY KEY (id);


--
-- Name: grids grids_pkey; Type: CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.grids
    ADD CONSTRAINT grids_pkey PRIMARY KEY (id);


--
-- Name: group_users group_users_pkey; Type: CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.group_users
    ADD CONSTRAINT group_users_pkey PRIMARY KEY (id);


--
-- Name: ical_token_query_assignments ical_token_query_assignments_pkey; Type: CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.ical_token_query_assignments
    ADD CONSTRAINT ical_token_query_assignments_pkey PRIMARY KEY (id);


--
-- Name: ifc_models ifc_models_pkey; Type: CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.ifc_models
    ADD CONSTRAINT ifc_models_pkey PRIMARY KEY (id);


--
-- Name: journals journals_pkey; Type: CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.journals
    ADD CONSTRAINT journals_pkey PRIMARY KEY (id);


--
-- Name: labor_budget_items labor_budget_items_pkey; Type: CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.labor_budget_items
    ADD CONSTRAINT labor_budget_items_pkey PRIMARY KEY (id);


--
-- Name: last_project_folders last_project_folders_pkey; Type: CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.last_project_folders
    ADD CONSTRAINT last_project_folders_pkey PRIMARY KEY (id);


--
-- Name: ldap_groups_memberships ldap_groups_memberships_pkey; Type: CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.ldap_groups_memberships
    ADD CONSTRAINT ldap_groups_memberships_pkey PRIMARY KEY (id);


--
-- Name: ldap_groups_synchronized_filters ldap_groups_synchronized_filters_pkey; Type: CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.ldap_groups_synchronized_filters
    ADD CONSTRAINT ldap_groups_synchronized_filters_pkey PRIMARY KEY (id);


--
-- Name: ldap_groups_synchronized_groups ldap_groups_synchronized_groups_pkey; Type: CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.ldap_groups_synchronized_groups
    ADD CONSTRAINT ldap_groups_synchronized_groups_pkey PRIMARY KEY (id);


--
-- Name: material_budget_items material_budget_items_pkey; Type: CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.material_budget_items
    ADD CONSTRAINT material_budget_items_pkey PRIMARY KEY (id);


--
-- Name: meeting_content_journals meeting_content_journals_pkey; Type: CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.meeting_content_journals
    ADD CONSTRAINT meeting_content_journals_pkey PRIMARY KEY (id);


--
-- Name: meeting_contents meeting_contents_pkey; Type: CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.meeting_contents
    ADD CONSTRAINT meeting_contents_pkey PRIMARY KEY (id);


--
-- Name: meeting_journals meeting_journals_pkey; Type: CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.meeting_journals
    ADD CONSTRAINT meeting_journals_pkey PRIMARY KEY (id);


--
-- Name: meeting_participants meeting_participants_pkey; Type: CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.meeting_participants
    ADD CONSTRAINT meeting_participants_pkey PRIMARY KEY (id);


--
-- Name: meetings meetings_pkey; Type: CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.meetings
    ADD CONSTRAINT meetings_pkey PRIMARY KEY (id);


--
-- Name: member_roles member_roles_pkey; Type: CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.member_roles
    ADD CONSTRAINT member_roles_pkey PRIMARY KEY (id);


--
-- Name: members members_pkey; Type: CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.members
    ADD CONSTRAINT members_pkey PRIMARY KEY (id);


--
-- Name: menu_items menu_items_pkey; Type: CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.menu_items
    ADD CONSTRAINT menu_items_pkey PRIMARY KEY (id);


--
-- Name: message_journals message_journals_pkey; Type: CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.message_journals
    ADD CONSTRAINT message_journals_pkey PRIMARY KEY (id);


--
-- Name: messages messages_pkey; Type: CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.messages
    ADD CONSTRAINT messages_pkey PRIMARY KEY (id);


--
-- Name: news_journals news_journals_pkey; Type: CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.news_journals
    ADD CONSTRAINT news_journals_pkey PRIMARY KEY (id);


--
-- Name: news news_pkey; Type: CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.news
    ADD CONSTRAINT news_pkey PRIMARY KEY (id);


--
-- Name: non_working_days non_working_days_pkey; Type: CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.non_working_days
    ADD CONSTRAINT non_working_days_pkey PRIMARY KEY (id);


--
-- Name: notification_settings notification_settings_pkey; Type: CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.notification_settings
    ADD CONSTRAINT notification_settings_pkey PRIMARY KEY (id);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: oauth_access_grants oauth_access_grants_pkey; Type: CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.oauth_access_grants
    ADD CONSTRAINT oauth_access_grants_pkey PRIMARY KEY (id);


--
-- Name: oauth_access_tokens oauth_access_tokens_pkey; Type: CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.oauth_access_tokens
    ADD CONSTRAINT oauth_access_tokens_pkey PRIMARY KEY (id);


--
-- Name: oauth_applications oauth_applications_pkey; Type: CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.oauth_applications
    ADD CONSTRAINT oauth_applications_pkey PRIMARY KEY (id);


--
-- Name: oauth_client_tokens oauth_client_tokens_pkey; Type: CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.oauth_client_tokens
    ADD CONSTRAINT oauth_client_tokens_pkey PRIMARY KEY (id);


--
-- Name: oauth_clients oauth_clients_pkey; Type: CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.oauth_clients
    ADD CONSTRAINT oauth_clients_pkey PRIMARY KEY (id);


--
-- Name: oidc_user_session_links oidc_user_session_links_pkey; Type: CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.oidc_user_session_links
    ADD CONSTRAINT oidc_user_session_links_pkey PRIMARY KEY (id);


--
-- Name: ordered_work_packages ordered_work_packages_pkey; Type: CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.ordered_work_packages
    ADD CONSTRAINT ordered_work_packages_pkey PRIMARY KEY (id);


--
-- Name: paper_trail_audits paper_trail_audits_pkey; Type: CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.paper_trail_audits
    ADD CONSTRAINT paper_trail_audits_pkey PRIMARY KEY (id);


--
-- Name: project_journals project_journals_pkey; Type: CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.project_journals
    ADD CONSTRAINT project_journals_pkey PRIMARY KEY (id);


--
-- Name: projects projects_pkey; Type: CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.projects
    ADD CONSTRAINT projects_pkey PRIMARY KEY (id);


--
-- Name: projects_storages projects_storages_pkey; Type: CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.projects_storages
    ADD CONSTRAINT projects_storages_pkey PRIMARY KEY (id);


--
-- Name: queries queries_pkey; Type: CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.queries
    ADD CONSTRAINT queries_pkey PRIMARY KEY (id);


--
-- Name: rates rates_pkey; Type: CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.rates
    ADD CONSTRAINT rates_pkey PRIMARY KEY (id);


--
-- Name: recaptcha_entries recaptcha_entries_pkey; Type: CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.recaptcha_entries
    ADD CONSTRAINT recaptcha_entries_pkey PRIMARY KEY (id);


--
-- Name: relations relations_pkey; Type: CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.relations
    ADD CONSTRAINT relations_pkey PRIMARY KEY (id);


--
-- Name: repositories repositories_pkey; Type: CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.repositories
    ADD CONSTRAINT repositories_pkey PRIMARY KEY (id);


--
-- Name: role_permissions role_permissions_pkey; Type: CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.role_permissions
    ADD CONSTRAINT role_permissions_pkey PRIMARY KEY (id);


--
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (version);


--
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (id);


--
-- Name: settings settings_pkey; Type: CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.settings
    ADD CONSTRAINT settings_pkey PRIMARY KEY (id);


--
-- Name: statuses statuses_pkey; Type: CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.statuses
    ADD CONSTRAINT statuses_pkey PRIMARY KEY (id);


--
-- Name: storages storages_pkey; Type: CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.storages
    ADD CONSTRAINT storages_pkey PRIMARY KEY (id);


--
-- Name: time_entries time_entries_pkey; Type: CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.time_entries
    ADD CONSTRAINT time_entries_pkey PRIMARY KEY (id);


--
-- Name: time_entry_activities_projects time_entry_activities_projects_pkey; Type: CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.time_entry_activities_projects
    ADD CONSTRAINT time_entry_activities_projects_pkey PRIMARY KEY (id);


--
-- Name: time_entry_journals time_entry_journals_pkey; Type: CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.time_entry_journals
    ADD CONSTRAINT time_entry_journals_pkey PRIMARY KEY (id);


--
-- Name: tokens tokens_pkey; Type: CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.tokens
    ADD CONSTRAINT tokens_pkey PRIMARY KEY (id);


--
-- Name: two_factor_authentication_devices two_factor_authentication_devices_pkey; Type: CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.two_factor_authentication_devices
    ADD CONSTRAINT two_factor_authentication_devices_pkey PRIMARY KEY (id);


--
-- Name: types types_pkey; Type: CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.types
    ADD CONSTRAINT types_pkey PRIMARY KEY (id);


--
-- Name: user_passwords user_passwords_pkey; Type: CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.user_passwords
    ADD CONSTRAINT user_passwords_pkey PRIMARY KEY (id);


--
-- Name: user_preferences user_preferences_pkey; Type: CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.user_preferences
    ADD CONSTRAINT user_preferences_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: version_settings version_settings_pkey; Type: CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.version_settings
    ADD CONSTRAINT version_settings_pkey PRIMARY KEY (id);


--
-- Name: versions versions_pkey; Type: CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.versions
    ADD CONSTRAINT versions_pkey PRIMARY KEY (id);


--
-- Name: views views_pkey; Type: CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.views
    ADD CONSTRAINT views_pkey PRIMARY KEY (id);


--
-- Name: watchers watchers_pkey; Type: CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.watchers
    ADD CONSTRAINT watchers_pkey PRIMARY KEY (id);


--
-- Name: webhooks_events webhooks_events_pkey; Type: CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.webhooks_events
    ADD CONSTRAINT webhooks_events_pkey PRIMARY KEY (id);


--
-- Name: webhooks_logs webhooks_logs_pkey; Type: CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.webhooks_logs
    ADD CONSTRAINT webhooks_logs_pkey PRIMARY KEY (id);


--
-- Name: webhooks_projects webhooks_projects_pkey; Type: CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.webhooks_projects
    ADD CONSTRAINT webhooks_projects_pkey PRIMARY KEY (id);


--
-- Name: webhooks_webhooks webhooks_webhooks_pkey; Type: CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.webhooks_webhooks
    ADD CONSTRAINT webhooks_webhooks_pkey PRIMARY KEY (id);


--
-- Name: wiki_page_journals wiki_page_journals_pkey; Type: CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.wiki_page_journals
    ADD CONSTRAINT wiki_page_journals_pkey PRIMARY KEY (id);


--
-- Name: wiki_pages wiki_pages_pkey; Type: CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.wiki_pages
    ADD CONSTRAINT wiki_pages_pkey PRIMARY KEY (id);


--
-- Name: wiki_redirects wiki_redirects_pkey; Type: CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.wiki_redirects
    ADD CONSTRAINT wiki_redirects_pkey PRIMARY KEY (id);


--
-- Name: wikis wikis_pkey; Type: CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.wikis
    ADD CONSTRAINT wikis_pkey PRIMARY KEY (id);


--
-- Name: work_package_journals work_package_journals_pkey; Type: CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.work_package_journals
    ADD CONSTRAINT work_package_journals_pkey PRIMARY KEY (id);


--
-- Name: work_packages work_packages_pkey; Type: CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.work_packages
    ADD CONSTRAINT work_packages_pkey PRIMARY KEY (id);


--
-- Name: workflows workflows_pkey; Type: CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.workflows
    ADD CONSTRAINT workflows_pkey PRIMARY KEY (id);


--
-- Name: announcements announcements_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.announcements
    ADD CONSTRAINT announcements_pkey PRIMARY KEY (id);


--
-- Name: ar_internal_metadata ar_internal_metadata_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ar_internal_metadata
    ADD CONSTRAINT ar_internal_metadata_pkey PRIMARY KEY (key);


--
-- Name: attachable_journals attachable_journals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attachable_journals
    ADD CONSTRAINT attachable_journals_pkey PRIMARY KEY (id);


--
-- Name: attachment_journals attachment_journals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attachment_journals
    ADD CONSTRAINT attachment_journals_pkey PRIMARY KEY (id);


--
-- Name: attachments attachments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attachments
    ADD CONSTRAINT attachments_pkey PRIMARY KEY (id);


--
-- Name: attribute_help_texts attribute_help_texts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attribute_help_texts
    ADD CONSTRAINT attribute_help_texts_pkey PRIMARY KEY (id);


--
-- Name: auth_sources auth_sources_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_sources
    ADD CONSTRAINT auth_sources_pkey PRIMARY KEY (id);


--
-- Name: backups backups_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.backups
    ADD CONSTRAINT backups_pkey PRIMARY KEY (id);


--
-- Name: bcf_comments bcf_comments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bcf_comments
    ADD CONSTRAINT bcf_comments_pkey PRIMARY KEY (id);


--
-- Name: bcf_issues bcf_issues_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bcf_issues
    ADD CONSTRAINT bcf_issues_pkey PRIMARY KEY (id);


--
-- Name: bcf_viewpoints bcf_viewpoints_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bcf_viewpoints
    ADD CONSTRAINT bcf_viewpoints_pkey PRIMARY KEY (id);


--
-- Name: budget_journals budget_journals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.budget_journals
    ADD CONSTRAINT budget_journals_pkey PRIMARY KEY (id);


--
-- Name: budgets budgets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.budgets
    ADD CONSTRAINT budgets_pkey PRIMARY KEY (id);


--
-- Name: categories categories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_pkey PRIMARY KEY (id);


--
-- Name: changes changes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.changes
    ADD CONSTRAINT changes_pkey PRIMARY KEY (id);


--
-- Name: changeset_journals changeset_journals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.changeset_journals
    ADD CONSTRAINT changeset_journals_pkey PRIMARY KEY (id);


--
-- Name: changesets changesets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.changesets
    ADD CONSTRAINT changesets_pkey PRIMARY KEY (id);


--
-- Name: colors colors_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.colors
    ADD CONSTRAINT colors_pkey PRIMARY KEY (id);


--
-- Name: comments comments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.comments
    ADD CONSTRAINT comments_pkey PRIMARY KEY (id);


--
-- Name: cost_entries cost_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cost_entries
    ADD CONSTRAINT cost_entries_pkey PRIMARY KEY (id);


--
-- Name: cost_queries cost_queries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cost_queries
    ADD CONSTRAINT cost_queries_pkey PRIMARY KEY (id);


--
-- Name: cost_types cost_types_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cost_types
    ADD CONSTRAINT cost_types_pkey PRIMARY KEY (id);


--
-- Name: custom_actions custom_actions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.custom_actions
    ADD CONSTRAINT custom_actions_pkey PRIMARY KEY (id);


--
-- Name: custom_actions_projects custom_actions_projects_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.custom_actions_projects
    ADD CONSTRAINT custom_actions_projects_pkey PRIMARY KEY (id);


--
-- Name: custom_actions_roles custom_actions_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.custom_actions_roles
    ADD CONSTRAINT custom_actions_roles_pkey PRIMARY KEY (id);


--
-- Name: custom_actions_statuses custom_actions_statuses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.custom_actions_statuses
    ADD CONSTRAINT custom_actions_statuses_pkey PRIMARY KEY (id);


--
-- Name: custom_actions_types custom_actions_types_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.custom_actions_types
    ADD CONSTRAINT custom_actions_types_pkey PRIMARY KEY (id);


--
-- Name: custom_fields custom_fields_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.custom_fields
    ADD CONSTRAINT custom_fields_pkey PRIMARY KEY (id);


--
-- Name: custom_options custom_options_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.custom_options
    ADD CONSTRAINT custom_options_pkey PRIMARY KEY (id);


--
-- Name: custom_styles custom_styles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.custom_styles
    ADD CONSTRAINT custom_styles_pkey PRIMARY KEY (id);


--
-- Name: custom_values custom_values_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.custom_values
    ADD CONSTRAINT custom_values_pkey PRIMARY KEY (id);


--
-- Name: customizable_journals customizable_journals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customizable_journals
    ADD CONSTRAINT customizable_journals_pkey PRIMARY KEY (id);


--
-- Name: delayed_job_statuses delayed_job_statuses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.delayed_job_statuses
    ADD CONSTRAINT delayed_job_statuses_pkey PRIMARY KEY (id);


--
-- Name: delayed_jobs delayed_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.delayed_jobs
    ADD CONSTRAINT delayed_jobs_pkey PRIMARY KEY (id);


--
-- Name: design_colors design_colors_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.design_colors
    ADD CONSTRAINT design_colors_pkey PRIMARY KEY (id);


--
-- Name: document_journals document_journals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_journals
    ADD CONSTRAINT document_journals_pkey PRIMARY KEY (id);


--
-- Name: documents documents_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_pkey PRIMARY KEY (id);


--
-- Name: enabled_modules enabled_modules_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.enabled_modules
    ADD CONSTRAINT enabled_modules_pkey PRIMARY KEY (id);


--
-- Name: enterprise_tokens enterprise_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.enterprise_tokens
    ADD CONSTRAINT enterprise_tokens_pkey PRIMARY KEY (id);


--
-- Name: enumerations enumerations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.enumerations
    ADD CONSTRAINT enumerations_pkey PRIMARY KEY (id);


--
-- Name: export_card_configurations export_card_configurations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.export_card_configurations
    ADD CONSTRAINT export_card_configurations_pkey PRIMARY KEY (id);


--
-- Name: exports exports_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.exports
    ADD CONSTRAINT exports_pkey PRIMARY KEY (id);


--
-- Name: file_links file_links_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.file_links
    ADD CONSTRAINT file_links_pkey PRIMARY KEY (id);


--
-- Name: forums forums_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.forums
    ADD CONSTRAINT forums_pkey PRIMARY KEY (id);


--
-- Name: github_check_runs github_check_runs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.github_check_runs
    ADD CONSTRAINT github_check_runs_pkey PRIMARY KEY (id);


--
-- Name: github_pull_requests github_pull_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.github_pull_requests
    ADD CONSTRAINT github_pull_requests_pkey PRIMARY KEY (id);


--
-- Name: github_users github_users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.github_users
    ADD CONSTRAINT github_users_pkey PRIMARY KEY (id);


--
-- Name: grid_widgets grid_widgets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.grid_widgets
    ADD CONSTRAINT grid_widgets_pkey PRIMARY KEY (id);


--
-- Name: grids grids_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.grids
    ADD CONSTRAINT grids_pkey PRIMARY KEY (id);


--
-- Name: group_users group_users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.group_users
    ADD CONSTRAINT group_users_pkey PRIMARY KEY (id);


--
-- Name: ical_token_query_assignments ical_token_query_assignments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ical_token_query_assignments
    ADD CONSTRAINT ical_token_query_assignments_pkey PRIMARY KEY (id);


--
-- Name: ifc_models ifc_models_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ifc_models
    ADD CONSTRAINT ifc_models_pkey PRIMARY KEY (id);


--
-- Name: journals journals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.journals
    ADD CONSTRAINT journals_pkey PRIMARY KEY (id);


--
-- Name: labor_budget_items labor_budget_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.labor_budget_items
    ADD CONSTRAINT labor_budget_items_pkey PRIMARY KEY (id);


--
-- Name: last_project_folders last_project_folders_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.last_project_folders
    ADD CONSTRAINT last_project_folders_pkey PRIMARY KEY (id);


--
-- Name: ldap_groups_memberships ldap_groups_memberships_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ldap_groups_memberships
    ADD CONSTRAINT ldap_groups_memberships_pkey PRIMARY KEY (id);


--
-- Name: ldap_groups_synchronized_filters ldap_groups_synchronized_filters_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ldap_groups_synchronized_filters
    ADD CONSTRAINT ldap_groups_synchronized_filters_pkey PRIMARY KEY (id);


--
-- Name: ldap_groups_synchronized_groups ldap_groups_synchronized_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ldap_groups_synchronized_groups
    ADD CONSTRAINT ldap_groups_synchronized_groups_pkey PRIMARY KEY (id);


--
-- Name: material_budget_items material_budget_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.material_budget_items
    ADD CONSTRAINT material_budget_items_pkey PRIMARY KEY (id);


--
-- Name: meeting_content_journals meeting_content_journals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.meeting_content_journals
    ADD CONSTRAINT meeting_content_journals_pkey PRIMARY KEY (id);


--
-- Name: meeting_contents meeting_contents_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.meeting_contents
    ADD CONSTRAINT meeting_contents_pkey PRIMARY KEY (id);


--
-- Name: meeting_journals meeting_journals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.meeting_journals
    ADD CONSTRAINT meeting_journals_pkey PRIMARY KEY (id);


--
-- Name: meeting_participants meeting_participants_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.meeting_participants
    ADD CONSTRAINT meeting_participants_pkey PRIMARY KEY (id);


--
-- Name: meetings meetings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.meetings
    ADD CONSTRAINT meetings_pkey PRIMARY KEY (id);


--
-- Name: member_roles member_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_roles
    ADD CONSTRAINT member_roles_pkey PRIMARY KEY (id);


--
-- Name: members members_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.members
    ADD CONSTRAINT members_pkey PRIMARY KEY (id);


--
-- Name: menu_items menu_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.menu_items
    ADD CONSTRAINT menu_items_pkey PRIMARY KEY (id);


--
-- Name: message_journals message_journals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.message_journals
    ADD CONSTRAINT message_journals_pkey PRIMARY KEY (id);


--
-- Name: messages messages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_pkey PRIMARY KEY (id);


--
-- Name: news_journals news_journals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.news_journals
    ADD CONSTRAINT news_journals_pkey PRIMARY KEY (id);


--
-- Name: news news_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.news
    ADD CONSTRAINT news_pkey PRIMARY KEY (id);


--
-- Name: non_working_days non_working_days_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.non_working_days
    ADD CONSTRAINT non_working_days_pkey PRIMARY KEY (id);


--
-- Name: notification_settings notification_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_settings
    ADD CONSTRAINT notification_settings_pkey PRIMARY KEY (id);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: oauth_access_grants oauth_access_grants_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth_access_grants
    ADD CONSTRAINT oauth_access_grants_pkey PRIMARY KEY (id);


--
-- Name: oauth_access_tokens oauth_access_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth_access_tokens
    ADD CONSTRAINT oauth_access_tokens_pkey PRIMARY KEY (id);


--
-- Name: oauth_applications oauth_applications_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth_applications
    ADD CONSTRAINT oauth_applications_pkey PRIMARY KEY (id);


--
-- Name: oauth_client_tokens oauth_client_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth_client_tokens
    ADD CONSTRAINT oauth_client_tokens_pkey PRIMARY KEY (id);


--
-- Name: oauth_clients oauth_clients_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth_clients
    ADD CONSTRAINT oauth_clients_pkey PRIMARY KEY (id);


--
-- Name: oidc_user_session_links oidc_user_session_links_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oidc_user_session_links
    ADD CONSTRAINT oidc_user_session_links_pkey PRIMARY KEY (id);


--
-- Name: ordered_work_packages ordered_work_packages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ordered_work_packages
    ADD CONSTRAINT ordered_work_packages_pkey PRIMARY KEY (id);


--
-- Name: paper_trail_audits paper_trail_audits_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.paper_trail_audits
    ADD CONSTRAINT paper_trail_audits_pkey PRIMARY KEY (id);


--
-- Name: project_journals project_journals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_journals
    ADD CONSTRAINT project_journals_pkey PRIMARY KEY (id);


--
-- Name: projects projects_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_pkey PRIMARY KEY (id);


--
-- Name: projects_storages projects_storages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.projects_storages
    ADD CONSTRAINT projects_storages_pkey PRIMARY KEY (id);


--
-- Name: queries queries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.queries
    ADD CONSTRAINT queries_pkey PRIMARY KEY (id);


--
-- Name: rates rates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rates
    ADD CONSTRAINT rates_pkey PRIMARY KEY (id);


--
-- Name: recaptcha_entries recaptcha_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recaptcha_entries
    ADD CONSTRAINT recaptcha_entries_pkey PRIMARY KEY (id);


--
-- Name: relations relations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.relations
    ADD CONSTRAINT relations_pkey PRIMARY KEY (id);


--
-- Name: repositories repositories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.repositories
    ADD CONSTRAINT repositories_pkey PRIMARY KEY (id);


--
-- Name: role_permissions role_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT role_permissions_pkey PRIMARY KEY (id);


--
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (version);


--
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (id);


--
-- Name: settings settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.settings
    ADD CONSTRAINT settings_pkey PRIMARY KEY (id);


--
-- Name: statuses statuses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.statuses
    ADD CONSTRAINT statuses_pkey PRIMARY KEY (id);


--
-- Name: storages storages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.storages
    ADD CONSTRAINT storages_pkey PRIMARY KEY (id);


--
-- Name: time_entries time_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.time_entries
    ADD CONSTRAINT time_entries_pkey PRIMARY KEY (id);


--
-- Name: time_entry_activities_projects time_entry_activities_projects_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.time_entry_activities_projects
    ADD CONSTRAINT time_entry_activities_projects_pkey PRIMARY KEY (id);


--
-- Name: time_entry_journals time_entry_journals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.time_entry_journals
    ADD CONSTRAINT time_entry_journals_pkey PRIMARY KEY (id);


--
-- Name: tokens tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tokens
    ADD CONSTRAINT tokens_pkey PRIMARY KEY (id);


--
-- Name: two_factor_authentication_devices two_factor_authentication_devices_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.two_factor_authentication_devices
    ADD CONSTRAINT two_factor_authentication_devices_pkey PRIMARY KEY (id);


--
-- Name: types types_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.types
    ADD CONSTRAINT types_pkey PRIMARY KEY (id);


--
-- Name: user_passwords user_passwords_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_passwords
    ADD CONSTRAINT user_passwords_pkey PRIMARY KEY (id);


--
-- Name: user_preferences user_preferences_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_preferences
    ADD CONSTRAINT user_preferences_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: version_settings version_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.version_settings
    ADD CONSTRAINT version_settings_pkey PRIMARY KEY (id);


--
-- Name: versions versions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.versions
    ADD CONSTRAINT versions_pkey PRIMARY KEY (id);


--
-- Name: views views_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.views
    ADD CONSTRAINT views_pkey PRIMARY KEY (id);


--
-- Name: watchers watchers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.watchers
    ADD CONSTRAINT watchers_pkey PRIMARY KEY (id);


--
-- Name: webhooks_events webhooks_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.webhooks_events
    ADD CONSTRAINT webhooks_events_pkey PRIMARY KEY (id);


--
-- Name: webhooks_logs webhooks_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.webhooks_logs
    ADD CONSTRAINT webhooks_logs_pkey PRIMARY KEY (id);


--
-- Name: webhooks_projects webhooks_projects_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.webhooks_projects
    ADD CONSTRAINT webhooks_projects_pkey PRIMARY KEY (id);


--
-- Name: webhooks_webhooks webhooks_webhooks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.webhooks_webhooks
    ADD CONSTRAINT webhooks_webhooks_pkey PRIMARY KEY (id);


--
-- Name: wiki_page_journals wiki_page_journals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wiki_page_journals
    ADD CONSTRAINT wiki_page_journals_pkey PRIMARY KEY (id);


--
-- Name: wiki_pages wiki_pages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wiki_pages
    ADD CONSTRAINT wiki_pages_pkey PRIMARY KEY (id);


--
-- Name: wiki_redirects wiki_redirects_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wiki_redirects
    ADD CONSTRAINT wiki_redirects_pkey PRIMARY KEY (id);


--
-- Name: wikis wikis_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wikis
    ADD CONSTRAINT wikis_pkey PRIMARY KEY (id);


--
-- Name: work_package_journals work_package_journals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_package_journals
    ADD CONSTRAINT work_package_journals_pkey PRIMARY KEY (id);


--
-- Name: work_packages work_packages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_packages
    ADD CONSTRAINT work_packages_pkey PRIMARY KEY (id);


--
-- Name: workflows workflows_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workflows
    ADD CONSTRAINT workflows_pkey PRIMARY KEY (id);


--
-- Name: changesets_changeset_id; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX changesets_changeset_id ON backup_preview_5.changes USING btree (changeset_id);


--
-- Name: changesets_repos_rev; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE UNIQUE INDEX changesets_repos_rev ON backup_preview_5.changesets USING btree (repository_id, revision);


--
-- Name: changesets_repos_scmid; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX changesets_repos_scmid ON backup_preview_5.changesets USING btree (repository_id, scmid);


--
-- Name: changesets_work_packages_ids; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE UNIQUE INDEX changesets_work_packages_ids ON backup_preview_5.changesets_work_packages USING btree (changeset_id, work_package_id);


--
-- Name: custom_fields_types_unique; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE UNIQUE INDEX custom_fields_types_unique ON backup_preview_5.custom_fields_types USING btree (custom_field_id, type_id);


--
-- Name: custom_values_customized; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX custom_values_customized ON backup_preview_5.custom_values USING btree (customized_type, customized_id);


--
-- Name: delayed_jobs_priority; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX delayed_jobs_priority ON backup_preview_5.delayed_jobs USING btree (priority, run_at);


--
-- Name: documents_project_id; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX documents_project_id ON backup_preview_5.documents USING btree (project_id);


--
-- Name: enabled_modules_project_id; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX enabled_modules_project_id ON backup_preview_5.enabled_modules USING btree (project_id);


--
-- Name: forums_project_id; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX forums_project_id ON backup_preview_5.forums USING btree (project_id);


--
-- Name: github_pr_wp_pr_id; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX github_pr_wp_pr_id ON backup_preview_5.github_pull_requests_work_packages USING btree (github_pull_request_id);


--
-- Name: group_user_ids; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE UNIQUE INDEX group_user_ids ON backup_preview_5.group_users USING btree (group_id, user_id);


--
-- Name: index_announcements_on_show_until_and_active; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_announcements_on_show_until_and_active ON backup_preview_5.announcements USING btree (show_until, active);


--
-- Name: index_attachable_journals_on_attachment_id; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_attachable_journals_on_attachment_id ON backup_preview_5.attachable_journals USING btree (attachment_id);


--
-- Name: index_attachable_journals_on_journal_id; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_attachable_journals_on_journal_id ON backup_preview_5.attachable_journals USING btree (journal_id);


--
-- Name: index_attachments_on_author_id; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_attachments_on_author_id ON backup_preview_5.attachments USING btree (author_id);


--
-- Name: index_attachments_on_container_id_and_container_type; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_attachments_on_container_id_and_container_type ON backup_preview_5.attachments USING btree (container_id, container_type);


--
-- Name: index_attachments_on_created_at; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_attachments_on_created_at ON backup_preview_5.attachments USING btree (created_at);


--
-- Name: index_attachments_on_file_tsv; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_attachments_on_file_tsv ON backup_preview_5.attachments USING gin (file_tsv);


--
-- Name: index_attachments_on_fulltext_tsv; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_attachments_on_fulltext_tsv ON backup_preview_5.attachments USING gin (fulltext_tsv);


--
-- Name: index_auth_sources_on_id_and_type; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_auth_sources_on_id_and_type ON backup_preview_5.auth_sources USING btree (id, type);


--
-- Name: index_backups_on_creator_id; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_backups_on_creator_id ON backup_preview_5.backups USING btree (creator_id);


--
-- Name: index_bcf_comments_on_issue_id; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_bcf_comments_on_issue_id ON backup_preview_5.bcf_comments USING btree (issue_id);


--
-- Name: index_bcf_comments_on_journal_id; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_bcf_comments_on_journal_id ON backup_preview_5.bcf_comments USING btree (journal_id);


--
-- Name: index_bcf_comments_on_uuid; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_bcf_comments_on_uuid ON backup_preview_5.bcf_comments USING btree (uuid);


--
-- Name: index_bcf_comments_on_uuid_and_issue_id; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE UNIQUE INDEX index_bcf_comments_on_uuid_and_issue_id ON backup_preview_5.bcf_comments USING btree (uuid, issue_id);


--
-- Name: index_bcf_comments_on_viewpoint_id; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_bcf_comments_on_viewpoint_id ON backup_preview_5.bcf_comments USING btree (viewpoint_id);


--
-- Name: index_bcf_issues_on_uuid; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE UNIQUE INDEX index_bcf_issues_on_uuid ON backup_preview_5.bcf_issues USING btree (uuid);


--
-- Name: index_bcf_issues_on_work_package_id; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE UNIQUE INDEX index_bcf_issues_on_work_package_id ON backup_preview_5.bcf_issues USING btree (work_package_id);


--
-- Name: index_bcf_viewpoints_on_issue_id; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_bcf_viewpoints_on_issue_id ON backup_preview_5.bcf_viewpoints USING btree (issue_id);


--
-- Name: index_bcf_viewpoints_on_uuid; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_bcf_viewpoints_on_uuid ON backup_preview_5.bcf_viewpoints USING btree (uuid);


--
-- Name: index_bcf_viewpoints_on_uuid_and_issue_id; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE UNIQUE INDEX index_bcf_viewpoints_on_uuid_and_issue_id ON backup_preview_5.bcf_viewpoints USING btree (uuid, issue_id);


--
-- Name: index_budgets_on_project_id_and_updated_at; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_budgets_on_project_id_and_updated_at ON backup_preview_5.budgets USING btree (project_id, updated_at);


--
-- Name: index_categories_on_assigned_to_id; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_categories_on_assigned_to_id ON backup_preview_5.categories USING btree (assigned_to_id);


--
-- Name: index_changesets_on_committed_on; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_changesets_on_committed_on ON backup_preview_5.changesets USING btree (committed_on);


--
-- Name: index_changesets_on_repository_id; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_changesets_on_repository_id ON backup_preview_5.changesets USING btree (repository_id);


--
-- Name: index_changesets_on_repository_id_and_committed_on; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_changesets_on_repository_id_and_committed_on ON backup_preview_5.changesets USING btree (repository_id, committed_on);


--
-- Name: index_changesets_on_user_id; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_changesets_on_user_id ON backup_preview_5.changesets USING btree (user_id);


--
-- Name: index_comments_on_author_id; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_comments_on_author_id ON backup_preview_5.comments USING btree (author_id);


--
-- Name: index_comments_on_commented_id_and_commented_type; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_comments_on_commented_id_and_commented_type ON backup_preview_5.comments USING btree (commented_id, commented_type);


--
-- Name: index_cost_entries_on_logged_by_id; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_cost_entries_on_logged_by_id ON backup_preview_5.cost_entries USING btree (logged_by_id);


--
-- Name: index_custom_actions_projects_on_custom_action_id; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_custom_actions_projects_on_custom_action_id ON backup_preview_5.custom_actions_projects USING btree (custom_action_id);


--
-- Name: index_custom_actions_projects_on_project_id; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_custom_actions_projects_on_project_id ON backup_preview_5.custom_actions_projects USING btree (project_id);


--
-- Name: index_custom_actions_roles_on_custom_action_id; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_custom_actions_roles_on_custom_action_id ON backup_preview_5.custom_actions_roles USING btree (custom_action_id);


--
-- Name: index_custom_actions_roles_on_role_id; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_custom_actions_roles_on_role_id ON backup_preview_5.custom_actions_roles USING btree (role_id);


--
-- Name: index_custom_actions_statuses_on_custom_action_id; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_custom_actions_statuses_on_custom_action_id ON backup_preview_5.custom_actions_statuses USING btree (custom_action_id);


--
-- Name: index_custom_actions_statuses_on_status_id; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_custom_actions_statuses_on_status_id ON backup_preview_5.custom_actions_statuses USING btree (status_id);


--
-- Name: index_custom_actions_types_on_custom_action_id; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_custom_actions_types_on_custom_action_id ON backup_preview_5.custom_actions_types USING btree (custom_action_id);


--
-- Name: index_custom_actions_types_on_type_id; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_custom_actions_types_on_type_id ON backup_preview_5.custom_actions_types USING btree (type_id);


--
-- Name: index_custom_fields_on_id_and_type; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_custom_fields_on_id_and_type ON backup_preview_5.custom_fields USING btree (id, type);


--
-- Name: index_custom_fields_projects_on_custom_field_id_and_project_id; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE UNIQUE INDEX index_custom_fields_projects_on_custom_field_id_and_project_id ON backup_preview_5.custom_fields_projects USING btree (custom_field_id, project_id);


--
-- Name: index_custom_values_on_custom_field_id; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_custom_values_on_custom_field_id ON backup_preview_5.custom_values USING btree (custom_field_id);


--
-- Name: index_custom_values_on_value; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_custom_values_on_value ON backup_preview_5.custom_values USING gin (value gin_trgm_ops);


--
-- Name: index_customizable_journals_on_custom_field_id; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_customizable_journals_on_custom_field_id ON backup_preview_5.customizable_journals USING btree (custom_field_id);


--
-- Name: index_customizable_journals_on_journal_id; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_customizable_journals_on_journal_id ON backup_preview_5.customizable_journals USING btree (journal_id);


--
-- Name: index_delayed_job_statuses_on_job_id; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE UNIQUE INDEX index_delayed_job_statuses_on_job_id ON backup_preview_5.delayed_job_statuses USING btree (job_id);


--
-- Name: index_delayed_job_statuses_on_reference_type_and_reference_id; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE UNIQUE INDEX index_delayed_job_statuses_on_reference_type_and_reference_id ON backup_preview_5.delayed_job_statuses USING btree (reference_type, reference_id);


--
-- Name: index_delayed_job_statuses_on_user_id; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_delayed_job_statuses_on_user_id ON backup_preview_5.delayed_job_statuses USING btree (user_id);


--
-- Name: index_design_colors_on_variable; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE UNIQUE INDEX index_design_colors_on_variable ON backup_preview_5.design_colors USING btree (variable);


--
-- Name: index_documents_on_category_id; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_documents_on_category_id ON backup_preview_5.documents USING btree (category_id);


--
-- Name: index_documents_on_created_at; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_documents_on_created_at ON backup_preview_5.documents USING btree (created_at);


--
-- Name: index_enabled_modules_on_name; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_enabled_modules_on_name ON backup_preview_5.enabled_modules USING btree (name);


--
-- Name: index_enumerations_on_color_id; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_enumerations_on_color_id ON backup_preview_5.enumerations USING btree (color_id);


--
-- Name: index_enumerations_on_id_and_type; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_enumerations_on_id_and_type ON backup_preview_5.enumerations USING btree (id, type);


--
-- Name: index_enumerations_on_project_id; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_enumerations_on_project_id ON backup_preview_5.enumerations USING btree (project_id);


--
-- Name: index_file_links_on_container_id_and_container_type; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_file_links_on_container_id_and_container_type ON backup_preview_5.file_links USING btree (container_id, container_type);


--
-- Name: index_file_links_on_creator_id; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_file_links_on_creator_id ON backup_preview_5.file_links USING btree (creator_id);


--
-- Name: index_file_links_on_origin_id_and_storage_id; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_file_links_on_origin_id_and_storage_id ON backup_preview_5.file_links USING btree (origin_id, storage_id);


--
-- Name: index_file_links_on_storage_id; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_file_links_on_storage_id ON backup_preview_5.file_links USING btree (storage_id);


--
-- Name: index_forums_on_last_message_id; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_forums_on_last_message_id ON backup_preview_5.forums USING btree (last_message_id);


--
-- Name: index_github_check_runs_on_github_pull_request_id; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_github_check_runs_on_github_pull_request_id ON backup_preview_5.github_check_runs USING btree (github_pull_request_id);


--
-- Name: index_github_pull_requests_on_github_user_id; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_github_pull_requests_on_github_user_id ON backup_preview_5.github_pull_requests USING btree (github_user_id);


--
-- Name: index_github_pull_requests_on_merged_by_id; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_github_pull_requests_on_merged_by_id ON backup_preview_5.github_pull_requests USING btree (merged_by_id);


--
-- Name: index_grid_widgets_on_grid_id; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_grid_widgets_on_grid_id ON backup_preview_5.grid_widgets USING btree (grid_id);


--
-- Name: index_grids_on_project_id; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_grids_on_project_id ON backup_preview_5.grids USING btree (project_id);


--
-- Name: index_grids_on_user_id; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_grids_on_user_id ON backup_preview_5.grids USING btree (user_id);


--
-- Name: index_group_users_on_user_id_and_group_id; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE UNIQUE INDEX index_group_users_on_user_id_and_group_id ON backup_preview_5.group_users USING btree (user_id, group_id);


--
-- Name: index_ical_token_query_assignments_on_ical_token_id; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_ical_token_query_assignments_on_ical_token_id ON backup_preview_5.ical_token_query_assignments USING btree (ical_token_id);


--
-- Name: index_ical_token_query_assignments_on_query_id; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_ical_token_query_assignments_on_query_id ON backup_preview_5.ical_token_query_assignments USING btree (query_id);


--
-- Name: index_ifc_models_on_is_default; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_ifc_models_on_is_default ON backup_preview_5.ifc_models USING btree (is_default);


--
-- Name: index_ifc_models_on_project_id; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_ifc_models_on_project_id ON backup_preview_5.ifc_models USING btree (project_id);


--
-- Name: index_ifc_models_on_uploader_id; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_ifc_models_on_uploader_id ON backup_preview_5.ifc_models USING btree (uploader_id);


--
-- Name: index_journals_on_created_at; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_journals_on_created_at ON backup_preview_5.journals USING btree (created_at);


--
-- Name: index_journals_on_data_id_and_data_type; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE UNIQUE INDEX index_journals_on_data_id_and_data_type ON backup_preview_5.journals USING btree (data_id, data_type);


--
-- Name: index_journals_on_journable_id; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_journals_on_journable_id ON backup_preview_5.journals USING btree (journable_id);


--
-- Name: index_journals_on_journable_type; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_journals_on_journable_type ON backup_preview_5.journals USING btree (journable_type);


--
-- Name: index_journals_on_journable_type_and_journable_id_and_version; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE UNIQUE INDEX index_journals_on_journable_type_and_journable_id_and_version ON backup_preview_5.journals USING btree (journable_type, journable_id, version);


--
-- Name: index_journals_on_notes; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_journals_on_notes ON backup_preview_5.journals USING gin (notes gin_trgm_ops);


--
-- Name: index_journals_on_user_id; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_journals_on_user_id ON backup_preview_5.journals USING btree (user_id);


--
-- Name: index_last_project_folders_on_projects_storage_id; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_last_project_folders_on_projects_storage_id ON backup_preview_5.last_project_folders USING btree (projects_storage_id);


--
-- Name: index_last_project_folders_on_projects_storage_id_and_mode; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE UNIQUE INDEX index_last_project_folders_on_projects_storage_id_and_mode ON backup_preview_5.last_project_folders USING btree (projects_storage_id, mode);


--
-- Name: index_ldap_groups_memberships_on_group_id; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_ldap_groups_memberships_on_group_id ON backup_preview_5.ldap_groups_memberships USING btree (group_id);


--
-- Name: index_ldap_groups_memberships_on_user_id; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_ldap_groups_memberships_on_user_id ON backup_preview_5.ldap_groups_memberships USING btree (user_id);


--
-- Name: index_ldap_groups_memberships_on_user_id_and_group_id; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE UNIQUE INDEX index_ldap_groups_memberships_on_user_id_and_group_id ON backup_preview_5.ldap_groups_memberships USING btree (user_id, group_id);


--
-- Name: index_ldap_groups_synchronized_filters_on_auth_source_id; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_ldap_groups_synchronized_filters_on_auth_source_id ON backup_preview_5.ldap_groups_synchronized_filters USING btree (auth_source_id);


--
-- Name: index_ldap_groups_synchronized_groups_on_auth_source_id; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_ldap_groups_synchronized_groups_on_auth_source_id ON backup_preview_5.ldap_groups_synchronized_groups USING btree (auth_source_id);


--
-- Name: index_ldap_groups_synchronized_groups_on_filter_id; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_ldap_groups_synchronized_groups_on_filter_id ON backup_preview_5.ldap_groups_synchronized_groups USING btree (filter_id);


--
-- Name: index_ldap_groups_synchronized_groups_on_group_id; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_ldap_groups_synchronized_groups_on_group_id ON backup_preview_5.ldap_groups_synchronized_groups USING btree (group_id);


--
-- Name: index_meetings_on_project_id_and_updated_at; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_meetings_on_project_id_and_updated_at ON backup_preview_5.meetings USING btree (project_id, updated_at);


--
-- Name: index_member_roles_on_inherited_from; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_member_roles_on_inherited_from ON backup_preview_5.member_roles USING btree (inherited_from);


--
-- Name: index_member_roles_on_member_id; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_member_roles_on_member_id ON backup_preview_5.member_roles USING btree (member_id);


--
-- Name: index_member_roles_on_role_id; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_member_roles_on_role_id ON backup_preview_5.member_roles USING btree (role_id);


--
-- Name: index_members_on_project_id; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_members_on_project_id ON backup_preview_5.members USING btree (project_id);


--
-- Name: index_members_on_user_id; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_members_on_user_id ON backup_preview_5.members USING btree (user_id);


--
-- Name: index_members_on_user_id_and_project_id; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE UNIQUE INDEX index_members_on_user_id_and_project_id ON backup_preview_5.members USING btree (user_id, project_id);


--
-- Name: index_menu_items_on_navigatable_id_and_title; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_menu_items_on_navigatable_id_and_title ON backup_preview_5.menu_items USING btree (navigatable_id, title);


--
-- Name: index_menu_items_on_parent_id; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_menu_items_on_parent_id ON backup_preview_5.menu_items USING btree (parent_id);


--
-- Name: index_messages_on_author_id; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_messages_on_author_id ON backup_preview_5.messages USING btree (author_id);


--
-- Name: index_messages_on_created_at; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_messages_on_created_at ON backup_preview_5.messages USING btree (created_at);


--
-- Name: index_messages_on_forum_id_and_updated_at; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_messages_on_forum_id_and_updated_at ON backup_preview_5.messages USING btree (forum_id, updated_at);


--
-- Name: index_messages_on_last_reply_id; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_messages_on_last_reply_id ON backup_preview_5.messages USING btree (last_reply_id);


--
-- Name: index_news_journals_on_project_id; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_news_journals_on_project_id ON backup_preview_5.news_journals USING btree (project_id);


--
-- Name: index_news_on_author_id; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_news_on_author_id ON backup_preview_5.news USING btree (author_id);


--
-- Name: index_news_on_created_at; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_news_on_created_at ON backup_preview_5.news USING btree (created_at);


--
-- Name: index_news_on_project_id_and_created_at; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_news_on_project_id_and_created_at ON backup_preview_5.news USING btree (project_id, created_at);


--
-- Name: index_non_working_days_on_date; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE UNIQUE INDEX index_non_working_days_on_date ON backup_preview_5.non_working_days USING btree (date);


--
-- Name: index_notification_settings_on_document_added; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_notification_settings_on_document_added ON backup_preview_5.notification_settings USING btree (document_added);


--
-- Name: index_notification_settings_on_forum_messages; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_notification_settings_on_forum_messages ON backup_preview_5.notification_settings USING btree (forum_messages);


--
-- Name: index_notification_settings_on_membership_added; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_notification_settings_on_membership_added ON backup_preview_5.notification_settings USING btree (membership_added);


--
-- Name: index_notification_settings_on_membership_updated; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_notification_settings_on_membership_updated ON backup_preview_5.notification_settings USING btree (membership_updated);


--
-- Name: index_notification_settings_on_news_added; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_notification_settings_on_news_added ON backup_preview_5.notification_settings USING btree (news_added);


--
-- Name: index_notification_settings_on_news_commented; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_notification_settings_on_news_commented ON backup_preview_5.notification_settings USING btree (news_commented);


--
-- Name: index_notification_settings_on_project_id; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_notification_settings_on_project_id ON backup_preview_5.notification_settings USING btree (project_id);


--
-- Name: index_notification_settings_on_user_id; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_notification_settings_on_user_id ON backup_preview_5.notification_settings USING btree (user_id);


--
-- Name: index_notification_settings_on_wiki_page_added; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_notification_settings_on_wiki_page_added ON backup_preview_5.notification_settings USING btree (wiki_page_added);


--
-- Name: index_notification_settings_on_wiki_page_updated; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_notification_settings_on_wiki_page_updated ON backup_preview_5.notification_settings USING btree (wiki_page_updated);


--
-- Name: index_notification_settings_on_work_package_commented; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_notification_settings_on_work_package_commented ON backup_preview_5.notification_settings USING btree (work_package_commented);


--
-- Name: index_notification_settings_on_work_package_created; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_notification_settings_on_work_package_created ON backup_preview_5.notification_settings USING btree (work_package_created);


--
-- Name: index_notification_settings_on_work_package_prioritized; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_notification_settings_on_work_package_prioritized ON backup_preview_5.notification_settings USING btree (work_package_prioritized);


--
-- Name: index_notification_settings_on_work_package_processed; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_notification_settings_on_work_package_processed ON backup_preview_5.notification_settings USING btree (work_package_processed);


--
-- Name: index_notification_settings_on_work_package_scheduled; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_notification_settings_on_work_package_scheduled ON backup_preview_5.notification_settings USING btree (work_package_scheduled);


--
-- Name: index_notification_settings_unique_project; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE UNIQUE INDEX index_notification_settings_unique_project ON backup_preview_5.notification_settings USING btree (user_id, project_id) WHERE (project_id IS NOT NULL);


--
-- Name: index_notification_settings_unique_project_null; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE UNIQUE INDEX index_notification_settings_unique_project_null ON backup_preview_5.notification_settings USING btree (user_id) WHERE (project_id IS NULL);


--
-- Name: index_notifications_on_actor_id; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_notifications_on_actor_id ON backup_preview_5.notifications USING btree (actor_id);


--
-- Name: index_notifications_on_journal_id; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_notifications_on_journal_id ON backup_preview_5.notifications USING btree (journal_id);


--
-- Name: index_notifications_on_mail_alert_sent; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_notifications_on_mail_alert_sent ON backup_preview_5.notifications USING btree (mail_alert_sent);


--
-- Name: index_notifications_on_mail_reminder_sent; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_notifications_on_mail_reminder_sent ON backup_preview_5.notifications USING btree (mail_reminder_sent);


--
-- Name: index_notifications_on_project_id; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_notifications_on_project_id ON backup_preview_5.notifications USING btree (project_id);


--
-- Name: index_notifications_on_read_ian; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_notifications_on_read_ian ON backup_preview_5.notifications USING btree (read_ian);


--
-- Name: index_notifications_on_recipient_id; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_notifications_on_recipient_id ON backup_preview_5.notifications USING btree (recipient_id);


--
-- Name: index_notifications_on_resource; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_notifications_on_resource ON backup_preview_5.notifications USING btree (resource_type, resource_id);


--
-- Name: index_oauth_access_grants_on_application_id; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_oauth_access_grants_on_application_id ON backup_preview_5.oauth_access_grants USING btree (application_id);


--
-- Name: index_oauth_access_grants_on_resource_owner_id; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_oauth_access_grants_on_resource_owner_id ON backup_preview_5.oauth_access_grants USING btree (resource_owner_id);


--
-- Name: index_oauth_access_grants_on_token; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE UNIQUE INDEX index_oauth_access_grants_on_token ON backup_preview_5.oauth_access_grants USING btree (token);


--
-- Name: index_oauth_access_tokens_on_application_id; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_oauth_access_tokens_on_application_id ON backup_preview_5.oauth_access_tokens USING btree (application_id);


--
-- Name: index_oauth_access_tokens_on_refresh_token; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE UNIQUE INDEX index_oauth_access_tokens_on_refresh_token ON backup_preview_5.oauth_access_tokens USING btree (refresh_token);


--
-- Name: index_oauth_access_tokens_on_resource_owner_id; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_oauth_access_tokens_on_resource_owner_id ON backup_preview_5.oauth_access_tokens USING btree (resource_owner_id);


--
-- Name: index_oauth_access_tokens_on_token; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE UNIQUE INDEX index_oauth_access_tokens_on_token ON backup_preview_5.oauth_access_tokens USING btree (token);


--
-- Name: index_oauth_applications_on_integration; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_oauth_applications_on_integration ON backup_preview_5.oauth_applications USING btree (integration_type, integration_id);


--
-- Name: index_oauth_applications_on_owner_id_and_owner_type; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_oauth_applications_on_owner_id_and_owner_type ON backup_preview_5.oauth_applications USING btree (owner_id, owner_type);


--
-- Name: index_oauth_applications_on_uid; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE UNIQUE INDEX index_oauth_applications_on_uid ON backup_preview_5.oauth_applications USING btree (uid);


--
-- Name: index_oauth_client_tokens_on_oauth_client_id; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_oauth_client_tokens_on_oauth_client_id ON backup_preview_5.oauth_client_tokens USING btree (oauth_client_id);


--
-- Name: index_oauth_client_tokens_on_user_id; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_oauth_client_tokens_on_user_id ON backup_preview_5.oauth_client_tokens USING btree (user_id);


--
-- Name: index_oauth_client_tokens_on_user_id_and_oauth_client_id; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE UNIQUE INDEX index_oauth_client_tokens_on_user_id_and_oauth_client_id ON backup_preview_5.oauth_client_tokens USING btree (user_id, oauth_client_id);


--
-- Name: index_oauth_clients_on_integration; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE UNIQUE INDEX index_oauth_clients_on_integration ON backup_preview_5.oauth_clients USING btree (integration_type, integration_id);


--
-- Name: index_oidc_user_session_links_on_oidc_session; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_oidc_user_session_links_on_oidc_session ON backup_preview_5.oidc_user_session_links USING btree (oidc_session);


--
-- Name: index_oidc_user_session_links_on_session_id; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_oidc_user_session_links_on_session_id ON backup_preview_5.oidc_user_session_links USING btree (session_id);


--
-- Name: index_ordered_work_packages_on_position; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_ordered_work_packages_on_position ON backup_preview_5.ordered_work_packages USING btree ("position");


--
-- Name: index_ordered_work_packages_on_query_id; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_ordered_work_packages_on_query_id ON backup_preview_5.ordered_work_packages USING btree (query_id);


--
-- Name: index_ordered_work_packages_on_work_package_id; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_ordered_work_packages_on_work_package_id ON backup_preview_5.ordered_work_packages USING btree (work_package_id);


--
-- Name: index_paper_trail_audits_on_item_type_and_item_id; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_paper_trail_audits_on_item_type_and_item_id ON backup_preview_5.paper_trail_audits USING btree (item_type, item_id);


--
-- Name: index_projects_on_identifier; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE UNIQUE INDEX index_projects_on_identifier ON backup_preview_5.projects USING btree (identifier);


--
-- Name: index_projects_on_lft; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_projects_on_lft ON backup_preview_5.projects USING btree (lft);


--
-- Name: index_projects_on_lft_and_rgt; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_projects_on_lft_and_rgt ON backup_preview_5.projects USING btree (lft, rgt);


--
-- Name: index_projects_on_rgt; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_projects_on_rgt ON backup_preview_5.projects USING btree (rgt);


--
-- Name: index_projects_storages_on_creator_id; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_projects_storages_on_creator_id ON backup_preview_5.projects_storages USING btree (creator_id);


--
-- Name: index_projects_storages_on_project_id; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_projects_storages_on_project_id ON backup_preview_5.projects_storages USING btree (project_id);


--
-- Name: index_projects_storages_on_project_id_and_storage_id; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE UNIQUE INDEX index_projects_storages_on_project_id_and_storage_id ON backup_preview_5.projects_storages USING btree (project_id, storage_id);


--
-- Name: index_projects_storages_on_storage_id; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_projects_storages_on_storage_id ON backup_preview_5.projects_storages USING btree (storage_id);


--
-- Name: index_queries_on_project_id; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_queries_on_project_id ON backup_preview_5.queries USING btree (project_id);


--
-- Name: index_queries_on_updated_at; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_queries_on_updated_at ON backup_preview_5.queries USING btree (updated_at);


--
-- Name: index_queries_on_user_id; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_queries_on_user_id ON backup_preview_5.queries USING btree (user_id);


--
-- Name: index_recaptcha_entries_on_user_id; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_recaptcha_entries_on_user_id ON backup_preview_5.recaptcha_entries USING btree (user_id);


--
-- Name: index_relations_on_from_id; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_relations_on_from_id ON backup_preview_5.relations USING btree (from_id);


--
-- Name: index_relations_on_from_id_and_to_id_and_relation_type; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE UNIQUE INDEX index_relations_on_from_id_and_to_id_and_relation_type ON backup_preview_5.relations USING btree (from_id, to_id, relation_type);


--
-- Name: index_relations_on_to_id; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_relations_on_to_id ON backup_preview_5.relations USING btree (to_id);


--
-- Name: index_relations_on_to_id_and_from_id_and_relation_type; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE UNIQUE INDEX index_relations_on_to_id_and_from_id_and_relation_type ON backup_preview_5.relations USING btree (to_id, from_id, relation_type);


--
-- Name: index_repositories_on_project_id; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_repositories_on_project_id ON backup_preview_5.repositories USING btree (project_id);


--
-- Name: index_role_permissions_on_role_id; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_role_permissions_on_role_id ON backup_preview_5.role_permissions USING btree (role_id);


--
-- Name: index_sessions_on_session_id; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_sessions_on_session_id ON backup_preview_5.sessions USING btree (session_id);


--
-- Name: index_sessions_on_updated_at; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_sessions_on_updated_at ON backup_preview_5.sessions USING btree (updated_at);


--
-- Name: index_settings_on_name; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_settings_on_name ON backup_preview_5.settings USING btree (name);


--
-- Name: index_statuses_on_color_id; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_statuses_on_color_id ON backup_preview_5.statuses USING btree (color_id);


--
-- Name: index_statuses_on_is_closed; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_statuses_on_is_closed ON backup_preview_5.statuses USING btree (is_closed);


--
-- Name: index_statuses_on_is_default; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_statuses_on_is_default ON backup_preview_5.statuses USING btree (is_default);


--
-- Name: index_statuses_on_position; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_statuses_on_position ON backup_preview_5.statuses USING btree ("position");


--
-- Name: index_storages_on_creator_id; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_storages_on_creator_id ON backup_preview_5.storages USING btree (creator_id);


--
-- Name: index_storages_on_host; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE UNIQUE INDEX index_storages_on_host ON backup_preview_5.storages USING btree (host);


--
-- Name: index_storages_on_name; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE UNIQUE INDEX index_storages_on_name ON backup_preview_5.storages USING btree (name);


--
-- Name: index_teap_on_project_id_and_activity_id; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE UNIQUE INDEX index_teap_on_project_id_and_activity_id ON backup_preview_5.time_entry_activities_projects USING btree (project_id, activity_id);


--
-- Name: index_time_entries_on_activity_id; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_time_entries_on_activity_id ON backup_preview_5.time_entries USING btree (activity_id);


--
-- Name: index_time_entries_on_created_at; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_time_entries_on_created_at ON backup_preview_5.time_entries USING btree (created_at);


--
-- Name: index_time_entries_on_logged_by_id; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_time_entries_on_logged_by_id ON backup_preview_5.time_entries USING btree (logged_by_id);


--
-- Name: index_time_entries_on_project_id_and_updated_at; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_time_entries_on_project_id_and_updated_at ON backup_preview_5.time_entries USING btree (project_id, updated_at);


--
-- Name: index_time_entries_on_user_id; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_time_entries_on_user_id ON backup_preview_5.time_entries USING btree (user_id);


--
-- Name: index_time_entry_activities_projects_on_active; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_time_entry_activities_projects_on_active ON backup_preview_5.time_entry_activities_projects USING btree (active);


--
-- Name: index_time_entry_activities_projects_on_activity_id; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_time_entry_activities_projects_on_activity_id ON backup_preview_5.time_entry_activities_projects USING btree (activity_id);


--
-- Name: index_time_entry_activities_projects_on_project_id; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_time_entry_activities_projects_on_project_id ON backup_preview_5.time_entry_activities_projects USING btree (project_id);


--
-- Name: index_time_entry_journals_on_logged_by_id; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_time_entry_journals_on_logged_by_id ON backup_preview_5.time_entry_journals USING btree (logged_by_id);


--
-- Name: index_time_entry_journals_on_project_id; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_time_entry_journals_on_project_id ON backup_preview_5.time_entry_journals USING btree (project_id);


--
-- Name: index_tokens_on_user_id; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_tokens_on_user_id ON backup_preview_5.tokens USING btree (user_id);


--
-- Name: index_two_factor_authentication_devices_on_user_id; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_two_factor_authentication_devices_on_user_id ON backup_preview_5.two_factor_authentication_devices USING btree (user_id);


--
-- Name: index_types_on_color_id; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_types_on_color_id ON backup_preview_5.types USING btree (color_id);


--
-- Name: index_user_passwords_on_user_id; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_user_passwords_on_user_id ON backup_preview_5.user_passwords USING btree (user_id);


--
-- Name: index_user_preferences_on_user_id; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_user_preferences_on_user_id ON backup_preview_5.user_preferences USING btree (user_id);


--
-- Name: index_user_prefs_settings_daily_reminders_enabled; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_user_prefs_settings_daily_reminders_enabled ON backup_preview_5.user_preferences USING gin ((((settings -> 'daily_reminders'::text) -> 'enabled'::text)));


--
-- Name: index_user_prefs_settings_daily_reminders_times; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_user_prefs_settings_daily_reminders_times ON backup_preview_5.user_preferences USING gin ((((settings -> 'daily_reminders'::text) -> 'times'::text)));


--
-- Name: index_user_prefs_settings_pause_reminders_enabled; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_user_prefs_settings_pause_reminders_enabled ON backup_preview_5.user_preferences USING btree (((((settings -> 'pause_reminders'::text) ->> 'enabled'::text))::boolean));


--
-- Name: index_user_prefs_settings_time_zone; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_user_prefs_settings_time_zone ON backup_preview_5.user_preferences USING gin (((settings -> 'time_zone'::text)));


--
-- Name: index_user_prefs_settings_workdays; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_user_prefs_settings_workdays ON backup_preview_5.user_preferences USING gin (((settings -> 'workdays'::text)));


--
-- Name: index_users_on_auth_source_id; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_users_on_auth_source_id ON backup_preview_5.users USING btree (auth_source_id);


--
-- Name: index_users_on_id_and_type; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_users_on_id_and_type ON backup_preview_5.users USING btree (id, type);


--
-- Name: index_users_on_type; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_users_on_type ON backup_preview_5.users USING btree (type);


--
-- Name: index_users_on_type_and_login; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_users_on_type_and_login ON backup_preview_5.users USING btree (type, login);


--
-- Name: index_users_on_type_and_status; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_users_on_type_and_status ON backup_preview_5.users USING btree (type, status);


--
-- Name: index_version_settings_on_project_id_and_version_id; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_version_settings_on_project_id_and_version_id ON backup_preview_5.version_settings USING btree (project_id, version_id);


--
-- Name: index_versions_on_sharing; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_versions_on_sharing ON backup_preview_5.versions USING btree (sharing);


--
-- Name: index_views_on_query_id; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE UNIQUE INDEX index_views_on_query_id ON backup_preview_5.views USING btree (query_id);


--
-- Name: index_watchers_on_user_id; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_watchers_on_user_id ON backup_preview_5.watchers USING btree (user_id);


--
-- Name: index_watchers_on_watchable_id_and_watchable_type; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_watchers_on_watchable_id_and_watchable_type ON backup_preview_5.watchers USING btree (watchable_id, watchable_type);


--
-- Name: index_webhooks_events_on_webhooks_webhook_id; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_webhooks_events_on_webhooks_webhook_id ON backup_preview_5.webhooks_events USING btree (webhooks_webhook_id);


--
-- Name: index_webhooks_logs_on_webhooks_webhook_id; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_webhooks_logs_on_webhooks_webhook_id ON backup_preview_5.webhooks_logs USING btree (webhooks_webhook_id);


--
-- Name: index_webhooks_projects_on_project_id; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_webhooks_projects_on_project_id ON backup_preview_5.webhooks_projects USING btree (project_id);


--
-- Name: index_webhooks_projects_on_webhooks_webhook_id; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_webhooks_projects_on_webhooks_webhook_id ON backup_preview_5.webhooks_projects USING btree (webhooks_webhook_id);


--
-- Name: index_wiki_pages_on_author_id; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_wiki_pages_on_author_id ON backup_preview_5.wiki_pages USING btree (author_id);


--
-- Name: index_wiki_pages_on_parent_id; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_wiki_pages_on_parent_id ON backup_preview_5.wiki_pages USING btree (parent_id);


--
-- Name: index_wiki_pages_on_updated_at; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_wiki_pages_on_updated_at ON backup_preview_5.wiki_pages USING btree (updated_at);


--
-- Name: index_wiki_pages_on_wiki_id; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_wiki_pages_on_wiki_id ON backup_preview_5.wiki_pages USING btree (wiki_id);


--
-- Name: index_wiki_redirects_on_wiki_id; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_wiki_redirects_on_wiki_id ON backup_preview_5.wiki_redirects USING btree (wiki_id);


--
-- Name: index_work_package_journals_on_project_id; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_work_package_journals_on_project_id ON backup_preview_5.work_package_journals USING btree (project_id);


--
-- Name: index_work_packages_on_assigned_to_id; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_work_packages_on_assigned_to_id ON backup_preview_5.work_packages USING btree (assigned_to_id);


--
-- Name: index_work_packages_on_author_id; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_work_packages_on_author_id ON backup_preview_5.work_packages USING btree (author_id);


--
-- Name: index_work_packages_on_category_id; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_work_packages_on_category_id ON backup_preview_5.work_packages USING btree (category_id);


--
-- Name: index_work_packages_on_created_at; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_work_packages_on_created_at ON backup_preview_5.work_packages USING btree (created_at);


--
-- Name: index_work_packages_on_due_date; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_work_packages_on_due_date ON backup_preview_5.work_packages USING btree (due_date);


--
-- Name: index_work_packages_on_parent_id; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_work_packages_on_parent_id ON backup_preview_5.work_packages USING btree (parent_id);


--
-- Name: index_work_packages_on_project_id; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_work_packages_on_project_id ON backup_preview_5.work_packages USING btree (project_id);


--
-- Name: index_work_packages_on_project_id_and_updated_at; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_work_packages_on_project_id_and_updated_at ON backup_preview_5.work_packages USING btree (project_id, updated_at);


--
-- Name: index_work_packages_on_responsible_id; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_work_packages_on_responsible_id ON backup_preview_5.work_packages USING btree (responsible_id);


--
-- Name: index_work_packages_on_schedule_manually; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_work_packages_on_schedule_manually ON backup_preview_5.work_packages USING btree (schedule_manually) WHERE schedule_manually;


--
-- Name: index_work_packages_on_start_date; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_work_packages_on_start_date ON backup_preview_5.work_packages USING btree (start_date);


--
-- Name: index_work_packages_on_status_id; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_work_packages_on_status_id ON backup_preview_5.work_packages USING btree (status_id);


--
-- Name: index_work_packages_on_type_id; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_work_packages_on_type_id ON backup_preview_5.work_packages USING btree (type_id);


--
-- Name: index_work_packages_on_updated_at; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_work_packages_on_updated_at ON backup_preview_5.work_packages USING btree (updated_at);


--
-- Name: index_work_packages_on_version_id; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_work_packages_on_version_id ON backup_preview_5.work_packages USING btree (version_id);


--
-- Name: index_workflows_on_new_status_id; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_workflows_on_new_status_id ON backup_preview_5.workflows USING btree (new_status_id);


--
-- Name: index_workflows_on_old_status_id; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_workflows_on_old_status_id ON backup_preview_5.workflows USING btree (old_status_id);


--
-- Name: index_workflows_on_role_id; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX index_workflows_on_role_id ON backup_preview_5.workflows USING btree (role_id);


--
-- Name: issue_categories_project_id; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX issue_categories_project_id ON backup_preview_5.categories USING btree (project_id);


--
-- Name: messages_board_id; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX messages_board_id ON backup_preview_5.messages USING btree (forum_id);


--
-- Name: messages_parent_id; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX messages_parent_id ON backup_preview_5.messages USING btree (parent_id);


--
-- Name: news_project_id; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX news_project_id ON backup_preview_5.news USING btree (project_id);


--
-- Name: projects_types_project_id; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX projects_types_project_id ON backup_preview_5.projects_types USING btree (project_id);


--
-- Name: projects_types_unique; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE UNIQUE INDEX projects_types_unique ON backup_preview_5.projects_types USING btree (project_id, type_id);


--
-- Name: time_entries_issue_id; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX time_entries_issue_id ON backup_preview_5.time_entries USING btree (work_package_id);


--
-- Name: time_entries_project_id; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX time_entries_project_id ON backup_preview_5.time_entries USING btree (project_id);


--
-- Name: unique_index_gh_prs_wps_on_gh_pr_id_and_wp_id; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE UNIQUE INDEX unique_index_gh_prs_wps_on_gh_pr_id_and_wp_id ON backup_preview_5.github_pull_requests_work_packages USING btree (github_pull_request_id, work_package_id);


--
-- Name: unique_inherited_role; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE UNIQUE INDEX unique_inherited_role ON backup_preview_5.member_roles USING btree (member_id, role_id, inherited_from);


--
-- Name: unique_lastname_for_groups_and_placeholder_users; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE UNIQUE INDEX unique_lastname_for_groups_and_placeholder_users ON backup_preview_5.users USING btree (lastname, type) WHERE (((type)::text = 'Group'::text) OR ((type)::text = 'PlaceholderUser'::text));


--
-- Name: versions_project_id; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX versions_project_id ON backup_preview_5.versions USING btree (project_id);


--
-- Name: watchers_user_id_type; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX watchers_user_id_type ON backup_preview_5.watchers USING btree (user_id, watchable_type);


--
-- Name: wiki_pages_wiki_id_slug; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE UNIQUE INDEX wiki_pages_wiki_id_slug ON backup_preview_5.wiki_pages USING btree (wiki_id, slug);


--
-- Name: wiki_pages_wiki_id_title; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX wiki_pages_wiki_id_title ON backup_preview_5.wiki_pages USING btree (wiki_id, title);


--
-- Name: wiki_redirects_wiki_id_title; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX wiki_redirects_wiki_id_title ON backup_preview_5.wiki_redirects USING btree (wiki_id, title);


--
-- Name: wikis_project_id; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX wikis_project_id ON backup_preview_5.wikis USING btree (project_id);


--
-- Name: wkfs_role_type_old_status; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX wkfs_role_type_old_status ON backup_preview_5.workflows USING btree (role_id, type_id, old_status_id);


--
-- Name: work_package_anc_desc_idx; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE UNIQUE INDEX work_package_anc_desc_idx ON backup_preview_5.work_package_hierarchies USING btree (ancestor_id, descendant_id, generations);


--
-- Name: work_package_desc_idx; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX work_package_desc_idx ON backup_preview_5.work_package_hierarchies USING btree (descendant_id);


--
-- Name: work_package_journal_on_burndown_attributes; Type: INDEX; Schema: backup_preview_5; Owner: -
--

CREATE INDEX work_package_journal_on_burndown_attributes ON backup_preview_5.work_package_journals USING btree (version_id, status_id, project_id, type_id);


--
-- Name: changesets_changeset_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX changesets_changeset_id ON public.changes USING btree (changeset_id);


--
-- Name: changesets_repos_rev; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX changesets_repos_rev ON public.changesets USING btree (repository_id, revision);


--
-- Name: changesets_repos_scmid; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX changesets_repos_scmid ON public.changesets USING btree (repository_id, scmid);


--
-- Name: changesets_work_packages_ids; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX changesets_work_packages_ids ON public.changesets_work_packages USING btree (changeset_id, work_package_id);


--
-- Name: custom_fields_types_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX custom_fields_types_unique ON public.custom_fields_types USING btree (custom_field_id, type_id);


--
-- Name: custom_values_customized; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX custom_values_customized ON public.custom_values USING btree (customized_type, customized_id);


--
-- Name: delayed_jobs_priority; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX delayed_jobs_priority ON public.delayed_jobs USING btree (priority, run_at);


--
-- Name: documents_project_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX documents_project_id ON public.documents USING btree (project_id);


--
-- Name: enabled_modules_project_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX enabled_modules_project_id ON public.enabled_modules USING btree (project_id);


--
-- Name: forums_project_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX forums_project_id ON public.forums USING btree (project_id);


--
-- Name: github_pr_wp_pr_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX github_pr_wp_pr_id ON public.github_pull_requests_work_packages USING btree (github_pull_request_id);


--
-- Name: group_user_ids; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX group_user_ids ON public.group_users USING btree (group_id, user_id);


--
-- Name: index_announcements_on_show_until_and_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_announcements_on_show_until_and_active ON public.announcements USING btree (show_until, active);


--
-- Name: index_attachable_journals_on_attachment_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_attachable_journals_on_attachment_id ON public.attachable_journals USING btree (attachment_id);


--
-- Name: index_attachable_journals_on_journal_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_attachable_journals_on_journal_id ON public.attachable_journals USING btree (journal_id);


--
-- Name: index_attachments_on_author_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_attachments_on_author_id ON public.attachments USING btree (author_id);


--
-- Name: index_attachments_on_container_id_and_container_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_attachments_on_container_id_and_container_type ON public.attachments USING btree (container_id, container_type);


--
-- Name: index_attachments_on_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_attachments_on_created_at ON public.attachments USING btree (created_at);


--
-- Name: index_attachments_on_file_tsv; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_attachments_on_file_tsv ON public.attachments USING gin (file_tsv);


--
-- Name: index_attachments_on_fulltext_tsv; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_attachments_on_fulltext_tsv ON public.attachments USING gin (fulltext_tsv);


--
-- Name: index_auth_sources_on_id_and_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_auth_sources_on_id_and_type ON public.auth_sources USING btree (id, type);


--
-- Name: index_backups_on_creator_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_backups_on_creator_id ON public.backups USING btree (creator_id);


--
-- Name: index_bcf_comments_on_issue_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_bcf_comments_on_issue_id ON public.bcf_comments USING btree (issue_id);


--
-- Name: index_bcf_comments_on_journal_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_bcf_comments_on_journal_id ON public.bcf_comments USING btree (journal_id);


--
-- Name: index_bcf_comments_on_uuid; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_bcf_comments_on_uuid ON public.bcf_comments USING btree (uuid);


--
-- Name: index_bcf_comments_on_uuid_and_issue_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_bcf_comments_on_uuid_and_issue_id ON public.bcf_comments USING btree (uuid, issue_id);


--
-- Name: index_bcf_comments_on_viewpoint_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_bcf_comments_on_viewpoint_id ON public.bcf_comments USING btree (viewpoint_id);


--
-- Name: index_bcf_issues_on_uuid; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_bcf_issues_on_uuid ON public.bcf_issues USING btree (uuid);


--
-- Name: index_bcf_issues_on_work_package_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_bcf_issues_on_work_package_id ON public.bcf_issues USING btree (work_package_id);


--
-- Name: index_bcf_viewpoints_on_issue_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_bcf_viewpoints_on_issue_id ON public.bcf_viewpoints USING btree (issue_id);


--
-- Name: index_bcf_viewpoints_on_uuid; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_bcf_viewpoints_on_uuid ON public.bcf_viewpoints USING btree (uuid);


--
-- Name: index_bcf_viewpoints_on_uuid_and_issue_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_bcf_viewpoints_on_uuid_and_issue_id ON public.bcf_viewpoints USING btree (uuid, issue_id);


--
-- Name: index_budgets_on_project_id_and_updated_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_budgets_on_project_id_and_updated_at ON public.budgets USING btree (project_id, updated_at);


--
-- Name: index_categories_on_assigned_to_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_categories_on_assigned_to_id ON public.categories USING btree (assigned_to_id);


--
-- Name: index_changesets_on_committed_on; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_changesets_on_committed_on ON public.changesets USING btree (committed_on);


--
-- Name: index_changesets_on_repository_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_changesets_on_repository_id ON public.changesets USING btree (repository_id);


--
-- Name: index_changesets_on_repository_id_and_committed_on; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_changesets_on_repository_id_and_committed_on ON public.changesets USING btree (repository_id, committed_on);


--
-- Name: index_changesets_on_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_changesets_on_user_id ON public.changesets USING btree (user_id);


--
-- Name: index_comments_on_author_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_comments_on_author_id ON public.comments USING btree (author_id);


--
-- Name: index_comments_on_commented_id_and_commented_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_comments_on_commented_id_and_commented_type ON public.comments USING btree (commented_id, commented_type);


--
-- Name: index_cost_entries_on_logged_by_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_cost_entries_on_logged_by_id ON public.cost_entries USING btree (logged_by_id);


--
-- Name: index_custom_actions_projects_on_custom_action_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_custom_actions_projects_on_custom_action_id ON public.custom_actions_projects USING btree (custom_action_id);


--
-- Name: index_custom_actions_projects_on_project_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_custom_actions_projects_on_project_id ON public.custom_actions_projects USING btree (project_id);


--
-- Name: index_custom_actions_roles_on_custom_action_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_custom_actions_roles_on_custom_action_id ON public.custom_actions_roles USING btree (custom_action_id);


--
-- Name: index_custom_actions_roles_on_role_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_custom_actions_roles_on_role_id ON public.custom_actions_roles USING btree (role_id);


--
-- Name: index_custom_actions_statuses_on_custom_action_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_custom_actions_statuses_on_custom_action_id ON public.custom_actions_statuses USING btree (custom_action_id);


--
-- Name: index_custom_actions_statuses_on_status_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_custom_actions_statuses_on_status_id ON public.custom_actions_statuses USING btree (status_id);


--
-- Name: index_custom_actions_types_on_custom_action_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_custom_actions_types_on_custom_action_id ON public.custom_actions_types USING btree (custom_action_id);


--
-- Name: index_custom_actions_types_on_type_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_custom_actions_types_on_type_id ON public.custom_actions_types USING btree (type_id);


--
-- Name: index_custom_fields_on_id_and_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_custom_fields_on_id_and_type ON public.custom_fields USING btree (id, type);


--
-- Name: index_custom_fields_projects_on_custom_field_id_and_project_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_custom_fields_projects_on_custom_field_id_and_project_id ON public.custom_fields_projects USING btree (custom_field_id, project_id);


--
-- Name: index_custom_values_on_custom_field_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_custom_values_on_custom_field_id ON public.custom_values USING btree (custom_field_id);


--
-- Name: index_custom_values_on_value; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_custom_values_on_value ON public.custom_values USING gin (value gin_trgm_ops);


--
-- Name: index_customizable_journals_on_custom_field_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_customizable_journals_on_custom_field_id ON public.customizable_journals USING btree (custom_field_id);


--
-- Name: index_customizable_journals_on_journal_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_customizable_journals_on_journal_id ON public.customizable_journals USING btree (journal_id);


--
-- Name: index_delayed_job_statuses_on_job_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_delayed_job_statuses_on_job_id ON public.delayed_job_statuses USING btree (job_id);


--
-- Name: index_delayed_job_statuses_on_reference_type_and_reference_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_delayed_job_statuses_on_reference_type_and_reference_id ON public.delayed_job_statuses USING btree (reference_type, reference_id);


--
-- Name: index_delayed_job_statuses_on_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_delayed_job_statuses_on_user_id ON public.delayed_job_statuses USING btree (user_id);


--
-- Name: index_design_colors_on_variable; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_design_colors_on_variable ON public.design_colors USING btree (variable);


--
-- Name: index_documents_on_category_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_documents_on_category_id ON public.documents USING btree (category_id);


--
-- Name: index_documents_on_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_documents_on_created_at ON public.documents USING btree (created_at);


--
-- Name: index_enabled_modules_on_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_enabled_modules_on_name ON public.enabled_modules USING btree (name);


--
-- Name: index_enumerations_on_color_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_enumerations_on_color_id ON public.enumerations USING btree (color_id);


--
-- Name: index_enumerations_on_id_and_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_enumerations_on_id_and_type ON public.enumerations USING btree (id, type);


--
-- Name: index_enumerations_on_project_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_enumerations_on_project_id ON public.enumerations USING btree (project_id);


--
-- Name: index_file_links_on_container_id_and_container_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_file_links_on_container_id_and_container_type ON public.file_links USING btree (container_id, container_type);


--
-- Name: index_file_links_on_creator_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_file_links_on_creator_id ON public.file_links USING btree (creator_id);


--
-- Name: index_file_links_on_origin_id_and_storage_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_file_links_on_origin_id_and_storage_id ON public.file_links USING btree (origin_id, storage_id);


--
-- Name: index_file_links_on_storage_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_file_links_on_storage_id ON public.file_links USING btree (storage_id);


--
-- Name: index_forums_on_last_message_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_forums_on_last_message_id ON public.forums USING btree (last_message_id);


--
-- Name: index_github_check_runs_on_github_pull_request_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_github_check_runs_on_github_pull_request_id ON public.github_check_runs USING btree (github_pull_request_id);


--
-- Name: index_github_pull_requests_on_github_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_github_pull_requests_on_github_user_id ON public.github_pull_requests USING btree (github_user_id);


--
-- Name: index_github_pull_requests_on_merged_by_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_github_pull_requests_on_merged_by_id ON public.github_pull_requests USING btree (merged_by_id);


--
-- Name: index_grid_widgets_on_grid_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_grid_widgets_on_grid_id ON public.grid_widgets USING btree (grid_id);


--
-- Name: index_grids_on_project_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_grids_on_project_id ON public.grids USING btree (project_id);


--
-- Name: index_grids_on_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_grids_on_user_id ON public.grids USING btree (user_id);


--
-- Name: index_group_users_on_user_id_and_group_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_group_users_on_user_id_and_group_id ON public.group_users USING btree (user_id, group_id);


--
-- Name: index_ical_token_query_assignments_on_ical_token_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_ical_token_query_assignments_on_ical_token_id ON public.ical_token_query_assignments USING btree (ical_token_id);


--
-- Name: index_ical_token_query_assignments_on_query_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_ical_token_query_assignments_on_query_id ON public.ical_token_query_assignments USING btree (query_id);


--
-- Name: index_ifc_models_on_is_default; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_ifc_models_on_is_default ON public.ifc_models USING btree (is_default);


--
-- Name: index_ifc_models_on_project_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_ifc_models_on_project_id ON public.ifc_models USING btree (project_id);


--
-- Name: index_ifc_models_on_uploader_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_ifc_models_on_uploader_id ON public.ifc_models USING btree (uploader_id);


--
-- Name: index_journals_on_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_journals_on_created_at ON public.journals USING btree (created_at);


--
-- Name: index_journals_on_data_id_and_data_type; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_journals_on_data_id_and_data_type ON public.journals USING btree (data_id, data_type);


--
-- Name: index_journals_on_journable_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_journals_on_journable_id ON public.journals USING btree (journable_id);


--
-- Name: index_journals_on_journable_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_journals_on_journable_type ON public.journals USING btree (journable_type);


--
-- Name: index_journals_on_journable_type_and_journable_id_and_version; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_journals_on_journable_type_and_journable_id_and_version ON public.journals USING btree (journable_type, journable_id, version);


--
-- Name: index_journals_on_notes; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_journals_on_notes ON public.journals USING gin (notes gin_trgm_ops);


--
-- Name: index_journals_on_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_journals_on_user_id ON public.journals USING btree (user_id);


--
-- Name: index_last_project_folders_on_projects_storage_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_last_project_folders_on_projects_storage_id ON public.last_project_folders USING btree (projects_storage_id);


--
-- Name: index_last_project_folders_on_projects_storage_id_and_mode; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_last_project_folders_on_projects_storage_id_and_mode ON public.last_project_folders USING btree (projects_storage_id, mode);


--
-- Name: index_ldap_groups_memberships_on_group_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_ldap_groups_memberships_on_group_id ON public.ldap_groups_memberships USING btree (group_id);


--
-- Name: index_ldap_groups_memberships_on_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_ldap_groups_memberships_on_user_id ON public.ldap_groups_memberships USING btree (user_id);


--
-- Name: index_ldap_groups_memberships_on_user_id_and_group_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_ldap_groups_memberships_on_user_id_and_group_id ON public.ldap_groups_memberships USING btree (user_id, group_id);


--
-- Name: index_ldap_groups_synchronized_filters_on_auth_source_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_ldap_groups_synchronized_filters_on_auth_source_id ON public.ldap_groups_synchronized_filters USING btree (auth_source_id);


--
-- Name: index_ldap_groups_synchronized_groups_on_auth_source_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_ldap_groups_synchronized_groups_on_auth_source_id ON public.ldap_groups_synchronized_groups USING btree (auth_source_id);


--
-- Name: index_ldap_groups_synchronized_groups_on_filter_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_ldap_groups_synchronized_groups_on_filter_id ON public.ldap_groups_synchronized_groups USING btree (filter_id);


--
-- Name: index_ldap_groups_synchronized_groups_on_group_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_ldap_groups_synchronized_groups_on_group_id ON public.ldap_groups_synchronized_groups USING btree (group_id);


--
-- Name: index_meetings_on_project_id_and_updated_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_meetings_on_project_id_and_updated_at ON public.meetings USING btree (project_id, updated_at);


--
-- Name: index_member_roles_on_inherited_from; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_member_roles_on_inherited_from ON public.member_roles USING btree (inherited_from);


--
-- Name: index_member_roles_on_member_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_member_roles_on_member_id ON public.member_roles USING btree (member_id);


--
-- Name: index_member_roles_on_role_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_member_roles_on_role_id ON public.member_roles USING btree (role_id);


--
-- Name: index_members_on_project_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_members_on_project_id ON public.members USING btree (project_id);


--
-- Name: index_members_on_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_members_on_user_id ON public.members USING btree (user_id);


--
-- Name: index_members_on_user_id_and_project_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_members_on_user_id_and_project_id ON public.members USING btree (user_id, project_id);


--
-- Name: index_menu_items_on_navigatable_id_and_title; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_menu_items_on_navigatable_id_and_title ON public.menu_items USING btree (navigatable_id, title);


--
-- Name: index_menu_items_on_parent_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_menu_items_on_parent_id ON public.menu_items USING btree (parent_id);


--
-- Name: index_messages_on_author_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_messages_on_author_id ON public.messages USING btree (author_id);


--
-- Name: index_messages_on_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_messages_on_created_at ON public.messages USING btree (created_at);


--
-- Name: index_messages_on_forum_id_and_updated_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_messages_on_forum_id_and_updated_at ON public.messages USING btree (forum_id, updated_at);


--
-- Name: index_messages_on_last_reply_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_messages_on_last_reply_id ON public.messages USING btree (last_reply_id);


--
-- Name: index_news_journals_on_project_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_news_journals_on_project_id ON public.news_journals USING btree (project_id);


--
-- Name: index_news_on_author_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_news_on_author_id ON public.news USING btree (author_id);


--
-- Name: index_news_on_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_news_on_created_at ON public.news USING btree (created_at);


--
-- Name: index_news_on_project_id_and_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_news_on_project_id_and_created_at ON public.news USING btree (project_id, created_at);


--
-- Name: index_non_working_days_on_date; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_non_working_days_on_date ON public.non_working_days USING btree (date);


--
-- Name: index_notification_settings_on_document_added; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_notification_settings_on_document_added ON public.notification_settings USING btree (document_added);


--
-- Name: index_notification_settings_on_forum_messages; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_notification_settings_on_forum_messages ON public.notification_settings USING btree (forum_messages);


--
-- Name: index_notification_settings_on_membership_added; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_notification_settings_on_membership_added ON public.notification_settings USING btree (membership_added);


--
-- Name: index_notification_settings_on_membership_updated; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_notification_settings_on_membership_updated ON public.notification_settings USING btree (membership_updated);


--
-- Name: index_notification_settings_on_news_added; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_notification_settings_on_news_added ON public.notification_settings USING btree (news_added);


--
-- Name: index_notification_settings_on_news_commented; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_notification_settings_on_news_commented ON public.notification_settings USING btree (news_commented);


--
-- Name: index_notification_settings_on_project_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_notification_settings_on_project_id ON public.notification_settings USING btree (project_id);


--
-- Name: index_notification_settings_on_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_notification_settings_on_user_id ON public.notification_settings USING btree (user_id);


--
-- Name: index_notification_settings_on_wiki_page_added; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_notification_settings_on_wiki_page_added ON public.notification_settings USING btree (wiki_page_added);


--
-- Name: index_notification_settings_on_wiki_page_updated; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_notification_settings_on_wiki_page_updated ON public.notification_settings USING btree (wiki_page_updated);


--
-- Name: index_notification_settings_on_work_package_commented; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_notification_settings_on_work_package_commented ON public.notification_settings USING btree (work_package_commented);


--
-- Name: index_notification_settings_on_work_package_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_notification_settings_on_work_package_created ON public.notification_settings USING btree (work_package_created);


--
-- Name: index_notification_settings_on_work_package_prioritized; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_notification_settings_on_work_package_prioritized ON public.notification_settings USING btree (work_package_prioritized);


--
-- Name: index_notification_settings_on_work_package_processed; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_notification_settings_on_work_package_processed ON public.notification_settings USING btree (work_package_processed);


--
-- Name: index_notification_settings_on_work_package_scheduled; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_notification_settings_on_work_package_scheduled ON public.notification_settings USING btree (work_package_scheduled);


--
-- Name: index_notification_settings_unique_project; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_notification_settings_unique_project ON public.notification_settings USING btree (user_id, project_id) WHERE (project_id IS NOT NULL);


--
-- Name: index_notification_settings_unique_project_null; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_notification_settings_unique_project_null ON public.notification_settings USING btree (user_id) WHERE (project_id IS NULL);


--
-- Name: index_notifications_on_actor_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_notifications_on_actor_id ON public.notifications USING btree (actor_id);


--
-- Name: index_notifications_on_journal_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_notifications_on_journal_id ON public.notifications USING btree (journal_id);


--
-- Name: index_notifications_on_mail_alert_sent; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_notifications_on_mail_alert_sent ON public.notifications USING btree (mail_alert_sent);


--
-- Name: index_notifications_on_mail_reminder_sent; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_notifications_on_mail_reminder_sent ON public.notifications USING btree (mail_reminder_sent);


--
-- Name: index_notifications_on_project_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_notifications_on_project_id ON public.notifications USING btree (project_id);


--
-- Name: index_notifications_on_read_ian; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_notifications_on_read_ian ON public.notifications USING btree (read_ian);


--
-- Name: index_notifications_on_recipient_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_notifications_on_recipient_id ON public.notifications USING btree (recipient_id);


--
-- Name: index_notifications_on_resource; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_notifications_on_resource ON public.notifications USING btree (resource_type, resource_id);


--
-- Name: index_oauth_access_grants_on_application_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_oauth_access_grants_on_application_id ON public.oauth_access_grants USING btree (application_id);


--
-- Name: index_oauth_access_grants_on_resource_owner_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_oauth_access_grants_on_resource_owner_id ON public.oauth_access_grants USING btree (resource_owner_id);


--
-- Name: index_oauth_access_grants_on_token; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_oauth_access_grants_on_token ON public.oauth_access_grants USING btree (token);


--
-- Name: index_oauth_access_tokens_on_application_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_oauth_access_tokens_on_application_id ON public.oauth_access_tokens USING btree (application_id);


--
-- Name: index_oauth_access_tokens_on_refresh_token; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_oauth_access_tokens_on_refresh_token ON public.oauth_access_tokens USING btree (refresh_token);


--
-- Name: index_oauth_access_tokens_on_resource_owner_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_oauth_access_tokens_on_resource_owner_id ON public.oauth_access_tokens USING btree (resource_owner_id);


--
-- Name: index_oauth_access_tokens_on_token; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_oauth_access_tokens_on_token ON public.oauth_access_tokens USING btree (token);


--
-- Name: index_oauth_applications_on_integration; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_oauth_applications_on_integration ON public.oauth_applications USING btree (integration_type, integration_id);


--
-- Name: index_oauth_applications_on_owner_id_and_owner_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_oauth_applications_on_owner_id_and_owner_type ON public.oauth_applications USING btree (owner_id, owner_type);


--
-- Name: index_oauth_applications_on_uid; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_oauth_applications_on_uid ON public.oauth_applications USING btree (uid);


--
-- Name: index_oauth_client_tokens_on_oauth_client_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_oauth_client_tokens_on_oauth_client_id ON public.oauth_client_tokens USING btree (oauth_client_id);


--
-- Name: index_oauth_client_tokens_on_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_oauth_client_tokens_on_user_id ON public.oauth_client_tokens USING btree (user_id);


--
-- Name: index_oauth_client_tokens_on_user_id_and_oauth_client_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_oauth_client_tokens_on_user_id_and_oauth_client_id ON public.oauth_client_tokens USING btree (user_id, oauth_client_id);


--
-- Name: index_oauth_clients_on_integration; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_oauth_clients_on_integration ON public.oauth_clients USING btree (integration_type, integration_id);


--
-- Name: index_oidc_user_session_links_on_oidc_session; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_oidc_user_session_links_on_oidc_session ON public.oidc_user_session_links USING btree (oidc_session);


--
-- Name: index_oidc_user_session_links_on_session_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_oidc_user_session_links_on_session_id ON public.oidc_user_session_links USING btree (session_id);


--
-- Name: index_ordered_work_packages_on_position; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_ordered_work_packages_on_position ON public.ordered_work_packages USING btree ("position");


--
-- Name: index_ordered_work_packages_on_query_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_ordered_work_packages_on_query_id ON public.ordered_work_packages USING btree (query_id);


--
-- Name: index_ordered_work_packages_on_work_package_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_ordered_work_packages_on_work_package_id ON public.ordered_work_packages USING btree (work_package_id);


--
-- Name: index_paper_trail_audits_on_item_type_and_item_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_paper_trail_audits_on_item_type_and_item_id ON public.paper_trail_audits USING btree (item_type, item_id);


--
-- Name: index_projects_on_identifier; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_projects_on_identifier ON public.projects USING btree (identifier);


--
-- Name: index_projects_on_lft; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_projects_on_lft ON public.projects USING btree (lft);


--
-- Name: index_projects_on_lft_and_rgt; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_projects_on_lft_and_rgt ON public.projects USING btree (lft, rgt);


--
-- Name: index_projects_on_rgt; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_projects_on_rgt ON public.projects USING btree (rgt);


--
-- Name: index_projects_storages_on_creator_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_projects_storages_on_creator_id ON public.projects_storages USING btree (creator_id);


--
-- Name: index_projects_storages_on_project_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_projects_storages_on_project_id ON public.projects_storages USING btree (project_id);


--
-- Name: index_projects_storages_on_project_id_and_storage_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_projects_storages_on_project_id_and_storage_id ON public.projects_storages USING btree (project_id, storage_id);


--
-- Name: index_projects_storages_on_storage_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_projects_storages_on_storage_id ON public.projects_storages USING btree (storage_id);


--
-- Name: index_queries_on_project_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_queries_on_project_id ON public.queries USING btree (project_id);


--
-- Name: index_queries_on_updated_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_queries_on_updated_at ON public.queries USING btree (updated_at);


--
-- Name: index_queries_on_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_queries_on_user_id ON public.queries USING btree (user_id);


--
-- Name: index_recaptcha_entries_on_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_recaptcha_entries_on_user_id ON public.recaptcha_entries USING btree (user_id);


--
-- Name: index_relations_on_from_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_relations_on_from_id ON public.relations USING btree (from_id);


--
-- Name: index_relations_on_from_id_and_to_id_and_relation_type; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_relations_on_from_id_and_to_id_and_relation_type ON public.relations USING btree (from_id, to_id, relation_type);


--
-- Name: index_relations_on_to_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_relations_on_to_id ON public.relations USING btree (to_id);


--
-- Name: index_relations_on_to_id_and_from_id_and_relation_type; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_relations_on_to_id_and_from_id_and_relation_type ON public.relations USING btree (to_id, from_id, relation_type);


--
-- Name: index_repositories_on_project_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_repositories_on_project_id ON public.repositories USING btree (project_id);


--
-- Name: index_role_permissions_on_role_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_role_permissions_on_role_id ON public.role_permissions USING btree (role_id);


--
-- Name: index_sessions_on_session_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_sessions_on_session_id ON public.sessions USING btree (session_id);


--
-- Name: index_sessions_on_updated_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_sessions_on_updated_at ON public.sessions USING btree (updated_at);


--
-- Name: index_settings_on_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_settings_on_name ON public.settings USING btree (name);


--
-- Name: index_statuses_on_color_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_statuses_on_color_id ON public.statuses USING btree (color_id);


--
-- Name: index_statuses_on_is_closed; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_statuses_on_is_closed ON public.statuses USING btree (is_closed);


--
-- Name: index_statuses_on_is_default; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_statuses_on_is_default ON public.statuses USING btree (is_default);


--
-- Name: index_statuses_on_position; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_statuses_on_position ON public.statuses USING btree ("position");


--
-- Name: index_storages_on_creator_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_storages_on_creator_id ON public.storages USING btree (creator_id);


--
-- Name: index_storages_on_host; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_storages_on_host ON public.storages USING btree (host);


--
-- Name: index_storages_on_name; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_storages_on_name ON public.storages USING btree (name);


--
-- Name: index_teap_on_project_id_and_activity_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_teap_on_project_id_and_activity_id ON public.time_entry_activities_projects USING btree (project_id, activity_id);


--
-- Name: index_time_entries_on_activity_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_time_entries_on_activity_id ON public.time_entries USING btree (activity_id);


--
-- Name: index_time_entries_on_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_time_entries_on_created_at ON public.time_entries USING btree (created_at);


--
-- Name: index_time_entries_on_logged_by_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_time_entries_on_logged_by_id ON public.time_entries USING btree (logged_by_id);


--
-- Name: index_time_entries_on_project_id_and_updated_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_time_entries_on_project_id_and_updated_at ON public.time_entries USING btree (project_id, updated_at);


--
-- Name: index_time_entries_on_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_time_entries_on_user_id ON public.time_entries USING btree (user_id);


--
-- Name: index_time_entry_activities_projects_on_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_time_entry_activities_projects_on_active ON public.time_entry_activities_projects USING btree (active);


--
-- Name: index_time_entry_activities_projects_on_activity_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_time_entry_activities_projects_on_activity_id ON public.time_entry_activities_projects USING btree (activity_id);


--
-- Name: index_time_entry_activities_projects_on_project_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_time_entry_activities_projects_on_project_id ON public.time_entry_activities_projects USING btree (project_id);


--
-- Name: index_time_entry_journals_on_logged_by_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_time_entry_journals_on_logged_by_id ON public.time_entry_journals USING btree (logged_by_id);


--
-- Name: index_time_entry_journals_on_project_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_time_entry_journals_on_project_id ON public.time_entry_journals USING btree (project_id);


--
-- Name: index_tokens_on_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_tokens_on_user_id ON public.tokens USING btree (user_id);


--
-- Name: index_two_factor_authentication_devices_on_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_two_factor_authentication_devices_on_user_id ON public.two_factor_authentication_devices USING btree (user_id);


--
-- Name: index_types_on_color_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_types_on_color_id ON public.types USING btree (color_id);


--
-- Name: index_user_passwords_on_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_user_passwords_on_user_id ON public.user_passwords USING btree (user_id);


--
-- Name: index_user_preferences_on_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_user_preferences_on_user_id ON public.user_preferences USING btree (user_id);


--
-- Name: index_user_prefs_settings_daily_reminders_enabled; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_user_prefs_settings_daily_reminders_enabled ON public.user_preferences USING gin ((((settings -> 'daily_reminders'::text) -> 'enabled'::text)));


--
-- Name: index_user_prefs_settings_daily_reminders_times; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_user_prefs_settings_daily_reminders_times ON public.user_preferences USING gin ((((settings -> 'daily_reminders'::text) -> 'times'::text)));


--
-- Name: index_user_prefs_settings_pause_reminders_enabled; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_user_prefs_settings_pause_reminders_enabled ON public.user_preferences USING btree (((((settings -> 'pause_reminders'::text) ->> 'enabled'::text))::boolean));


--
-- Name: index_user_prefs_settings_time_zone; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_user_prefs_settings_time_zone ON public.user_preferences USING gin (((settings -> 'time_zone'::text)));


--
-- Name: index_user_prefs_settings_workdays; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_user_prefs_settings_workdays ON public.user_preferences USING gin (((settings -> 'workdays'::text)));


--
-- Name: index_users_on_auth_source_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_users_on_auth_source_id ON public.users USING btree (auth_source_id);


--
-- Name: index_users_on_id_and_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_users_on_id_and_type ON public.users USING btree (id, type);


--
-- Name: index_users_on_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_users_on_type ON public.users USING btree (type);


--
-- Name: index_users_on_type_and_login; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_users_on_type_and_login ON public.users USING btree (type, login);


--
-- Name: index_users_on_type_and_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_users_on_type_and_status ON public.users USING btree (type, status);


--
-- Name: index_version_settings_on_project_id_and_version_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_version_settings_on_project_id_and_version_id ON public.version_settings USING btree (project_id, version_id);


--
-- Name: index_versions_on_sharing; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_versions_on_sharing ON public.versions USING btree (sharing);


--
-- Name: index_views_on_query_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_views_on_query_id ON public.views USING btree (query_id);


--
-- Name: index_watchers_on_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_watchers_on_user_id ON public.watchers USING btree (user_id);


--
-- Name: index_watchers_on_watchable_id_and_watchable_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_watchers_on_watchable_id_and_watchable_type ON public.watchers USING btree (watchable_id, watchable_type);


--
-- Name: index_webhooks_events_on_webhooks_webhook_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_webhooks_events_on_webhooks_webhook_id ON public.webhooks_events USING btree (webhooks_webhook_id);


--
-- Name: index_webhooks_logs_on_webhooks_webhook_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_webhooks_logs_on_webhooks_webhook_id ON public.webhooks_logs USING btree (webhooks_webhook_id);


--
-- Name: index_webhooks_projects_on_project_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_webhooks_projects_on_project_id ON public.webhooks_projects USING btree (project_id);


--
-- Name: index_webhooks_projects_on_webhooks_webhook_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_webhooks_projects_on_webhooks_webhook_id ON public.webhooks_projects USING btree (webhooks_webhook_id);


--
-- Name: index_wiki_pages_on_author_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_wiki_pages_on_author_id ON public.wiki_pages USING btree (author_id);


--
-- Name: index_wiki_pages_on_parent_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_wiki_pages_on_parent_id ON public.wiki_pages USING btree (parent_id);


--
-- Name: index_wiki_pages_on_updated_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_wiki_pages_on_updated_at ON public.wiki_pages USING btree (updated_at);


--
-- Name: index_wiki_pages_on_wiki_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_wiki_pages_on_wiki_id ON public.wiki_pages USING btree (wiki_id);


--
-- Name: index_wiki_redirects_on_wiki_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_wiki_redirects_on_wiki_id ON public.wiki_redirects USING btree (wiki_id);


--
-- Name: index_work_package_journals_on_project_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_work_package_journals_on_project_id ON public.work_package_journals USING btree (project_id);


--
-- Name: index_work_packages_on_assigned_to_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_work_packages_on_assigned_to_id ON public.work_packages USING btree (assigned_to_id);


--
-- Name: index_work_packages_on_author_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_work_packages_on_author_id ON public.work_packages USING btree (author_id);


--
-- Name: index_work_packages_on_category_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_work_packages_on_category_id ON public.work_packages USING btree (category_id);


--
-- Name: index_work_packages_on_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_work_packages_on_created_at ON public.work_packages USING btree (created_at);


--
-- Name: index_work_packages_on_due_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_work_packages_on_due_date ON public.work_packages USING btree (due_date);


--
-- Name: index_work_packages_on_parent_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_work_packages_on_parent_id ON public.work_packages USING btree (parent_id);


--
-- Name: index_work_packages_on_project_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_work_packages_on_project_id ON public.work_packages USING btree (project_id);


--
-- Name: index_work_packages_on_project_id_and_updated_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_work_packages_on_project_id_and_updated_at ON public.work_packages USING btree (project_id, updated_at);


--
-- Name: index_work_packages_on_responsible_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_work_packages_on_responsible_id ON public.work_packages USING btree (responsible_id);


--
-- Name: index_work_packages_on_schedule_manually; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_work_packages_on_schedule_manually ON public.work_packages USING btree (schedule_manually) WHERE schedule_manually;


--
-- Name: index_work_packages_on_start_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_work_packages_on_start_date ON public.work_packages USING btree (start_date);


--
-- Name: index_work_packages_on_status_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_work_packages_on_status_id ON public.work_packages USING btree (status_id);


--
-- Name: index_work_packages_on_type_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_work_packages_on_type_id ON public.work_packages USING btree (type_id);


--
-- Name: index_work_packages_on_updated_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_work_packages_on_updated_at ON public.work_packages USING btree (updated_at);


--
-- Name: index_work_packages_on_version_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_work_packages_on_version_id ON public.work_packages USING btree (version_id);


--
-- Name: index_workflows_on_new_status_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_workflows_on_new_status_id ON public.workflows USING btree (new_status_id);


--
-- Name: index_workflows_on_old_status_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_workflows_on_old_status_id ON public.workflows USING btree (old_status_id);


--
-- Name: index_workflows_on_role_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_workflows_on_role_id ON public.workflows USING btree (role_id);


--
-- Name: issue_categories_project_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX issue_categories_project_id ON public.categories USING btree (project_id);


--
-- Name: messages_board_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX messages_board_id ON public.messages USING btree (forum_id);


--
-- Name: messages_parent_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX messages_parent_id ON public.messages USING btree (parent_id);


--
-- Name: news_project_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX news_project_id ON public.news USING btree (project_id);


--
-- Name: projects_types_project_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX projects_types_project_id ON public.projects_types USING btree (project_id);


--
-- Name: projects_types_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX projects_types_unique ON public.projects_types USING btree (project_id, type_id);


--
-- Name: time_entries_issue_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX time_entries_issue_id ON public.time_entries USING btree (work_package_id);


--
-- Name: time_entries_project_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX time_entries_project_id ON public.time_entries USING btree (project_id);


--
-- Name: unique_index_gh_prs_wps_on_gh_pr_id_and_wp_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX unique_index_gh_prs_wps_on_gh_pr_id_and_wp_id ON public.github_pull_requests_work_packages USING btree (github_pull_request_id, work_package_id);


--
-- Name: unique_inherited_role; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX unique_inherited_role ON public.member_roles USING btree (member_id, role_id, inherited_from);


--
-- Name: unique_lastname_for_groups_and_placeholder_users; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX unique_lastname_for_groups_and_placeholder_users ON public.users USING btree (lastname, type) WHERE (((type)::text = 'Group'::text) OR ((type)::text = 'PlaceholderUser'::text));


--
-- Name: versions_project_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX versions_project_id ON public.versions USING btree (project_id);


--
-- Name: watchers_user_id_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX watchers_user_id_type ON public.watchers USING btree (user_id, watchable_type);


--
-- Name: wiki_pages_wiki_id_slug; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX wiki_pages_wiki_id_slug ON public.wiki_pages USING btree (wiki_id, slug);


--
-- Name: wiki_pages_wiki_id_title; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX wiki_pages_wiki_id_title ON public.wiki_pages USING btree (wiki_id, title);


--
-- Name: wiki_redirects_wiki_id_title; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX wiki_redirects_wiki_id_title ON public.wiki_redirects USING btree (wiki_id, title);


--
-- Name: wikis_project_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX wikis_project_id ON public.wikis USING btree (project_id);


--
-- Name: wkfs_role_type_old_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX wkfs_role_type_old_status ON public.workflows USING btree (role_id, type_id, old_status_id);


--
-- Name: work_package_anc_desc_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX work_package_anc_desc_idx ON public.work_package_hierarchies USING btree (ancestor_id, descendant_id, generations);


--
-- Name: work_package_desc_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX work_package_desc_idx ON public.work_package_hierarchies USING btree (descendant_id);


--
-- Name: work_package_journal_on_burndown_attributes; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX work_package_journal_on_burndown_attributes ON public.work_package_journals USING btree (version_id, status_id, project_id, type_id);


--
-- Name: projects_storages fk_rails_04546d7b88; Type: FK CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.projects_storages
    ADD CONSTRAINT fk_rails_04546d7b88 FOREIGN KEY (storage_id) REFERENCES backup_preview_5.storages(id) ON DELETE CASCADE;


--
-- Name: bcf_comments fk_rails_0571c4b386; Type: FK CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.bcf_comments
    ADD CONSTRAINT fk_rails_0571c4b386 FOREIGN KEY (reply_to) REFERENCES backup_preview_5.bcf_comments(id) ON DELETE SET NULL;


--
-- Name: notifications fk_rails_06a39bb8cc; Type: FK CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.notifications
    ADD CONSTRAINT fk_rails_06a39bb8cc FOREIGN KEY (actor_id) REFERENCES backup_preview_5.users(id);


--
-- Name: two_factor_authentication_devices fk_rails_0b09e132e7; Type: FK CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.two_factor_authentication_devices
    ADD CONSTRAINT fk_rails_0b09e132e7 FOREIGN KEY (user_id) REFERENCES backup_preview_5.users(id);


--
-- Name: workflows fk_rails_0c5f149c21; Type: FK CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.workflows
    ADD CONSTRAINT fk_rails_0c5f149c21 FOREIGN KEY (role_id) REFERENCES backup_preview_5.roles(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: notification_settings fk_rails_0c95e91db7; Type: FK CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.notification_settings
    ADD CONSTRAINT fk_rails_0c95e91db7 FOREIGN KEY (user_id) REFERENCES backup_preview_5.users(id);


--
-- Name: cost_entries fk_rails_0d35f09506; Type: FK CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.cost_entries
    ADD CONSTRAINT fk_rails_0d35f09506 FOREIGN KEY (logged_by_id) REFERENCES backup_preview_5.users(id);


--
-- Name: custom_fields_projects fk_rails_12fb30588e; Type: FK CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.custom_fields_projects
    ADD CONSTRAINT fk_rails_12fb30588e FOREIGN KEY (project_id) REFERENCES backup_preview_5.projects(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: backups fk_rails_173504d244; Type: FK CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.backups
    ADD CONSTRAINT fk_rails_173504d244 FOREIGN KEY (creator_id) REFERENCES backup_preview_5.users(id);


--
-- Name: workflows fk_rails_2a8f410364; Type: FK CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.workflows
    ADD CONSTRAINT fk_rails_2a8f410364 FOREIGN KEY (type_id) REFERENCES backup_preview_5.types(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: oauth_applications fk_rails_3d1f3b58d2; Type: FK CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.oauth_applications
    ADD CONSTRAINT fk_rails_3d1f3b58d2 FOREIGN KEY (client_credentials_user_id) REFERENCES backup_preview_5.users(id) ON DELETE SET NULL;


--
-- Name: wiki_pages fk_rails_4189064f3f; Type: FK CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.wiki_pages
    ADD CONSTRAINT fk_rails_4189064f3f FOREIGN KEY (author_id) REFERENCES backup_preview_5.users(id);


--
-- Name: ldap_groups_synchronized_groups fk_rails_44dac1537e; Type: FK CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.ldap_groups_synchronized_groups
    ADD CONSTRAINT fk_rails_44dac1537e FOREIGN KEY (filter_id) REFERENCES backup_preview_5.ldap_groups_synchronized_filters(id);


--
-- Name: types fk_rails_46ceaf0e5b; Type: FK CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.types
    ADD CONSTRAINT fk_rails_46ceaf0e5b FOREIGN KEY (color_id) REFERENCES backup_preview_5.colors(id) ON DELETE SET NULL;


--
-- Name: notification_settings fk_rails_496a500fda; Type: FK CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.notification_settings
    ADD CONSTRAINT fk_rails_496a500fda FOREIGN KEY (project_id) REFERENCES backup_preview_5.projects(id);


--
-- Name: notifications fk_rails_4aea6afa11; Type: FK CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.notifications
    ADD CONSTRAINT fk_rails_4aea6afa11 FOREIGN KEY (recipient_id) REFERENCES backup_preview_5.users(id);


--
-- Name: bcf_issues fk_rails_4e35bc3056; Type: FK CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.bcf_issues
    ADD CONSTRAINT fk_rails_4e35bc3056 FOREIGN KEY (work_package_id) REFERENCES backup_preview_5.work_packages(id) ON DELETE CASCADE;


--
-- Name: ifc_models fk_rails_4f53d4601c; Type: FK CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.ifc_models
    ADD CONSTRAINT fk_rails_4f53d4601c FOREIGN KEY (project_id) REFERENCES backup_preview_5.projects(id) ON DELETE CASCADE;


--
-- Name: webhooks_logs fk_rails_551257cdac; Type: FK CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.webhooks_logs
    ADD CONSTRAINT fk_rails_551257cdac FOREIGN KEY (webhooks_webhook_id) REFERENCES backup_preview_5.webhooks_webhooks(id) ON DELETE CASCADE;


--
-- Name: bcf_comments fk_rails_556ef6e73e; Type: FK CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.bcf_comments
    ADD CONSTRAINT fk_rails_556ef6e73e FOREIGN KEY (viewpoint_id) REFERENCES backup_preview_5.bcf_viewpoints(id) ON DELETE SET NULL;


--
-- Name: notifications fk_rails_595318131c; Type: FK CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.notifications
    ADD CONSTRAINT fk_rails_595318131c FOREIGN KEY (journal_id) REFERENCES backup_preview_5.journals(id) ON DELETE CASCADE;


--
-- Name: time_entry_activities_projects fk_rails_5b669d4f34; Type: FK CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.time_entry_activities_projects
    ADD CONSTRAINT fk_rails_5b669d4f34 FOREIGN KEY (project_id) REFERENCES backup_preview_5.projects(id);


--
-- Name: oidc_user_session_links fk_rails_5e6a849f92; Type: FK CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.oidc_user_session_links
    ADD CONSTRAINT fk_rails_5e6a849f92 FOREIGN KEY (session_id) REFERENCES backup_preview_5.sessions(id) ON DELETE CASCADE;


--
-- Name: work_packages fk_rails_5edb6f06e6; Type: FK CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.work_packages
    ADD CONSTRAINT fk_rails_5edb6f06e6 FOREIGN KEY (status_id) REFERENCES backup_preview_5.statuses(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: file_links fk_rails_650ebb2e1a; Type: FK CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.file_links
    ADD CONSTRAINT fk_rails_650ebb2e1a FOREIGN KEY (creator_id) REFERENCES backup_preview_5.users(id);


--
-- Name: oauth_client_tokens fk_rails_65a92bfbf4; Type: FK CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.oauth_client_tokens
    ADD CONSTRAINT fk_rails_65a92bfbf4 FOREIGN KEY (user_id) REFERENCES backup_preview_5.users(id) ON DELETE CASCADE;


--
-- Name: workflows fk_rails_66af376b7e; Type: FK CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.workflows
    ADD CONSTRAINT fk_rails_66af376b7e FOREIGN KEY (new_status_id) REFERENCES backup_preview_5.statuses(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: storages fk_rails_6c69bacb8d; Type: FK CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.storages
    ADD CONSTRAINT fk_rails_6c69bacb8d FOREIGN KEY (creator_id) REFERENCES backup_preview_5.users(id);


--
-- Name: oauth_client_tokens fk_rails_6e922d4135; Type: FK CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.oauth_client_tokens
    ADD CONSTRAINT fk_rails_6e922d4135 FOREIGN KEY (oauth_client_id) REFERENCES backup_preview_5.oauth_clients(id) ON DELETE CASCADE;


--
-- Name: time_entries fk_rails_709864c72f; Type: FK CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.time_entries
    ADD CONSTRAINT fk_rails_709864c72f FOREIGN KEY (logged_by_id) REFERENCES backup_preview_5.users(id);


--
-- Name: oauth_access_tokens fk_rails_732cb83ab7; Type: FK CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.oauth_access_tokens
    ADD CONSTRAINT fk_rails_732cb83ab7 FOREIGN KEY (application_id) REFERENCES backup_preview_5.oauth_applications(id);


--
-- Name: last_project_folders fk_rails_73e1c678f1; Type: FK CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.last_project_folders
    ADD CONSTRAINT fk_rails_73e1c678f1 FOREIGN KEY (projects_storage_id) REFERENCES backup_preview_5.projects_storages(id) ON DELETE CASCADE;


--
-- Name: bcf_comments fk_rails_7ac870008c; Type: FK CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.bcf_comments
    ADD CONSTRAINT fk_rails_7ac870008c FOREIGN KEY (issue_id) REFERENCES backup_preview_5.bcf_issues(id) ON DELETE CASCADE;


--
-- Name: projects_types fk_rails_7c3935a107; Type: FK CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.projects_types
    ADD CONSTRAINT fk_rails_7c3935a107 FOREIGN KEY (project_id) REFERENCES backup_preview_5.projects(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: recaptcha_entries fk_rails_890a90efa9; Type: FK CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.recaptcha_entries
    ADD CONSTRAINT fk_rails_890a90efa9 FOREIGN KEY (user_id) REFERENCES backup_preview_5.users(id) ON DELETE CASCADE;


--
-- Name: work_packages fk_rails_931ad309e8; Type: FK CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.work_packages
    ADD CONSTRAINT fk_rails_931ad309e8 FOREIGN KEY (project_id) REFERENCES backup_preview_5.projects(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: projects_storages fk_rails_96ab713fe3; Type: FK CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.projects_storages
    ADD CONSTRAINT fk_rails_96ab713fe3 FOREIGN KEY (project_id) REFERENCES backup_preview_5.projects(id) ON DELETE CASCADE;


--
-- Name: webhooks_events fk_rails_a166925c91; Type: FK CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.webhooks_events
    ADD CONSTRAINT fk_rails_a166925c91 FOREIGN KEY (webhooks_webhook_id) REFERENCES backup_preview_5.webhooks_webhooks(id);


--
-- Name: file_links fk_rails_a29c1fb981; Type: FK CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.file_links
    ADD CONSTRAINT fk_rails_a29c1fb981 FOREIGN KEY (storage_id) REFERENCES backup_preview_5.storages(id) ON DELETE CASCADE;


--
-- Name: tokens fk_rails_ac8a5d0441; Type: FK CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.tokens
    ADD CONSTRAINT fk_rails_ac8a5d0441 FOREIGN KEY (user_id) REFERENCES backup_preview_5.users(id);


--
-- Name: projects_storages fk_rails_acca00a591; Type: FK CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.projects_storages
    ADD CONSTRAINT fk_rails_acca00a591 FOREIGN KEY (creator_id) REFERENCES backup_preview_5.users(id);


--
-- Name: workflows fk_rails_b4628cffdf; Type: FK CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.workflows
    ADD CONSTRAINT fk_rails_b4628cffdf FOREIGN KEY (old_status_id) REFERENCES backup_preview_5.statuses(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: oauth_access_grants fk_rails_b4b53e07b8; Type: FK CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.oauth_access_grants
    ADD CONSTRAINT fk_rails_b4b53e07b8 FOREIGN KEY (application_id) REFERENCES backup_preview_5.oauth_applications(id);


--
-- Name: time_entry_activities_projects fk_rails_bc6c409022; Type: FK CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.time_entry_activities_projects
    ADD CONSTRAINT fk_rails_bc6c409022 FOREIGN KEY (activity_id) REFERENCES backup_preview_5.enumerations(id);


--
-- Name: oauth_applications fk_rails_cc886e315a; Type: FK CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.oauth_applications
    ADD CONSTRAINT fk_rails_cc886e315a FOREIGN KEY (owner_id) REFERENCES backup_preview_5.users(id) ON DELETE SET NULL;


--
-- Name: webhooks_projects fk_rails_d7ea5de5b8; Type: FK CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.webhooks_projects
    ADD CONSTRAINT fk_rails_d7ea5de5b8 FOREIGN KEY (webhooks_webhook_id) REFERENCES backup_preview_5.webhooks_webhooks(id);


--
-- Name: projects_types fk_rails_da213a0c8b; Type: FK CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.projects_types
    ADD CONSTRAINT fk_rails_da213a0c8b FOREIGN KEY (type_id) REFERENCES backup_preview_5.types(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ical_token_query_assignments fk_rails_e0ecbb71e6; Type: FK CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.ical_token_query_assignments
    ADD CONSTRAINT fk_rails_e0ecbb71e6 FOREIGN KEY (ical_token_id) REFERENCES backup_preview_5.tokens(id) ON DELETE CASCADE;


--
-- Name: custom_fields_projects fk_rails_e51cefe60d; Type: FK CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.custom_fields_projects
    ADD CONSTRAINT fk_rails_e51cefe60d FOREIGN KEY (custom_field_id) REFERENCES backup_preview_5.custom_fields(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: webhooks_projects fk_rails_e978b5e3d7; Type: FK CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.webhooks_projects
    ADD CONSTRAINT fk_rails_e978b5e3d7 FOREIGN KEY (project_id) REFERENCES backup_preview_5.projects(id);


--
-- Name: ordered_work_packages fk_rails_e99c4d5dfe; Type: FK CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.ordered_work_packages
    ADD CONSTRAINT fk_rails_e99c4d5dfe FOREIGN KEY (query_id) REFERENCES backup_preview_5.queries(id) ON DELETE CASCADE;


--
-- Name: views fk_rails_ef3c430897; Type: FK CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.views
    ADD CONSTRAINT fk_rails_ef3c430897 FOREIGN KEY (query_id) REFERENCES backup_preview_5.queries(id);


--
-- Name: work_packages fk_rails_f2a8977aa1; Type: FK CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.work_packages
    ADD CONSTRAINT fk_rails_f2a8977aa1 FOREIGN KEY (type_id) REFERENCES backup_preview_5.types(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ical_token_query_assignments fk_rails_f5e934437b; Type: FK CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.ical_token_query_assignments
    ADD CONSTRAINT fk_rails_f5e934437b FOREIGN KEY (query_id) REFERENCES backup_preview_5.queries(id) ON DELETE CASCADE;


--
-- Name: time_entry_journals fk_rails_f6e3d60ab5; Type: FK CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.time_entry_journals
    ADD CONSTRAINT fk_rails_f6e3d60ab5 FOREIGN KEY (logged_by_id) REFERENCES backup_preview_5.users(id);


--
-- Name: bcf_viewpoints fk_rails_fa5c88e5be; Type: FK CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.bcf_viewpoints
    ADD CONSTRAINT fk_rails_fa5c88e5be FOREIGN KEY (issue_id) REFERENCES backup_preview_5.bcf_issues(id) ON DELETE CASCADE;


--
-- Name: ordered_work_packages fk_rails_fe038e4e03; Type: FK CONSTRAINT; Schema: backup_preview_5; Owner: -
--

ALTER TABLE ONLY backup_preview_5.ordered_work_packages
    ADD CONSTRAINT fk_rails_fe038e4e03 FOREIGN KEY (work_package_id) REFERENCES backup_preview_5.work_packages(id) ON DELETE CASCADE;


--
-- Name: projects_storages fk_rails_04546d7b88; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.projects_storages
    ADD CONSTRAINT fk_rails_04546d7b88 FOREIGN KEY (storage_id) REFERENCES public.storages(id) ON DELETE CASCADE;


--
-- Name: bcf_comments fk_rails_0571c4b386; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bcf_comments
    ADD CONSTRAINT fk_rails_0571c4b386 FOREIGN KEY (reply_to) REFERENCES public.bcf_comments(id) ON DELETE SET NULL;


--
-- Name: notifications fk_rails_06a39bb8cc; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT fk_rails_06a39bb8cc FOREIGN KEY (actor_id) REFERENCES public.users(id);


--
-- Name: two_factor_authentication_devices fk_rails_0b09e132e7; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.two_factor_authentication_devices
    ADD CONSTRAINT fk_rails_0b09e132e7 FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: workflows fk_rails_0c5f149c21; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workflows
    ADD CONSTRAINT fk_rails_0c5f149c21 FOREIGN KEY (role_id) REFERENCES public.roles(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: notification_settings fk_rails_0c95e91db7; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_settings
    ADD CONSTRAINT fk_rails_0c95e91db7 FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: cost_entries fk_rails_0d35f09506; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cost_entries
    ADD CONSTRAINT fk_rails_0d35f09506 FOREIGN KEY (logged_by_id) REFERENCES public.users(id);


--
-- Name: custom_fields_projects fk_rails_12fb30588e; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.custom_fields_projects
    ADD CONSTRAINT fk_rails_12fb30588e FOREIGN KEY (project_id) REFERENCES public.projects(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: backups fk_rails_173504d244; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.backups
    ADD CONSTRAINT fk_rails_173504d244 FOREIGN KEY (creator_id) REFERENCES public.users(id);


--
-- Name: workflows fk_rails_2a8f410364; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workflows
    ADD CONSTRAINT fk_rails_2a8f410364 FOREIGN KEY (type_id) REFERENCES public.types(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: oauth_applications fk_rails_3d1f3b58d2; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth_applications
    ADD CONSTRAINT fk_rails_3d1f3b58d2 FOREIGN KEY (client_credentials_user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: wiki_pages fk_rails_4189064f3f; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wiki_pages
    ADD CONSTRAINT fk_rails_4189064f3f FOREIGN KEY (author_id) REFERENCES public.users(id);


--
-- Name: ldap_groups_synchronized_groups fk_rails_44dac1537e; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ldap_groups_synchronized_groups
    ADD CONSTRAINT fk_rails_44dac1537e FOREIGN KEY (filter_id) REFERENCES public.ldap_groups_synchronized_filters(id);


--
-- Name: types fk_rails_46ceaf0e5b; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.types
    ADD CONSTRAINT fk_rails_46ceaf0e5b FOREIGN KEY (color_id) REFERENCES public.colors(id) ON DELETE SET NULL;


--
-- Name: notification_settings fk_rails_496a500fda; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_settings
    ADD CONSTRAINT fk_rails_496a500fda FOREIGN KEY (project_id) REFERENCES public.projects(id);


--
-- Name: notifications fk_rails_4aea6afa11; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT fk_rails_4aea6afa11 FOREIGN KEY (recipient_id) REFERENCES public.users(id);


--
-- Name: bcf_issues fk_rails_4e35bc3056; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bcf_issues
    ADD CONSTRAINT fk_rails_4e35bc3056 FOREIGN KEY (work_package_id) REFERENCES public.work_packages(id) ON DELETE CASCADE;


--
-- Name: ifc_models fk_rails_4f53d4601c; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ifc_models
    ADD CONSTRAINT fk_rails_4f53d4601c FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE CASCADE;


--
-- Name: webhooks_logs fk_rails_551257cdac; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.webhooks_logs
    ADD CONSTRAINT fk_rails_551257cdac FOREIGN KEY (webhooks_webhook_id) REFERENCES public.webhooks_webhooks(id) ON DELETE CASCADE;


--
-- Name: bcf_comments fk_rails_556ef6e73e; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bcf_comments
    ADD CONSTRAINT fk_rails_556ef6e73e FOREIGN KEY (viewpoint_id) REFERENCES public.bcf_viewpoints(id) ON DELETE SET NULL;


--
-- Name: notifications fk_rails_595318131c; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT fk_rails_595318131c FOREIGN KEY (journal_id) REFERENCES public.journals(id) ON DELETE CASCADE;


--
-- Name: time_entry_activities_projects fk_rails_5b669d4f34; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.time_entry_activities_projects
    ADD CONSTRAINT fk_rails_5b669d4f34 FOREIGN KEY (project_id) REFERENCES public.projects(id);


--
-- Name: oidc_user_session_links fk_rails_5e6a849f92; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oidc_user_session_links
    ADD CONSTRAINT fk_rails_5e6a849f92 FOREIGN KEY (session_id) REFERENCES public.sessions(id) ON DELETE CASCADE;


--
-- Name: work_packages fk_rails_5edb6f06e6; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_packages
    ADD CONSTRAINT fk_rails_5edb6f06e6 FOREIGN KEY (status_id) REFERENCES public.statuses(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: file_links fk_rails_650ebb2e1a; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.file_links
    ADD CONSTRAINT fk_rails_650ebb2e1a FOREIGN KEY (creator_id) REFERENCES public.users(id);


--
-- Name: oauth_client_tokens fk_rails_65a92bfbf4; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth_client_tokens
    ADD CONSTRAINT fk_rails_65a92bfbf4 FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: workflows fk_rails_66af376b7e; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workflows
    ADD CONSTRAINT fk_rails_66af376b7e FOREIGN KEY (new_status_id) REFERENCES public.statuses(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: storages fk_rails_6c69bacb8d; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.storages
    ADD CONSTRAINT fk_rails_6c69bacb8d FOREIGN KEY (creator_id) REFERENCES public.users(id);


--
-- Name: oauth_client_tokens fk_rails_6e922d4135; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth_client_tokens
    ADD CONSTRAINT fk_rails_6e922d4135 FOREIGN KEY (oauth_client_id) REFERENCES public.oauth_clients(id) ON DELETE CASCADE;


--
-- Name: time_entries fk_rails_709864c72f; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.time_entries
    ADD CONSTRAINT fk_rails_709864c72f FOREIGN KEY (logged_by_id) REFERENCES public.users(id);


--
-- Name: oauth_access_tokens fk_rails_732cb83ab7; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth_access_tokens
    ADD CONSTRAINT fk_rails_732cb83ab7 FOREIGN KEY (application_id) REFERENCES public.oauth_applications(id);


--
-- Name: last_project_folders fk_rails_73e1c678f1; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.last_project_folders
    ADD CONSTRAINT fk_rails_73e1c678f1 FOREIGN KEY (projects_storage_id) REFERENCES public.projects_storages(id) ON DELETE CASCADE;


--
-- Name: bcf_comments fk_rails_7ac870008c; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bcf_comments
    ADD CONSTRAINT fk_rails_7ac870008c FOREIGN KEY (issue_id) REFERENCES public.bcf_issues(id) ON DELETE CASCADE;


--
-- Name: projects_types fk_rails_7c3935a107; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.projects_types
    ADD CONSTRAINT fk_rails_7c3935a107 FOREIGN KEY (project_id) REFERENCES public.projects(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: recaptcha_entries fk_rails_890a90efa9; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recaptcha_entries
    ADD CONSTRAINT fk_rails_890a90efa9 FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: work_packages fk_rails_931ad309e8; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_packages
    ADD CONSTRAINT fk_rails_931ad309e8 FOREIGN KEY (project_id) REFERENCES public.projects(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: projects_storages fk_rails_96ab713fe3; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.projects_storages
    ADD CONSTRAINT fk_rails_96ab713fe3 FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE CASCADE;


--
-- Name: webhooks_events fk_rails_a166925c91; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.webhooks_events
    ADD CONSTRAINT fk_rails_a166925c91 FOREIGN KEY (webhooks_webhook_id) REFERENCES public.webhooks_webhooks(id);


--
-- Name: file_links fk_rails_a29c1fb981; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.file_links
    ADD CONSTRAINT fk_rails_a29c1fb981 FOREIGN KEY (storage_id) REFERENCES public.storages(id) ON DELETE CASCADE;


--
-- Name: tokens fk_rails_ac8a5d0441; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tokens
    ADD CONSTRAINT fk_rails_ac8a5d0441 FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: projects_storages fk_rails_acca00a591; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.projects_storages
    ADD CONSTRAINT fk_rails_acca00a591 FOREIGN KEY (creator_id) REFERENCES public.users(id);


--
-- Name: workflows fk_rails_b4628cffdf; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workflows
    ADD CONSTRAINT fk_rails_b4628cffdf FOREIGN KEY (old_status_id) REFERENCES public.statuses(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: oauth_access_grants fk_rails_b4b53e07b8; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth_access_grants
    ADD CONSTRAINT fk_rails_b4b53e07b8 FOREIGN KEY (application_id) REFERENCES public.oauth_applications(id);


--
-- Name: time_entry_activities_projects fk_rails_bc6c409022; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.time_entry_activities_projects
    ADD CONSTRAINT fk_rails_bc6c409022 FOREIGN KEY (activity_id) REFERENCES public.enumerations(id);


--
-- Name: oauth_applications fk_rails_cc886e315a; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth_applications
    ADD CONSTRAINT fk_rails_cc886e315a FOREIGN KEY (owner_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: webhooks_projects fk_rails_d7ea5de5b8; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.webhooks_projects
    ADD CONSTRAINT fk_rails_d7ea5de5b8 FOREIGN KEY (webhooks_webhook_id) REFERENCES public.webhooks_webhooks(id);


--
-- Name: projects_types fk_rails_da213a0c8b; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.projects_types
    ADD CONSTRAINT fk_rails_da213a0c8b FOREIGN KEY (type_id) REFERENCES public.types(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ical_token_query_assignments fk_rails_e0ecbb71e6; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ical_token_query_assignments
    ADD CONSTRAINT fk_rails_e0ecbb71e6 FOREIGN KEY (ical_token_id) REFERENCES public.tokens(id) ON DELETE CASCADE;


--
-- Name: custom_fields_projects fk_rails_e51cefe60d; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.custom_fields_projects
    ADD CONSTRAINT fk_rails_e51cefe60d FOREIGN KEY (custom_field_id) REFERENCES public.custom_fields(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: webhooks_projects fk_rails_e978b5e3d7; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.webhooks_projects
    ADD CONSTRAINT fk_rails_e978b5e3d7 FOREIGN KEY (project_id) REFERENCES public.projects(id);


--
-- Name: ordered_work_packages fk_rails_e99c4d5dfe; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ordered_work_packages
    ADD CONSTRAINT fk_rails_e99c4d5dfe FOREIGN KEY (query_id) REFERENCES public.queries(id) ON DELETE CASCADE;


--
-- Name: views fk_rails_ef3c430897; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.views
    ADD CONSTRAINT fk_rails_ef3c430897 FOREIGN KEY (query_id) REFERENCES public.queries(id);


--
-- Name: work_packages fk_rails_f2a8977aa1; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_packages
    ADD CONSTRAINT fk_rails_f2a8977aa1 FOREIGN KEY (type_id) REFERENCES public.types(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ical_token_query_assignments fk_rails_f5e934437b; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ical_token_query_assignments
    ADD CONSTRAINT fk_rails_f5e934437b FOREIGN KEY (query_id) REFERENCES public.queries(id) ON DELETE CASCADE;


--
-- Name: time_entry_journals fk_rails_f6e3d60ab5; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.time_entry_journals
    ADD CONSTRAINT fk_rails_f6e3d60ab5 FOREIGN KEY (logged_by_id) REFERENCES public.users(id);


--
-- Name: bcf_viewpoints fk_rails_fa5c88e5be; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bcf_viewpoints
    ADD CONSTRAINT fk_rails_fa5c88e5be FOREIGN KEY (issue_id) REFERENCES public.bcf_issues(id) ON DELETE CASCADE;


--
-- Name: ordered_work_packages fk_rails_fe038e4e03; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ordered_work_packages
    ADD CONSTRAINT fk_rails_fe038e4e03 FOREIGN KEY (work_package_id) REFERENCES public.work_packages(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

